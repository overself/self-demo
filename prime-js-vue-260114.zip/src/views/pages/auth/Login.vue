<template>
  <!-- <FloatingConfigurator /> -->
  <div class="items-center flex justify-center min-h-screen min-w-[100vw] overflow-hidden">
    <div class="login-background"></div>
    <Dialog v-model:visible="dialogVisible" :header="t('biz.login.changePassword')" :modal="true" :closable
            :breakpoints="{ '960px': '50vw' }" :style="{ width: '50vw' }">
      <div class="items-center w-full flex flex-col justify-center">
        <Form autocomplete="off" v-slot="$form" :initialValues :resolver @submit="onFormSubmit" class="flex flex-col gap-4 w-full sm:w-56">
          <!-- 旧パスワード入力 (新增旧密码输入框) -->
          <div class="flex flex-col gap-1">
            <Password name="oldPassword" autocomplete="off" :placeholder="t('biz.login.oldPassword')" :feedback toggleMask fluid />
            <Message v-if="$form.oldPassword?.invalid" severity="error" size="small" variant="simple">{{ $form.oldPassword.error?.message }}</Message>
          </div>
          <!-- パスワード入力 -->
          <div class="flex flex-col gap-1">
            <Password name="newPassword" :placeholder="t('biz.login.newPassword')" :feedback toggleMask fluid />
            <Message v-if="$form.newPassword?.invalid" severity="error" size="small" variant="simple">{{ $form.newPassword.error?.message }}</Message>
          </div>

          <!-- パスワード確認入力 -->
          <div class="flex flex-col gap-1">
            <Password name="confirmPassword" :placeholder="t('biz.login.confirmPassword')" :feedback toggleMask fluid />
            <Message v-if="$form.confirmPassword?.invalid" severity="error" size="small" variant="simple">{{ $form.confirmPassword.error?.message }}</Message>
          </div>
          <Button type="submit" severity="secondary" :label="t('biz.login.submit')" />
        </Form>
        <span class="info-icon mt-1" @click="toggle" ref="dd">
          <i class="pi pi-info" style="position: absolute; bottom: 1px; right: 1px"></i>
        </span>
      </div>
      <template #footer>
        <Button label="Save" @click="dialogVisible = false" />
      </template>
    </Dialog>
    <Popover ref="op">
      <template v-for="i in 9" :key="i">
        <p style="white-space: pre-line">{{ t('biz.login.msg' + i) }}</p>
      </template>
    </Popover>
    <div class="login-card relative items-center justify-center left-96 bottom-nav">
      <div class="flex flex-col items-center justify-center right-80">
        <div style="border-radius: 20px; padding: 0.3rem; background: linear-gradient(180deg, var(--primary-color) 10%, rgba(33, 150, 243, 0) 50%)">
          <div class="w-full bg-surface-0 dark:bg-surface-900 py-20 px-8 sm:px-20" style="border-radius: 15px">
            <div class="text-center mb-8">
              <div class="text-surface-900 dark:text-surface-0 text-3xl font-medium mb-4">F-ECOシステム</div>
              <span class="text-muted-color font-medium">ログインしてください</span>
            </div>
            <div>
              <label for="usid" class="block text-surface-900 dark:text-surface-0 text-xl font-medium mb-2">ユーザーID</label>
              <InputText id="usid" type="text" v-model="userId" @keyup.enter="handleLoginSubmit" fluid @change="handleUserIdChange" />
              <Message v-if="valid.userId.check" severity="error" size="small" variant="simple">{{ valid.userId.message }}</Message>

              <label for="password1" class="block text-surface-900 dark:text-surface-0 font-medium text-xl mt-3">パスワード</label>
              <Password id="password1" ref="password1" v-model="password" @keyup.enter="handleLoginSubmit" :toggleMask="true" fluid :feedback="false" />
              <Message v-if="valid.password.check" severity="error" size="small" variant="simple">{{ valid.password.message }}</Message>

              <Button label="ログイン" class="w-full mt-6" @click="handleLoginSubmit" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { useFieldProcessor } from '@/hooks/useFieldProcessor'
import { ref, watch, reactive, onActivated } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStoreWithOut } from '@/store/modules/user'
import { usePermissionStoreWithOut } from '@/store/modules/permission'
import { login } from '@/api/common'
import { LoginResponse } from '@/types/response/login'
import { cacheSave } from '@/utils/handleStorage'
import { useI18n } from 'vue-i18n'
import { psChgApi } from '@/api/business/Item/ItemApi'
const { t } = useI18n()
const userStore = useUserStoreWithOut()
const permissionStore = usePermissionStoreWithOut()
const router = useRouter()
const route = useRoute()
// 提示信息
const message = 'を入力してください。'
const password1 = ref()
// 校验信息
const valid = ref({
  userId: { check: false, message: '' },
  password: { check: false, message: '' }
})
onActivated(() => {
  // if (route.query.reload === 'true') {
  //   router.push({ query: { reload: undefined } })
  // }
})
// 输入框信息
const userId = ref(userStore.userId)
const password = ref('')

// 检验结果=>正常:true  异常:false
const inputCheck = () => {
  let res = true
  if (!userId.value) {
    valid.value.userId.check = true
    valid.value.userId.message = `ユーザーID${message}`
    res = false
  }
  if (!password.value) {
    valid.value.password.check = true
    valid.value.password.message = `パスワード${message}`
    res = false
  }
  return res
}
const { handleChange: handleUserIdChange } = useFieldProcessor(userId)
// 监视器：用户ID
watch(userId, () => {
  valid.value.userId.check = !userId.value || userId.value === ''
  valid.value.userId.message = `ユーザーID${message}`
})
// 监视器：密码
watch(password, () => {
  valid.value.password.check = !password.value || password.value === ''
  valid.value.password.message = `パスワード${message}`
})
// 登录成功后广播通知其他标签页
// 登录按钮
const handleLoginSubmit = async () => {
  // 入力校验
  if (inputCheck()) {
    try {
      // 通过接口初始化用户信息
      // const ret: LoginResponse = await login({ usId: userId.value, password: password.value })
      // const ret: string = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c0lkIjoiUllGIiwicGVybWlzc2lvbnMiOiIwMSIsImV4cCI6MTc0NjQyMzg2MX0.ueogoDQZDIM0NPCCKYL7VCSXbKouZTm4ehmHFSNLtZA'
      login({ usId: userId.value, password: password.value }).then((ret: LoginResponse) => {
        if (ret) {
          ret?.auth?.push({
            name: 'ChangePassword',
            authEles: ['ALL']
          })
          userStore.setTokenKey('authorization')
          userStore.setToken(ret.token)
          userStore.setUserId(String(userId.value))
          userStore.setRoleRouters(ret.auth)
          permissionStore.reset()
          // 广播登录状态
          // broadcastAuthStatus(true)
          const authData = {
            token: ret.token,
            userId: String(userId.value),
            roleRouters: ret.auth,
            timestamp: Date.now()
          }
          cacheSave('auth_data', JSON.stringify(authData))
        }
        // cachedUserInfo.value = JSON.parse(sessionRead('user'))
        if (!ret.isValid) {
          dialogVisible.value = true
          closable.value = false
        } else {
          // router.push({ name: 'Dashboard' })
          // 获取 redirect 参数
          // const redirect = route.query.redirect as string | undefined
          // 解析 redirect 参数（支持多层嵌套）
          const redirect = (() => {
            const rawRedirect = route.query.redirect as string | undefined
            if (!rawRedirect) return undefined

            // 拆分所有 redirect 参数，取最后一个
            const redirectParts = rawRedirect.split('?redirect=')
            const finalRedirect = redirectParts[redirectParts.length - 1]
            return finalRedirect
          })()
          // 登录后跳转目标
          // const targetRoute = redirect ? decodeURIComponent(redirect) : { name: 'Dashboard' }
          // router.push(targetRoute)
          if (redirect) {
            // 创建 URL 对象
            const url = new URL(redirect, window.location.origin)
            // console.log(url)
            // 提取 path 和 query 对象
            const path = url.pathname
            const query: Record<string, string> = {}
            url.searchParams.forEach((value, key) => {
              query[key] = value
            })
            // console.log(path, query)
            // 跳转
            // router.push({
            //   path: path,
            //   query: query
            // })
            const queryString = new URLSearchParams(query).toString()
            window.location.href = `${path}?${queryString}`
            // console.log(`${path}?${queryString}`)
          } else {
            router.push({ name: 'Dashboard' })
          }
        }
      })
    } catch (error) {
      // router.push({ name: 'Error' })
    }
  }
}
// JSON.parse(sessionRead('user'))
const initialValues = reactive({
  // username: '',
  // username: cachedUserInfo.value?.userId,
  oldPassword: '', // 新增旧密码字段
  newPassword: '',
  confirmPassword: ''
})

const resolver = ({ values }) => {
  const errors: any = {}
  // ユーザー名の検証
  if (!values.username) {
    errors.username = [{ message: t('biz.login.usernameRequired') }]
  } else if (values.username.length < 3) {
    errors.username = [{ message: t('biz.login.usernameMinLength') }]
  }
  // 旧パスワードの検証
  if (!values.oldPassword) {
    errors.oldPassword = [{ message: t('biz.login.oldPasswordRequired') }]
  }
  // パスワードの検証
  const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[`~!@#$%^&*()_+\-={}|[\]\\:";'<>?,./])[A-Za-z0-9`~!@#$%^&*()_+\-={}|[\]\\:";'<>?,./]{10,}$/
  if (!values.newPassword) {
    errors.newPassword = [{ message: t('biz.login.passwordRequired') }]
  } else if (values.newPassword.length < 10) {
    errors.newPassword = [{ message: t('biz.login.passwordMinLength') }]
  } else if (!passwordRegex.test(values.newPassword)) {
    dd.value.click()
    errors.newPassword = [{ message: t('biz.login.passwordComplexity') }]
  } else if (values.username && values.newPassword === values.username) {
    errors.newPassword = [{ message: t('biz.login.passwordSameAsUsername') }]
  } else if (values.oldPassword && values.newPassword === values.oldPassword) {
    errors.newPassword = [{ message: t('biz.login.passwordSameAsOldPassword') }]
  }

  // パスワード確認の検証
  if (!values.confirmPassword) {
    errors.confirmPassword = [{ message: t('biz.login.confirmPasswordRequired') }]
  } else if (values.newPassword !== values.confirmPassword) {
    errors.confirmPassword = [{ message: t('biz.login.passwordMismatch') }]
  }

  return {
    values,
    errors
  }
}
const op = ref()
const dd = ref()
const toggle = (event) => {
  op.value.toggle(event)
}
import { MD5 } from 'crypto-js'
const onFormSubmit = ({ valid, values }) => {
  // console.log('Form submitted:', values)
  const newvalues = {
    oldPassword: MD5(values.oldPassword).toString().toUpperCase(),
    newPassword: MD5(values.newPassword).toString().toUpperCase()
  }
  if (valid) {
    psChgApi(newvalues).then((data) => {
      if (typeof data === 'number') {
        dialogVisible.value = false
        password.value = ''
        document.getElementById('password1')?.focus()
      }
    })
  }
}
const dialogVisible = ref(true)
const feedback = ref(false)
const closable = ref(true)
</script>

<style lang="scss" scoped>
.pi-eye {
  transform: scale(1.6);
  margin-right: 1rem;
}

.pi-eye-slash {
  transform: scale(1.6);
  margin-right: 1rem;
}
.info-icon {
  display: inline-block;
  width: 13px;
  height: 13px;
  background-color: var(--p-primary-500); /* 你可以根据需要更改背景色 */
  border-radius: 50%;
  margin-left: 8px;
  position: relative;
  top: 2px;
  cursor: pointer;
  text-align: center;
  line-height: 15px;
  color: white;
}

.info-icon i {
  font-size: 11px;
}

.login-background {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: url('/images/login-bg.jpg'); /* 请替换为你的图片路径 */
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  z-index: 0;
}
.login-card {
  max-width: 95%;
  margin-right: 0;
  z-index: 1;
}
</style>
