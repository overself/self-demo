import VueI18nPlugin from '@intlify/unplugin-vue-i18n/vite'
import { PrimeVueResolver } from '@primevue/auto-import-resolver'
import Vue from '@vitejs/plugin-vue'
import VueJsx from '@vitejs/plugin-vue-jsx'
import { resolve } from 'path'
import Components from 'unplugin-vue-components/vite'
import type { ConfigEnv, UserConfig } from 'vite'
import { loadEnv } from 'vite'
import { ViteEjsPlugin } from 'vite-plugin-ejs'
import EslintPlugin from 'vite-plugin-eslint'
import { viteMockServe } from 'vite-plugin-mock'
import progress from 'vite-plugin-progress'
import PurgeIcons from 'vite-plugin-purge-icons'
import { createStyleImportPlugin, ElementPlusResolve } from 'vite-plugin-style-import'
import { createSvgIconsPlugin } from 'vite-plugin-svg-icons'
import ServerUrlCopy from 'vite-plugin-url-copy'

// https://vitejs.dev/config/
const root = process.cwd()

function pathResolve(dir: string) {
  return resolve(root, '.', dir)
}

export default ({ command, mode }: ConfigEnv): UserConfig => {
  let env = {} as any
  const isBuild = command === 'build'
  if (!isBuild) {
    env = loadEnv(process.argv[3] === '--mode' ? process.argv[4] : process.argv[3], root)
  } else {
    env = loadEnv(mode, root)
  }

  // 检查是否启用Mock
  const isMockEnabled = env.VITE_USE_MOCK === 'true'
  const isDev = command === 'serve'
  console.log(`🔨 当前命令: ${command}`)
  console.log(`🚀 环境: ${mode}`)
  console.log(`📡 Mock: ${isMockEnabled ? '已启用' : '已禁用'}`)

  console.log('\n📋 加载的环境变量:')
  console.log('  MODE:', env.MODE || mode)
  console.log('  VITE_USE_MOCK:', env.VITE_USE_MOCK || '(未设置)')
  console.log('  VITE_API_BASE_URL:', env.VITE_API_BASE_URL || '(未设置)')
  console.log('  VITE_MOCK_PREFIX:', env.VITE_MOCK_PREFIX || '(未设置)')
  console.log('  VITE_APP_TITLE:', env.VITE_APP_TITLE || '(未设置)')
  console.log('  VITE_REAL_API_URL:', env.VITE_REAL_API_URL || '(未设置)')

  return {
    base: '/design_change/',
    // base: '/change/',
    // base: mode === 'production' ? '/design_change/' : '/change/', // 生产环境使用 /my-app/，开发环境使用 /
    // base: './',
    plugins: [
      Vue({
        script: {
          // 开启defineModel
          defineModel: true
        }
      }),

      VueJsx(),
      ServerUrlCopy(),
      progress(),
      Components({
        resolvers: [PrimeVueResolver()]
      }),
      env.VITE_USE_ALL_ELEMENT_PLUS_STYLE === 'false'
        ? createStyleImportPlugin({
            resolves: [ElementPlusResolve()],
            libs: [
              {
                libraryName: 'element-plus',
                esModule: true,
                resolveStyle: (name) => {
                  if (name === 'click-outside') {
                    return ''
                  }
                  return `element-plus/es/components/${name.replace(/^el-/, '')}/style/css`
                }
              }
            ]
          })
        : undefined,
      EslintPlugin({
        cache: false,
        failOnWarning: false,
        failOnError: false,
        include: ['src/**/*.vue', 'src/**/*.ts', 'src/**/*.tsx'] // 检查的文件
      }),
      VueI18nPlugin({
        runtimeOnly: true,
        compositionOnly: true,
        include: [resolve(__dirname, 'src/locales/**')]
      }),
      createSvgIconsPlugin({
        iconDirs: [pathResolve('src/assets/svgs')],
        symbolId: 'icon-[dir]-[name]',
        svgoOptions: true
      }),
      PurgeIcons(),
      viteMockServe({
            ignore: /^_/,
            mockPath: 'src/mock',
            localEnabled: !isBuild,
            prodEnabled: isBuild
          }),
      ViteEjsPlugin({
        title: env.VITE_APP_TITLE
      })
    ],

    css: {
      preprocessorOptions: {
        scss: {
          api: 'modern'
        }
      }
    },
    resolve: {
      extensions: ['.mjs', '.js', '.ts', '.jsx', '.tsx', '.json', '.less', '.css'],
      alias: [
        {
          find: 'vue-i18n',
          replacement: 'vue-i18n/dist/vue-i18n.cjs.js'
        },
        {
          find: /\@\//,
          replacement: `${pathResolve('src')}/`
        },
        {
          find: /\~\//,
          replacement: `${pathResolve('public')}/`
        }
      ]
    },
    esbuild: {
      pure: env.VITE_DROP_CONSOLE === 'true' ? ['console.log'] : undefined,
      drop: env.VITE_DROP_DEBUGGER === 'true' ? ['debugger'] : undefined
    },
    build: {
      outDir: env.VITE_OUT_DIR || 'dist', // 输出目录，默认为 'dist'
      assetsDir: 'assets', // 静态资源目录，默认为 'assets'
      sourcemap: false, // 是否生成 source map
      minify: 'terser' // 代码压缩工具，默认为 'terser'
      // 更多构建选项...
    },
    // build: {
    //   target: 'es2015',
    //   minify: 'esbuild',
    //   outDir: env.VITE_OUT_DIR || 'dist',
    //   sourcemap: env.VITE_SOURCEMAP === 'true',
    //   // brotliSize: false,
    //   rollupOptions: {
    //     plugins: env.VITE_USE_BUNDLE_ANALYZER === 'true' ? [visualizer()] : undefined,
    //     // 拆包
    //     output: {
    //       manualChunks: {
    //         'vue-chunks': ['vue', 'vue-router', 'pinia', 'vue-i18n'],
    //         'element-plus': ['element-plus']
    //       }
    //     }
    //   },
    //   cssCodeSplit: !(env.VITE_USE_CSS_SPLIT === 'false'),
    //   cssTarget: ['chrome31']
    // },
    server: {
      port: 4599,
      proxy: {
        '^/design_change/api/v1': {
          // target:'http://10.219.225.132:8080/eca_api/',
          target: env.VITE_REAL_API_URL,
          // target: 'http://10.192.12.130:9999',
          changeOrigin: true,
          rewrite: (path) => {
            console.log(path)
            let temp = path.replace(/^\/design_change/, '')
            if (env.VITE_USE_MOCK === 'true') {
              temp = temp.replace('/api/', '/api/mock/')
            }
            return temp
          }
        }
      },
      hmr: {
        overlay: false
      },
      host: '0.0.0.0'
    },
    optimizeDeps: {
      include: [
        'vue',
        'vue-router',
        'vue-types',
        // 'element-plus/es/locale/lang/zh-cn',
        // 'element-plus/es/locale/lang/en',
        '@iconify/iconify',
        '@vueuse/core',
        'axios',
        'qs',
        'qrcode',
        'vue-json-pretty',
        'dayjs',
        'path-browserify'
      ]
    }
  }
}
