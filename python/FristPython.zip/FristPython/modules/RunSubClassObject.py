#! python
# -*- coding: utf-8 -*-

import logging
import traceback
from dataclasses import dataclass

import modules
from modules.AbstractClass import AbstractClass
from modules.BaseClass import BaseClass
from modules.RunClassObject import ComplexTest

# logging.fileConfig('../config/logging.conf')

logging.basicConfig(filename='../data/myapp.log', level=logging.DEBUG)

# create logger
logger = logging.getLogger('simple_example')
logger.setLevel(logging.DEBUG)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)

# 在类之外定义的函数
def minFun(self, x, y):
    return min(x, y)


def addFun(x, y):
    return x + y


# 如果子类中定义与父类同名的方法或属性，则会自动覆盖父类对应的方法或属性
# 解析属性： 当构造类对象时，基类会被记住，如果请求的属性在类中找不到，则会转往基类逐层递归查找。

class RunSubClass(modules.RunClassObject.MyClass, ComplexTest, AbstractClass):
    """类和实例变量，类继承及， 重载，等"""

    def __init__(self):
        # 初始化基类
        # 有一种方式可以简单地直接调用基类方法：即调用 BaseClassName.methodname(self, arguments)
        modules.RunClassObject.MyClass.__init__(self, "RunSubClass")
        ComplexTest.__init__(self, realpart=2, imagpart=1)

    # 函数定义的文本并非必须包含于类定义之内
    # 任何一个作为类属性的函数，都为该类的实例定义了一个相应方法
    getMin = minFun

    def maxFun(self, x, y):
        return max(x, y)

    # getMax与maxFun完全等价，但这种做法通常只会使程序的阅读者感到迷惑。建议不要这么做。
    getMax = maxFun

    """实现抽象方法"""

    def abstract_method(self):
        return "test"

    def fun(self, param):
        super(RunSubClass, self).fun(param)
        print("实现基类方法fun(self, param)，data：", self.data)


@dataclass
class Employee:
    name: str
    dept: str
    salary: int


if __name__ == '__main__':
    print('')
    logger.debug('Debugging information')
    logger.info('Informational message')
    logger.warning('Warning:config file %s not found', 'server.conf')
    logger.error('Error occurred')
    logger.critical('Critical error -- shutting down')

    print('-' * 20)
    # 初始化一个类实例对象
    subClass1 = RunSubClass()
    print("subClass1:: ", subClass1.__doc__)
    print("subClass1.data:: ", subClass1.data)
    print("subClass1.kind:: ", subClass1.kind)
    print("subClass1.getComplexTest:: ", subClass1.getComplexTest())

    print('-' * 20)
    # 使用 isinstance() 来检查一个实例的类型: isinstance(obj, int)
    # 使用 issubclass() 来检查类的继承关系: issubclass(bool, int)
    print(f'subClass1 is RunSubClass: {isinstance(subClass1, RunSubClass)}')
    print(f'subClass1 is ComplexTest: {isinstance(subClass1, ComplexTest)}')
    print(f'subClass1 is BaseClass: {isinstance(subClass1, BaseClass)}')
    print(f'subClass1 is Subclass of ComplexTest: {issubclass(RunSubClass, ComplexTest)}')
    print(f'subClass1 is Subclass of modules.RunClassObject.MyClass: {issubclass(RunSubClass, (modules.RunClassObject.MyClass, ComplexTest))}')

    # 方法解析顺序会动态改变以支持对 super() 的协同调用
    print('-' * 20)
    subClass2 = RunSubClass()
    print("RunSubClass.abstract_method.doc:: ", subClass2.abstract_method().__doc__)
    print('-' * 20)
    print("RunSubClass.abstract_method:: ", subClass2.abstract_method())
    subClass2.fun("测试一下重载方法")
    print("RunSubClass.data :: ", subClass2.data)
    subClass2.execute_method()
    AbstractClass.static_method()
    RunSubClass.static_method()
    subClass2.static_method()

    print('-' * 20)
    john = Employee("John", 'computer lab', 2021)
    print('Employee.John=', john)
    print('Employee.John.name=', john.name)
    try:
        print('Employee.default=', Employee())
    except Exception as e:
        print(F"Exception: {type(e)} ", e)
        traceback.print_exc()
