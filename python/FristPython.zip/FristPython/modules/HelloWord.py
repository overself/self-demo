#! python

# 创建示例多项集
users = {'Hans': 'active', 'Éléonore': 'inactive', '景太郎': 'active'}

print(users.copy().items())
# 策略：迭代一个副本
for user, status in users.copy().items():
    print(user)
    print(status)
    if status == 'inactive':
        del users[user]

print(users)

# 策略：创建一个新多项集
active_users = {}
for user, status in users.items():
    if status == 'active':
        active_users[user] = status

print(active_users)