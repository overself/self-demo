#! python
# -*- coding: utf-8 -*-

class Point:
    __match_args__ = ('x', 'y')

    def __init__(self, x, y):
        self.x = x
        self.y = y


def greet(name):
    if name is None:
        name = "default"
    return f'Hello, {name}! Wellcome to  here.'


def http_error(status):
    match status + 1:
        case 400:
            return "Bad request"
        case 401 | 402 | 403:
            return "Not allowed"
        case 404:
            return "Not found"
        case 418:
            return "I'm a teapot"
        case _:
            return "Something's wrong with the internet"


def point_value(point):
    match point:
        case (0, 0):
            print("Origin")
        case (0, y):
            print(f"Y={y}")
        case (x, 0):
            print(f"X={x}")
        case (x, y):
            print(f"X={x}, Y={y}")
        case _:
            raise ValueError("Not a point")


def where_is(point):
    match point:
        case Point(x=0, y=0):
            print("x-y:Origin")
        case Point(x=0, y=y):
            print(f"yY={y}")
        case Point(x=x, y=0):
            print(f"xX={x}")
        case Point(x=x, y=y) if x == y:
            print(f"xX=yY，XY={x}：{y}")
        case Point(x=x, y=y):
            print(f"xX={x}，yY={y}")
        case Point():
            print("x-y:Somewhere else")
        case _:
            print("x-y:Not a point")


def where_is_points(points):
    match points:
        case []:
            print("XX-YY:No points")
        case [Point(0, 0)]:
            print("XX-YY:Origin")
        case [Point(x, y)]:
            print(f"XX={x}，YY={y}")
        case [Point(0, y1), Point(0, y2)]:
            print(f"Two on the Y axis at {y1}, {y2}")
        case _:
            print("XX-YY:Not a point")


# 参数默认值: 非常有用的方式，默认值在定义作用域里的函数定义中求值，默认值只计算一次
def FunGenDefParam(v=1):
    print(f'>>>>>{v}')


# 默认值为列表、字典或类实例等可变对象时，会产生与该规则不同的结果
def FunShareDefParam(a, L=[]):
    L.append(a)
    return L


#
def FunDefParam(a, l=None):
    if l is None:
        l = []
    l.append(a)
    return l


def parrotFunParams(voltage, state='a stiff', action='voom', type='Norwegian Blue'):
    print("-- This parrot wouldn't", action, end=' ')
    print("if you put", voltage, "volts through it.")
    print("-- Lovely plumage, the", type)
    print("-- It's", state, "!")


# 参数: 位置参数, 元组参数, 关键字参数(命名), 特殊参数(/和*)
# *name 必须在 **name 前面
# *name 元组形参，接收一个元组，该元组包含形参列表之外的位置参数。
# **name 关键字参数，必须跟在位置参数后面
def cheeseshop(kind, *arguments, **keywords):
    print("-- Do you have any", kind, "?")
    print("-- I'm sorry, we're all out of", kind)
    for arg in arguments:
        print(arg)
    print("#" * 40)
    for kw in keywords:
        print(kw, ":", keywords[kw])


# Lambda 表达式
def make_incrementor(n=1):
    return lambda x: x + n


# 文档字符串
def my_function():
    """Do nothing, but document it.

    No, really, it doesn't do anything.
    """
    pass


# 函数注解 是可选的用户自定义函数类型的元数据完整信息
def FunAnnotations(ham: str, eggs: str = 'eggParams') -> str:
    print("Annotations:", FunAnnotations.__annotations__)
    print("Arguments:", ham, eggs)
    return ham + ' and ' + eggs


if __name__ == "__main__":
    import sys

    pram = None if sys.argv is None else sys.argv[1]
    print(sys.argv)
    print(greet(pram))
    print(http_error(401))
    print("-" * 20)
    point_value((10, 0))
    # point_value((1))
    print("-" * 20)
    where_is(Point(x=0, y=10))
    where_is(Point(2, 2))
    where_is(Point(1, 4))
    var = 100
    where_is(Point(y=var, x=2))
    print("-" * 20)
    where_is_points([Point(1, 4)])
    where_is_points([])
    where_is_points([Point(4, 5), Point(44, 55)])
    where_is_points([Point(0, 5), Point(0, 55)])
    print("-" * 20)
    FunGenDefParam()
    var = 11
    FunGenDefParam(var)
    print("-" * 20)
    print(FunShareDefParam(1))
    print(FunShareDefParam(2))
    print(FunShareDefParam(3))
    print("-" * 20)
    print(FunDefParam(11))
    print(FunDefParam(22))
    print(FunDefParam(33))
    print("-" * 20)
    parrotFunParams(1000)  # 1 个位置参数
    print('>>>')
    parrotFunParams(voltage=1000)  # 1 个关键字参数
    print('>>>')
    parrotFunParams(voltage=1000000, action='VOOOOOM')  # 2 个关键字参数
    print('>>>')
    parrotFunParams(action='VOOOOOM', voltage=1000000)  # 2 个关键字参数
    print('>>>')
    parrotFunParams('a million', 'bereft of life', 'jump')  # 3 个位置参数
    print('>>>')
    parrotFunParams('a thousand', state='pushing up the daisies')  # 1 个位置参数，1 个关键字参数
    print("-" * 20)
    cheeseshop("Limburger", "It's very runny, sir.",
               "It's really very, VERY runny, sir.",
               "This is Test .",
               shopkeeper="Michael Palin",
               client="John Cleese",
               sketch="Cheese Shop Sketch", endParam="over shopping !!!!")
    print("-" * 20)
    f = make_incrementor()
    print(f(1))
    print(f(3))
    print(f(3))
    print("-" * 20)
    pairs = [(1, 'one'), (2, 'two'), (3, 'three'), (4, 'four')]
    pairs.sort(key=lambda pair: pair[1])
    print(pairs)
    print("-" * 20)
    print(my_function.__doc__)
    print("-" * 20)
    print(FunAnnotations('spam', 'TEST'))
