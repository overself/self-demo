#! python
# -*- coding: utf-8 -*-
from collections import deque
from math import pi


def print_list():
    fruits = ['orange', 'apple', 'pear', 'banana', 'kiwi', 'apple', 'banana']
    print(fruits.count('banana'))
    print(fruits.index('apple'))
    print(fruits.index('apple', 3))
    fruits.append('grape')
    print(fruits)
    fruits.reverse()
    print("fruits", fruits)
    fruits2 = fruits.copy()
    print('fruits2:', fruits2)
    fruits2.sort()
    print('fruits2.sorted:', fruits2)
    fruits.extend(fruits2)
    print('fruits.extended:', fruits)
    return 0


# 用列表实现堆栈
def print_stack():
    stack = [3, 4, 5]
    print(stack.pop())
    stack.append(6)
    stack.append(7)
    print(stack.pop())
    stack.append(8)
    print(stack.pop(3))
    return


# 用列表实现队列
def print_deque():
    queue = deque(["Eric", "John", "Michael"])
    queue.append("Terry")
    print(queue.popleft())


# 列表推导式
# 列表推导式的方括号内包含以下内容：一个表达式，后面为一个 for 子句，然后，是零个或多个 for 或 if 子句。
# 结果是由表达式依据 for 和 if 子句求值计算而得出一个新列表
def print_squares():
    squares = []
    for x in range(10): squares.append(x ** 2)
    print("squares1=", squares)
    squares = list(map(lambda r: r ** 2, range(10)))
    print("squares2=", squares)

    squares = [x ** 2 for x in range(10)]
    print("列表推导式:", squares)
    print("复杂列表推导式:", [str(round(pi, i)) for i in range(1, 10)])

    matrix = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], ]
    print("嵌套的列表推导式:", [[row[i] for row in matrix] for i in range(4)])
    print("zip代替嵌套的列表推导式:", list(zip(*matrix)))


def print_other():
    a = [-1, 1, 66.25, 333, 333, 1234.5]
    del a[3:5]
    print("按索引和切片从列表中del元素:", a)
    # 循环的技巧
    # 字典：使用 items() 方法同时提取键及其对应的值
    knights = {'gallahad': 'the pure', 'robin': 'the brave'}
    for k, v in knights.items(): print(k, v)
    # 序列：使用用 enumerate() 函数可以同时取出位置索引和对应的值
    for i, v in enumerate(['tic', 'tac', 'toe']): print(i, v)
    # 序列：循环两个或多个序列时，用 zip() 函数可以将其内的元素一一匹配
    for q, a in zip(['name', 'quest', 'favorite color'], ['lancelot', 'the holy grail', 'blue']):
        print('What is your {0}?  It is {1}.'.format(q, a))
    # 使用 set() 去除序列中的重复元素。使用 sorted() 加 set() 则按排序后的顺序，循环遍历序列中的唯一元素：
    for f in sorted(set(['apple', 'orange', 'apple', 'pear', 'orange', 'banana'])):  print(f)

    # 深入条件控制
    # 比较运算符
    #  in 和 not in 用于执行确定一个值是否存在（或不存在）于某个容器中
    #  is 和 is not 用于比较两个对象是否是同一个对象
    # 比较操作支持链式操作
    #  a < b == c 校验 a 是否小于 b，且 b 是否等于 c
    lists = ['Trondheim', '1111', '2222', '3333', '', 'Hammer Dance']
    i = -1
    while temp := lists[i := i + 1]: print(temp)


if __name__ == "__main__":
    print()
    print("-" * 20)
    print_list()
    print("-" * 20)
    print_stack()
    print("-" * 20)
    print_deque()
    print("-" * 20)
    print_squares()
    print("-" * 20)
    print_other()
