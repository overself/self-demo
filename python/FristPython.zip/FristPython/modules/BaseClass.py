#! python

class BaseClass:

    def to_string(self):
        pass

    def equals(self, other):
        pass
