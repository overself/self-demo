#! python
# -*- coding: utf-8 -*-
from string import Template


# 输出格式：
def str_output_701():
    # 1、格式化字符串字面值
    year, event = 2016, 'Referendum'
    print(F'Results of the {year} {event}')

    # 2、字符串的str.format()
    yes_votes, total_votes = 42_572_654, 85_705_149
    str_value, percentage = '{} : #{:-10}# YES votes #{:2.2%}#', yes_votes / total_votes
    print(str_value.format("测试字符串格式化", yes_votes, percentage))
    print('The story of {0}, {1}, and {other}.'.format('Bill', 'Manfred', other='Georg'))

    # 3、repr() 或 str()
    # str() 函数返回供人阅读的值，repr() 则生成适于解释器读取的值
    hello = 'hello, world\n' '!!'
    print(hello)
    print(repr(hello))
    print(str(hello))
    x, y = 10 * 3.25, 200 * 200
    print(repr((x, y, ('spam', 'eggs'))))
    # 4、Template 类
    s = Template('$who likes $what')
    print(s.substitute(who='tim', what='kung pao'))

    ##格式化字符串字面值
    # ':' 后传递整数，为该字段设置最小字符宽度，常用于列对齐：
    # 用修饰符在格式化前转换值，如：'!a' => ascii() ，'!s'=> str()，'!r' => repr()：
    # = 说明符可将一个表达式扩展为表达式文本
    animals = 'eels'
    print(f'My hovercraft is full of {animals + '@_@'}.==> {animals!r}.')
    bugs, count, area = 'roaches', 13, 'living room'
    print(f'Debugging {bugs} {count=} {area=}')
    print(F'Debugging {bugs!r} {count=} {area=}')

    # 通过传递字典，并用方括号 '[]' 访问键来完成
    table = {'Sjoerd': 4127, 'Jack': 4098, 'Dcab': 8637678}
    print('Jack:{0[Jack]:8d}; Sjoerd:{0[Sjoerd]:8d}; ' ' Dcab:{0[Dcab]:8d}'.format(table))
    # 通过将 table 字典作为采用 ** 标记的关键字参数传入来实现
    print('Jack: {Jack:d}; Sjoerd: {Sjoerd:d}; Dcab: {Dcab:d}'.format(**table))
    print('-' * 20)
    print(vars().items())
    # 使用内置函数vars()+关键字参数的方式，回一个包含所有局部变量的字典:
    table = {k: str(v) for k, v in vars().items()}
    message = " ".join([f'{k}: ' + '{' + k + '};' for k in table.keys()])
    print(message.format(**table))

    # 手动格式化字符串： 如：str.rjust() str.ljust() 和 str.center() str.zfill()
    for x in range(1, 11):
        print(repr(x).rjust(2), repr(x * x).rjust(3), end=' ')  # 'end' 的使用不换行
        print(repr(x * x * x).rjust(4))


def read_write_file():
    print('\r\n' + '-' * 20)
    # mode包括 'r'->只能读取（默认值）；'w'->写入（现有同名文件会被覆盖）；'a'->打开文件并追加内容；'r+' 表示打开文件进行读写
    # 通常情况下，文件是以 text mode 打开，在模式后面加上一个 'b' ，可以用 binary mode 打开文件
    # 如果没有指定 encoding ，默认的是与平台有关，建议使用 encoding="utf-8"
    # f.read(size) : size 是可选的数值参数。省略 size 或 size 为负数时，读取并返回整个文件的内容
    # 如已到达文件末尾，f.read() 返回空字符串（''）。
    with open('../data/TestFileRead.txt', 'r', encoding="utf-8") as f:
        read_data = f.read()
    print('File closed? ', f.closed)
    print(read_data)

    # f.readline() 字符串末尾保留换行符（\n） f.readline() 返回空字符串，表示已经到达了文件末尾
    print('\r\n' + '-' * 20)
    with open('../data/TestFileRead.txt', 'r', encoding="utf-8") as f2:
        for line in f2: print(line, end='')

    # 以列表形式读取文件中的所有行，可以用 list(f) 或 f.readlines()
    print('\r\n' + '-' * 20)
    with open('../data/TestFileRead.txt', 'r', encoding="utf-8") as f3:
        file_lines1 = list(f3)
        file_lines2 = f3.readlines()
    print("file_lines1=\n", *file_lines1)
    print("file_lines2=\n", file_lines2)  # 因为file_lines1已读到文末，所以file_lines2为空字符

    # 以列表形式读取文件中的所有行，可以用 list(f) 或 f.readlines()
    print('\r\n' + '-' * 20)
    with open('../data/TestFileWriteT', 'w', encoding="utf-8") as f4:
        print(f4.write('This is a test\n'))
        print(f4.write(str(('the answer', 42)) + '\n'))
        print(f4.write('写入其他类型的对象前，要先把它们转化为字符串（文本模式）或字节对象（二进制模式）：\n'))

    # 以列表形式读取文件中的所有行，可以用 list(f) 或 f.readlines()
    print('\r\n' + '-' * 20)
    with open('../data/TestFileWriteB', 'wb') as f5:
        print(f5.write(bytes('This is a test\n', 'utf-8')))
        print(f5.write(bytes('写入其他类型的对象前，要先把它们转化为字符串（文本模式）或字节对象（二进制模式）：\n', 'utf-8')))


if __name__ == '__main__':
    str_output_701()
    read_write_file()
