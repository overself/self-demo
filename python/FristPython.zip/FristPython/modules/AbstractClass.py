#! python

from abc import abstractmethod, ABC


class AbstractClass(ABC):
    """抽象类测试"""

    @abstractmethod
    def abstract_method(self):
        pass

    def execute_method(self):
        print(F"这是抽象类中的一个可执行方法。")

    @staticmethod
    def static_method():
        print(F"这是抽象类中的一个静态方法。")
