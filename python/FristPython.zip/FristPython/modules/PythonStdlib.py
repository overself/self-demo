import os
import shutil


# 操作系统接口
def osOperation():
    print("os.name=", os.name)


# 日常文件和目录管理
def shutilOperation():
    print("shutil.get_archive_formats=", shutil.get_archive_formats())

# 文件通配符: glob 模块提供了一个在目录中使用通配符搜索创建文件列表的函数
# 命令行参数: argparse 模块提供了一种更复杂的机制来处理命令行参数
# 字符串模式匹配: re 模块为高级字符串处理提供正则表达式工具
# 数学:
#  ➡　math 模块提供对用于浮点数学运算的下层 C 库函数的访问
#  ➡　random 模块提供了进行随机选择的工具
#  ➡　statistics 模块计算数值数据的基本统计属性（均值，中位数，方差等）
#  ➡　SciPy项目用于数值计算的其他模块
# 互联网访问： urllib.request 用于从URL检索数据，以及 smtplib 用于发送邮件
# 日期和时间： datetime 模块提供了以简单和复杂的方式操作日期和时间的类
# 数据压缩： zlib, gzip, bz2, lzma, zipfile 和 tarfile
# 质量控制：
#  ➡　doctest 用于扫描模块并验证程序文档字符串中嵌入的测试
#  ➡　unittest允许在一个单独的文件中维护更全面的测试集
# 其包的复杂和强大功能
#  ➡　mlrpc.client 和 xmlrpc.server
#  ➡　json 包为解析这种流行的数据交换格式提供了强大的支持。 csv 模块支持以逗号分隔值格式直接读取和写入文件
#  ➡　XML 处理由 xml.etree.ElementTree ， xml.dom 和 xml.sax 包支持
#  ➡　email 一个用于管理电子邮件的库
#  ➡　sqlite3 模块是 SQLite 数据库库的包装器，提供了一个可以使用稍微非标准的 SQL 语法更新和访问的持久数据库
#  ➡　国际化由许多模块支持，包括 gettext ， locale ，以及 codecs 包

if __name__ == '__main__':
    osOperation()
    shutilOperation()
