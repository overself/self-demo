#! python
# -*- coding: utf-8 -*-
import traceback

from modules.BaseClass import BaseClass

# 类
# 1、Python 的类有点类似于 C++ 和 Modula-3 中类的结合体
# 2、支持面向对象编程（OOP）：
# ➡ 继承机制支持多个基类；
# ➡ 派生的类能覆盖基类的方法；
# ➡ 类的方法能调用基类中的同名方法;
# 3、和模块一样，类支持Python动态特性：在运行时创建，并可以修改
# 4、类成员（数据成员）与类方法
# ➡ 类成员一般为public，但可以指定为私有。（所有成员函数都为virtual）
# ➡ 方法函数在声明时

# 命名空间(namespace)： 是从名称到对象的映射，大多数命名空间都使用Python字典实现，不同命名空间中的名称之间绝对没有关系
# 如：内置名称集合；模块的全局名称；函数调用中的局部名称；对象的属性集合
# 命名空间是在不同时刻创建的，且拥有不同的生命周期，
# ➡ 内置名称的命名空间是在 Python 解释器启动时创建的，永远不会被删除
# ➡ 模块的全局命名空间在读取模块定义时创建；通常，模块的命名空间也会持续到解释器退出
# ➡ 函数的局部命名空间在函数被调用时被创建，并在函数返回或抛出未在函数内被处理的异常时，被删除

# 命名空间的作用域是Python代码中的一段文本区域，从这个区域可直接访问该命名空间，
# 作用域虽然是被静态确定的，但会被动态使用
# Python代码中如果不存在生效的 global 或 nonlocal 语句，则对名称的赋值总是会进入最内层作用域
# global 语句用于表明特定变量在全局作用域里，并应在全局作用域中重新绑定
# nonlocal  语句表明特定变量在外层作用域中，并应在外层作用域中重新绑定

# Python 中所有的方法实际上都是 virtual 方法
test_parm = 'model spam'


def scope_test():
    def do_local():
        # 局部 赋值
        spam = "local spam"
        test_parm = " test_parm model spam"
        print("in do_local assignment:", spam)
        print("testParm 000:", test_parm)

    def do_nonlocal():
        # nonlocal 赋值会改变 scope_test 对 spam 的绑定
        nonlocal spam
        spam = "nonlocal spam"
        print("in do_nonlocal assignment:", spam)

    def do_global():
        # global 赋值会改变模块层级的绑定
        global spam
        spam = "global spam"

        print("in do_global assignment:", spam)

    spam = "test spam"
    print("First var assignment:", spam)
    do_local()
    print("After local assignment:", spam)
    do_nonlocal()
    print("After nonlocal assignment:", spam)
    do_global()
    print("After global assignment:", spam)
    print("testParm 111:", test_parm)


class MyClass(BaseClass):
    """一个简单的示例类"""

    # 魔法方法
    def __init__(self, datas):
        if type(datas) is list:
            self.data = datas
        if type(datas) is str:
            self.data = [datas]

    # def __init__(self):
    #     self.data = []

    var = 12345

    # 方法的第一个参数常常被命名为self的名称，self在 Python中没有特殊含义，但应该去遵循此约定
    def fun(self):
        self.data.append('hello world')

    def fun(self, param):
        self.data.append(param)


class ComplexTest:
    """类实例化运算符的参数示例"""

    kind = 'canine'

    tricks = []

    # 方法的第一个参数常常被命名为 self，self这一名称在 Python 中绝对没有特殊含义，就是一个约定
    def __init__(self, realpart, imagpart):
        self.realpart = realpart
        self.imagpart = imagpart
        self.tests = []

    def getComplexTest(self):
        # return {"kind": self.kind, "realpart": self.realpart, "imagpart": self.imagpart} #返回一个字典
        return (self.kind, self.realpart, self.imagpart)  # 返回一个元组对象

    def add_trick(self, trick):
        self.tricks.append(trick)

    def add_test(self, test):
        self.tests.append(test)
        # 方法可以通过使用 self 参数的方法属性调用其他方法
        self.add_trick(test)

    # “私有”变量
    # 仅限从一个对象内部访问的“私有”实例变量在 Python 中并不存在
    #  Python代码约定: 带有一个下划线的名称 (例如 _spam) 被当作是API的非公有部分(无论它是函数、方法或是数据成员)
    #  任何形式为 __spam 的标识符（至少带有两个前缀下划线，至多一个后缀下划线）的文本将被替换为 _classname__spam
    # 名称改写有助于让子类重写方法而不破坏类内方法调用
    # Python目前的私有机制其实是伪私有，Python的类是没有权限控制的，所有变量和方法都是可以被外部访问的。
    # 改写规则的设计主要是为了避免意外冲突；访问或修改被视为私有的变量仍然是可能的
    __attr1 = None

    _attr2 = "一个下横线的变量，不是隐藏的私有属性"

    def setMyAttr1(self, attr1):
        self.__reSetMyAttr1(attr1)

    def __reSetMyAttr1(self, attr1):
        self.__attr1 = attr1

    def getMyAttr1(self):
        return self.__attr1


# 类不能用于实现纯抽象数据类型
# 客户端可能通过直接操作数据属性的方式破坏由方法所维护的固定变量
# 客户端可以向一个实例对象添加他们自己的数据属性而不会影响方法的可用性，只要保证避免名称冲突
# 每个值都是一个对象，因此具有 类 （也称为 类型），并存储为 object.__class__ 。
if __name__ == '__main__':
    print('')
    scope_test()
    print("In global scope:", spam)
    print("testParm 222:", test_parm)

    print('-' * 20)
    print("MyClass i:", MyClass.__doc__)
    print("MyClass i:", MyClass.i)
    # 需要参数的函数在不附带任何参数的情况下被调用时 Python 肯定会引发异常
    # missing 1 required positional argument: 'self'
    # print("MyClass fun:", MyClass.fun())
    print("MyClass fun:", MyClass.fun(MyClass()))

    print('-' * 20)
    myclass = MyClass()
    print("MyClass Obj info:", myclass.__doc__)
    print("MyClass Obj i:", myclass.i)
    # 方法的特殊之处就在于实例对象会作为函数的第一个参数被传入
    # 调用 x.f() 其实就相当于 MyClass.f(x)
    print("MyClass Obj fun:", myclass.fun())

    print('-' * 20)
    complex1 = ComplexTest(7.0, -8.5)
    print("Complex 1 Obj info:", complex1.__doc__)
    print(f"Complex 1 Obj i:{complex1.imagpart};r:{complex1.realpart}")
    print(f"Complex 1 Obj kind:{complex1.kind}")

    print('-' * 10)
    complex2 = ComplexTest(3.0, -6.5)
    print("Complex 2 Obj info:", complex2.__doc__)
    print(f"Complex 2 Obj i:{complex2.imagpart};r:{complex2.realpart}")
    print(f"Complex 2 Obj kind:{complex1.kind}")

    # 如果同样的属性名称同时出现在实例和类中，则属性查找会优先选择实例:
    print('-' * 10)
    complex1.kind = complex1.kind + '-' + complex1.kind
    print(f"Modify Complex 1 Obj kind:{complex1.kind}")  # 优先选择实例
    print(f"NonModify Complex 2 Obj kind:{complex2.kind}")
    print(f"NonModify Complex Class kind:{ComplexTest.kind}")

    print('-' * 10)
    ComplexTest.kind = ComplexTest.kind + '-Modify Complex kind'
    print(f"NonModify Complex 1 Obj kind:{complex1.kind}")
    print(f"NonModify Complex 2 Obj kind:{complex2.kind}")
    print(f"Modify Complex Class kind:{ComplexTest.kind}")

    print('-' * 10)
    complex1.add_trick('roll over')
    complex2.add_trick('play dead')
    print(f"Modify Complex 1 Obj tricks:{complex1.tricks}")
    print(f"Modify Complex 2 Obj tricks:{complex2.tricks}")
    print(f"NonModify Complex Class tricks:{ComplexTest.tricks}")
    print('-' * 10)
    complex1.add_test('test over')
    complex2.add_test('test dead')
    print(f"Modify Complex 1 Obj tests:{complex1.tests}")
    print(f"Modify Complex 1 Obj tricks:{complex1.tricks}")
    print(f"Modify Complex 2 Obj tests:{complex2.tests}")
    print(f"Modify Complex 2 Obj tricks:{complex2.tricks}")
    try:
        print(f"NonModify Complex Class tests:{ComplexTest.tests}")
    except Exception as e:
        print(f"Error Type: {type(e)} ===", e.__doc__)

    print('-' * 10)
    complex1.temp = 'temp String'
    print(f"Modify Complex 1 Obj temp:{complex1.temp}")
    try:
        print(f"NonModify Complex 2 Obj temp:{complex2.temp}")
    except Exception as e:
        print(f"Error Type: {type(e)} ===", e.__doc__)
    try:
        print(f"NonModify Complex Class temp:{ComplexTest.temp}")
    except Exception as e:
        print(f"Error Type: {type(e)} ===", e.__doc__)

    print('-' * 10)
    ComplexTest.attrs = ['param1', 'param2']
    print(f"NonModify Complex 1 Obj attrs:{complex1.attrs}")
    print(f"NonModify Complex 2 Obj attrs:{complex1.attrs}")
    print(f"Modify Complex Class temp:{ComplexTest.attrs}")

    # 类的私有属性
    print('-' * 10)
    complex3 = ComplexTest(1, 2)
    try:
        print("complex3.__attr1: ", complex3.__attr1)
    except Exception as e:
        print(f"Error Type: {type(e)} ===", e.__doc__)
        traceback.print_exc()

    # 使用【_类名__变量名】的方式，将双下横线的名称进行修改，即可访问双下横线的私有变量
    # 这种方式别成为“名称改写”，即任何形式为 __spam 的标识符的文本将被替换为 _classname__spam，
    # 其中 classname 为去除了前缀下划线的当前类名称。 这种改写不考虑标识符的句法位置，只要它出现在类定义内部就会进行
    print("complex3.__attr1: ", complex3._ComplexTest__attr1)
    print("complex3.getMyAttr1: ", complex3.getMyAttr1())
    try:
        complex3.__reSetMyAttr1("双下横线的名称的私有方法")
    except Exception as e:
        print(f"Error Type: {type(e)} ===", e.__doc__)
        traceback.print_exc()

    #
    complex3._ComplexTest__reSetMyAttr1('类的私有属性' '_000001')
    print("complex3.getMyAttr1: ", complex3.getMyAttr1())

    complex3.setMyAttr1('类的私有属性' '_000002222')
    print("complex3.getMyAttr1: ", complex3.getMyAttr1())

    print("complex3._attr2: ", complex3._attr2)
