#! python
# -*- coding: utf-8 -*-
# 错误和异常
import traceback


# 用户自定义异常： 不论是以直接还是间接的方式，异常都应从 Exception 类派生
class B(Exception):
    pass


class C(B):
    pass


class D(C):
    pass


# 异常的处理1：
def error_01():
    # 1、格式化字符串字面值
    while True:
        try:
            int(input("Please enter a number: "))
            break
        except (RuntimeError, TypeError, NameError, ValueError):
            print("Oops!  That was no valid number.  Try again...")

    # 异常匹配: 该类本身的实例或其所派生的类的实例
    for cls in [B, C, D]:
        try:
            raise cls()
        except D:
            print("D")
        except C:
            print("C")
        except B:
            print("B")

    # 打印异常信息
    try:
        raise Exception('spam', 'eggs')
    except Exception as inst:
        print('inst.type：', type(inst))  # 异常的类型
        print('inst.args：', inst.args)  # 参数保存在.args中
        print(inst)  # __str__ 允许 args 被直接打印，
        # 但可能在异常子类中被覆盖
        # 解包 args
        print('error Info =', *inst.args)


def error_02():
    # BaseException 是所有异常的共同基类
    # Exception ，是所有非致命异常的基类，可以被用作通配符，捕获（几乎）一切异常
    print('-' * 20)
    f = None
    try:
        f = open('myfile.txt')
        s = f.readline()
        i = int(s.strip())
    except OSError as err:
        print(f"OS error: {err=}, {type(err)=}")
        print(f"OS error INFO:", err)
    except ValueError:
        print("Could not convert data to an integer.")
    except Exception as err:
        print(f"Unexpected {err=}, {type(err)=}")
        raise
    finally:  # 用于定义在所有情况下都必须要执行的清理操作
        if f is not None and not f.closed: f.close()
    print('-' * 20)

    # try ... except语句具有可选的else子句，该子句如果存在，它必须放在所有except子句之后
    # 适用于 try 子句没有引发异常但又必须要执行的代码
    # 定义清理操作finally: 用于定义在所有情况下都必须要执行的清理操作
    file_name = '../data/TestFileRead.txt'
    try:
        f = open(file_name, 'r', encoding="utf-8")
    except OSError:
        print('cannot open', file_name)
    else:
        print(file_name, 'has', len(f.readlines()), 'lines')
        f.close()
    finally:
        if not f.closed: f.close()


# 异常链
# 如果一个未处理的异常发生在 except 部分内，它将会有被处理的异常附加到它上面，并包括在错误信息中:
# 为了表明一个异常是另一个异常的直接后果， raise 语句允许一个可选的 from 子句:
def error_03():
    print('--------------Run error_03--------------')
    try:
        open("database.sqlite")
    except OSError as exr:
        # from的exc必须为异常实例或为None。
        raise RuntimeError("unable to handle error") from exr


# 预定义的清理操作
# with 语句支持以及时、正确的清理的方式使用文件对象
def error_04():
    print('--------------Run error_04--------------')
    with open('../data/TestFileRead.txt', 'r', encoding="utf-8") as f: print(f.read())
    print('File closed? ', f.closed)


# 引发和处理多个不相关的异常
# 收集多个错误使用内置的ExceptionGroup打包成一个异常实例的列表，一起被引发成一个异常
def error_05():
    print('--------------Run error_05--------------')
    try:
        except_raise()
    except OSError as e:
        print(f'caught OSError {type(e)}: e')
    except SystemError as e:
        print(f'caught SystemError {type(e)}: e')


# 通过使用except* 代替except，可以有选择地只处理组中符合某种类型的异常，
# 而其他未被处理的异常则传播到其他子句，并最终被重新引发
# 例中未处理RecursionError，被继续抛出
def error_06():
    print('--------------Run error_06--------------')
    try:
        except_raise2()
    except* OSError as e:
        print("There were OSErrors")
    except* SystemError as e:
        print("There were SystemErrors")
    # except* RecursionError as e:
    #     print("There were RecursionError")


def except_raise():
    excs = [OSError('raise error 1'), SystemError('raise error 2')]
    raise ExceptionGroup('there were problems', excs)


def except_raise2():
    raise ExceptionGroup("group1", [
        OSError('raise2 OSError 1'),
        SystemError('raise2 System Error 2'),
        ExceptionGroup("group2", [
            OSError('raise2 OSError 3'),
            RecursionError('raise2 Recursion Error 4'),
        ])
    ])


# 用注释add_note(note)细化异常情况
# 当一个异常被创建以引发时，它通常被初始化为描述所发生错误的信息
# 在有些情况下，在异常被捕获后添加信息是很有用的。
# 例中未处理RecursionError，被继续抛出
def error_07():
    print('--------------Run error_07--------------')
    try:
        raise TypeError('bad type for error_07')
    except Exception as e:
        e.add_note('Add some information for error_07')
        e.add_note('Add some more information for error_07')
        raise


if __name__ == '__main__':
    # error_01()
    # error_02()
    # try:
    #     error_03()
    # except Exception as inst:
    #     print('----------------error_03:----------------', inst)
    #     traceback.print_exc()

    # try:
    #     error_04()
    # except Exception as inst:
    #     print('----------------error_04:----------------', inst)
    #     traceback.print_exc()

    # try:
    #     error_05()
    # except Exception as inst:
    #     print(f'----------------error_05:----------------{type(inst)}', inst)
    #     traceback.print_exc()

    # try:
    #     error_06()
    # except Exception as inst:
    #     print(f'----------------error_06:----------------{type(inst)}', inst)
    #     traceback.print_exc()

    try:
        error_07()
    except Exception as inst:
        print(f'----------------error_07:----------------{type(inst)}', inst)
        traceback.print_exc()
