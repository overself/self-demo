#! python
# -*- coding: utf-8 -*-


"""
SharePoint Graph API 完整客户端
使用纯requests库实现，包含自动令牌刷新机制
"""

import json
import os
import time
from datetime import datetime
from typing import Optional, Dict, List, Any

import requests


class SharePointClient:
    """
    使用requests库的完整SharePoint Graph API客户端
    包含自动令牌刷新和所有文件操作功能
    """

    def __init__(self, config: Dict[str, str]):
        """
        初始化SharePoint客户端
        Args:
            config: 配置字典，包含以下键：
                - tenant_id: Azure租户ID
                - client_id: 应用客户端ID
                - client_secret: 客户端密钥
                - site_hostname: SharePoint主机名 (如: contoso.sharepoint.com)
                - site_path: 站点路径 (如: sites/MySite 或 teams/MyTeam)
        """
        self.config = config

        self.access_token = None
        self.token_expires_at = 0
        self.refresh_token = None  # 客户端凭证流通常没有refresh_token

        # API端点
        self.graph_endpoint = "https://graph.microsoft.com/v1.0"
        self.auth_endpoint = f"https://login.microsoftonline.com/{self.config['tenant_id']}/oauth2/v2.0/token"

        # 站点信息缓存
        self.site_id = None
        self.drive_id = None
        self.drive_info = None

        # 请求头
        self.headers = {
            "Content-Type": "application/json",
            "User-Agent": "SharePoint-Client/1.0"
        }

        # 初始化
        print("🚀 初始化SharePoint客户端...")
        self._ensure_token_valid()
        if self.access_token:
            self._get_site_and_drive()

    def _get_token(self) -> Optional[Dict[str, Any]]:
        """
        获取新的访问令牌（客户端凭证流）

        Returns:
            令牌信息字典或None
        """
        try:
            token_data = {
                "grant_type": "client_credentials",
                "client_id": self.config["client_id"],
                "client_secret": self.config["client_secret"],
                "scope": "https://graph.microsoft.com/.default"
            }

            headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            }

            response = requests.post(
                self.auth_endpoint,
                data=token_data,
                headers=headers,
                timeout=30
            )

            if response.status_code == 200:
                token_info = response.json()

                # 计算绝对过期时间（提前5分钟过期以确保安全）
                expires_in = token_info.get("expires_in", 3600)
                self.token_expires_at = time.time() + expires_in - 300  # 提前5分钟

                print(f"✅ 获取新令牌成功，有效期至: {datetime.fromtimestamp(self.token_expires_at).strftime('%Y-%m-%d %H:%M:%S')}")
                return token_info
            else:
                print(f"❌ 获取令牌失败: {response.status_code}")
                print(f"错误详情: {response.text}")
                return None

        except requests.exceptions.RequestException as e:
            print(f"❌ 令牌请求异常: {str(e)}")
            return None
        except Exception as e:
            print(f"❌ 获取令牌时发生未知错误: {str(e)}")
            return None

    def _ensure_token_valid(self) -> bool:
        """
        确保令牌有效，如果过期或即将过期则获取新令牌

        Returns:
            令牌是否有效
        """
        current_time = time.time()

        # 检查令牌是否存在且未过期
        if self.access_token and current_time < self.token_expires_at:
            # 令牌仍然有效
            return True
        else:
            # 需要获取新令牌
            print("🔄 令牌已过期或不存在，正在获取新令牌..." if self.access_token else "🔑 正在获取初始令牌...")

            token_info = self._get_token()
            if token_info and "access_token" in token_info:
                self.access_token = token_info["access_token"]
                self.headers["Authorization"] = f"Bearer {self.access_token}"
                return True
            else:
                print("❌ 无法获取有效令牌")
                return False

    def _make_request(self, method: str, endpoint: str, **kwargs) -> Optional[requests.Response]:
        """
        发送API请求，自动处理令牌刷新

        Args:
            method: HTTP方法 (GET, POST, PUT, DELETE, PATCH)
            endpoint: API端点路径
            **kwargs: 传递给requests的额外参数

        Returns:
            响应对象或None
        """
        # 确保令牌有效
        if not self._ensure_token_valid():
            return None

        # 构建完整URL
        if endpoint.startswith("http"):
            url = endpoint
        else:
            url = f"{self.graph_endpoint}{endpoint}"

        # 设置超时
        if "timeout" not in kwargs:
            kwargs["timeout"] = 30

        try:
            # 发送请求
            response = requests.request(
                method=method,
                url=url,
                headers=self.headers,
                **kwargs
            )

            # 处理401未授权错误（令牌可能突然失效）
            if response.status_code == 401:
                print("⚠️ 令牌无效，尝试刷新...")
                # 强制获取新令牌并重试一次
                self.access_token = None
                if self._ensure_token_valid():
                    self.headers["Authorization"] = f"Bearer {self.access_token}"
                    response = requests.request(
                        method=method,
                        url=url,
                        headers=self.headers,
                        **kwargs
                    )

            # 记录错误（非2xx状态码）
            if response.status_code >= 400:
                print(f"⚠️ API请求错误: {response.status_code}")
                if response.text:
                    try:
                        error_data = response.json()
                        print(f"错误信息: {json.dumps(error_data, indent=2, ensure_ascii=False)}")
                    except:
                        print(f"错误详情: {response.text[:500]}")

            return response

        except requests.exceptions.Timeout:
            print(f"❌ 请求超时: {url}")
            return None
        except requests.exceptions.RequestException as e:
            print(f"❌ 请求异常: {str(e)}")
            return None

    def _get_site_and_drive(self) -> bool:
        """
        获取站点ID和默认驱动器ID

        Returns:
            是否成功获取
        """
        try:
            # 获取站点ID
            print(f"🔍 获取站点信息: {self.config['site_hostname']}/{self.config['site_path']}")

            # 使用站点路径获取站点ID
            site_url = f"/sites/{self.config['site_hostname']}:/{self.config['site_path']}"
            response = self._make_request("GET", site_url)

            if response and response.status_code == 200:
                site_data = response.json()
                self.site_id = site_data["id"]
                print(f"✅ 获取站点ID成功: {self.site_id[:50]}...")

                # 获取驱动器列表
                drives_url = f"/sites/{self.site_id}/drives"
                response = self._make_request("GET", drives_url)

                if response and response.status_code == 200:
                    drives_data = response.json()
                    if drives_data.get("value") and len(drives_data["value"]) > 0:
                        # 通常第一个是默认文档库
                        self.drive_info = drives_data["value"][0]
                        self.drive_id = self.drive_info["id"]
                        print(f"✅ 获取驱动器成功: {self.drive_info['name']} (ID: {self.drive_id})")
                        return True
                    else:
                        print("❌ 未找到驱动器")
                else:
                    print("❌ 获取驱动器列表失败")
            else:
                print("❌ 获取站点信息失败")

            return False

        except Exception as e:
            print(f"❌ 获取站点和驱动器时发生错误: {str(e)}")
            return False

    # ==================== 文件操作方法 ====================

    def list_directory(self, folder_path: str = "/") -> List[Dict[str, Any]]:
        """
        列出目录内容

        Args:
            folder_path: 文件夹路径

        Returns:
            文件/文件夹列表
        """
        if not self.drive_id:
            print("❌ 驱动器ID未初始化")
            return []

        try:
            # 处理根目录
            if folder_path == "/" or folder_path == "":
                endpoint = f"/drives/{self.drive_id}/root/children"
            else:
                endpoint = f"/drives/{self.drive_id}/root:{folder_path}:/children"

            response = self._make_request("GET", endpoint)

            if response and response.status_code == 200:
                data = response.json()
                items = []

                for item in data.get("value", []):
                    item_info = {
                        "id": item.get("id"),
                        "name": item.get("name"),
                        "type": "folder" if item.get("folder") else "file",
                        "size": item.get("size", 0),
                        "lastModified": item.get("lastModifiedDateTime"),
                        "created": item.get("createdDateTime"),
                        "webUrl": item.get("webUrl"),
                        "downloadUrl": item.get("@microsoft.graph.downloadUrl")
                    }
                    items.append(item_info)

                print(f"📁 列出目录成功: {folder_path}，共 {len(items)} 个项目")
                return items
            else:
                return []

        except Exception as e:
            print(f"❌ 列出目录时发生错误: {str(e)}")
            return []

    def upload_file(self, local_path: str, remote_folder: str,
                    remote_name: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        上传文件

        Args:
            local_path: 本地文件路径
            remote_folder: 远程文件夹路径
            remote_name: 远程文件名（可选，默认使用本地文件名）

        Returns:
            上传的文件信息或None
        """
        if not self.drive_id:
            print("❌ 驱动器ID未初始化")
            return None

        if not os.path.exists(local_path):
            print(f"❌ 本地文件不存在: {local_path}")
            return None

        try:
            # 设置远程文件名
            if remote_name is None:
                remote_name = os.path.basename(local_path)

            # 构建远程路径
            remote_path = f"{remote_folder.rstrip('/')}/{remote_name}"

            # 读取文件
            with open(local_path, 'rb') as f:
                file_content = f.read()

            # 上传URL
            upload_url = f"/drives/{self.drive_id}/root:{remote_path}:/content"

            # 临时修改请求头用于文件上传
            upload_headers = self.headers.copy()
            upload_headers["Content-Type"] = "application/octet-stream"

            response = requests.put(
                f"{self.graph_endpoint}{upload_url}",
                headers=upload_headers,
                data=file_content,
                timeout=60
            )

            if response.status_code in [200, 201]:
                file_info = response.json()
                print(f"✅ 文件上传成功: {remote_path} ({len(file_content)} bytes)")
                return file_info
            else:
                print(f"❌ 文件上传失败: {response.status_code}")
                print(f"错误详情: {response.text[:500]}")
                return None

        except Exception as e:
            print(f"❌ 上传文件时发生错误: {str(e)}")
            return None

    def download_file(self, remote_path: str, local_path: str) -> bool:
        """
        下载文件

        Args:
            remote_path: 远程文件路径
            local_path: 本地保存路径

        Returns:
            是否成功
        """
        if not self.drive_id:
            print("❌ 驱动器ID未初始化")
            return False

        try:
            # 确保本地目录存在
            local_dir = os.path.dirname(local_path)
            if local_dir and not os.path.exists(local_dir):
                os.makedirs(local_dir, exist_ok=True)

            # 获取文件下载URL
            download_url = f"/drives/{self.drive_id}/root:{remote_path}:/content"
            response = self._make_request("GET", download_url)

            if response and response.status_code == 200:
                with open(local_path, 'wb') as f:
                    f.write(response.content)

                file_size = os.path.getsize(local_path)
                print(f"✅ 文件下载成功: {local_path} ({file_size} bytes)")
                return True
            else:
                print(f"❌ 文件下载失败: {remote_path}")
                return False

        except Exception as e:
            print(f"❌ 下载文件时发生错误: {str(e)}")
            return False

    def create_folder(self, parent_path: str, folder_name: str) -> Optional[Dict[str, Any]]:
        """
        创建文件夹

        Args:
            parent_path: 父文件夹路径
            folder_name: 新文件夹名称

        Returns:
            创建的文件夹信息或None
        """
        if not self.drive_id:
            print("❌ 驱动器ID未初始化")
            return None

        try:
            # 创建文件夹URL
            create_url = f"/drives/{self.drive_id}/root:{parent_path}:/children"

            folder_data = {
                "name": folder_name,
                "folder": {},
                "@microsoft.graph.conflictBehavior": "rename"
            }

            response = self._make_request("POST", create_url, json=folder_data)

            if response and response.status_code == 201:
                folder_info = response.json()
                print(f"✅ 文件夹创建成功: {folder_name}")
                return folder_info
            else:
                print(f"❌ 文件夹创建失败: {folder_name}")
                return None

        except Exception as e:
            print(f"❌ 创建文件夹时发生错误: {str(e)}")
            return None

    def delete_item(self, item_path: str) -> bool:
        """
        删除文件或文件夹

        Args:
            item_path: 项目路径

        Returns:
            是否成功
        """
        if not self.drive_id:
            print("❌ 驱动器ID未初始化")
            return False

        try:
            # 先获取项目ID
            item_url = f"/drives/{self.drive_id}/root:{item_path}"
            response = self._make_request("GET", item_url)

            if not response or response.status_code != 200:
                print(f"❌ 未找到项目: {item_path}")
                return False

            item_data = response.json()
            item_id = item_data["id"]

            # 删除项目
            delete_url = f"/drives/{self.drive_id}/items/{item_id}"
            response = self._make_request("DELETE", delete_url)

            if response and response.status_code == 204:
                print(f"✅ 项目删除成功: {item_path}")
                return True
            else:
                print(f"❌ 项目删除失败: {item_path}")
                return False

        except Exception as e:
            print(f"❌ 删除项目时发生错误: {str(e)}")
            return False

    def move_item(self, source_path: str, target_folder: str,
                  new_name: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        移动或重命名项目

        Args:
            source_path: 源项目路径
            target_folder: 目标文件夹路径
            new_name: 新名称（可选，用于重命名）

        Returns:
            移动后的项目信息或None
        """
        if not self.drive_id:
            print("❌ 驱动器ID未初始化")
            return None

        try:
            # 获取源项目ID
            source_url = f"/drives/{self.drive_id}/root:{source_path}"
            response = self._make_request("GET", source_url)

            if not response or response.status_code != 200:
                print(f"❌ 未找到源项目: {source_path}")
                return None

            source_data = response.json()
            source_id = source_data["id"]

            # 获取目标文件夹ID
            target_url = f"/drives/{self.drive_id}/root:{target_folder}"
            response = self._make_request("GET", target_url)

            if not response or response.status_code != 200:
                print(f"❌ 未找到目标文件夹: {target_folder}")
                return None

            target_data = response.json()
            target_id = target_data["id"]

            # 准备更新数据
            update_data = {
                "parentReference": {
                    "id": target_id,
                    "driveId": self.drive_id
                }
            }

            if new_name:
                update_data["name"] = new_name

            # 移动项目
            move_url = f"/drives/{self.drive_id}/items/{source_id}"
            response = self._make_request("PATCH", move_url, json=update_data)

            if response and response.status_code == 200:
                moved_item = response.json()
                action = "重命名" if new_name else "移动"
                print(f"✅ 项目{action}成功: {source_path} -> {target_folder}/{new_name if new_name else ''}")
                return moved_item
            else:
                print(f"❌ 项目移动失败: {source_path}")
                return None

        except Exception as e:
            print(f"❌ 移动项目时发生错误: {str(e)}")
            return None

    def copy_item(self, source_path: str, target_path: str) -> bool:
        """
        复制项目

        Args:
            source_path: 源项目路径
            target_path: 目标路径

        Returns:
            是否成功发起复制请求（复制是异步操作）
        """
        if not self.drive_id:
            print("❌ 驱动器ID未初始化")
            return False

        try:
            # 获取源项目ID
            source_url = f"/drives/{self.drive_id}/root:{source_path}"
            response = self._make_request("GET", source_url)

            if not response or response.status_code != 200:
                print(f"❌ 未找到源项目: {source_path}")
                return False

            source_data = response.json()
            source_id = source_data["id"]

            # 准备复制数据
            target_dir = os.path.dirname(target_path)
            target_name = os.path.basename(target_path)

            copy_data = {
                "parentReference": {
                    "driveId": self.drive_id,
                    "path": f"/drive/root:{target_dir}"
                },
                "name": target_name
            }

            # 发起复制请求
            copy_url = f"/drives/{self.drive_id}/items/{source_id}/copy"
            response = self._make_request("POST", copy_url, json=copy_data)

            if response and response.status_code in [200, 202]:
                print(f"✅ 复制请求已接受: {source_path} -> {target_path}")
                print("ℹ️  复制是异步操作，可能需要一些时间完成")
                return True
            else:
                print(f"❌ 复制请求失败: {source_path}")
                return False

        except Exception as e:
            print(f"❌ 复制项目时发生错误: {str(e)}")
            return False

    def search_items(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        """
        搜索文件或文件夹

        Args:
            query: 搜索关键词
            limit: 结果数量限制

        Returns:
            搜索结果列表
        """
        if not self.drive_id:
            print("❌ 驱动器ID未初始化")
            return []

        try:
            # 搜索URL
            search_url = f"/drives/{self.drive_id}/root/search(q='{query}')?$top={limit}"

            response = self._make_request("GET", search_url)

            if response and response.status_code == 200:
                data = response.json()
                results = []

                for item in data.get("value", []):
                    item_info = {
                        "id": item.get("id"),
                        "name": item.get("name"),
                        "path": item.get("parentReference", {}).get("path", ""),
                        "type": "folder" if item.get("folder") else "file",
                        "size": item.get("size", 0),
                        "lastModified": item.get("lastModifiedDateTime"),
                        "webUrl": item.get("webUrl")
                    }
                    results.append(item_info)

                print(f"🔍 搜索成功: '{query}'，找到 {len(results)} 个结果")
                return results
            else:
                return []

        except Exception as e:
            print(f"❌ 搜索时发生错误: {str(e)}")
            return []

    def get_item_info(self, item_path: str) -> Optional[Dict[str, Any]]:
        """
        获取项目详细信息

        Args:
            item_path: 项目路径

        Returns:
            项目信息或None
        """
        if not self.drive_id:
            print("❌ 驱动器ID未初始化")
            return None

        try:
            endpoint = f"/drives/{self.drive_id}/root:{item_path}"
            response = self._make_request("GET", endpoint)

            if response and response.status_code == 200:
                return response.json()
            else:
                return None

        except Exception as e:
            print(f"❌ 获取项目信息时发生错误: {str(e)}")
            return None


# ==================== 使用示例和配置 ====================

def main():
    """
    主函数：演示SharePoint客户端的完整使用
    """
    print("=" * 70)
    print("SharePoint Graph API 完整客户端演示")
    print("=" * 70)

    # ====================================================
    # 第一步：配置信息 - 请根据实际情况修改！
    # ====================================================

    # 从环境变量获取配置（推荐方式）
    config = {
        "tenant_id": os.getenv("SHAREPOINT_TENANT_ID", "YOUR_TENANT_ID"),
        "client_id": os.getenv("SHAREPOINT_CLIENT_ID", "YOUR_CLIENT_ID"),
        "client_secret": os.getenv("SHAREPOINT_CLIENT_SECRET", "YOUR_CLIENT_SECRET"),
        "site_hostname": os.getenv("SHAREPOINT_SITE_HOSTNAME", "company.sharepoint.com"),
        "site_path": os.getenv("SHAREPOINT_SITE_PATH", "sites/MyTeamSite")
    }

    # 或者直接填写配置（不推荐用于生产环境）
    """
    config = {
        "tenant_id": "YOUR_TENANT_ID",  # Azure目录(租户)ID
        "client_id": "YOUR_CLIENT_ID",  # 应用(客户端)ID
        "client_secret": "YOUR_CLIENT_SECRET",  # 客户端密钥
        "site_hostname": "company.sharepoint.com",  # SharePoint域名
        "site_path": "sites/MyTeamSite"  # 站点路径，从浏览器地址栏获取
    }
    """

    # 检查配置是否已填写
    if "YOUR_" in config["tenant_id"]:
        print("\n⚠️  请先配置您的Azure应用信息！")
        print("\n📋 配置步骤:")
        print("1. 访问 https://portal.azure.com")
        print("2. 进入 Azure Active Directory > 应用注册")
        print("3. 创建或选择应用，获取以下信息:")
        print("   - 目录(租户) ID → tenant_id")
        print("   - 应用程序(客户端) ID → client_id")
        print("   - 证书和密码 > 新建客户端密钥 → client_secret")
        print("4. API权限 > 添加权限 > Microsoft Graph > 应用程序权限")
        print("   - Files.ReadWrite.All")
        print("   - Sites.ReadWrite.All")
        print("5. 点击'授予管理员同意'")
        print("\n🌐 站点信息获取:")
        print("   - 打开您的SharePoint站点")
        print("   - 从浏览器地址栏获取:")
        print("     示例: https://company.sharepoint.com/sites/MyTeamSite")
        print("     site_hostname: company.sharepoint.com")
        print("     site_path: sites/MyTeamSite")
        print("\n💡 提示: 建议使用环境变量来存储敏感信息")
        print("   export SHAREPOINT_CLIENT_SECRET='your_secret'")
        return

    # ====================================================
    # 第二步：创建客户端实例
    # ====================================================
    print(f"\n1. 创建SharePoint客户端实例...")
    print(f"   站点: {config['site_hostname']}/{config['site_path']}")

    try:
        client = SharePointClient(config)

        if not client.access_token:
            print("❌ 客户端初始化失败，请检查配置和网络连接")
            return

        print("✅ 客户端初始化成功！")

    except Exception as e:
        print(f"❌ 初始化失败: {str(e)}")
        return

    # ====================================================
    # 第三步：演示各种操作
    # ====================================================

    # 3.1 列出根目录内容
    print(f"\n2. 列出SharePoint根目录内容...")
    root_items = client.list_directory("/")

    if root_items:
        print(f"   找到 {len(root_items)} 个项目:")
        for i, item in enumerate(root_items[:5], 1):  # 只显示前5个
            icon = "📁" if item["type"] == "folder" else "📄"
            print(f"   {i}. {icon} {item['name']} ({item['type']})")
        if len(root_items) > 5:
            print(f"   ... 还有 {len(root_items) - 5} 个项目")
    else:
        print("   目录为空或访问失败")

    # 3.2 创建测试文件夹
    print(f"\n3. 创建测试文件夹...")
    test_folder = "/测试文件夹_" + datetime.now().strftime("%Y%m%d_%H%M%S")

    folder_info = client.create_folder("/", test_folder.replace("/", ""))
    if folder_info:
        print(f"   ✅ 测试文件夹创建成功: {test_folder}")

        # 3.3 在测试文件夹中创建示例文件
        print(f"\n4. 在测试文件夹中创建示例文件...")

        # 创建本地测试文件
        test_content = f"""这是一个通过SharePoint Graph API创建的测试文件。
                        创建时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                        用途: 演示完整的文件操作功能。
                        客户端: requests + Python
                        """
        local_test_file = "local_test_file.txt"
        with open(local_test_file, "w", encoding="utf-8") as f:
            f.write(test_content)

        # 上传测试文件
        remote_path = f"{test_folder}/uploaded_file.txt"
        upload_result = client.upload_file(local_test_file, test_folder, "api_demo_file.txt")

        if upload_result:
            print(f"   ✅ 测试文件上传成功")

            # 3.4 列出测试文件夹内容
            print(f"\n5. 列出测试文件夹内容...")
            test_items = client.list_directory(test_folder)
            if test_items:
                for item in test_items:
                    size_kb = item["size"] / 1024 if item["size"] > 0 else 0
                    print(f"   📄 {item['name']} ({size_kb:.1f} KB)")

            # 3.5 下载文件
            print(f"\n6. 下载文件测试...")
            download_path = "downloaded_test_file.txt"
            if client.download_file(f"{test_folder}/api_demo_file.txt", download_path):
                print(f"   ✅ 文件下载成功: {download_path}")

                # 验证下载的文件
                if os.path.exists(download_path):
                    with open(download_path, "r", encoding="utf-8") as f:
                        content = f.read(100)  # 读取前100个字符
                    print(f"   文件预览: {content}...")

            # 3.6 复制文件
            print(f"\n7. 复制文件测试...")
            copy_success = client.copy_item(
                f"{test_folder}/api_demo_file.txt",
                f"{test_folder}/api_demo_file_copy.txt"
            )

            if copy_success:
                print(f"   ✅ 复制请求已发送")

                # 等待片刻，然后检查复制结果
                import time
                print(f"   等待3秒让复制操作完成...")
                time.sleep(3)

                # 再次列出文件夹查看复制结果
                updated_items = client.list_directory(test_folder)
                file_count = len([item for item in updated_items if item["type"] == "file"])
                print(f"   测试文件夹中现有 {file_count} 个文件")

            # 3.7 搜索文件
            print(f"\n8. 搜索功能测试...")
            search_results = client.search_items("api_demo", limit=5)

            if search_results:
                print(f"   搜索 'api_demo' 找到 {len(search_results)} 个结果:")
                for i, result in enumerate(search_results, 1):
                    print(f"   {i}. {result['name']}")

            # 3.8 移动/重命名文件
            print(f"\n9. 移动和重命名测试...")
            move_result = client.move_item(
                f"{test_folder}/api_demo_file_copy.txt",
                test_folder,
                "renamed_file.txt"
            )

            if move_result:
                print(f"   ✅ 文件重命名成功")

            # 3.9 清理测试文件
            print(f"\n10. 清理测试文件...")
            files_to_delete = [
                f"{test_folder}/api_demo_file.txt",
                f"{test_folder}/renamed_file.txt"
            ]

            deleted_count = 0
            for file_path in files_to_delete:
                if client.delete_item(file_path):
                    deleted_count += 1

            print(f"   已删除 {deleted_count} 个测试文件")

            # 删除测试文件夹
            if deleted_count > 0:
                print(f"\n11. 删除测试文件夹...")
                if client.delete_item(test_folder):
                    print(f"   ✅ 测试文件夹删除成功")

        # 清理本地文件
        local_files = [local_test_file, download_path] if 'download_path' in locals() else [local_test_file]
        for file_path in local_files:
            if os.path.exists(file_path):
                os.remove(file_path)
                print(f"   🗑️  已删除本地文件: {file_path}")

    # ====================================================
    # 第四步：显示令牌状态
    # ====================================================
    print(f"\n" + "=" * 70)
    print("客户端状态摘要")
    print("=" * 70)

    if client.access_token:
        token_age = client.token_expires_at - time.time()
        if token_age > 0:
            print(f"🔑 令牌状态: 有效")
            print(f"   剩余有效期: {int(token_age // 60)}分{int(token_age % 60)}秒")
            print(f"   过期时间: {datetime.fromtimestamp(client.token_expires_at).strftime('%Y-%m-%d %H:%M:%S')}")
        else:
            print(f"🔑 令牌状态: 已过期")

    print(f"🌐 站点ID: {client.site_id[:50]}..." if client.site_id else "🌐 站点ID: 未获取")
    print(f"💾 驱动器: {client.drive_info['name'] if client.drive_info else '未获取'}")

    print(f"\n🎉 演示完成！")
    print("=" * 70)


def quick_start():
    """
    快速开始示例
    """
    # 最简单的使用方式
    config = {
        "tenant_id": "your_tenant_id",
        "client_id": "your_client_id",
        "client_secret": "your_client_secret",
        "site_hostname": "company.sharepoint.com",
        "site_path": "sites/MyTeamSite"
    }

    # 创建客户端
    client = SharePointClient(config)

    # 基本操作
    # 1. 列出文件
    items = client.list_directory("/Shared Documents")
    for item in items:
        print(f"{item['name']} - {item['type']}")

    # 2. 上传文件
    client.upload_file("本地文件.pdf", "/Shared Documents", "远程文件.pdf")

    # 3. 下载文件
    client.download_file("/Shared Documents/远程文件.pdf", "下载的文件.pdf")

    # 4. 创建文件夹
    client.create_folder("/Shared Documents", "新文件夹")


if __name__ == "__main__":
    # 运行完整演示
    main()

    # 或者运行快速开始
    # quick_start()