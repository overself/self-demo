import pandas as pd
import openpyxl
import os
from datetime import datetime

def process_excel_file(input_file, output_dir='../output'):
    """
    处理Excel文件：读取数据生成CSV，并创建新的Excel文件

    参数:
    input_file: 输入的Excel文件路径
    output_dir: CSV文件输出目录

    返回:
    csv_filepath: 生成的CSV文件路径
    new_excel_filepath: 生成的新Excel文件路径
    """

    # 创建输出目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    try:
        # 1. 读取Excel文件
        print("正在读取Excel文件...")
        df = pd.read_excel(input_file)

        # 2. 删除空行（所有列都为NaN或空值的行）
        df_clean = df.dropna(how='all').reset_index(drop=True)
        print(f"找到 {len(df_clean)} 行有效数据")

        # 3. 重新计算F列和G列（确保数据正确性）
        df_clean['总重量(吨)'] = df_clean['数量'] * df_clean['单包重量(千克)'] / 1000
        df_clean['总价格（元）'] = df_clean['数量'] * df_clean['单包重量(千克)'] * df_clean['单包价格(元/千克)']

        # 4. 生成CSV文件
        base_name = os.path.splitext(os.path.basename(input_file))[0]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f"{base_name}_export_{timestamp}.csv"
        csv_filepath = os.path.join(output_dir, csv_filename)

        df_clean.to_csv(csv_filepath, index=False, encoding='utf-8-sig')
        print(f"CSV文件已生成: {csv_filepath}")

        # 5. 创建新的Excel文件
        print("正在创建新的Excel文件...")
        new_wb = openpyxl.Workbook()
        new_ws = new_wb.active
        new_ws.title = "Sheet1"

        # 6. 写入表头
        headers = list(df_clean.columns)
        for col_idx, header in enumerate(headers, 1):
            new_ws.cell(1, col_idx, value=header)

        # 添加H列表头（如果不存在）
        if len(headers) < 8:
            new_ws.cell(1, 8, value="CSV导出状态")

        # 添加I列表头 - 税费金额
        new_ws.cell(1, 9, value="税费金额")

        # 7. 写入数据行
        for row_idx, (_, row_data) in enumerate(df_clean.iterrows(), 2):
            # 写入A到G列数据
            for col_idx, value in enumerate(row_data.values, 1):
                new_ws.cell(row_idx, col_idx, value=value)

            # 8. 更新H列为"已导出"
            new_ws.cell(row_idx, 8, value="已导出")

            # 9. 在I列添加税费公式 = G列 * 2%
            new_ws.cell(row_idx, 9, value=f"=G{row_idx}*0.02")

        # 10. 保存新的Excel文件
        new_excel_filename = f"{base_name}_updated_{timestamp}.xlsx"
        new_excel_filepath = os.path.join(os.path.dirname(input_file), new_excel_filename)
        new_wb.save(new_excel_filepath)
        new_wb.close()

        print(f"新的Excel文件已生成: {new_excel_filepath}")
        print("处理完成！")

        return csv_filepath, new_excel_filepath

    except FileNotFoundError:
        print(f"错误：找不到文件 '{input_file}'，请检查文件路径是否正确")
        return None, None
    except Exception as e:
        print(f"处理过程中出现错误: {str(e)}")
        return None, None

def main():
    """
    主函数：用户交互界面
    """
    print("=== Excel文件处理程序 ===")
    print("功能说明：")
    print("1. 读取Excel文件并生成CSV")
    print("2. 跳过空行，确保数据完整性")
    print("3. 重新计算总重量和总价格")
    print("4. 创建新的Excel文件，更新导出状态并添加税费计算")
    print()

    # 获取用户输入文件路径
    input_file = input("请输入Excel文件路径（或直接拖拽文件到此处）: ").strip().strip('"')

    # 检查文件是否存在
    if not os.path.exists(input_file):
        print(f"错误：文件 '{input_file}' 不存在")
        return

    # 检查文件格式
    if not input_file.lower().endswith(('.xlsx', '.xls')):
        print("错误：请提供Excel文件（.xlsx 或 .xls 格式）")
        return

    # 处理文件
    csv_path, excel_path = process_excel_file(input_file)

    if csv_path and excel_path:
        print("\n" + "="*50)
        print("处理结果汇总：")
        print(f"✓ CSV导出文件: {csv_path}")
        print(f"✓ 更新后的Excel文件: {excel_path}")
        print("="*50)
    else:
        print("\n处理失败，请检查文件格式或联系技术支持")

# 直接调用的示例
def example_usage():
    """
    直接调用示例（如果知道具体文件路径）
    """
    # 请将下面的路径替换为您的实际Excel文件路径
    excel_file_path = "example.xlsx"  # 替换为您的文件路径

    if os.path.exists(excel_file_path):
        csv_path, excel_path = process_excel_file(excel_file_path)
        if csv_path and excel_path:
            print("处理成功！")
            print(f"CSV文件: {csv_path}")
            print(f"Excel文件: {excel_path}")
    else:
        print(f"文件 {excel_file_path} 不存在，请检查路径")

if __name__ == "__main__":
    # 自动检测运行方式
    import sys

    if len(sys.argv) > 1:
        # 命令行参数方式
        input_file = sys.argv[1]
        if os.path.exists(input_file):
            csv_path, excel_path = process_excel_file(input_file)
            if csv_path and excel_path:
                print("处理成功！")
            else:
                print("处理失败")
        else:
            print(f"文件 {input_file} 不存在")
    else:
        # 交互式方式
        main()

    # 或者取消注释下面这行来使用直接调用方式
    # example_usage()