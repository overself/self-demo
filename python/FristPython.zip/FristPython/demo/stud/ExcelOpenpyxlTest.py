import os
from datetime import datetime

import openpyxl
import pandas as pd
from openpyxl.utils.dataframe import dataframe_to_rows


def process_excel_file(input_file, output_dir='../output/'):
    # 创建输出目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    try:
        # 一、读操作 - 使用openpyxl读取以保留公式计算结果
        print("正在读取Excel文件...")
        wb = openpyxl.load_workbook(input_file, data_only=False)  # data_only=False保留公式
        ws = wb.active

        # 获取表头
        headers = [cell.value for cell in ws[1]]

        # 读取数据行，跳过空行
        data_rows = []
        valid_rows_indices = []  # 记录有效行的行号

        for row in ws.iter_rows(min_row=2, values_only=False):
            # 检查是否为空行（A到H列都没有数据）
            is_empty = True
            for cell in row[:8]:  # 只检查A到H列
                if cell.value is not None and str(cell.value).strip() != '':
                    is_empty = False
                    break

            if not is_empty:
                # 获取单元格值，对于公式列使用计算后的值
                row_data = []
                for cell in row[:8]:  # 只处理A到H列
                    # if cell.column_letter in ['F', 'G'] and cell.data_type == 'f':
                    if cell.data_type == 'f':
                        # 对于公式列，获取计算后的值
                        ws_temp = openpyxl.load_workbook(input_file, data_only=True)
                        ws_temp_active = ws_temp.active
                        calculated_value = ws_temp_active.cell(row=cell.row, column=cell.column).value
                        row_data.append(calculated_value)
                        ws_temp.close()
                    else:
                        row_data.append(cell.value)
                data_rows.append(row_data)
                valid_rows_indices.append(row[0].row)  # 记录行号

        # 创建DataFrame
        df = pd.DataFrame(data_rows, columns=headers[:8])

        # 生成CSV文件名（基于Excel文件名）
        base_name = os.path.splitext(os.path.basename(input_file))[0]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f"{base_name}_export_{timestamp}.csv"
        csv_filepath = os.path.join(output_dir, csv_filename)

        # 导出到CSV
        print(f"正在导出数据到CSV文件: {csv_filename}")
        df.to_csv(csv_filepath, index=False, encoding='utf-8-sig')
        print(f"CSV文件已生成: {csv_filepath}")

        # 二、写操作 - 创建新的Excel文件
        print("正在创建新的Excel文件...")

        # 创建新的工作簿
        new_wb = openpyxl.Workbook()
        new_ws = new_wb.active

        # 复制原表头
        for col_idx, header in enumerate(headers, 1):
            new_ws.cell(1, col_idx, value=header)

        # 添加I列表头 - 税费金额
        new_ws.cell(1, 9, value="税费金额")

        # 复制数据并更新状态
        for row_idx, (data_row, original_row_num) in enumerate(zip(data_rows, valid_rows_indices), start=2):
            # 复制A到G列数据
            for col_idx, value in enumerate(data_row, 1):
                new_ws.cell(row_idx, col_idx, value=value)

            # 更新H列为"已导出"
            new_ws.cell(row_idx, 8, value="已导出")

            # 在I列添加税费公式 =G列*2%
            g_column_letter = openpyxl.utils.get_column_letter(7)  # G列
            formula = f"={g_column_letter}{row_idx}*0.02"
            new_ws.cell(row_idx, 9, value=formula)

        # 生成新的Excel文件名
        new_excel_filename = f"{base_name}_updated_{timestamp}.xlsx"
        new_excel_filepath = os.path.join(output_dir, new_excel_filename)

        # 保存新的Excel文件
        new_wb.save(new_excel_filepath)
        new_wb.close()
        wb.close()

        print(f"新的Excel文件已生成: {new_excel_filepath}")
        print("处理完成！")

        return csv_filepath, new_excel_filepath

    except Exception as e:
        print(f"处理过程中出现错误: {str(e)}")
        return None, None


def process_excel_file_optimized(input_file, output_dir='../output/'):
    """
    优化版本：正确处理空行，保留F列和G列的原有公式
    """

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    try:
        # 第一次读取：获取公式的计算结果（用于CSV导出）
        print("第一次读取：获取公式计算结果...")
        wb_calculated = openpyxl.load_workbook(input_file, data_only=True)
        ws_calculated = wb_calculated.active

        # 第二次读取：保留公式结构（用于创建新Excel）
        print("第二次读取：保留公式结构...")
        wb_formulas = openpyxl.load_workbook(input_file, data_only=False)
        ws_formulas = wb_formulas.active

        # 获取表头
        headers = [cell.value for cell in ws_formulas[1]]

        # 存储有效行的数据和公式信息
        valid_rows_data = []  # 存储每行的数据和公式信息

        for row_idx, (row_formulas, row_calculated) in enumerate(zip(
                ws_formulas.iter_rows(min_row=2, values_only=False),
                ws_calculated.iter_rows(min_row=2, values_only=False)
        ), start=2):

            # 检查是否为空行（A到H列都没有数据）
            is_empty = True
            for cell in row_formulas[:8]:
                if cell.value is not None and str(cell.value).strip() != '':
                    is_empty = False
                    break

            if not is_empty:
                # 收集这行的所有信息
                row_info = {
                    'original_row_idx': row_idx,
                    'values': [cell.value for cell in row_calculated[:8]],  # 计算后的值（CSV用）
                    'formulas': {},  # 存储公式
                    'raw_cells': row_formulas[:8]  # 原始单元格对象
                }

                # 提取公式信息
                for col_idx, cell in enumerate(row_formulas[:8], 1):
                    if cell.data_type == 'f':  # 如果是公式
                        row_info['formulas'][col_idx] = cell.value

                valid_rows_data.append(row_info)

        # 导出CSV
        data_for_csv = [row_info['values'] for row_info in valid_rows_data]
        df_csv = pd.DataFrame(data_for_csv, columns=headers[:8])

        base_name = os.path.splitext(os.path.basename(input_file))[0]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f"{base_name}_export_{timestamp}.csv"
        csv_filepath = os.path.join(output_dir, csv_filename)

        df_csv.to_csv(csv_filepath, index=False, encoding='utf-8-sig')
        print(f"CSV文件已生成: {csv_filepath}")
        print(f"共处理 {len(valid_rows_data)} 行有效数据")

        # 创建新的Excel文件（保留原有公式）
        print("正在创建新的Excel文件（保留公式）...")
        new_wb = openpyxl.Workbook()
        new_ws = new_wb.active

        # 复制表头
        for col_idx, header in enumerate(headers, 1):
            new_ws.cell(1, col_idx, value=header)

        # 添加税费列表头（I列）
        new_ws.cell(1, 9, value="税费金额")

        # 复制数据并保留原有公式
        for new_row_idx, row_info in enumerate(valid_rows_data, start=2):
            original_row_idx = row_info['original_row_idx']

            # 复制A到G列数据，保留原有公式
            for col_idx in range(1, 8):  # A到G列
                if col_idx in row_info['formulas']:
                    # 保留原有公式
                    original_formula = row_info['formulas'][col_idx]
                    # 修正公式中的行引用
                    corrected_formula = adjust_formula_references(original_formula, original_row_idx, new_row_idx)
                    new_ws.cell(new_row_idx, col_idx, value=corrected_formula)
                else:
                    # 复制普通值
                    cell_value = row_info['raw_cells'][col_idx - 1].value
                    new_ws.cell(new_row_idx, col_idx, value=cell_value)

            # 更新H列为"已导出"
            new_ws.cell(new_row_idx, 8, value="已导出")

            # 在I列添加税费公式 = G列 * 2%
            new_ws.cell(new_row_idx, 9, value=f"=G{new_row_idx}*0.02")

        # 保存新的Excel文件
        new_excel_filename = f"{base_name}_updated_{timestamp}.xlsx"
        new_excel_filepath = os.path.join(output_dir, new_excel_filename)
        new_wb.save(new_excel_filepath)

        # 关闭所有工作簿
        wb_calculated.close()
        wb_formulas.close()
        new_wb.close()

        print(f"新的Excel文件已生成: {new_excel_filepath}")
        print("✓ F列和G列保留了原有公式")
        print("✓ 公式行引用已正确调整")
        return csv_filepath, new_excel_filepath

    except Exception as e:
        print(f"处理过程中出现错误: {str(e)}")
        return None, None


def process_excel_single_read(input_file, output_dir='../output/'):
    """
    单次读取方案：正确处理空行，保留公式
    """

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    try:
        # 读取Excel文件，不计算公式（保留公式文本）
        print("读取Excel文件（保留公式）...")
        wb = openpyxl.load_workbook(input_file, data_only=False)
        ws = wb.active

        # 获取表头
        headers = [cell.value for cell in ws[1]]

        # 存储有效行的信息
        valid_rows_info = []

        # 首先扫描所有行，记录有效行信息
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=False), start=2):
            # 检查是否为空行
            is_empty = True
            for cell in row[:8]:
                if cell.value is not None and str(cell.value).strip() != '':
                    is_empty = False
                    break

            if not is_empty:
                row_info = {
                    'original_row_idx': row_idx,
                    'cells': row[:8],
                    'formulas': {}
                }

                # 记录公式信息
                for col_idx, cell in enumerate(row[:8], 1):
                    if cell.data_type == 'f':
                        row_info['formulas'][col_idx] = cell.value

                valid_rows_info.append(row_info)

        # 获取计算值用于CSV导出
        print("获取计算值用于CSV导出...")
        wb_calculated = openpyxl.load_workbook(input_file, data_only=True)
        ws_calculated = wb_calculated.active

        data_for_csv = []
        for row_info in valid_rows_info:
            original_row_idx = row_info['original_row_idx']
            calculated_row = ws_calculated[original_row_idx]
            row_values = [cell.value for cell in calculated_row[:8]]
            data_for_csv.append(row_values)

        wb_calculated.close()

        # 导出CSV
        df_csv = pd.DataFrame(data_for_csv, columns=headers[:8])

        base_name = os.path.splitext(os.path.basename(input_file))[0]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f"{base_name}_export_{timestamp}.csv"
        csv_filepath = os.path.join(output_dir, csv_filename)

        df_csv.to_csv(csv_filepath, index=False, encoding='utf-8-sig')
        print(f"CSV文件已生成: {csv_filepath}")
        print(f"共处理 {len(valid_rows_info)} 行有效数据")

        # 创建新的Excel文件
        print("正在创建新的Excel文件...")
        new_wb = openpyxl.Workbook()
        new_ws = new_wb.active

        # 复制表头
        for col_idx, header in enumerate(headers, 1):
            new_ws.cell(1, col_idx, value=header)
        new_ws.cell(1, 9, value="税费金额")

        # 复制数据并保留公式（修正行引用）
        for new_row_idx, row_info in enumerate(valid_rows_info, start=2):
            original_row_idx = row_info['original_row_idx']

            # 复制A到G列数据
            for col_idx in range(1, 8):  # A到G列
                original_cell = row_info['cells'][col_idx - 1]

                if col_idx in row_info['formulas']:
                    # 处理公式：修正行引用
                    original_formula = row_info['formulas'][col_idx]
                    corrected_formula = adjust_formula_references(original_formula, original_row_idx, new_row_idx)
                    new_ws.cell(new_row_idx, col_idx, value=corrected_formula)
                else:
                    # 复制普通值
                    new_ws.cell(new_row_idx, col_idx, value=original_cell.value)

            # 更新H列为"已导出"
            new_ws.cell(new_row_idx, 8, value="已导出")

            # 在I列添加税费公式 = G列 * 2%
            new_ws.cell(new_row_idx, 9, value=f"=G{new_row_idx}*0.02")

        # 保存新的Excel文件
        new_excel_filename = f"{base_name}_updated_{timestamp}.xlsx"
        new_excel_filepath = os.path.join(output_dir, new_excel_filename)
        new_wb.save(new_excel_filepath)
        wb.close()
        new_wb.close()

        print(f"新的Excel文件已生成: {new_excel_filepath}")
        print("✓ F列和G列保留了原有公式")
        print("✓ 公式行引用已正确调整")
        return csv_filepath, new_excel_filepath

    except Exception as e:
        print(f"处理过程中出现错误: {str(e)}")
        return None, None


def adjust_formula_references(formula, original_row, new_row):
    """
    调整公式中的行引用，从原始行号调整到新行号
    参数:
    formula: 原始公式字符串
    original_row: 原始行号
    new_row: 新行号
    返回:
    调整后的公式字符串
    """
    if not formula or not formula.startswith('='):
        return formula

    # 简单的行引用调整逻辑
    # 将公式中所有的"原始行"引用替换为"新行"引用
    import re

    # 匹配Excel单元格引用模式：字母+数字，如A2, C10, $G$5等
    pattern = r'([A-Z]{1,3})(\$?)(\d+)'

    def replace_row_ref(match):
        col_letter = match.group(1)  # 列字母
        dollar_sign = match.group(2)  # $符号（如果有）
        row_num = int(match.group(3))  # 行号

        # 如果这个行号匹配原始行号，就替换为新行号
        if row_num == original_row:
            return f"{col_letter}{dollar_sign}{new_row}"
        else:
            # 保持原样（可能是引用其他行的公式）
            return match.group(0)

    # 应用替换
    adjusted_formula = re.sub(pattern, replace_row_ref, formula)

    return adjusted_formula


# 使用示例
if __name__ == "__main__":
    # 指定您的Excel文件路径
    excel_file = "验证数据模板.xlsx"  # 请替换为您的实际文件路径
    out_dir = "../output/"
    print()
    print("\n=== Excel文件处理程序 ===")
    # csv_path, updated_excel_path = process_excel_file(excel_file, out_dir)
    csv_path, updated_excel_path = process_excel_single_read(excel_file, out_dir)
    # csv_path, updated_excel_path = process_excel_file_optimized(excel_file, out_dir)
    if csv_path and updated_excel_path:
        print(f"\n处理结果:")
        print(f"CSV文件: {csv_path}")
        print(f"新的Excel文件: {updated_excel_path}")
    else:
        print("处理失败，请检查文件路径和格式")
