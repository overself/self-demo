export const NodeService = {
    getTreeNodesData() {
        return fetch('/demo/data/treenodes.json').then((response) => {return response.json()});
    },

    getTreeTableNodesData() {
        return fetch('/demo/data/treetablenodes.json').then((response) => {return response.json()});
    },

    getTreeTableNodes() {
        return Promise.resolve(this.getTreeTableNodesData());
    },

    getTreeNodes() {
        return Promise.resolve(this.getTreeNodesData());
    }
};
