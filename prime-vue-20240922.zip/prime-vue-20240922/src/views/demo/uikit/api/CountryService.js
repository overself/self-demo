export const CountryService = {
    getData() {
        return fetch('/demo/data/countries.json').then((response) => {return response.json()});
    },

    getCountries() {
        return Promise.resolve(this.getData());
    }
};
