export const PhotoService = {
    getData() {
        return fetch('/demo/data/photos.json').then((response) => {return response.json()});
    },

    getImages() {
        return Promise.resolve(this.getData());
    }
};
