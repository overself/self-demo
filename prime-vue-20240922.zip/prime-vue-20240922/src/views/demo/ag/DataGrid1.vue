<script setup>
import { onMounted, ref } from 'vue';
import { title } from '@/i18n';

const themeClass = 'ag-theme-quartz';

const columnDefs = ref([
    { field: 'country', headerName: title('biz.olympic.country'), width: 150 },
    { field: 'athlete', headerName: title('biz.olympic.athlete'), minWidth: 170 },
    { field: 'age', headerName: title('biz.olympic.age'), width: 80 },
    { field: 'year', headerName: title('biz.olympic.year'), width: 80 },
    { field: 'date', headerName: title('biz.olympic.date'), width: 110 },
    { field: 'sport', headerName: title('biz.olympic.sport'), width: 150 },
    { field: 'gold', headerName: title('biz.olympic.gold'), width: 120 },
    { field: 'silver', headerName: title('biz.olympic.silver'), width: 120 },
    { field: 'bronze', headerName: title('biz.olympic.bronze'), width: 120 },
    { field: 'total', headerName: title('biz.olympic.total'), width: 80 }
]);

const rowData = ref([]);
const defaultColDef = ref({
    editable: false,
    filter: true
});

// Fetch data when the component is mounted
onMounted(async () => {
    rowData.value = await fetchData();
});

const fetchData = async () => {
    const response = await fetch('/demo/grid/olympic-winners.json');
    return response.json();
};

const selection = ref({
    mode: 'multiRow',
    headerCheckbox: true
});

// 动态计算 Ag-Grid 国际化文本
// const localeText = ref(getAgTitles());
</script>

<template>
    <div class="card" style="height: 100%">
        <ag-grid-vue
            style="width: auto; height:25rem;"
            :class="themeClass"
            :columnDefs="columnDefs"
            :pagination="true"
            :rowData="rowData"
            :selection="selection"
            :locale-text="$AgGrid.localeText"
            :defaultColDef="defaultColDef"></ag-grid-vue>
    </div>
</template>

<style scoped lang="scss">

</style>
