<script setup>
import { columnDefs, defaultColDef, rowClassRules, rowData, selection } from '@/views/demo/ag/DataGrid3';
import { defineComponent, onBeforeMount, ref, shallowRef } from 'vue';


// eslint-disable-next-line no-import-assign
const CustomButtonComponent = defineComponent("CustomButtonComponent",{
    template: `
        <div>
            <button v-on:click="buttonClicked">Push Me!</button>
        </div>
    `,
    methods: {
        buttonClicked() {
            alert("clicked");
        },
    },
});

const gridApi = shallowRef();
const paginationPageSize = ref(10);
const paginationPageSizeSelector = ref([10, 25, 50]);

const themeClass = 'ag-theme-balham';

onBeforeMount(() => {
    //console.log(rowData.value);
});

const onGridReady = (params) => {
    gridApi.value = params.api;
};

</script>

<template>
    <div class="card" style="height: 100%">
        <ag-grid-vue
            style="width: 100%; height: 25rem;"
            :class="themeClass"
            :locale-text="$AgGrid.localeText"
            :rowClassRules="rowClassRules"
            :columnDefs="columnDefs"
            @grid-ready="onGridReady"
            :rowData="rowData"
            :defaultColDef="defaultColDef"
            :selection="selection"
            :pagination="true"
            :paginationPageSize="paginationPageSize"
            :paginationPageSizeSelector="paginationPageSizeSelector">
        </ag-grid-vue>
    </div>
</template>

<style>
.rag-red {
    background-color: #cc222244;
}

.rag-green {
    background-color: #33cc3344;
}
</style>
