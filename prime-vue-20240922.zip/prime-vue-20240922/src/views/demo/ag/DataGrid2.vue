<script setup>
import { defineAsyncComponent, onBeforeMount, ref, resolveDynamicComponent, shallowRef } from 'vue';
import { title } from '@/i18n';
// 自定义渲染器
const CompanyLogoRenderer = defineAsyncComponent({
    template: `
        <span style="display: flex; height: 100%; width: 100%; align-items: center;">
      <img :src="'https://www.ag-grid.com/example-assets/space-company-logos/' + cellValueLowerCase + '.png'"
           style="display: block; width: 25px; height: auto; max-height: 50%; margin-right: 12px; filter: brightness(1.1);" />
      <p style="text-overflow: ellipsis; overflow: hidden; white-space: nowrap;">{{ cellValue }}</p>
    </span>
    `,
    props: ['params'],
    computed: {
        cellValue() {
            return this.params.value;
        },
        cellValueLowerCase() {
            return this.cellValue.toLowerCase();
        }
    }
});

const MissionResultRenderer = defineAsyncComponent({
    template: `
        <span style="display: flex; justify-content: center; height: 100%; align-items: center;">
	      <img
              :alt="params.value"
              :src="'https://www.ag-grid.com/example-assets/icons/' + cellValue + '.png'"
              style="width: auto; height: auto;"
          />
	    </span>
    `,
    setup(props) {
        const cellValue = props.params.value ? 'tick-in-circle' : 'cross-in-circle';
        return {
            cellValue
        };
    }
});

resolveDynamicComponent('companyLogoRenderer', CompanyLogoRenderer);
resolveDynamicComponent('missionResultRenderer', MissionResultRenderer);

const themeClass = 'ag-theme-balham';

const rowData = ref([]);
const dateFormatter = (params) => {
    return new Date(params.value).toLocaleDateString('en-us', {
        weekday: 'long',
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
};

function onCellValueChanged(event) {
    console.log(`New Cell Value: ${event.value}`);
}

function onSelectionChanged(event) {
    console.log('Row Selection Event!');
}

const colDefs = ref([
    {
        field: 'mission',
        headerName: title('biz.spaceMission.mission'),
        width: 150
    },
    {
        field: 'company',
        headerName: title('biz.spaceMission.company'),
        width: 130,
        cellRenderer: 'companyLogoRenderer'
    },
    {
        field: 'location',
        headerName: title('biz.spaceMission.location'),
        width: 225
    },
    {
        field: 'date',
        headerName: title('biz.spaceMission.date'),
        valueFormatter: dateFormatter
    },
    {
        field: 'price',
        headerName: title('biz.spaceMission.price'),
        width: 130,
        valueFormatter: (params) => {
            return '£' + params.value.toLocaleString();
        }
    },
    {
        field: 'successful',
        headerName: title('biz.spaceMission.successful'),
        width: 120,
        cellRenderer: 'missionResultRenderer'
    },
    {
        field: 'rocket',
        headerName: title('biz.spaceMission.rocket')
    }
]);

const selection = ref({
    mode: 'multiRow',
    headerCheckbox: true
});

const defaultColDef = ref({
    filter: true,
    editable: true
});

onBeforeMount(() => {
});

// Fetch data when the component is mounted
const onGridReady = () => {
    const updateData = (data) => (rowData.value = data);
    fetch('/demo/grid/space-mission-data.json')
        .then((resp) => resp.json())
        .then((data) => updateData(data));
};

// 动态计算 Ag-Grid 国际化文本
// const localeText = ref(getAgTitles());
</script>

<template>
    <div class="card" style="height: 100%">
        <ag-grid-vue
            style="auto; height:25rem;"
            :class="themeClass"
            :rowData="rowData"
            :columnDefs="colDefs"
            :defaultColDef="defaultColDef"
            :pagination="true"
            :selection="selection"
            :locale-text="$AgGrid.localeText"
            @grid-ready="onGridReady"
            @cell-value-changed="onCellValueChanged"
            @selection-changed="onSelectionChanged"
        >
        </ag-grid-vue>
    </div>
</template>

<style scoped lang="scss">

</style>
