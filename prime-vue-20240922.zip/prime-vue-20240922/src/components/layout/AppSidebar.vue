<script setup>
import AppMenu from '../menu/AppMenu.vue';
import { useLayout } from '@/components/layout/composables/layout';
const { isDrawerMenu, onMenuToggle } = useLayout();
const handleMouseEnterLeave = () => {
    if (isDrawerMenu.value) {
        setTimeout(() => {
            onMenuToggle();
        }, 50);
    }
};
</script>

<template>
    <div class="layout-sidebar" @mouseenter="handleMouseEnterLeave" @mouseleave="handleMouseEnterLeave">
        <app-menu></app-menu>
    </div>
</template>

<style lang="scss" scoped></style>
