import { createApp, reactive } from 'vue';
import App from '@/App.vue';
import router from '@/router';

import Aura from '@primevue/themes/aura';
import PrimeVue from 'primevue/config';
import ConfirmationService from 'primevue/confirmationservice';
import ToastService from 'primevue/toastservice';
import i18n, { getAgTitles } from '@/i18n';
import { AgGridVue } from 'ag-grid-vue3';
import { createPinia } from 'pinia';

import '@/assets/styles.scss';
import '@/assets/tailwind.css';

const app = createApp(App);
const pinia = createPinia();

// Vue Routers
app.use(router);

// PrimeVue UI custom
app.use(PrimeVue, {
    theme: {
        preset: Aura,
        options: {
            darkModeSelector: '.app-dark'
        }
    }
});
app.use(ToastService);
app.use(ConfirmationService);

app.use(i18n);
app.use(pinia);
app.provide('i18n', i18n);

// AG Grid import
app.component('ag-grid-vue', AgGridVue);
// AG Grid 国际化支持
app.config.globalProperties.$AgGrid = reactive({
    localeText: getAgTitles(),
    themeClass: 'ag-theme-balham'
});

// APP amount
app.mount('#app');
