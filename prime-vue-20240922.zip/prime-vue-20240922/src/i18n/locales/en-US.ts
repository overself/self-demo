export const PRIME_UI_LOCALE_EN = {
    common: {
        topBar: {
            langEn: 'English',
            langZh: '简体中文',
            langJa: '日本語',
            langKo: '한국어'
        },
        menu: {
            agGrid: 'Ag Grid Demo',
            agGridDisplay: 'AgGrid Display',
            agGridEdit: 'AgGrid Edit',
            agGridSample: 'AgGrid Sample'
        }
    },
    biz: {
        olympic: {
            country: 'Country',
            athlete: 'Athlete',
            age: 'Age',
            year: 'Year',
            date: 'Date',
            sport: 'Sport',
            gold: 'Gold',
            silver: 'Silver',
            bronze: 'Bronze',
            total: 'Total'
        },
        spaceMission: {
            mission: 'Mission',
            company: 'Company',
            location: 'Location',
            date: 'Date',
            price: 'Price',
            successful: 'Successful',
            rocket: 'Rocket',
        }
    }
};
