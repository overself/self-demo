export const PRIME_UI_LOCALE_JP = {
    common: {
        topBar:{
            langEn: 'English',
            langZh: '简体中文',
            langJa: '日本語',
            langKo: '한국어',
        },
        menu: {
            agGrid:'Ag Grid サンプル',
            agGridDisplay:'AgGrid表示リスト',
            agGridEdit:'AgGrid編集リスト',
            agGridSample:'AgGridサンプルリスト',
        }
    },
    biz:{
        olympic:{
            country: '国',
            athlete: '選手',
            age: '年齢',
            year: '年',
            date: '日付',
            sport: 'スポーツ',
            gold: '金メダル',
            silver: '銀メダル',
            bronze: '銅メダル',
            total: '合計'
        },
        spaceMission: {
            mission: '使命',
            company: '会社',
            location: '場所',
            date: '日付',
            price: '価格',
            successful: '成功',
            rocket: 'ロヶット',
        }
    }
}
