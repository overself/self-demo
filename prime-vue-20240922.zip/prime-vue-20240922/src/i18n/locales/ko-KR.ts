export const PRIME_UI_LOCALE_KR = {
    common: {
        topBar:{
            langEn: 'English',
            langZh: '简体中文',
            langJa: '日本語',
            langKo: '한국어',
        },
        menu: {
            agGrid:'Ag-Grid 프레젠테이션',
            agGridDisplay:'AgGrid 모니터',
            agGridEdit:'AgGrid 편집',
            agGridSample:'AgGrid 샘플',
        }
    },
    biz:{
        olympic:{
            country: '국가',
            athlete: '운동선수',
            age: '나이',
            year: '년도',
            date: '날짜',
            sport: '스포츠 종목',
            gold: '금메달',
            silver: '은메달',
            bronze: '동메달',
            total: '합계',
        },
        spaceMission: {
            mission: '사명',
            company: '단위',
            location: '장소',
            date: '날짜',
            price: '가격',
            successful: '성공',
            rocket: '로켓',
        }
    }
}
