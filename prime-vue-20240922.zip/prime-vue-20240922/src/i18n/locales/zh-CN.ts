export const PRIME_UI_LOCALE_CN = {
    common: {
        topBar: {
            langEn: 'English',
            langZh: '简体中文',
            langJa: '日本語',
            langKo: '한국어'
        },
        menu: {
            agGrid: 'Ag Grid 示例',
            agGridDisplay: 'AgGrid查看列表',
            agGridEdit: 'AgGrid可编辑列表',
            agGridSample: 'AgGrid综合示例'
        }
    },
    biz: {
        olympic: {
            country: '国家',
            athlete: '运动员',
            age: '年龄',
            year: '年份',
            date: '日期',
            sport: '体育项目',
            gold: '金牌',
            silver: '银牌',
            bronze: '铜牌',
            total: '总计'
        },
        spaceMission: {
            mission: '使命',
            company: '公司',
            location: '地点',
            date: '日期',
            price: '价格',
            successful: '成功',
            rocket: '火箭'
        }
    }
};
