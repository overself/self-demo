import { createI18n } from 'vue-i18n';
import { computed } from 'vue';
import { cacheRead, cacheSave } from '@/libs/common/utils';
import { AG_GRID_LOCALE_EN } from './ag/en-US';
import { AG_GRID_LOCALE_JP } from './ag/ja-JP';
import { AG_GRID_LOCALE_KR } from './ag/ko-KR';
import { AG_GRID_LOCALE_CN } from './ag/zh-CN';
import { PRIME_UI_LOCALE_EN } from './locales/en-US';
import { PRIME_UI_LOCALE_JP } from './locales/ja-JP';
import { PRIME_UI_LOCALE_KR } from './locales/ko-KR';
import { PRIME_UI_LOCALE_CN } from './locales/zh-CN';

// 组合语言包
const LOCALE_MESSAGE = {
    'zh-CN': {
        ...AG_GRID_LOCALE_CN,
        ...PRIME_UI_LOCALE_CN
    },
    'en-US': {
        ...AG_GRID_LOCALE_EN,
        ...PRIME_UI_LOCALE_EN
    },
    'ja-JP': {
        ...AG_GRID_LOCALE_JP,
        ...PRIME_UI_LOCALE_JP
    },
    'ko-KR': {
        ...AG_GRID_LOCALE_KR,
        ...PRIME_UI_LOCALE_KR
    }
};

export const getLocalLang = () => {
    return cacheRead('local_lang');
};

// 通过选项创建 VueI18n 实例，获取浏览器语言
//const lang = getLocalLang() || (navigator.language || navigator.browserLanguage).toLowerCase();
const lang = getLocalLang() || (navigator.language || navigator.browserLanguage);
const i18n = new createI18n({
    fallbackLocale: 'en-US',
    locale: lang, // 设置地区
    messages: { ...LOCALE_MESSAGE }, // 设置地区信息
    legacy: false, // 如果要支持compositionAPI，此项必须设置为false;
    globalInjection: true // 全局注册$t方法
});

export const changeLocalLang = (localLang) => {
    i18n.global.locale.value = localLang;
    cacheSave('local_lang', localLang);
};

export const getLocaleTitles = () => {
    return i18n.global.messages.value[i18n.global.locale.value];
};
export const getAgTitles = () => {
    //动态计算 国际化文本
    return computed(() => i18n.global.messages.value[i18n.global.locale.value]);
};

export const title = (key) => {
    //动态计算 国际化文本
    return computed(() => i18n.global.t(key));
};

export default i18n;
