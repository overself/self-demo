# vue-js-demo

This template should help get you started developing with Vue 3 in Vite.

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```

### 介绍说明

- 1） ESLint

官网： https://zh-hans.eslint.org/

ESLint 是一个开源项目，可以帮助你发现并修复 JavaScript 代码中的问题。 不论你的 JavaScript 是在浏览器还是在服务器，是否使用框架，ESLint 都可以帮助你的代码变得更好。

- 2） editorconfig

  .editorconfig 文件用于定义编辑器的配置，以确保在不同的开发环境中代码的一致性。例如，它可以定义缩进、换行符、字符集等细节。编辑器和IDE可以通过插件或内置功能来支持.editorconfig文件。

- 3） postcss

PostCSS是一个使用 JavaScript 插件来转换 CSS 的工具。这些插件可以检查（lint）你的 CSS、支持变量、混合ins 和其他高级功能、 polyfill 新功能、 minify CSS 代码等等。

Vue 项目中通常会使用 PostCSS 的预设 postcss-loader 来处理 .vue 文件中的 <style> 标签内的 CSS。

- 4） Autoprefixer

Autoprefixer是一款自动管理浏览器前缀的插件，它可以解析CSS文件并且添加浏览器前缀到CSS内容里，主要用于处理兼容性问题
