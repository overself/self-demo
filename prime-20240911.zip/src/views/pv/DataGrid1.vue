<script setup>

</script>

<template>
    <div style="height: 30rem">
        PrimeUI Gird1 做成中。。。。。
    </div>
</template>

<style scoped lang="scss">

</style>
