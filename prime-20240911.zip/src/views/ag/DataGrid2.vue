<script setup>
import { onBeforeMount, ref, shallowRef } from 'vue';
import { AgGridVue } from 'ag-grid-vue3';

const columnDefs = ref([
    { field: 'country' },
    { field: 'athlete', minWidth: 170 },
    { field: 'age' },
    { field: 'year' },
    { field: 'date' },
    { field: 'sport' },
    { field: 'gold' },
    { field: 'silver' },
    { field: 'bronze' },
    { field: 'total' }
]);
const gridApi = shallowRef();
const defaultColDef = ref({
    editable: true,
    filter: true
});
const rowData = ref(null);
const themeClass = 'ag-theme-quartz';
onBeforeMount(() => {
});

const onGridReady = (params) => {
    gridApi.value = params.api;
    const updateData = (data) => (rowData.value = data);
    //fetch('https://www.ag-grid.com/example-assets/olympic-winners.json')
    fetch('/demo/gird/olympic-winners.json')
        .then((resp) => resp.json())
        .then((data) => updateData(data));
};

</script>

<template>
    <div style="height: 30rem">
        <ag-grid-vue
            style="width: 100%; height:25rem;"
            :class="themeClass"
            :columnDefs="columnDefs"
            @grid-ready="onGridReady"
            :rowData="rowData"
            :defaultColDef="defaultColDef"></ag-grid-vue>
    </div>
</template>

<style scoped lang="scss">

</style>
