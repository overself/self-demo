<script setup>
import { onMounted, ref } from 'vue';
import { AgGridVue } from 'ag-grid-vue3';

const themeClass = 'ag-theme-quartz';

const columnDefs = ref([
    { field: 'country' },
    { field: 'athlete', minWidth: 170 },
    { field: 'age' },
    { field: 'year' },
    { field: 'date' },
    { field: 'sport' },
    { field: 'gold' },
    { field: 'silver' },
    { field: 'bronze' },
    { field: 'total' }
]);

const rowData = ref([]);
const defaultColDef = ref({
    editable: false,
    filter: true
});

// Fetch data when the component is mounted
onMounted(async () => {
    rowData.value = await fetchData();
});

const fetchData = async () => {
    const response = await fetch('/demo/gird/olympic-winners.json');
    return response.json();
};

</script>

<template>
    <div style="height: 30rem">
        <ag-grid-vue
            style="width: 100%; height:25rem;"
            :class="themeClass"
            :columnDefs="columnDefs"
            :rowData="rowData"
            :defaultColDef="defaultColDef"></ag-grid-vue>
    </div>
</template>

<style scoped lang="scss">

</style>
