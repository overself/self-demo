import { createApp } from 'vue';
import App from './App.vue';
import router from './router';

import Aura from '@primevue/themes/aura';
import PrimeVue from 'primevue/config';
import ConfirmationService from 'primevue/confirmationservice';
import ToastService from 'primevue/toastservice';
import LOCALE_MESSAGE from './i18n';
import { createI18n } from 'vue-i18n';
import { AgGridVue } from 'ag-grid-vue3';

import '@/assets/styles.scss';
import '@/assets/tailwind.css';

const app = createApp(App);

// Vue Routers
app.use(router);

// 国际化导入
// 通过选项创建 VueI18n 实例
// 获取浏览器语言
const preferredLang = localStorage.getItem('preferred_lang');
console.log('preferredLang=', preferredLang);
const lang = preferredLang || (navigator.language || navigator.browserLanguage).toLowerCase();
console.log('lang=', lang);
console.log('lang.substring=', lang.substring(0, 2));

const i18n = new createI18n({
    fallbackLocale: 'en', // 设置备用语言
    locale: lang.substring(0, 2), // 设置地区
    messages: { ...LOCALE_MESSAGE }, // 设置地区信息
    legacy: false, // 如果要支持compositionAPI，此项必须设置为false;
    globalInjection: true // 全局注册$t方法
});
app.use(i18n);

// PrimeVue UI custom
app.use(PrimeVue, {
    theme: {
        preset: Aura,
        options: {
            darkModeSelector: '.app-dark'
        }
    }
});
app.use(ToastService);
app.use(ConfirmationService);

// AG Grid import
app.component('ag-grid-vue', AgGridVue);

app.config.globalProperties.$AgGrid = {
    localeText: LOCALE_MESSAGE.jp
};

// APP amount
app.mount('#app');
