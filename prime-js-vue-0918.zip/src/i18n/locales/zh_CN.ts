export const PRIME_UI_LOCALE_CN = {
    "views.pv.000001": "个人中心",
    "views.pv.000002": "退出",
    "views.pv.000003": "首页"
}
