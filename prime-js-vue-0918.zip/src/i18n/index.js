import { AG_GRID_LOCALE_EN } from './ag/en-US';
import { AG_GRID_LOCALE_JP } from './ag/ja-JP';
import { AG_GRID_LOCALE_KR } from './ag/ko-KR';
import { AG_GRID_LOCALE_CN } from './ag/zh-CN';
import { PRIME_UI_LOCALE_EN } from './locales/en_US';
import { PRIME_UI_LOCALE_CN } from './locales/zh_CN';
import { PRIME_UI_LOCALE_JP } from './locales/ja_JP';
import { PRIME_UI_LOCALE_KR } from './locales/ko_KR';

// 组合语言包
const LOCALE_MESSAGE = {
    zh: {
        ...AG_GRID_LOCALE_CN,
        ...PRIME_UI_LOCALE_CN,
    },
    en: {
        ...AG_GRID_LOCALE_EN,
        ...PRIME_UI_LOCALE_EN,
    },
    jp: {
        ...AG_GRID_LOCALE_JP,
        ...PRIME_UI_LOCALE_JP,
    },
    kr: {
        ...AG_GRID_LOCALE_KR,
        ...PRIME_UI_LOCALE_KR,
    }
};

// // 通过选项创建 VueI18n 实例
// // 获取浏览器语言
// const preferredLang = localStorage.getItem('preferred_lang');
// console.log("preferredLang=", preferredLang);
// const lang = preferredLang || (navigator.language || navigator.browserLanguage).toLowerCase();
// console.log("lang=", lang);
// console.log("lang.substring=", lang.substring(0, 2));
//
// const i18n = new createI18n({
//     locale: lang.substring(0, 2), // 设置地区
//     messages: { ...LOCALE_MESSAGE }, // 设置地区信息
//     legacy: false, // 如果要支持compositionAPI，此项必须设置为false;
//     globalInjection: true // 全局注册$t方法
// });

export default LOCALE_MESSAGE
