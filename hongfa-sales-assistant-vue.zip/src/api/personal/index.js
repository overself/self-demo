import request from '@/utils/request'

export function list(query) {
  return request({
    url: '/system/sales-task/new_list',
    method: 'get',
    params: query
  })
}

export function update(data) {
  return request({
    url: '/system/sales-task/update',
    method: 'put',
    data,
  })
}

// 更新销售任务
export function updateSalesTask(data) {
  return request({
    url: '/system/sales-task/update',
    method: 'put',
    data,
  })
}

// 根据客户类型获取客户和默认联系人精简列表
export function getCustomerContact(query) {
  return request({
    url: '/system/customer-contact/list',
    method: 'get',
    params: query
  })
}

// 销售任务-获得客户的销售量
export function getCustomerSales(query) {
  return request({
    url: '/system/sales-task/customer/sales',
    method: 'get',
    params: query
  })
}

// 获取计划完成度和环比同比
export function getSalesKanban(query) {
  return request({
    url: '/system/sales-task/kanban',
    method: 'get',
    params: query
  })
}

// 根据大区获得业务员列表
export function getSalesList(query) {
  return request({
    url: '/system/user/sales/list',
    method: 'get',
    params: query
  })
}

// 根据大区获得经理信息
export function getManagerInfoByArea(query) {
  return request({
    url: '/system/user/area/manager/info',
    method: 'get',
    params: query
  })
}

// 获得配置月
export function getConfigMonth() {
  return request({
    url: '/system/time-config/getConfigMonth',
    method: 'get',
  })
}
// 获得销售任务列表-客户
export function getCustomerTask(query) {
  return request({
    url: '/system/sales-task/list/customer',
    method: 'get',
    params: query
  })
}

// 新增计划
export function newUpdate(data) {
  return request({
    url: '/system/sales-task/new_update',
    method: 'put',
    data,
  })
}
//编辑获取计划
export function listDetail(query) {
  return request({
    url: '/system/sales-task/new_list_detail',
    method: 'get',
    params: query
  })
}

//获取客户数据
export function simpleList(query) {
  return request({
    url: '/system/customer/simple-list',
    method: 'get',
    params: query
  })
}

//获取大区销售计划-up上面信息
export function newListUp(query) {
  return request({
    url: '/system/sales-task/new_list_up',
    method: 'get',
    params: query
  })
}

//获取大区销售计划-up上面信息
export function newPersonUp(query) {
  return request({
    url: '/system/sales-task/new_person_up',
    method: 'get',
    params: query
  })
}

//删除大区销售计划
export function newDel(data) {
  return request({
    url: '/system/sales-task/new_del',
    method: 'put',
    data,
  })
}
