import request from '@/utils/request'

export function systemBrief(query) {
  return request({
    url: '/system/index/systemBrief',
    method: 'get',
    params: query
  }) 
}
 //库存趋势
export function inventoryTrend(query) {
    return request({
      url: '/system/index/inventoryTrend',
      method: 'get',
      params: query
    })    
  }
 //销售计划
     export function outputPlan(query) {
        return request({
          url: '/system/index/outputPlan',
          method: 'get',
          params: query
        })    
      }
  //业绩对比
  export function copmpareAcheieve(query) {
    return request({
      url: '/system/index/dept',
      method: 'get',
      params: query
    })    
  }

   //销售趋势
  export function salesTrend(query) {
    return request({
      url: '/system/index/salesTrend',
      method: 'get',
      params: query
    })    
  }
    //渠道销量
    export function channelSales(query) {
        return request({
          url: '/system/index/channel/sales',
          method: 'get',
          params: query
        })    
      }
    
  // 客户分布
  export function customerDist(query) {
    return request({
      url: '/system/index/customerDist',
      method: 'get',
      params: query
    })    
  }
   //业绩排行TOP10
  export function performance(query) {
    return request({
      url: '/system/index/performance',
      method: 'get',
      params: query
    })    
  }
 
   