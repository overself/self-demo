import request from '@/utils/request'

// 客户预警开启关闭状态设置
export function toggleWarning(data) {
  return request({
    url: '/system/customer/warnstatus',
    method: 'put',
    data
  })
}

// 客户预警设置
export function setWarning(data) {
  return request({
    url: '/system/customer/warnset',
    method: 'put',
    data
  })
}

// 更新客户
export function updateClient(data) {
  return request({
    url: '/system/customer/update',
    method: 'put',
    data
  })
}

// 重新指派客户
export function assignClient(data) {
  return request({
    url: '/system/customer/assign',
    method: 'put',
    data
  })
}

// 获得客户分页
export function listData(query) {
  return request({
    url: '/system/customer/page',
    method: 'get',
    params: query
  })
}

// 获得客户信息
export function getClient(query) {
  return request({
    url: '/system/customer/get',
    method: 'get',
    params: query
  })
}

// 导出 Excel
export function exportExcel(query) {
  return request({
    url: '/system/customer/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 获得编辑页面使用的 客户标签
export function getClientTags(query) {
  return request({
    url: '/system/sign/simple-list',
    method: 'get',
    params: query
  })
}

// 获得编辑页面使用的 归属销售
export function getBelong(query) {
  return request({
    url: '/system/user/simple-list',
    method: 'get',
    params: query
  })
}

// 获得编辑页面使用的 渠道
export function getChannel(query) {
  return request({
    url: '/system/channel/simple-list',
    method: 'get',
    params: query
  })
}
//出库单记录
export function list(query) {
  return request({
    url: '/system/outbound-order/page',
    method: 'get',
    params: query
  })
}
//操作日志
export function logList(query) {
  return request({
    url: '/system/operate-log/page',
    method: 'get',
    params: query
  })
}
