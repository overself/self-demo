import request from '@/utils/request'

// 更新客户跟进
export function updateFollow(data) {
  return request({
    url: '/hf/customer-follow/update',
    method: 'put',
    data
  })
}

// 创建客户跟进
export function addFollow(data) {
  return request({
    url: '/hf/customer-follow/create',
    method: 'post',
    data
  })
}

// 获得客户跟进分页
export function listData(query) {
  return request({
    url: '/hf/customer-follow/page',
    method: 'get',
    params: query
  })
}

// 获得客户跟进
export function getFollow(query) {
  return request({
    url: '/hf/customer-follow/get',
    method: 'get',
    params: query
  })
}

// 删除客户跟进
export function delFollow(query) {
  return request({
    url: '/hf/customer-follow/delete',
    method: 'delete',
    params: query
  })
}
