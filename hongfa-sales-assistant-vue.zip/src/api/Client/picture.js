/*
 * @Author: LinChunpeng
 * @Date: 2024-09-09 14:36:41
 * @LastEditTime: 2024-09-11 20:36:31
 * @LastEditors: LinChunpeng
 * @Version: 1.1.2
 * @Feature:
 * @FilePath: \hongfa-sales-assistant-vue\src\api\Client\picture.js
 * 可以输入预定的版权声明、个性签名、空行等
 */
import request from '@/utils/request'

// 客户预警开启关闭状态设置
export function first(params) {
  return request({
    url: '/customer/portrait/board',
    method: 'get',
    params
  })
}
export function Second(params) {
  return request({
    url: '/customer/portrait/sales/sale',
    method: 'get',
    params,
  })
}
export function ProductType(params) {
  return request({
    url: '/customer/portrait/product/type',
    method: 'get',
    params,
  })
}
export function ProductList(params) {
  return request({
    url: '/customer/portrait/product',
    method: 'get',
    params,
  })
}
export function four(params) {
  return request({
    url: '/customer/portrait/plan/complete/analysis',
    method: 'get',
    params,
  })
}
// 客户画像销售分析导出Excel
export function exportList(query) {
  return request({
    url: '/customer/portrait/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 客户画像销售分析导出Excel
export function exportList1(query) {
  return request({
    url: '/customer/portrait/export-product-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
