import request from '@/utils/request'

// 获得客户联系人分页
export function listData(query) {
  return request({
    url: '/system/customer/deliver-goods',
    method: 'get',
    params: query
  })
}
