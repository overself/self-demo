import request from '@/utils/request'

// 更新客户联系人
export function updateClient(data) {
  return request({
    url: '/system/customer-contact/update',
    method: 'put',
    data
  })
}

// 设置默认联系人
export function setClient(query) {
  return request({
    url: '/system/customer-contact/default',
    method: 'put',
    params: query
  })
}

// 创建客户联系人
export function addClient(data) {
  return request({
    url: '/system/customer-contact/create',
    method: 'post',
    data
  })
}

// 获得客户联系人精简信息列表
export function getLinksByClient(query) {
  return request({
    url: '/system/customer-contact/simple/list',
    method: 'get',
    params: query
  })
}

// 获得客户联系人分页
export function listData(query) {
  return request({
    url: '/system/customer-contact/page',
    method: 'get',
    params: query
  })
}

// 获得客户联系人
export function getLink(query) {
  return request({
    url: '/system/customer-contact/get',
    method: 'get',
    params: query
  })
}

// 导出客户联系人 Excel
export function exportExcel(query) {
  return request({
    url: '/system/customer-contact/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 删除客户联系人
export function delClient(query) {
  return request({
    url: '/system/customer-contact/delete',
    method: 'delete',
    params: query,
  })
}
