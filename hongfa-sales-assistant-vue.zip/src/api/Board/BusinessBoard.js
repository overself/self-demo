import request from '@/utils/request'

// 获得价格库存分页
export function listData(query) {
  return request({
    url: '/system/board/price/list',
    method: 'get',
    params: query
  })
}

// 导出价格库存 Excel
export function exportExcel(query) {
  return request({
    url: '/system/board/price/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
// 导入价格库存 Excel
export function importExcel(query) {
  return request({
    url: '/system/board/price/import',
    method: 'post',
    params: query,
  })
}
// 更新价格信息
export function updateData(data) {
  return request({
    url: '/system/board/price/update',
    method: 'put',
    data: data
  })
}

// 生成本日价格
export function getToday() {
  return request({
    url: '/system/board/price/clone',
    method: 'get',
  })
}
