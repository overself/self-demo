import request from '@/utils/request'

// 获得价格库存分页
export function listData(query) {
  return request({
    url: '/system/board/priceinv/list',
    method: 'get',
    params: query
  })
}

export function listCount(query) {
  return request({
    url: '/system/board/priceinv/total',
    method: 'get',
    params: query
  })
}

export function sortKeys(query) {
  return request({
    url: '/system/board/priceinv/sortkeys',
    method: 'get',
    params: query
  })
}

export function listDataRealtime(query) {
  return request({
    url: '/system/board/inventory/current/list',
    method: 'get',
    params: query
  })
}

// 导出价格库存 Excel
export function exportPriceBoardExcel(query) {
  return request({
    url: '/system/board/priceinv/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function productData(query) {
  return request({
    url: '/system/board/priceinv/products',
    method: 'get',
    params: query
  })
}

// 获得库存趋势图表数据
export function getStockChart(query) {
  return request({
    url: '/system/board/priceinv/invtrend',
    method: 'get',
    params: query
  })
}

// 获得价格趋势图表数据
export function getPriceChart(query) {
  return request({
    url: '/system/board/priceinv/pricetrend',
    method: 'get',
    params: query
  })
}
