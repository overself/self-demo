import request from '@/utils/request'

// 获得工厂产量分页
export function listData(query) {
  return request({
    url: '/system/board/output/list',
    method: 'get',
    params: query
  })
}

// 导出工厂产量 Excel
export function exportExcel(query) {
  return request({
    url: '/system/board/output/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 更新价格信息
export function updateData(data) {
  return request({
    url: '/system/board/output/update',
    method: 'put',
    data: data
  })
}

