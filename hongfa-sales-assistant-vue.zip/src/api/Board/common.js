import request from '@/utils/request'

// 获取商品精简信息列表
export function productData(query) {
  return request({
    url: '/system/product/simple-list',
    method: 'get',
    params: query
  })
}
