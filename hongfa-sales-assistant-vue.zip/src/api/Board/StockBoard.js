import request from '@/utils/request'

// 获得看板库存分页
export function listData(query) {
  return request({
    url: '/system/board/inventory/list',
    method: 'get',
    params: query
  })
}

// 导出看板库存 Excel
export function exportExcel(query) {
  return request({
    url: '/system/board/inventory/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
// 导入看板库存 Excel
export function importExcel(query) {
  return request({
    url: '/system/board/inventory/import',
    method: 'post',
    params: query,
  })
}
// 更新价格信息
export function updateData(data) {
  return request({
    url: '/system/board/inventory/update',
    method: 'put',
    data: data
  })
}

// 生成本日价格
export function getToday() {
  return request({
    url: '/system/board/inventory/clone',
    method: 'get',
  })
}
// 获取商品大分类精简信息列表
export function productTopType() {
    return request({
      url: '/system/product/top/type/simple-list',
      method: 'get',
    })
}
// 获取商品分类精简信息列表
export function producTtype(query) {
    return request({
      url: '/system/product/type/simple-list',
      method: 'get',
      params: query,
    })
}

// 获取商品精简信息列表
export function productSimple(query) {
    return request({
      url: '/system/product/simple-list',
      method: 'get',
      params: query,
    })
}
// 创建库存信息
export function inventoryCreate(query) {
    return request({
      url: '/system/board/inventory/create',
      method: 'post',
      data: query,
    })
  }

// 删除库存信息
export function inventoryDelete(query) {
    return request({
      url: '/system/board/inventory/delete',
      method: 'delete',
      params: query
    })
  }


  // 获得库存预警列表
export function inventoryList(query) {
    return request({
      url: '/system/board/inventory/warn/edit/list',
      method: 'get',
      params: query
    })
}

// 更新库存预警信息
export function warnupdate(data) {
    return request({
      url: '/system/board/inventory/warnupdate',
      method: 'put',
      data: data
    })
}