import request from '@/utils/request'

export function list(query) {
  return request({
    url: '/system/outbound-order-detail/page',
    method: 'get',
    params: query
  })
}

// 导出
export function exportList(query) {
  return request({
    url: '/system/outbound-order-detail/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
