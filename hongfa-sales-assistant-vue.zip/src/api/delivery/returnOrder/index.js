import request from '@/utils/request'

export function list(query) {
  return request({
    url: '/system/outbound-order/getReturnOrder',
    method: 'get',
    params: query
  })
}

export function detail(id) {
  return request({
    url: '/system/outbound-order/get',
    method: 'get',
    params: {
      id,
    }
  })
}

// 客户下拉选
export function getCustomerOptions(params) {
  return request({
    url: '/system/customer/simple-list',
    method: 'get',
    params,
  })
}

// 产品下拉选
export function getProductOptions(params) {
  return request({
    url: '/system/product/simple-list',
    method: 'get',
    params,
  })
}

// 导出
export function exportList(query) {
  return request({
    url: '/system/outbound-order/export-returnOrder-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
