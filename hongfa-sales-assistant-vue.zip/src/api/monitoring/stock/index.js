import request from '@/utils/request'

// 获得看板库存分页
export function listData(query) {
  return request({
    url: '/system/board/inventory/warn/list',
    method: 'get',
    params: query
  })
}

// 导出库存预警 Excel
export function exportExcel(query) {
  return request({
    url: '/system/board/inventory/export-warn-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
