import request from '@/utils/request'

// 导出看板库存 Excel
export function exportExcel(query) {
  return request({
    url: '/system/customer/export-warn-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
