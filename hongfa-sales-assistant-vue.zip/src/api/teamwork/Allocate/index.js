import request from '@/utils/request'
//周考核接口
export function weekCreate(data) {
  return request({
    url: '/system/appraise-week/create',
    method: "post",
    data: data
  })
}

export function weekPage(query) {
  return request({
    url: '/system/appraise-week/page',
    method: 'get',
    params: query
  })
}

export function weekDelete(params) {
  return request({
    url: '/system/appraise-week/delete',
    method: 'delete',
    params,
  })
}

export function weekUpdate(data) {
  return request({
    url: '/system/appraise-week/update',
    method: 'put',
    data: data
  })
}

export function weekGet(params) {
  return request({
    url: '/system/appraise-week/get',
    method: 'get',
    params,
  })
}
//品项提成接口
export function goodsCreate(data) {
  return request({
    url: '/hf/appraise-product/create',
    method: "post",
    data: data
  })
}

export function goodsPage(query) {
  return request({
    url: '/hf/appraise-product/page',
    method: 'get',
    params: query
  })
}

export function goodsDelete(params) {
  return request({
    url: '/hf/appraise-product/delete',
    method: 'delete',
    params,
  })
}

export function goodsUpdate(data) {
  return request({
    url: '/hf/appraise-product/update',
    method: 'put',
    data: data
  })
}

export function goodsGet(params) {
  return request({
    url: '/hf/appraise-product/get',
    method: 'get',
    params,
  })
}
//集团客户提成接口
export function clientCreate(data) {
  return request({
    url: '/hf/appraise-customer/create',
    method: "post",
    data: data
  })
}

export function clientPage(query) {
  return request({
    url: '/hf/appraise-customer/page',
    method: 'get',
    params: query
  })
}

export function clientDelete(params) {
  return request({
    url: '/hf/appraise-customer/delete',
    method: 'delete',
    params,
  })
}

export function clientUpdate(data) {
  return request({
    url: '/hf/appraise-customer/update',
    method: 'put',
    data: data
  })
}

export function clientGet(params) {
  return request({
    url: '/hf/appraise-customer/get',
    method: 'get',
    params,
  })
}
//市场客户提成接口
export function customerCreate(data) {
  return request({
    url: '/hf/appraise-factory/create',
    method: "post",
    data: data
  })
}

export function customerPage(query) {
  return request({
    url: '/hf/appraise-factory/page',
    method: 'get',
    params: query
  })
}

export function customerDelete(params) {
  return request({
    url: '/hf/appraise-factory/delete',
    method: 'delete',
    params,
  })
}

export function customerUpdate(data) {
  return request({
    url: '/hf/appraise-factory/update',
    method: 'put',
    data: data
  })
}

export function customerGet(params) {
  return request({
    url: '/hf/appraise-factory/get',
    method: 'get',
    params,
  })
}

export function customerList(params) {
  return request({
    url: '/system/customer/simple-list',
    method: 'get',
    params,
  })
}

// 工厂客户配置获得编辑页面使用的 归属销售
export function getCustomer(query) {
  return request({
    url: '/system/customer/appraise-list',
    method: 'get',
    params: query
  })
}


export function listData(params) {
  return request({
    url: '/system/customer/total/appraisePage',
    method: 'get',
    params,
  })
}

export function queryProduct(params) {
  return request({
    url: '/hf/appraise-product/query_product',
    method: 'get',
    params,
  })
}

export function queryConfirm(params) {
  return request({
    url: '/hf/appraise-product/query_confirm',
    method: 'get',
    params,
  })
}
