import request from '@/utils/request'

export function list(params) {
  return request({
    url: '/system/time-config/list',
    method: 'get',
    params,
  })
}

export function update(data) {
  return request({
    url: '/system/time-config/update',
    method: 'put',
    data,
  })
}

// 获得时间配置
export function getTimeConfig(params) {
  return request({
    url: '/system/time-config/get',
    method: 'get',
    params,
  })
}
