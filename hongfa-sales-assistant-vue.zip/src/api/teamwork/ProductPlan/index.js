import request from '@/utils/request'
//周考核接口
export function create(data) {
  return request({
    url: '/hf/production-task/create',
    method: "post",
    data: data
  })
}

export function page(query) {
  return request({
    url: '/hf/production-task/list',
    method: 'get',
    params: query
  })
}

export function update(data) {
  return request({
    url: '/hf/production-task/update',
    method: 'put',
    data: data
  })
}

export function deleteData(data) {
  return request({
    url: '/hf/production-task/delete',
    method: 'put',
    data: data
  })
}


export function getData(params) {
  return request({
    url: '/hf/production-task/get',
    method: 'get',
    params,
  })
}
