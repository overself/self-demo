import request from '@/utils/request'

// 查询配置月
export function getTimeConfig(query) {
  return request({
    url: '/system/time-config/list',
    method: 'get',
    params: query
  })
}

export function getList(params) {
  return request({
    url: '/system/sales-task/new_performance',
    method: 'get',
    params,
  })
}

// 导出Excel
export function exportList1(query) {
  return request({
    url: '/hf/appraise-customer-record/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 导出Excel
export function exportList2(query) {
  return request({
    url: '/hf/appraise-product-record/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 导出Excel
export function exportList3(query) {
  return request({
    url: '/system/appraise-week/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 客户的详情
export function getCustomerList(params) {
  return request({
    url: '/hf/appraise-customer-record/page',
    method: 'get',
    params,
  })
}

// 品相的详情
export function getProductList(params) {
  return request({
    url: '/hf/appraise-product-record/page',
    method: 'get',
    params,
  })
}

// 获得周考核
export function getWeekList(params) {
  return request({
    url: '/system/appraise-week/page',
    method: 'get',
    params,
  })
}
