import request from '@/utils/request'

export function list(query) {
  return request({
    url: '/system/teamwork/list',
    method: 'get',
    params: query
  })
}

// 计划完成进度
export function getCompletedProgress(query) {
  return request({
    url: '/system/teamwork/month/plan/complete',
    method: 'get',
    params: query
  })
}

// 业务员分析
export function getNewSalPersonAnalysis(query) {
  return request({
    url: '/system/salPerson-analysis/getNewSalPersonAnalysis',
    method: 'get',
    params: query
  })
}

// 业务员分析
export function newComplete(query) {
  return request({
    url: '/system/teamwork/month/plan/new_complete',
    method: 'get',
    params: query
  })
}
