import request from '@/utils/request'

// 查询配置月
export function getTimeConfig(query) {
  return request({
    url: '/system/time-config/list',
    method: 'get',
    params: query
  })
}

// 业务员分析
export function getSalPersonAnalysis(query) {
  return request({
    url: '/system/salPerson-analysis/getSalPersonAnalysis',
    method: 'get',
    params: query
  })
}

//业务员分析---大区
export function getSalPersonAreaAnalysis(query) {
  return request({
    url: '/system/salPerson-analysis/getSalPersonAreaAnalysis',
    method: 'get',
    params: query
  })
}

// 业务员分析 上面的统计
export function getSalPersonTotal(query) {
  return request({
    url: '/system/salPerson-analysis/getSalPersonTotal',
    method: 'get',
    params: query
  })
}

// 业务员分析---大区 上面的统计
export function getSalPersonAreaTotal(query) {
  return request({
    url: '/system/salPerson-analysis/getSalPersonAreaTotal',
    method: 'get',
    params: query
  })
}

// 导出 Excel
export function exportList1(query) {
  return request({
    url: '/system/salPerson-analysis/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 导出 Excel
export function exportList2(query) {
  return request({
    url: '/system/salPerson-analysis/export-areaExcel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
