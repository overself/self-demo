import request from '@/utils/request'

// 查询配置月
export function getTimeConfig(query) {
  return request({
    url: '/system/time-config/list',
    method: 'get',
    params: query
  })
}

// 产品销售排名查询
export function getProductAnalysis(query) {
  return request({
    url: '/system/product-rank/getProductAnalysis',
    method: 'get',
    params: query
  })
}

// 产品售排名导出Excel
export function exportList(query) {
  return request({
    url: '/system/product-rank/exportExcel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
