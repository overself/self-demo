import request from '@/utils/request'

// 查询配置月
export function getTimeConfig(query) {
  return request({
    url: '/system/time-config/list',
    method: 'get',
    params: query
  })
}

// 销售分析总览
export function getSalAnalysis(query) {
  return request({
    url: '/system/sal-analysis/getSalAnalysis',
    method: 'get',
    params: query
  })
}

// 销售出库趋势
export function getSalTrendTotal(query) {
  return request({
    url: '/system/sal-analysis/getSalTrendTotal',
    method: 'get',
    params: query
  })
}

// 获得销售分析----各个占比
export function getSaleTotal(query) {
  return request({
    url: '/system/sal-analysis/getSaleTotal',
    method: 'get',
    params: query
  })
}

// 获得销售分析----销售出库趋势
export function getSalTrend(query) {
  return request({
    url: '/system/sal-analysis/getSalTrend',
    method: 'get',
    params: query
  })
}

// 导出Excel
export function exportList1(query) {
  return request({
    url: '/system/sal-analysis/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 导出Excel
export function exportList2(query) {
  return request({
    url: '/system/sal-analysis/export-trendExcel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
