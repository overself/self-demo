import request from '@/utils/request'

// 查询列表
export function getList(query) {
  return request({
    url: '/system/day-analysis/getDayAnalysisSale',
    method: 'get',
    params: query
  })
}

// 查询列表
export function getList1(query) {
  return request({
    url: '/system/day-analysis/getDayAnalysisSalePerson',
    method: 'get',
    params: query
  })
}

// 查询列表
export function getList2(query) {
  return request({
    url: '/system/day-analysis/getDayAnalysisSaleProduct',
    method: 'get',
    params: query
  })
}

// 查询列表
export function getList3(query) {
  return request({
    url: '/system/day-analysis/getDayAnalysisSaleCustomer',
    method: 'get',
    params: query
  })
}

// 工厂出库占比
export function getDayAnalysisFactory(query) {
  return request({
    url: '/system/day-analysis/getDayAnalysisFactory',
    method: 'get',
    params: query
  })
}

// 导出业务员 Excel
export function exportList1(query) {
  return request({
    url: '/system/day-analysis/exportPerson-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 导出产品销售情况 Excel
export function exportList2(query) {
  return request({
    url: '/system/day-analysis/exportProduct-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 导出客户销售情况 Excel
export function exportList3(query) {
  return request({
    url: '/system/day-analysis/exportCustomer-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
