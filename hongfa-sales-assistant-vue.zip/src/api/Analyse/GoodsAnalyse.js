import request from '@/utils/request'

// 查询配置月
export function getTimeConfig(query) {
  return request({
    url: '/system/time-config/list',
    method: 'get',
    params: query
  })
}

// 统计分析 - 产品分析总览
export function getProductAnalysis(query) {
  return request({
    url: '/system/product-analysis/getProductAnalysis',
    method: 'get',
    params: query
  })
}

// 导出Excel
export function exportList(query) {
  return request({
    url: '/system/product-analysis/exportExcel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
