import request from '@/utils/request'

// 查询配置月
export function getTimeConfig(query) {
  return request({
    url: '/system/time-config/list',
    method: 'get',
    params: query
  })
}

// 客户分析总览
export function getCustomerAnalysis(query) {
  return request({
    url: '/system/customer-analysis/getCustomerAnalysis',
    method: 'get',
    params: query
  })
}

// 获得客户分析----按照省按照城市
export function getCustomerAnalysisProvince(query) {
  return request({
    url: '/system/customer-analysis/getCustomerAnalysisProvince',
    method: 'get',
    params: query
  })
}

// 客户分析 上面的统计
export function getCustomerTotal(query) {
  return request({
    url: '/system/customer-analysis/getCustomerTotal',
    method: 'get',
    params: query
  })
}

// 导出价格库存 Excel
export function exportList(query) {
  return request({
    url: '/system/customer-analysis/export-excel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

// 客户分析  销售渠道柱状图
export function getQdCustomerTotal(query) {
  return request({
    url: '/system/customer-analysis/getQdCustomerTotal',
    method: 'get',
    params: query
  })
}
