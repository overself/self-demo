import request from '@/utils/request'

// 查询配置月
export function getTimeConfig(query) {
  return request({
    url: '/system/time-config/list',
    method: 'get',
    params: query
  })
}

// 客户销售排名查询
export function getCustomerAnalysis(query) {
  return request({
    url: '/system/customer-rank/getCustomerAnalysis',
    method: 'get',
    params: query
  })
}

// 客户销售排名导出Excel
export function exportList(query) {
  return request({
    url: '/system/customer-rank/exportExcel',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
