import request from '@/utils/request'


export function listData(query) {
    return request({
      url: '/system/sign/page',
      method: 'get',
      params: query
    })
  }

// 创建标签
export function signCreate(data) {
    return request({
      url: '/system/sign/create',
      method: 'post',
      data: data
    })
  }
// 更新标签
export function signUpdate(data) {
    return request({
      url: '/system/sign/update',
      method: 'put',
      data: data
    })
  }
// 删除标签
export function signDelete(data) {
    return request({
      url: '/system/sign/delete',
      method: 'delete',
      params: data
    })
  }
  // 不分页标签
export function listDataNoPage(data) {
    return request({
      url: '/system/sign/get',
      method: 'get',
      params: data
    })
  }