import request from "@/utils/request";

export function getProductFactoryList(query) {
  return request({
    url: "/system/order-split/product/list",
    method: "post",
    data: query,
  });
}

export function getCustomerListByName(query) {
  return request({
    url: "/system/order-split/customer/list",
    method: "post",
    data: query,
  });
}

export function getSubCustomerList(query) {
  return request({
    url: "/system/order-split/customer/sub/list",
    method: "post",
    data: query,
  });
}
