import request from '@/utils/request'


export function listData(query) {
    return request({
      url: '/system/channel/list',
      method: 'get',
      params: query
    })
  }

// 创建渠道
export function channelCreate(data) {
    return request({
      url: '/system/channel/create',
      method: 'post',
      data: data
    })
}
// 更新渠道
export function channelUpdate(data) {
    return request({
      url: '/system/channel/update',
      method: 'put',
      data: data
    })
  }
// 删除渠道
export function channelDelete(data) {
    return request({
      url: '/system/channel/delete',
      method: 'delete',
      params: data
    })
  }
  // 获取渠道列表
  export function channelList(query) {
    return request({
      url: '/system/channel/list-all-simple',
      method: 'get',
      params: query
    })
  }