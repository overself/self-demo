import request from "@/utils/request";

export function listData(query) {
  return request({
    url: "/system/product/page",
    method: "get",
    params: query,
  });
}

// 创建品项(商品)
export function productCreate(data) {
  return request({
    url: "/system/product/create",
    method: "post",
    data: data,
  });
}

// 导出
export function exportRole(query) {
  return request({
    url: "/system/product/export-excel",
    method: "get",
    params: query,
    responseType: "blob",
  });
}

// 商品详情
export function productGet(query) {
  return request({
    url: "/system/product/get",
    method: "get",
    params: query,
  });
}

//更新商品
export function productUpdate(data) {
  return request({
    url: "/system/product/update",
    method: "put",
    data: data,
  });
}

// 设置商品业务状态
export function productBusinessStatus(productId) {
  return request({
    url: "/system/product/business-status",
    method: "post",
    params: {
      productId,
    },
  });
}
// 设置商品开启状态
export function customerIsEnable(productId) {
    return request({
      url: "/system/product/isEnable",
      method: "post",
      params: {
        productId,
      }
    });
  }