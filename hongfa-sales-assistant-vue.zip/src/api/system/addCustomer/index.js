/*
 * @Author: LinChunpeng
 * @Date: 2024-09-03 19:25:18
 * @LastEditTime: 2024-09-09 11:20:48
 * @LastEditors: LinChunpeng
 * @Version: 1.1.2
 * @Feature:
 * @FilePath: \hongfa-sales-assistant-vue\src\api\system\addCustomer\index.js
 * 可以输入预定的版权声明、个性签名、空行等
 */
import request from "@/utils/request";

export function listData(query) {
  return request({
    url: "/system/customer/warning/page",
    method: "get",
    params: query,
  });
}

// 系统管理-精简总客户列表
export function listSimpleData(query) {
  return request({
    url: "/system/customer/simple/total/page",
    method: "get",
    params: query,
  });
}

// 系统管理-总客户列表
export function listCustomerTotalData(query) {
  return request({
    url: "/system/customer/total/page",
    method: "get",
    params: query,
  });
}

// 创建客户
export function customerCreate(data) {
  return request({
    url: "/system/customer/create",
    method: "post",
    data: data,
  });
}

// 导出
export function exportRole(query) {
  return request({
    url: "/system/customer/export-excel",
    method: "get",
    params: query,
    responseType: "blob",
  });
}

// 系统管理-客户层级信息
export function getLevelCustomerInfo(customerId) {
  return request({
    url: "/system/customer/level/customer/info",
    method: "get",
    params: {
      customerId,
    },
  });
}

// 批量确认客户 示例：1,2,3,4
export function customerConfirm(params) {
  return request({
    url: "/system/customer/confirm",
    method: "post",
    params,
  });
}

// 设置客户开启状态
export function customerIsEnable(customerId) {
  return request({
    url: "/system/customer/isEnable",
    method: "post",
    params: {
      customerId,
    }
  });
}

// 设置客户业务状态
export function customerBusinessStatus(customerId) {
  return request({
    url: "/system/customer/business-status",
    method: "post",
    params: {
      customerId,
    }
  });
}
