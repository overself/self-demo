import request from "@/utils/request";

export function listData(query) {
  return request({
    url: "/system/inventory-right/page",
    method: "get",
    params: query,
  });
}

export function update(data) {
  return request({
    url: "/system/inventory-right/update",
    method: "put",
    data,
  });
}

export function factoryUserList(query) {
  return request({
    url: "/system/user/factory",
    method: "get",
    params: query,
  });
}
