<template>
  <div
    class="navbar"
    :style="{ backgroundColor: variables.menuLightLogoBackground }"
  >
    <hamburger
      id="hamburger-container"
      :is-active="sidebar.opened"
      class="hamburger-container"
      @toggleClick="toggleSideBar"
    />

    <breadcrumb
      id="breadcrumb-container"
      class="breadcrumb-container"
      v-if="!topNav"
    />
    <top-nav
      id="topmenu-container"
      class="topmenu-container"
      v-if="topNav"
    />

    <div class="right-menu">
      <div class="right-menu-info_item__wrapper">
        <div class="avatar-wrapper">
          <img
            src="@/assets/images/avatar.png"
            class="user-avatar"
          >
        </div>

        <div class="right-menu-info_item">
          <span class="label">部门：</span>
          <span class="value">{{userInfo.dept.name}}</span>
        </div>

        <div class="right-menu-info_item">
          <span class="label">职位：</span>
          <span class="value">{{displayPosts()}}</span>
        </div>

        <div
          class="right-menu-info_item"
          style="cursor: pointer;"
          @click="goSettingPwd"
        >
          <span class="label">姓名：</span>
          <span class="value">{{userInfo.nickname}}</span>
        </div>

        <div class="right-menu-info_item">
          <img
            class="logout-btn"
            src="@/assets/images/logout_btn.png"
            alt=""
            srcset=""
            @click="logout"
          >
        </div>
      </div>

      <!-- <template v-if="device!=='mobile'">
        <search
          id="header-search"
          class="right-menu-item"
        />

        <notify-message class="right-menu-item hover-effect" />

        <screenfull
          id="screenfull"
          class="right-menu-item hover-effect"
        />

        <el-tooltip
          content="布局大小"
          effect="dark"
          placement="bottom"
        >
          <size-select
            id="size-select"
            class="right-menu-item hover-effect"
          />
        </el-tooltip>

      </template> -->

      <!-- <el-dropdown
        class="avatar-container right-menu-item hover-effect"
        trigger="click"
      >
        <div class="avatar-wrapper">
          <img
            src="@/assets/images/avatar.png"
            class="user-avatar"
          >
          <span
            v-if="nickname"
            class="user-nickname"
          >{{ nickname }}</span>
          <i class="el-icon-caret-bottom" />
        </div>
        <el-dropdown-menu slot="dropdown">
          <router-link to="/user/profile">
            <el-dropdown-item>个人中心</el-dropdown-item>
          </router-link>
          <el-dropdown-item @click.native="setting = true">
            <span>布局设置</span>
          </el-dropdown-item>
          <el-dropdown-item
            divided
            @click.native="logout"
          >
            <span>退出登录</span>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown> -->
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import Breadcrumb from '@/components/Breadcrumb';
import TopNav from '@/components/TopNav';
import Hamburger from '@/components/Hamburger';
import Screenfull from '@/components/Screenfull';
import SizeSelect from '@/components/SizeSelect';
import Search from '@/components/HeaderSearch';
import NotifyMessage from '@/layout/components/Message';
import { getPath } from '@/utils/ruoyi';
import variables from '@/assets/styles/variables.scss';
import { getUserProfile } from '@/api/system/user';

export default {
  components: {
    Breadcrumb,
    TopNav,
    Hamburger,
    Screenfull,
    SizeSelect,
    Search,
    NotifyMessage,
  },

  data() {
    return {
      variables,
      userInfo: {
        dept: {
          name: '',
        },
      },
    };
  },

  computed: {
    ...mapGetters(['sidebar', 'avatar', 'nickname', 'device']),
    setting: {
      get() {
        return this.$store.state.settings.showSettings;
      },
      set(val) {
        this.$store.dispatch('settings/changeSetting', {
          key: 'showSettings',
          value: val,
        });
      },
    },
    topNav: {
      get() {
        return this.$store.state.settings.topNav;
      },
    },
  },

  created() {
    this.getUserInfo();
  },

  methods: {
    goSettingPwd() {
      this.$router.push({
        path: '/user/profile',
      });
    },
    displayPosts() {
      return this.userInfo.posts && this.userInfo.posts.length
        ? this.userInfo.posts.map((item) => item.name).join(',')
        : '暂无';
    },

    getUserInfo() {
      getUserProfile().then((res) => {
        this.userInfo = res.data;
      });
    },

    toggleSideBar() {
      this.$store.dispatch('app/toggleSideBar');
    },
    async logout() {
      this.$modal
        .confirm('确定注销并退出系统吗？', '提示')
        .then(() => {
          this.$store.dispatch('LogOut').then(() => {
            // location.href = getPath('/index');
            this.$router.push({ path: '/login' });
          });
        })
        .catch(() => {});
    },
  },
};
</script>

<style lang="scss" scoped>
.navbar {
  height: 50px;
  overflow: hidden;
  position: relative;
  background: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);

  .hamburger-container {
    line-height: 46px;
    height: 100%;
    float: left;
    cursor: pointer;
    transition: background 0.3s;
    -webkit-tap-highlight-color: transparent;

    &:hover {
      background: rgba(0, 0, 0, 0.025);
    }
  }

  .breadcrumb-container {
    float: left;
  }

  .topmenu-container {
    position: absolute;
    left: 50px;
  }

  .errLog-container {
    display: inline-block;
    vertical-align: top;
  }

  .right-menu {
    float: right;
    height: 100%;
    line-height: 50px;

    &:focus {
      outline: none;
    }

    .right-menu-item {
      display: inline-block;
      padding: 0 8px;
      height: 100%;
      font-size: 18px;
      color: #5a5e66;
      vertical-align: text-bottom;

      &.hover-effect {
        cursor: pointer;
        transition: background 0.3s;

        &:hover {
          background: rgba(0, 0, 0, 0.025);
        }
      }
    }

    .avatar-container {
      margin-right: 30px;

      .avatar-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;

        .user-avatar {
          cursor: pointer;
          width: 21px;
          height: 21px;
          border-radius: 50%;
        }
        .user-nickname {
          margin-left: 5px;
          font-size: 14px;
        }

        .el-icon-caret-bottom {
          cursor: pointer;
          position: absolute;
          right: -20px;
          top: 25px;
          font-size: 12px;
        }
      }
    }

    .right-menu-info_item__wrapper {
      display: flex;
      align-content: center;

      .avatar-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;

        .user-avatar {
          width: 21px;
          height: 21px;
          border-radius: 50%;
        }
      }

      .right-menu-info_item {
        margin-right: 22px;

        &:nth-child(2) {
          margin-left: 16px;
        }

        .label {
          font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
          font-weight: 400;
          font-size: 14px;
          color: rgba(255, 255, 255, 0.69);
          line-height: 16px;
          text-align: left;
          font-style: normal;
        }

        .value {
          font-family: Alibaba PuHuiTi, Alibaba PuHuiTi;
          font-weight: 400;
          font-size: 14px;
          color: rgba(255, 255, 255, 0.69);
          line-height: 16px;
          text-align: left;
          font-style: normal;
        }

        .logout-btn {
          width: 16px;
          height: 16px;
          margin-top: 18px;
          cursor: pointer;
        }
      }
    }
  }
}
</style>
