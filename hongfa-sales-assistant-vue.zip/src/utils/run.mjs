import { combine } from './pinCombine.mjs';
// 1. 模拟清洗后的库存（件单价已算好）
const skuList = [
  { name: '3035凤爪', price: 318.25, stock: 50 },
  { name: '3540凤爪', price: 318.25, stock: 100 },
  { name: '45以上凤爪', price: 380, stock: 70 },
  { name: '50以上凤爪', price: 427.5, stock: 20 },
  { name: '鸡胗', price: 135.36, stock: 50 },
  { name: '膝软骨', price: 252, stock: 50 },
  { name: '6070单冻爪', price: 266, stock: 30 },
  { name: '凤凰筋', price: 310, stock: 20 },
  { name: '100120琵琶腿', price: 126, stock: 200 },
  { name: '品10', price: 1, stock: 13 }
]
// 2. 要凑的金额
const targets = [500, 1000, 2000, 5000, 10000, 421427.4];
// 3. 直接跑
for (const t of targets) {
  const t0 = Date.now();
  const { plan, actual, gap } = combine(skuList, t);
  const cost = Date.now() - t0;
  console.log(`\n目标=${t}  实际=${actual.toFixed(2)}  差值=${gap.toFixed(2)}  耗时=${cost}ms`);
  console.log('方案:', plan);
}
