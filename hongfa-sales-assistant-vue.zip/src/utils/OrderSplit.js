/********************************************************************
 *  OrderSplit —— 顺序拆单工具类（零精度丢失版）
 *  1. 内部统一用“分”(整数)运算，输出再转回元
 *  2. 其余逻辑与之前完全一致：顺序贪心、指定品优先、不超目标
 ********************************************************************/
export default class OrderSplit {
  constructor(rawProducts) {
    // 库存深拷贝 → 转成分单位
    this.remaining = rawProducts
      .filter(p => p.qty > 0)
      .map(p => ({
        ...p,
        _specFen: Math.round(p.spec * 100),   // 规格→分
        _priceFen: Math.round(p.price * 100)  // 单价→分
      }));
  }

  /* 入口 */
  split(targets, priorityNames = []) {
    console.log('👋 OrderSplit.split 被调用', targets, priorityNames)
    return targets.map(t => this._round(t, priorityNames));
  }

  /* ---------------- 私有工具 ---------------- */
  _toFen(yuan) {
    return Math.round(yuan * 100);
  }

  _toYuan(fen) {
    return Math.round(fen) / 100;
  }

  _singleTotalFen(pc) {
    return pc._specFen * pc._priceFen / 100; // 单件总金额（分）
  }

  /* 一轮拆单 */
  _round(targetAmount, priorityNames) {
    const targetFen = this._toFen(targetAmount);
    const selected = [];
    let pickedFen = 0;

    /* 阶段 1：指定品 */
    if (priorityNames.length) {
      const prioList = this._buildPriorityList(priorityNames);
      const st = this._pickByList(targetFen - pickedFen, prioList);
      selected.push(...st.list);
      pickedFen += this._toFen(st.amount);
    }

    /* 阶段 2：剩余品 */
    const rest = targetFen - pickedFen;
    const st = this._pickByList(rest, this.remaining);
    selected.push(...st.list);
    pickedFen += this._toFen(st.amount);
    console.log('👋 OrderSplit.selected 被调用', selected)
    return {
      targetAmount,
      selectedProducts: selected,
      totalSelectedAmount: this._toYuan(pickedFen),
      remainingAmount: this._toYuan(targetFen - pickedFen),
      remainingProducts: this.remaining.map(p => ({...p}))
    };
  }

  /* 构造指定品列表（不修改库存） */
  _buildPriorityList(names) {
    const list = [];
    for (const n of names) {
      const idx = this.remaining.findIndex(p => p.name === n);
      if (idx !== -1) list.push({...this.remaining[idx], __idx: idx});
    }
    return list;
  }

  /* 顺序贪心拿：传入“分”单位目标，返回{list, amount}（元）并扣库存 */
  _pickByList(targetFen, candidateList) {
    const picked = [];
    let amountFen = 0;
    if (targetFen <= 0 || !candidateList.length) return {list: picked, amount: 0};
    console.log('👋 OrderSplit.candidateList 被调用', candidateList)
    for (const pc of candidateList) {
      if (targetFen <= 0) break;
      const singleFen = this._singleTotalFen(pc);
      if (singleFen <= 0) continue;
      const maxPieces = Math.min(pc.qty, Math.floor(targetFen / singleFen));
      if (maxPieces <= 0) continue;

      const takeFen = Math.round(maxPieces * singleFen);
      picked.push({
        ...pc,
        qty: maxPieces
      });

      // 真正扣库存
      const realIdx = pc.__idx ?? this.remaining.findIndex(p => p.name === pc.name);
      if (realIdx !== -1) this.remaining[realIdx].qty -= maxPieces;

      targetFen -= takeFen;
      amountFen += takeFen;
    }
    return {list: picked, amount: this._toYuan(amountFen)};
  }
}
