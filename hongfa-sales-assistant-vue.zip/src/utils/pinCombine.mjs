/**
 * 拆单核心
 * @param skuList  [{ name, price, stock }]   price=件单价（元）
 * @param target   目标金额（元）
 * @return { plan:{name:qty}, actual, gap }
 */
export function combine (skuList, target) {
  const best = { gap: Infinity, plan: {} }
  // ① 单一品优先
  for (const sku of skuList) {
    const take = Math.min(sku.stock, Math.floor(target / sku.price))
    if (take <= 0) continue
    const money = take * sku.price
    const gap = target - money
    if (gap < best.gap) {
      best.gap = gap
      best.plan = { [sku.name]: take }
    }
  }
  // ② 回溯补差
  if (best.gap > 0) {
    const cur = { ...best.plan }
    const already = target - best.gap
    backtrack(skuList, target, already, cur, best, 0)
  }
  const actual = Object.entries(best.plan)
    .reduce((s, [n, q]) => s + skuList.find(i => i.name === n).price * q, 0)
  return { plan: best.plan, actual, gap: target - actual }
}

function backtrack (list, target, already, cur, best, idx) {
  const gap = target - already
  if (gap <= 0) return
  if (gap < best.gap) {
    best.gap = gap
    best.plan = { ...cur }
  }
  if (idx === list.length) return
  const sku = list[idx]
  const maxTake = Math.min(sku.stock, Math.floor(gap / sku.price))
  for (let take = maxTake; take >= 0; take--) {
    if (take === 0 && maxTake > 3) continue
    cur[sku.name] = (cur[sku.name] || 0) + take
    backtrack(list, target, already + take * sku.price, cur, best, idx + 1)
    cur[sku.name] -= take
    if (!cur[sku.name]) delete cur[sku.name]
  }
}
