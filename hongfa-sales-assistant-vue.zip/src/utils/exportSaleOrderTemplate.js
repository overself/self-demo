import * as XLSX from 'xlsx-js-style'
import axios from 'axios'

/** 读模板 */
export async function loadTemplate(fileName = '销售订单批导模板.xlsx') {
  // const url = `${process.env.BASE_URL}static/template/${fileName}`
  const url = `/static/template/${fileName}`;
  const res = await axios.get(url, { responseType: 'arraybuffer' })
  return XLSX.read(res.data, { type: 'array', cellStyles: true })
}

/** 发货库位规则 */
function getDeliveryLoc(factoryCode, kindCode) {
  const map = {
    '1001-Z020': '1006',
    '1001-Z021': '1005',
    '1002-Z020': '1013',
    '1002-Z021': '1012'
  }
  return map[`${factoryCode}-${kindCode}`] || ''
}


export async function generateSaleOrderFile(tables) {
  // ----- 1. 准备数据（三行） -----
  const headers = [
    '订单编号', '行项目', '销售组织', '分销渠道', '部门', '订单类型', '客户编码', '客户名称', '配销地编码',
    '凭证日期', '计划发货日期', '运输方式', '是否含运费', '一级客户编码', '车牌号', '司机姓名', '司机电话',
    '客户参考', '客户参考日期', '物料编码', '物料描述', '发货工厂', '发货库位', '数量', '销售单位',
    '结算价', '折扣', '补差', '销售订单抬头备注', '销售订单行项目备注'
  ]
  const colWidths = [2, 4, 4, 2, 2, 4, 10, 35, 10, 8, 8, 2, 1, 10, 10, 8, 13, 35, 18, 18, 40, 4, 4, 13, 2, 10, 10, 10, 100, 100]
  const required = ['必填', '必填', '必输', '必输', '必输', '必输', '必输', '', '上海大客户', '必输', '必输', '必输', '必输', '必输', '生食必输', '生食必输', '', '', '', '必输', '', '必输', '必输', '必输', '必输', '', '拆单用', '拆单用', '', '']

  /* ===== 颜色定义 ===== */
  const YELLOW = { fgColor: { rgb: 'FFFFFF00' } }   // #FFFF00
  const LIGHT_BLUE = { fgColor: { rgb: 'FFB5C6EA' } } // #B5C6EA

  // ===== 1. 颜色池：同一订单一个色 =====
  const ORDER_COLORS = [
    { fgColor: { rgb: 'FFE3F2FD' } }, // 蓝-1
    { fgColor: { rgb: 'FFF3E5F5' } }, // 紫-1
    { fgColor: { rgb: 'FFE8F5E9' } }, // 绿-1
    { fgColor: { rgb: 'FFFFF3E0' } }, // 橙-1
    { fgColor: { rgb: 'FFEDE7F6' } }  // 靛-1
  ]

  const THIN_BORDER = {
    top: { style: 'thin', color: { rgb: 'FF000000' } },
    right: { style: 'thin', color: { rgb: 'FF000000' } },
    bottom: { style: 'thin', color: { rgb: 'FF000000' } },
    left: { style: 'thin', color: { rgb: 'FF000000' } }
  }

  /* ===== 需要高亮的列索引 ===== */
  const YELLOW_COLS = [11, 12, 13, 14, 15, 16] // 运输方式~司机电话

  const rows = [headers, colWidths, required]

  // ----- 2. 构造工作簿 -----
  const ws = XLSX.utils.aoa_to_sheet(rows)

  // ----- 3. 逐格写样式 -----
  const headerStyle = {
    font: { name: 'Calibri', sz: 12, bold: true },
    alignment: { horizontal: 'center', vertical: 'center' }
  }
  const widthStyle = {
    font: { name: 'Arial', sz: 10 },
    alignment: { horizontal: 'center', vertical: 'center' }
  }
  const reqStyle = {
    font: { name: 'Calibri', sz: 11, color: { rgb: 'FF0000' } },
    alignment: { horizontal: 'center', vertical: 'center' }
  }

  headers.forEach((_, c) => {
    // 第1行
    const addr1 = XLSX.utils.encode_cell({ r: 0, c })
    if (!ws[addr1]) ws[addr1] = { t: 's', v: headers[c] }
    ws[addr1].s = {
      ...headerStyle,
      fill: YELLOW_COLS.includes(c) ? YELLOW : LIGHT_BLUE
    }

    // 第2行
    const addr2 = XLSX.utils.encode_cell({ r: 1, c })
    if (!ws[addr2]) ws[addr2] = { t: 's', v: colWidths[c] ?? '' }
    ws[addr2].s = { ...widthStyle, fill: LIGHT_BLUE }

    // 第3行
    const addr3 = XLSX.utils.encode_cell({ r: 2, c })
    if (!ws[addr3]) ws[addr3] = { t: 's', v: required[c] ?? '' }
    ws[addr3].s = { ...reqStyle, fill: LIGHT_BLUE }

    // 2. 列宽 + 边框（三行一起加）
    for (let r = 0; r < 3; r++) {
      headers.forEach((_, c) => {
        const addr = XLSX.utils.encode_cell({ r, c })
        if (!ws[addr]) ws[addr] = { t: 's', v: '' }
        // 统一细边框
        ws[addr].s = { ...ws[addr].s, border: THIN_BORDER }
      })
    }

  })

  // ----- 4. 列宽 -----
  ws['!cols'] = headers.map((_, i) => ({ wch: Math.max(colWidths[i] || 0, 14) }))

  // ===== 2. 从第四行开始写数据 =====
  let currRow = 4 // 前三行已被表头/列宽/必填占用
  let orderNo = 1

  tables.forEach((table) => {
    const color = ORDER_COLORS[(orderNo - 1) % ORDER_COLORS.length]
    const rows = table.rows || []
    rows.forEach((r, idx) => {
      const rowNo = `${idx + 1}0`;
      const base = {
        A: orderNo, // 订单编号
        B: rowNo, // 行项目
        C: r.selectedLevel1Customer?.organizationCode || '', // 销售组织
        D: r.selectedLevel1Customer?.type || '', // 分销渠道
        E: r.selectedLevel1Customer?.dept || '', // 部门
        F: r.orderType, // 订单类型
        G: r.secondaryCustomer?.code || '', // 客户编码
        H: r.secondaryCustomer?.name || '', // 客户名称
        I: '', // 配销地编码
        J: r.selectedDate.replace(/-/g, ''), // 凭证日期
        K: r.selectedDate.replace(/-/g, ''), // 计划发货日期
        L: r.shipType  || '', // 运输方式
        M: r.includeFreight  || '', // 是否含运费
        N: r.selectedLevel1Customer.code || '', // 一级客户编码
        O: r.plateNumber || '', // 车牌号
        P: r.driverName || '', // 司机姓名
        Q: r.driverPhone || '', // 司机电话
        R: '', // 客户参考
        S: '', // 客户参考日期
        T: r.code || '', // 物料编码
        U: r.name || '', // 物料描述
        V: r.factoryCode || '', // 发货工厂
        W: getDeliveryLoc(r.factoryCode, r.product.kindCode), // 发货库位
        X: r.qty || 0, // 数量
        Y: 'KG', // 销售单位
        Z: Number(r.price || 0).toFixed(2), // 结算价
        AA: idx === 0 ? Number(table.discount || '').toFixed(2) : '', // 折扣
        AB: idx === 0 ? Number(table.remainingAmount || '').toFixed(2) : '', // 补差
        AC: '', // 抬头备注
        AD: '' // 行备注
      }

      Object.entries(base).forEach(([col, val]) => {
        const addr = col + currRow
        if (!ws[addr]) ws[addr] = {}
        ws[addr].v = val
        ws[addr].t = typeof val === 'number' ? 'n' : 's'
        // 同一订单一种底色 + 统一细边框
        ws[addr].s = { fill: color, border: THIN_BORDER }
      })
      currRow++
    })
    orderNo++
  })

  // 1. 写完所有数据后，重新计算工作表范围
  const range = {
    s: { r: 0, c: 0 },
    e: { r: currRow - 1, c: headers.length - 1 }
  }
  ws['!ref'] = XLSX.utils.encode_range(range)

  // 2. 再 append / 下载
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, '订单模板')
  XLSX.writeFile(wb, `订单_${Date.now()}.xlsx`)
}
