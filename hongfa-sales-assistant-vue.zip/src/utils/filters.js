
// 金额分位及浮点转化
export const moneyFormat = (num, symbo = '') => {
  if (!num) {
    if (num === 0) {
      return symbo + "0.00";
    } else {
      return symbo + "-";
    }
  }
  if(num == '-'){
    return symbo + "-";
  }
  // 接受数字变双浮点
  let numToFloat = num.toFixed(2);
  // 分割整数和浮点数
  let num0 = numToFloat.split(".")[0];
  let num1 = numToFloat.split(".")[1];
  num0 = parseInt(num0).toLocaleString();
  return symbo + num0 + "." + num1;
};

export const weightFormatNotLocale = (num, needConver = false, fixed = 2) => {
  let tempNum;

  if (needConver && !isNaN(num)) {
    tempNum = Number(num) / 1000;
  } else {
    tempNum = Number(num);
  }

  if (!tempNum) {
    if (tempNum === 0) {
      if(fixed==2){
        return  "0.00";
      }
      if(fixed==3){
        return  "0.000";
      }
    } else {
      return  "-";
    }
  }
  if(tempNum == '-'){
    return "-";
  }
  // 接受数字变双浮点
  let numToFloat = fixed==2?tempNum.toFixed(2):tempNum.toFixed(3);
  // 分割整数和浮点数
  let num0 = numToFloat.split(".")[0];
  let num1 = numToFloat.split(".")[1];
  let result = 0;

  if ((fixed == 2 && num1 === '00') || num1 === '000') {
    result = num0;
  } else {
    result = num0 + "." + num1;
  }

  return result;
  // return numToFloat;
};

// 产量 销量 出库量 吨数的时候都是保留三位小数,
// 千克的时候是2位小数
export const weightFormat = (num, needConver = false, fixed = 2) => {
  let tempNum = num;

  if (needConver && !isNaN(tempNum)) {
    tempNum = Number(tempNum) / 1000;
  } else {
    tempNum = Number(tempNum);
  }

  if (tempNum === null || tempNum == '-' || isNaN(tempNum)) {
    return "-";
  }

  // 接受数字变双浮点
  let numToFloat = fixed==2?tempNum.toFixed(2):tempNum.toFixed(3);
  // 分割整数和浮点数
  let num0 = numToFloat.split(".")[0];
  let num1 = numToFloat.split(".")[1];
  let result = 0;
  num0 = parseInt(num0).toLocaleString();

  if ((fixed == 2 && num1 === '00') || num1 === '000') {
    result = num0;
  } else {
    result = num0 + "." + num1;
  }

  return result;
};

export const weightFormatForKanBan = (num, needConver = false, fixed = 2) => {
  let tempNum;

  if (needConver && !isNaN(num)) {
    tempNum = Number(num) / 1000;
  } else {
    tempNum = Number(num);
  }

  if (!tempNum) {
    if (tempNum === 0) {
      if(fixed==2){
        return  "0.00";
      }
      if(fixed==3){
        return  "0.000";
      }
    } else {
      return  "-";
    }
  }
  if(tempNum == '-'){
    return "-";
  }
  // 接受数字变双浮点
  let numToFloat = fixed==2?tempNum.toFixed(2):tempNum.toFixed(3);
  // 分割整数和浮点数
  let num0 = numToFloat.split(".")[0];
  let num1 = numToFloat.split(".")[1];
  num0 = parseInt(num0).toLocaleString();
  return  num0 + "." + num1;
};

export const moneyAbsFormat = (num) => {
  if (typeof num === 'number') {
    return Math.abs(num);
  }

  return num;
}
export const removeTrailingZeros = (number) => {
   if(number== undefined || number==null || number=='-') return '-'
    let numberString = number.toString();
    numberString = numberString.replace(/(?:\.0*|(\.\d+?)0+)$/, "$1");
    let num = String(parseFloat(numberString))
   let arr = num.split('.')
  if (arr.length > 1 && arr[1].length > 3) {
    // console.log(arr[1].length,parseFloat(numberString));
    return parseFloat(numberString).toFixed(3);


  } else {
     return parseFloat(numberString)
  }


};
