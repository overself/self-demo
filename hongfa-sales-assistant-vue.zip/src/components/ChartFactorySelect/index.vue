<template>
  <div>
    <el-radio-group
      v-model="factoryValue"
      @input="handleInput"
    >
      <el-radio-button
        v-for="(item, index) in options"
        :key="index"
        :label="item.value"
      >{{item.label}}</el-radio-button>
    </el-radio-group>
  </div>
</template>

<script>
export default {
  props: {
    options: {
      type: Array,
      default: () => {
        return [
          { label: '全部', value: '' },
          { label: '一厂', value: '1' },
          { label: '二厂', value: '2' },
          { label: '朝阳', value: '3' },
          { label: '喀左', value: '4' },
        ];
      },
    },
  },

  data() {
    return {
      factoryValue: '',
    };
  },

  methods: {
    handleInput(e) {
      //   console.log(e, '1111111');
      this.$emit('radioChange', e);
    },
  },
};
</script>

<style lang="scss" scoped>
</style>
