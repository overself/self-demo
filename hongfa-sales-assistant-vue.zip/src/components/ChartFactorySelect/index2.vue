<template>
  <div>
    <el-radio-group v-model="factoryValue" size="small" @input="handleInput">
      <el-radio-button v-for="(item, index) in options" :key="index"
        :label="item.value">{{ item.label }}</el-radio-button>
    </el-radio-group>
  </div>
</template>

<script>
export default {
  props: {
    options: {
      type: Array,
      default: () => {
        return [
          //   { label: '本月', value: '0' },
          //   { label: '上月', value: '1' },
          //   { label: '本年', value: '2' },
          { label: '本月', value: '1' },
          { label: '上月', value: '2' },
          { label: '本年', value: '3' },
        ];
      },
    },
  },

  data() {
    return {
      factoryValue: '1',
      timeArr: [],
    };
  },

  methods: {
    // getMonth() {
    //   const now = new Date();
    //   const year = new Date().getFullYear();
    //   const currentMonth = now.getMonth() + 1;
    //   const lastDay = new Date(year, currentMonth, 0).getDate();
    //   const currentMonthStr =
    //     currentMonth > 9 ? currentMonth : '0' + currentMonth;
    //   return [
    //     year + '-' + currentMonthStr + '-01',
    //     year + '-' + currentMonthStr + '-' + lastDay,
    //   ];
    // },
    // getLastMonth() {
    //   const now = new Date();
    //   const lastMonthsAgo = new Date(now.setMonth(now.getMonth()));
    //   const month1 =
    //     lastMonthsAgo.getMonth() > 9
    //       ? lastMonthsAgo.getMonth()
    //       : '0' + lastMonthsAgo.getMonth();
    //   const year = lastMonthsAgo.getFullYear();
    //   const lastDay = new Date(year, month1, 0).getDate();
    //   return [year + '-' + month1 + '-01', year + '-' + month1 + '-' + lastDay];
    // },
    // getYear() {
    //   const year = new Date().getFullYear();
    //   let arr = [year + '-01-01', year + '-12-31'];
    //   return arr;
    // },
    handleInput(e) {
      //   switch (e) {
      //     case '0':
      //       this.timeArr = this.getMonth();
      //       break;
      //     case '1':
      //       this.timeArr = this.getLastMonth();
      //       break;
      //     case '2':
      //       this.timeArr = this.getYear();
      //       break;
      //     default:
      //       break;
      //   }
      //   this.$emit('radioChange', this.timeArr);
      this.$emit('radioChange', e);
    },
  },
};
</script>

<style lang="scss" scoped></style>
