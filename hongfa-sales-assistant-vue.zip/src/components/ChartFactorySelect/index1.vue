<template>
  <div>
    <el-radio-group
      v-model="factoryValue"
      @input="handleInput"
    >
      <el-radio-button
        v-for="(item, index) in options"
        :key="index"
        :label="item.value"
        :class="!showOther?index!==5?'':'hide':''"
      >{{item.label}}</el-radio-button>
    </el-radio-group>
  </div>
</template>
  
  <script>
export default {
  props: {
    options: {
      type: Array,
      default: () => {
        return [
          { label: '全部', value: '' },
          { label: '一区', value: '1' },
          { label: '二区', value: '2' },
          { label: '三区', value: '3' },
          { label: '集团', value: '4' },
          { label: '其他', value: '5' },
        ];
      },
    },
    showOther: {
      type: Boolean,
      default: true,
    },
  },

  data() {
    return {
      factoryValue: '',
    };
  },

  methods: {
    handleInput(e) {
      //   console.log(e, '1111111');
      this.$emit('radioChange', e);
    },
  },
};
</script>
  
  <style lang="scss" scoped>
.hide {
  display: none;
}
</style>
  