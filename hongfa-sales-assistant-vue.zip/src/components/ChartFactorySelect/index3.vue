<template>
  <div>
    <el-date-picker
      v-model="value"
      type="month"
      placeholder="选择月"
      format="yyyy-MM"
      value-format="yyyy-MM"
      @change="handeleChange"
      :clearable="false"
    >
    </el-date-picker>
  </div>
</template>
      
      <script>
import { getConfigMonth } from '@/api/personal/index';
export default {
  props: {},

  data() {
    return {
      value: '2024-11',
    };
  },
  created() {
    getConfigMonth()
      .then((res) => {
        if (
          res.data.oneWeek === null ||
          res.data.twoWeek === null ||
          res.data.threeWeek === null ||
          res.data.fourWeek === null
        ) {
          this.$notify.error({ title: `请先配置时间` });

          return;
        }

        this.value = res.data.year + '-' + res.data.month;
        this.$emit('initTime', this.value);
      })
      .catch((err) => {});
  },
  methods: {
    handeleChange(val) {
      console.log(val, 'handeleChange');

      this.$emit('timeChange', val);
    },
  },
};
</script>
      
      <style lang="scss" scoped>
</style>
      