<template>
  <div>
    <div class="content_wrap">
      <slot name='left'></slot>

      <div
        class="list_wrap"
        :style="this.$slots.list ? 'margin-top: 40px;' : ''"
      >
        <slot name='list'></slot>
      </div>

      <div class="tabs_right_btns">
        <slot name='rightBtns'></slot>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },

  methods: {},
};
</script>

<style scoped lang="scss">
</style>