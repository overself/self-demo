<template>
  <div>
    <p>{{ currentTime }}</p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      currentTime: null,
    };
  },
  created() {
    this.updateTimer(); // 创建时启动计时器
  },
  beforeDestroy() {
    clearInterval(this.timeInterval); // 销毁组件时清除计时器
  },
  methods: {
    updateCurrentTime() {
      const date = new Date();

      const year = date.getFullYear();

      const month = date.getMonth() + 1;

      const day = date.getDate();

      const hour = date.getHours();

      const minute = date.getMinutes();

      const second = date.getSeconds();

      this.currentTime = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
    },
    updateTimer() {
      this.updateCurrentTime();
      this.timeInterval = setInterval(() => this.updateCurrentTime(), 1000); // 每秒更新一次
    },
  },
};
</script>
