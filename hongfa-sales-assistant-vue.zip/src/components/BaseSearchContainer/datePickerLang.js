const datePickerLang = {
  // MMMM
  months: [
    '一月',
    '二月',
    '三月',
    '四月',
    '五月',
    '六月',
    '七月',
    '八月',
    '九月',
    '十月',
    '十一月',
    '十二月',
  ],
  // MMM
  monthsShort: [
    '1月',
    '2月',
    '3月',
    '4月',
    '5月',
    '6月',
    '7月',
    '8月',
    '9月',
    '10月',
    '11月',
    '12月',
  ],
  // dddd
  weekdays: [
    '星期日',
    '星期一',
    '星期二',
    '星期三',
    '星期四',
    '星期五',
    '星期六',
  ],
  // ddd
  weekdaysShort: ['日', '一', '二', '三', '四', '五', '六'],
  // dd
  weekdaysMin: ['日', '一', '二', '三', '四', '五', '六'],
  days: ['日', '一', '二', '三', '四', '五', '六'],
  yearFormat: 'YYYY 年',
  // the calendar title of month
  monthFormat: 'MM',
  monthBeforeYear: false,
};

export default datePickerLang; 
