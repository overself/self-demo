<template>
  <div class='st-base-search-container'>
    <div
      class="quick-wrapper"
      v-if="type === 'quick'"
    >
      <div>
        <div
          v-for="(item, index) in innerColumn"
          :key='index'
        >
          <div
            class="top-search"
            v-if="item.quick"
          >
            <div class="top-search-item">
              <div class="search-label">{{item.label}}</div>
              <div class="search-value">
                <div
                  class="search-value-item"
                  :class="formatSearchItemClass(item, idx)"
                  v-for="(itm, idx) in item.dicData"
                  :key="idx"
                  @click="changeSearchItem(item, itm, index, idx)"
                >
                  {{ itm.label }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 筛选条件 -->
      <div class="top-search-item dynamicTags pc_bottom">
        <div class="search-label">筛选条件</div>
        <div class="search-date-value">
          <el-tag
            v-for="(tag, idx) in dynamicTags"
            size="large"
            :key="idx"
            class="mx-1"
            closable
            :disable-transitions="true"
            @close="handleClose(tag)"
          >
            {{ tag._label }}
          </el-tag>
        </div>
      </div>

      <div class="search-btn-wrapper">
        <el-button
          icon="el-icon-search"
          @click="handleQuery('quick')"
        >查询</el-button>
        <el-button
          v-if="showResetBtn"
          icon="el-icon-refresh"
          @click="resetQuery('quick')"
        >重置</el-button>
      </div>
    </div>

    <div
      class="condition-wrapper"
      v-if="type === 'condition'"
    >
      <el-form
        :class="isCollapse ? (!isCollapseShow ? 'is-collapse' : '' ) : ''"
        :model="params"
        ref="hookForm"
        size="small"
        :inline="true"
        :label-width="labelWidth"
      >
        <div
          v-for="(item, index) in innerColumn"
          :key="index"
          style="display: inline-block;"
        >
          <el-form-item
            :label="item.label"
            :label-width="item.labelWidth || labelWidth"
            :prop="item.prop"
            v-if="item.search && item.type === 'input'"
          >
            <slot :name="item.prop">
              <el-input
                v-model="params[item.prop]"
                :placeholder="`请输入${item.label}`"
                :style="{width: item.width || '240px'}"
                clearable
                :type="item.inputType || 'text'"
                @keyup.enter.native="onInput($event, item, params)"
              ></el-input>
            </slot>
          </el-form-item>

          <el-form-item
            :label="item.label"
            :label-width="item.labelWidth || labelWidth"
            :prop="item.prop"
            v-if="item.search && (item.type === 'select' || item.type === 'radio')"
          >
            <slot :name="item.prop">
              <el-select
                v-model="params[item.prop]"
                :placeholder="`请选择${item.label}`"
                clearable
                filterable
                :multiple="item.multiple || false"
                :style="{width: item.width || '240px'}"
                :disabled="item.disabled"
                @change="onSelectChange($event, item)"
              >
                <el-option
                  v-for="item in item.dicData"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </slot>
          </el-form-item>

          <el-form-item
            :label="item.label"
            :label-width="item.labelWidth || labelWidth"
            :prop="item.prop"
            v-if="item.search && (item.type === 'city')"
          >
            <slot :name="item.prop">
              <el-cascader
                clearable
                filterable
                :style="{width: item.width || '240px'}"
                :placeholder="`请选择${item.label}`"
                v-model="params[item.prop]"
                :options="cityOption"
                :props="item.cascaderProp"
                @change="cityChange"
              >
              </el-cascader>
            </slot>
          </el-form-item>

          <el-form-item
            :label="item.label"
            :label-width="item.labelWidth || labelWidth"
            :prop="item.prop"
            v-if="item.search && (item.type == 'monthrange' || item.type === 'date' || item.type === 'datetime' || item.type === 'year' || item.type === 'month')"
          >
            <slot :name="item.prop">
              <el-date-picker
                v-model="params[item.prop]"
                :type="item.type"
                :placeholder="item.placeholder || '选择日期'"
                :start-placeholder="item.startPlaceholder || '开始日期'"
                :end-placeholder="item.endPlaceholder || '结束日期'"
                size="small"
                :format="item.format || 'yyyy-MM-dd'"
                :valueFormat="item.valueFormat || 'yyyy-MM-dd'"
                :style="{width: item.width || '240px'}"
                :clearable="item.clearable === false ? false : true"
                @change='onElDatePickerChange'
              ></el-date-picker>
            </slot>
          </el-form-item>

          <el-form-item
            :label="item.label"
            :label-width="item.labelWidth || labelWidth"
            :prop="item.prop"
            v-if="item.search && (item.type === 'daterange')"
          >
            <slot :name="item.prop">
              <el-date-picker
                v-model="params[item.prop]"
                :type="item.type"
                range
                placeholder="选择日期"
                :lang="datePickerLang"
                :value-format="item.format || 'yyyy-MM-dd'"
                :value-type="item.valueType || 'format'"
                :style="{width: item.width || '240px'}"
                :clearable="item.clearable === false ? false : true"
                @change='onVue2DatePickerChange'
              ></el-date-picker>
            </slot>
          </el-form-item>

          <el-form-item
            :label="item.label"
            :label-width="item.labelWidth || labelWidth"
            :prop="item.prop"
            v-if="item.search && (item.type === 'inputRange')"
          >
            <slot :name="item.prop">
              <div>
                <el-input
                  v-model="params[item.startProp]"
                  :placeholder="`请输入${item.startPlaceholder || item.label}`"
                  clearable
                  :style="{width: item.width || '240px'}"
                  :type="item.startInputType || 'text'"
                  :max="item.startInputMax"
                  :min="item.startInputMin"
                >
                  <template
                    slot="append"
                    v-if="item.startUnit"
                  >{{item.startUnit}}</template>
                </el-input>
                <span style="margin: 0 10px;">至</span>
                <el-input
                  v-model="params[item.endProp]"
                  :placeholder="`请输入${item.endPlaceholder || item.label}`"
                  clearable
                  :style="{width: item.width || '240px'}"
                  :type="item.endInputType || 'text'"
                  :max="item.endInputMax"
                  :min="item.endInputMin"
                >
                  <template
                    slot="append"
                    v-if="item.endUnit"
                  >{{item.endUnit}}</template>
                </el-input>
              </div>
            </slot>
          </el-form-item>
        </div>

        <el-form-item v-if="!isCollapse">
          <slot name='btnsLeft'></slot>

          <el-button
            v-if="showSearchBtn"
            icon="el-icon-search"
            @click="handleQuery('condition')"
          >查询</el-button>
          <el-button
            v-if="showResetBtn"
            icon="el-icon-refresh"
            @click="resetQuery('condition')"
          >重置</el-button>

          <slot name='btnsRight'></slot>
        </el-form-item>
      </el-form>

      <div
        v-if="isCollapse"
        style="text-align: center;"
      >
        <slot name='btnsLeft'></slot>

        <el-tooltip
          class="item"
          effect="dark"
          :content="!isCollapseShow ? '展开' : '收起'"
          placement="top"
        >
          <el-button
            size="mini"
            circle
            icon="el-icon-more"
            @click="toggleIsCollapseShow"
          />
        </el-tooltip>

        <el-button
          v-if="showSearchBtn"
          icon="el-icon-search"
          size="small"
          @click="handleQuery('condition')"
        >查询</el-button>

        <el-button
          v-if="showResetBtn"
          icon="el-icon-refresh"
          size="small"
          @click="resetQuery('condition')"
        >重置</el-button>

        <slot name='btnsRight'></slot>
      </div>
    </div>
  </div>
</template>

<script>
import { debounce } from 'throttle-debounce';
import { deepClone } from '@/utils';
import { getAreaTree } from '@/api/system/area';
import request from '@/utils/request';

export default {
  props: {
    type: {
      type: String,
      default: 'condition', // quick/condition
    },
    column: {
      type: Array,
      required: true,
    },
    params: {
      type: Object,
      default: () => {},
    },
    labelWidth: {
      type: String,
      default: '90px',
    },
    showSearchBtn: {
      type: Boolean,
      default: true,
    },
    showResetBtn: {
      type: Boolean,
      default: true,
    },
    isCollapse: {
      type: Boolean,
      default: false,
    },
    isAll: {
      type: Boolean,
      default: true,
    },
  },

  data() {
    return {
      innerColumn: [],
      datePickerLang: {
        // MMMM
        months: [
          '一月',
          '二月',
          '三月',
          '四月',
          '五月',
          '六月',
          '七月',
          '八月',
          '九月',
          '十月',
          '十一月',
          '十二月',
        ],
        // MMM
        monthsShort: [
          '1月',
          '2月',
          '3月',
          '4月',
          '5月',
          '6月',
          '7月',
          '8月',
          '9月',
          '10月',
          '11月',
          '12月',
        ],
        // dddd
        weekdays: [
          '星期日',
          '星期一',
          '星期二',
          '星期三',
          '星期四',
          '星期五',
          '星期六',
        ],
        // ddd
        weekdaysShort: ['日', '一', '二', '三', '四', '五', '六'],
        // dd
        weekdaysMin: ['日', '一', '二', '三', '四', '五', '六'],
        days: ['日', '一', '二', '三', '四', '五', '六'],
        yearFormat: 'YYYY 年',
        // the calendar title of month
        monthFormat: 'MM',
        monthBeforeYear: false,
      },
      cityOption: [],
      quickParams: {},
      isCollapseShow: false,
    };
  },

  watch: {
    column: {
      handler(newV) {
        if (newV) {
          this.innerColumn = deepClone(newV);

          this.innerColumn.forEach((item, index) => {
            if (item.dicUrl) {
              this.$set(item, 'dicData', []);

              let params = {
                url: item.dicUrl,
                method: item.dicMethod || 'get',
              };

              if (item.dicQuery) {
                params.params = item.dicQuery;
              }

              request(params).then((res) => {
                item.dicData = res.data.map((itm) => {
                  return {
                    label: itm[item.dicLabelProp || 'name'],
                    value: itm[item.dicValueProp || 'id'],
                  };
                });

                if (item.unshiftAll) {
                  if (this.isAll) {
                    item.dicData.unshift({
                      label: '全部',
                      value: 'all',
                    });
                  }
                }
                // this.$set(this.innerColumn, );
              });
            }
          });
        }
      },
      immediate: true,
    },
  },

  computed: {
    dynamicTags() {
      let arr = [];
      let quickParams = {};

      this.innerColumn.forEach((item, wrapIndex) => {
        // 多选
        if (item.index.length) {
          let quickParamsItemArr = [];
          item.index.forEach((itm) => {
            let label = item.dicData[itm].label;

            arr.push(
              Object.assign({}, item.dicData[itm], {
                _label: label == '全部' ? `全部${item.label}` : label,
                _wrapIndex: wrapIndex,
                _innerIndex: itm,
              })
            );

            quickParamsItemArr.push(item.dicData[itm].value);
          });

          quickParams[item.prop] = quickParamsItemArr;
        } else if (!Array.isArray(item.index) && item.index != -1) {
          let label = item.dicData[item.index].label;

          arr.push(
            Object.assign({}, item.dicData[item.index], {
              _label: label == '全部' ? `全部${item.label}` : label,
              _wrapIndex: wrapIndex,
              _innerIndex: item.index,
            })
          );

          // 构造查询参数
          quickParams[item.prop] = item.dicData[item.index].value;
        }
      });

      this.quickParams = quickParams;
      return arr;
    },
  },

  created() {
    getAreaTree().then((res) => {
      this.cityOption = res.data;

      this.cityOption.forEach((item) => {
        item.label = item.name;
        item.value = item.id;

        item.children.forEach((i) => {
          i.label = i.name;
          i.value = i.id;

          delete i.children;
        });
      });
    });
  },

  methods: {
    toggleIsCollapseShow() {
      this.isCollapseShow = !this.isCollapseShow;

      this.$emit('toggleCollapse');
    },

    handleQuery(type) {
      let params = {};

      if (type == 'condition') {
        params = this.params;
      } else {
        params = this.quickParams;
      }

      this.$emit('onSearch', params);
    },

    resetQuery(type) {
      if (type == 'quick') {
        this.innerColumn.forEach((item) => {
          if (Array.isArray(item.index)) {
            item.index = [];
          } else {
            item.index = -1;
          }
        });
      } else {
        this.$refs.hookForm.resetFields();
      }

      this.$emit('onReset');
    },

    cityChange(e) {
      this.$emit('cityChange', e);
    },

    onElDatePickerChange(e) {
      this.$emit('elDatePickerChange', e);
    },

    onVue2DatePickerChange(e) {
      try {
        this.$emit('datePickerChange', e[0] === null ? null : e);
      } catch (error) {
        this.$emit('datePickerChange', e);
      }
    },

    handleClose(tag) {
      // 处理innerColumn里的数据
      let item = this.innerColumn[tag._wrapIndex];

      if (Array.isArray(item.index)) {
        // 多选
        let idx = item.index.indexOf(tag._innerIndex);
        item.index.splice(idx, 1);
      } else {
        item.index = -1;
      }
    },

    changeSearchItem(item, itm, index, idx) {
      // item.index = idx;
      if (item.multiple && !Array.isArray(item.index)) {
        console.error('index不是个数组');
        return;
      }

      if (item.multiple) {
        if (item.index.includes(idx)) return; // 选过了

        // 处理全部互斥
        if (
          itm.label == '全部' ||
          item.index.some((id) => item.dicData[id].label == '全部')
        ) {
          item.index = [idx];
        } else {
          item.index.push(idx);
        }
      } else {
        item.index = idx;
      }

      this.$emit('change');
    },

    formatSearchItemClass(item, idx) {
      if (Array.isArray(item.index)) {
        return item.index.includes(idx) ? 'active' : '';
      } else {
        // 单选
        return item.index == idx ? 'active' : '';
      }
    },

    onInput: debounce(function (e, item) {
      this.$emit('onInput', {
        value: e,
        columnItem: item,
        params: this.params,
      });
    }, 300),

    onSelectChange(e, item) {
      this.$emit('selectChange', {
        value: e,
        columnItem: item,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.st-base-search-container {
  .quick-wrapper {
    .top-search {
      background: #ffffff;
      border-radius: 10px 10px 10px 10px;
      padding: 10px 0px;
      opacity: 1;
    }

    .top-search-item {
      display: flex;
      justify-content: start;
      align-items: center;

      .search-label {
        text-align: right;
        flex: 0 0 110px;
        font-size: 14px;
        font-weight: 400;
        color: #999;
        line-height: 16px;
        margin-right: 24px;
      }

      .search-date-value {
        margin-left: 11px;

        .el-tag {
          margin-right: 10px;
        }
      }

      .search-value-button {
        margin-right: 11px;
      }

      .search-value {
        display: flex;
        flex-wrap: wrap;

        .search-value-item {
          margin: 5px 10px;
          padding: 5px 20px;
          border-radius: 4px;
          border: 1px solid transparent;
          font-size: 14px;
          background-color: rgba(242, 242, 242, 1);
          color: rgba(102, 102, 102, 1);
          cursor: pointer;

          &.active {
            background-color: rgba(243, 249, 255, 1);
            color: #0079fe;
          }
        }
      }
    }

    // .dynamicTags {
    //   height: 30px;
    // }

    .search-time {
      padding-bottom: 17px;
      border-bottom: 1px solid #ececec;
    }

    .search-btn-wrapper {
      margin: 10px;
      text-align: center;
    }
  }

  .condition-wrapper {
    .is-collapse {
      height: 95px; // 2行
      overflow: hidden;
    }
  }
}
</style>
