let MIXIN = {
  data() {
    return {
      tabsWidth: 0,
    };
  },

  mounted() {
    // this.$_getTabsRect();
  },

  methods: {
    $_getTabsRect() {
      this.$nextTick(() => {
        const tabsArr = document.getElementsByClassName('st-rect-tabs');

        if (tabsArr.length) {
          const tabsNavArr = tabsArr[0].getElementsByClassName('el-tabs__nav');

          if (tabsNavArr.length) {
            setTimeout(() => {
              // console.log(tabsNavArr[0].getBoundingClientRect());
              this.tabsWidth = tabsNavArr[0].getBoundingClientRect().width;
            }, 300);
          }
        }
      })
    },
  },
};

export default MIXIN;
