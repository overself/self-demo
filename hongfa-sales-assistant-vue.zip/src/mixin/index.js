import { getToken, setStore } from "@/utils/auth";
// import { debounce } from "@/utils/debounce";
import { upload } from "@/api/login";
import CityOption from "@/static/js/city3";
import AreaOption from "@/static/js/cityArea";
// import Empty from "@/components/Empty";
import { getStore, removeStore } from "../utils/auth";
import CurrentTime from '@/components/CurrentTime';

let MIXIN = {
  components: {
    CurrentTime,
    // Empty,
  },
  data() {
    // const now = new Date();
    // const future = new Date(now.getFullYear() + 3, 11, 31);
    return {
      imgApi: process.env.VUE_APP_BASE_IMAGE,
      routerName: "",
      userInfo: {},
      cityOptions: [],
      areaOptions: [],
    };
  },
  watch: {
    $route(newValue) {
      if (newValue) {
        // console.log(newValue);
        this.routerName = newValue.name;
      }
    },
  },
  created() {
    if (this.$route) {
      this.routerName = this.$route.name;
    }
    this.getCityOptions();
    // console.log(now);
  },
  mounted() {},
  methods: {
    getRangeDate(type) {
      let start = this.$dayjs().startOf(type).format('YYYY-MM-DD');
      let end = this.$dayjs().endOf(type).format('YYYY-MM-DD');
      return `${start},${end}`;
    },
    changeInputPt2 (e,fixed) {
      console.log(e.target.value)
      if(fixed === 0&&e.target.value.indexOf('.') >= 0){
        e.target.value = e.target.value.split('.')[0]
      }
      if ((e.target.value.indexOf('.') >= 0)) {
        e.target.value = e.target.value.substring(0, e.target.value.indexOf('.') + (fixed+1)) // 这里采用截取 既可以限制第三位小数输入 也解决了数字输入框默认四舍五入问题
        e.target.value = parseInt(e.target.value,10)||0+'.'+e.target.value.split('.')[1]
      }else{
        e.target.value = parseInt(e.target.value.toString().replace(/^0+/, '')) || 0;
      }
      // e.target.value = parseInt(e.target.value,10)
      console.log(e.target.value)
    },
    adClick(item) {
      switch (item.detailType) {
        case 1:
          // 富文本
          this.linkJump("/RichText", { id: item.id });
          break;
        case 2:
          // 链接
          this.openWindow(item.linkUrl);
          break;
        default:
          break;
      }
    },
    toProtocol(code) {
      console.log(code);
      // window.open(process.env.VUE_APP_PROTOCOL_URL + "?code=" + code);
      window.open("http://ddns.lemlink.com:38001/protocol/userAgent.html");
    },
    toOpinion() {
      window.open(process.env.VUE_APP_YIJIAN_URL);
    },
    toBusiness() {
      // 去商家端
      window.open(process.env.VUE_APP_BUSINESS_URL);
    },
    getUserInfo() {
      // 从localStorage中取userInfo
      let userInfoStr = getStore("userInfo");
      if (userInfoStr) {
        this.userInfo = JSON.parse(userInfoStr);
      } else {
        this.userInfo = {};
      }
    },
    // toLogin(){
    //   // 记录当前页跳转登录
    //   console.log(this.$route);

    //   this.$router.push("/login");
    // },
    downloadFile(item) {
      window.open(
        process.env.VUE_APP_BASE_IMAGE + item.fileurl,
        "download=" + item.filename
      );
      // 下载
      this.$message({
        message: "下载中",
        type: "success",
      });
    },
    openWindow(link) {
      // 打开新窗口
      window.open(link);
    },
    getCityOptions() {
      AreaOption.map((item) => {
        item.value = item.label;
        item.children.map((i) => {
          i.value = i.label;
          if (i.children) {
            i.children.map((k) => {
              k.value = k.label;
            });
          }
        });
      });
      CityOption.map((item) => {
        item.value = item.label;
        item.children.map((i) => {
          i.value = i.label;
          delete i.children;
        });
      });
      this.areaOptions = AreaOption;
      this.cityOptions = CityOption;
    },
    // debounce,
    async singleUpload(formData) {
      const { data } = await upload(formData);
      return data;
    },
    toRightPath(path) {
      let urlRecord = getStore("urlRecord");
      if (!urlRecord) {
        console.log("toRightPath");
        this.$router.replace({ path });
      } else {
        removeStore("urlRecord");
        this.$router.replace({ path: urlRecord });
      }
    },
    linkJump(link, params = {}, after) {
      console.log(link);
      let routeData = this.$router.resolve({
        path: link,
        query: params,
      });
      console.log("看看routeData", routeData);
      if (!getToken()) {
        if (link === "/login") {
          if (after) {
            setStore("urlRecord", after);
          } else {
            setStore("urlRecord", this.$route.fullPath);
          }
        } else {
          setStore("urlRecord", routeData.route.fullPath);
        }
      }
      // if (!this.$common.isEmpty(params.id)) {
      //   window.open(routeData.href + "?id=" + params.id);
      // } else {
      window.open(routeData.href);
      // }
    },
    toRouterPush(path, query = {}, scroll) {
      document.documentElement.scrollTop = document.body.scrollTop = scroll;
      this.$router.push({
        path,
        query,
      });
    },

    handleVisiable(e) {
      // 监听页面离开事件
      if (e.target.visibilityState === "visible") {
        console.log("回来了,刷新列表");
        this.onRefresh();
      } else {
        console.log("离开了");
      }
    },
    // 裁剪取消
    canceltailor() {
      this.fileList = [];
    },

    // 校验全屏状态
    checkFull() {
      var isFull =
        document.fullscreenEnabled ||
        window.fullScreen ||
        document.webkitIsFullScreen ||
        document.msFullscreenEnabled;
      if (isFull === undefined) isFull = false;
      return isFull;
    },
    SplitArray(N, Q) {
      let R = [],
        F;
      for (F = 0; F < Q.length; ) R.push(Q.slice(F, (F += N)));
      return R;
    },
  },
};
export default MIXIN;
