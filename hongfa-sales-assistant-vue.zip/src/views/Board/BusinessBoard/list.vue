<!-- 价格看板编辑列表 -->
<template>
  <div class="list_wrap">
    <el-table
      v-loading="loading"
      ref="hookTable"
      :data="tableData"
      :span-method="objectSpanMethod"
      border
      style="width: 100%;"
      :cell-style="addClass"
      :height="tableHeight"
    >
      <!-- <el-table-column prop="id" label="ID" width="180"> </el-table-column> -->
      <el-table-column
        prop="productTopTypeName"
        label="品项大类"
        header-align="center"
        align="center"
        width="100"
      >
        <template slot-scope="scope">
          <div class="cat_text">
            {{ scope.row.productTopTypeName || '-' }}
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="productType"
        label="品类编码"
        header-align="center"
        align="center"
        width="100"
      ></el-table-column>

      <el-table-column
        prop="productTypeName"
        label="品项分类"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div
            :id="scope.row.domIds+scope.row.domIdxs"
            class="cat_mao"
            :ref="scope.$index"
          ></div>
          <div class="cat_text">
            {{ scope.row.productTypeName || '-' }}
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="productCode"
        label="品项编码"
        header-align="center"
        width="180"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="productName"
        label="品项"
        header-align="center"
        align="center"
        width="230"
      ></el-table-column>

      <el-table-column
        prop="productSpec"
        label="详细规格"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          {{ scope.row.productSpec }}
        </template>
      </el-table-column>
      <el-table-column prop="productSpec" label="工厂类型" header-align="center" align="center">
        <template slot-scope="scope">
          {{ scope.row.factoryName }}
        </template>
      </el-table-column>
      <el-table-column
        prop="yesterdayPrice"
        label="昨日价格（￥）"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div class="">{{ scope.row.yesterdayPrice | moneyFormat }}</div>
        </template>
      </el-table-column>

      <el-table-column
        prop="price"
        label="今日价格（￥）"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div class="is_edit" v-if="scope.row.isEdit || scope.row._isEditPrice">
            <el-input-number
              ref="_isEditPrice"
              style="width:100%"
              :controls="false"
              :step="0.01"
              :precision="2"
              v-model="scope.row.newRow.price"
              placeholder="请填写"
              @blur="onColumnBlur($event, scope.row, '_isEditPrice')"
            ></el-input-number>
          </div>

          <div
            class=""
            v-else
            @dblclick="onColumnDbClick(scope.row, '_isEditPrice')"
          >{{ scope.row.price | moneyFormat }}
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="adjustRange"
        label="调幅（￥）"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div
            class="is_edit adjustRange_class"
            v-if="scope.row.isEdit"
          >
            <span
              class="red"
              v-if="scope.row.newRow.adjustRange>0"
            >↑</span>
            <span
              class="green"
              v-if="scope.row.newRow.adjustRange <0"
            >↓</span>
            {{ scope.row.newRow.adjustRange | moneyAbsFormat | moneyFormat }}
          </div>

          <div
            class="adjustRange_class"
            v-else
          >
            <span
              class="red"
              v-if="scope.row.adjustRange>0"
            >↑</span>
            <span
              class="green"
              v-if="scope.row.adjustRange<0"
            >↓</span>
            {{ scope.row.adjustRange | moneyAbsFormat | moneyFormat }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        v-if="queryParams.priceType != 'wholesale_price_type'"
        prop="marketPrice"
        label="操作"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <el-button
            v-if="permi.hasPermi('system:board-price:update')"
            type="text"
            :disabled="editDisabled(scope.row)"
            style="border: none; background-color: transparent;"
            @click="handleEdit(scope.row, scope.$index)"
          >{{ scope.row.isEdit ? '保存' : '编辑' }}
          </el-button>

          <span v-else>暂无权限</span>
        </template>
      </el-table-column>
    </el-table>

    <ListMenu
      :menuData="menuData"
      isTableFixed
    ></ListMenu>
  </div>
</template>

<script>
import Decimal from 'decimal.js';
import ListMenu from '../components/ListMenu';
import {listData, updateData} from '@/api/Board/BusinessBoard';
import permi from '@/plugins/auth.js';

export default {
  // import引入的组件需要注入到对象中才能使用
  components: {ListMenu},
  props: {
    queryParams: {
      type: Object,
      default: () => {
        return {
          productId: '',
          productType: '',
          priceType: '',
          priceDate: '',
        };
      },
    },
    activeTabName: {
      type: String,
      default: () => {
        return '1';
      },
    },
  },

  data() {
    // 这里存放数据
    return {
      permi,
      loading: true,
      tableData: [],
      stockData: {
        xData: [
          '2024-5-1',
          '2024-5-2',
          '2024-5-3',
          '2024-5-4',
          '2024-5-5',
          '2024-5-6',
          '2024-5-7',
        ],
        yData: [0, 100, 200, 300, 400, 500, 600],
        max: 200,
        min: 20,
      },
      menuData: [],

      calcListData: [],
      calcListDatas: [],
      tableHeight: 0,
    };
  },
  watch: {
    activeTabName(val) {
      this.calTableHeight();
    },
  },
  // 监听属性 类似于data概念
  computed: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
  },

  created() {
    this.calTableHeight();
    this.getList();

    window.addEventListener('resize', this.calTableHeight);
  },

  mounted() {
    this.calcCatData();
    this.calcCatData2();
  },

  beforeDestroy() {
    window.removeEventListener('resize', this.calTableHeight);
  },

  methods: {
    calTableHeight() {
      const viewportHeight =
        window.innerHeight ||
        document.documentElement.clientHeight ||
        document.body.clientHeight;
      // this.tableHeight = viewportHeight - 50 - 20 - 41 - 55 - 20 - 10 - 36 - 60; // 36是tag
      this.tableHeight =
        this.activeTabName == '1'
          ? viewportHeight - 50 - 20 - 41 - 55 - 20 - 10 - 36 - 60 - 18
          : viewportHeight - 50 - 20 - 41 - 55 - 20 - 10 - 36 - 10; // 36是tag 63是搜索区域
      this.$nextTick(() => {
        this.$refs?.hookTable.doLayout();
      });
    },

    onColumnDbClick(row, key) {
      // console.log(row);
      if (this.isNotToday()) return;
      row[key] = true;
      this.$nextTick(() => {
        this.$refs[key]?.focus();
      });
    },

    onColumnBlur(e, row, key) {
      if (row.isEdit) return;

      if (
        (key === '_isEditPrice' &&
          Number(row.price) === Number(row.newRow.price)) ||
        (key === '_isEditPriceRemark' &&
          row.priceRemark === row.newRow.priceRemark)
      ) {
        row[key] = false;
        return;
      }

      const newData = {id: row.id, priceType: this.queryParams.priceType, ...row.newRow};
      this.updateDataFunc(newData).then(() => {
        row[key] = false;
        this.$message({
          type: 'success',
          message: '保存成功',
        });

        row.productSpec = row.newRow.productSpec;
        row.price = row.newRow.price;
        // row.adjustRange = row.newRow.adjustRange;
        row.priceRemark = row.newRow.priceRemark;
        row.marketPrice = row.newRow.marketPrice;

        // 算调幅
        if (
          row.price !== null &&
          row.yesterdayPrice !== null &&
          row.yesterdayPrice !== '-'
        ) {
          row.adjustRange = Number(row.price) - Number(row.yesterdayPrice);
        } else if (row.yesterdayPrice === null || row.yesterdayPrice === '-') {
          row.adjustRange = Number(row.price);
        }

        // this.$nextTick(() => {
        //   this.getList();
        // });
      });
    },

    editDisabled(row) {
      return this.isNotToday() || row._isEditPrice || row._isEditPriceRemark;
    },

    isNotToday() {
      return !this.$dayjs(this.queryParams.date).isSame(this.$dayjs(), 'day');
    },

    changeAdjustRange(row, currentValue, idx) {
      console.log('看看下标', idx, currentValue);
      let newRow = {...row.newRow};
      let newPrice = new Decimal(currentValue);
      let yesPrice = new Decimal(row.yesterdayPrice);
      newRow.adjustRange = newPrice - yesPrice;
      console.log('看看', newRow);
      // 变更
      const setRow = {
        ...row,
        // adjustRange: newRow.adjustRange,
        newRow,
      };
      this.$set(this.tableData, idx, setRow);
      console.log(this.tableData[idx]);
    },

    handleEdit(row, rowIdx) {
      // 编辑
      if (row.isEdit) {
        // 保存
        // console.log(row.newRow);
        // this.$set(this.tableData, rowIdx, { ...row, ...row.newRow });
        // this.tableData[rowIdx] = row.newRow;

        const newDate = {id: row.id, ...row.newRow};
        this.updateDataFunc(newDate).then(() => {
          row.isEdit = false;
          this.$message({
            type: 'success',
            message: '保存成功',
          });

          row.productSpec = row.newRow.productSpec;
          row.price = row.newRow.price;
          row.adjustRange = row.newRow.adjustRange;
          row.priceRemark = row.newRow.priceRemark;
          row.marketPrice = row.newRow.marketPrice;
          this.$nextTick(() => {
            this.getList();
          });
        });

        // console.log(this.tableData);
      } else {
        // 编辑
        row.isEdit = true;
      }
    },

    async updateDataFunc(data) {
      await updateData(data);
    },

    async getList() {
      // console.log(this.queryParams);
      this.loading = true;
      const res = await listData(this.queryParams);
      res.data.map((item) => {
        item._originIsEdit = item.isEdit;
        item._isEditPrice = false;
        item._isEditPriceRemark = false;
        item.isEdit = false;
        item.newRow = {
          productSpec: item.productSpec,
          priceType: this.queryParams.priceType,
          price: item.price,
          adjustRange: item.adjustRange,
          priceRemark: item.priceRemark,
          marketPrice: item.marketPrice,
        };
      });
      this.tableData = res.data;
      this.calcCatData();
      this.calcCatData2();
      this.loading = false;
    },

    // 处理分类相关数据
    calcCatData() {
      this.calcListData = [];
      this.menuData = [];
      let calcListDataIdx = 0;
      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];
        // console.log(item);
        if (index === 0) {
          item.domId = item.productTopTypeName;
          item.domIdx = calcListDataIdx;
          this.calcListData.push(1);
          this.menuData.push({
            label: item.productTopTypeName,
            code: calcListDataIdx,
          });
        } else {
          if (
            item.productTopTypeCode !==
            this.tableData[index - 1].productTopTypeCode
          ) {
            calcListDataIdx++;
            item.domId = item.productTopTypeName;
            item.domIdx = calcListDataIdx;
            this.calcListData.push(1);
            this.menuData.push({
              label: item.productTopTypeName,
              code: calcListDataIdx,
            });
          } else {
            item.domId = item.productTopTypeCode + index;
            this.calcListData[calcListDataIdx]++;
          }
        }
      }
      // console.log(this.tableData);
      // console.log(this.calcListData);
      // console.log(this.menuData);
    },
    calcCatData2() {
      this.calcListDatas = [];
      this.menuData = [];
      let calcListDataIdx = 0;
      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];
        // console.log(item);
        if (index === 0) {
          item.domIds = item.productTypeName;
          item.domIdxs = calcListDataIdx;
          this.calcListDatas.push(1);
          this.menuData.push({
            label: item.productTypeName,
            code: calcListDataIdx,
          });
        } else {
          if (item.productType !== this.tableData[index - 1].productType) {
            calcListDataIdx++;
            item.domIds = item.productTypeName;
            item.domIdxs = calcListDataIdx;
            this.calcListDatas.push(1);
            this.menuData.push({
              label: item.productTypeName,
              code: calcListDataIdx,
            });
          } else {
            item.domIds = item.productType + index;
            this.calcListDatas[calcListDataIdx]++;
          }
        }
      }
      // console.log(this.tableData);
      // console.log(this.calcListData);
      // console.log(this.menuData);
    },

    addClass({row, column, rowIndex, columnIndex}) {
      if (columnIndex === 0 || columnIndex === 4 || columnIndex === 5) {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      }

      if (column.property === 'price' && row.isUpdate === 1) {
        return 'font-weight: 700; font-size: 14px; color: #6AC768; line-height: 15px;';
      }

      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },
    toTop() {
      // console.log(this.$refs);
      // this.$scrollTo(this.$refs[0]);
      this.calcCatData();
      this.calcCatData2();
    },

    objectSpanMethod({row, column, rowIndex, columnIndex}) {
      if (columnIndex === 0) {
        // console.log('calcListData', this.calcListData);
        if (row.productTopTypeName === row.domId) {
          return {
            rowspan: this.calcListData[row.domIdx],
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }

      if (columnIndex === 1 || columnIndex === 2) {
        // console.log('calcListData', this.calcListData);
        if (row.productTypeName === row.domIds) {
          return {
            rowspan: this.calcListDatas[row.domIdxs],
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}

.cat_text {
  margin: auto;
  width: 14px;
}

.pop_text {
  color: #2d7ae6;
}
</style>
