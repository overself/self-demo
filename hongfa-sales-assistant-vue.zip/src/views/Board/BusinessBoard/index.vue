<!-- 价格看板编辑 -->
<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <el-collapse
          accordion
          v-model="activeTabName"
          @change="handleCollapseChange"
        >
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">价格编辑
                <div
                  class="title_right_btns"
                  @click.stop="handleScreen"
                >
                  <screenfull
                    id="screenfull"
                    class="right-menu-item hover-effect"
                    ref="screenIcon"
                    @screenToggle="handleScreenToggle"
                  />{{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">

              <el-form
                :model="queryParams"
                ref="queryForm"
                size="small"
                :inline="true"
                label-width="68px"
              >
                <el-form-item
                  label="工厂类型"
                  prop="productType"
                >
                  <el-select
                    v-model="queryParams.factoryCode"
                    placeholder="请选择"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="factory in factoryOption"
                      :key="factory.value"
                      :label="factory.label"
                      :value="factory.value"
                    />
                  </el-select>
                </el-form-item>
                <el-form-item
                  label="品项大类"
                  prop="productType"
                >
                  <el-select
                    filterable
                    clearable
                    v-model="queryParams.productTopTypeCode"
                    placeholder="请选择"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="dict in searchProductTopTypeList"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="品项分类"
                  prop="productType"
                >
                  <el-select
                    filterable
                    clearable
                    v-model="queryParams.productTypeCode"
                    placeholder="请选择"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="dict in searchProductTypeList"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="品项名称"
                  prop="productId"
                >
                  <el-select
                    filterable
                    clearable
                    allow-create
                    v-model="queryParams._productName"
                    placeholder="请选择"
                    style="width: 240px"
                    @change="onProductNameChange"
                  >
                    <el-option
                      v-for="dict in searchProductNameList"
                      :key="dict.id"
                      :label="dict.name"
                      :value="dict.id"
                    >
                      <span class="st-name-spec">{{dict.name}} / {{dict.spec}}</span>
                    </el-option>
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="品项编码"
                  prop="productCode"
                >
                  <el-input
                    v-model="queryParams.productCode"
                    placeholder="请输入"
                    clearable
                    style="width: 240px"
                  ></el-input>
                </el-form-item>

                <!-- <el-form-item
              label="选择日期"
              prop="priceDate"
            >
              <el-date-picker
                v-model="queryParams.priceDate"
                style="width: 240px"
                value-format="yyyy-MM-dd"
                type="date"
                placeholder="选择日期"
              />
            </el-form-item> -->

                <el-form-item>
                  <el-button
                    icon="el-icon-search"
                    @click="handleQuery"
                  >查询</el-button>
                  <el-button
                    icon="el-icon-refresh"
                    @click="resetQuery"
                  >重置</el-button>
                </el-form-item>
              </el-form>
            </div>
          </el-collapse-item>
        </el-collapse>
        <div class="content_wrap">
          <el-tabs
            v-model="activeName"
            @tab-click="handleClick"
          >
            <el-tab-pane
              label="产品市场价格表"
              name="market_price_type"
            >
              <List
                v-if="activeName=='market_price_type'"
                ref="market_price_type"
                :queryParams="{...queryParams,priceType:'market_price_type'}"
                :activeTabName="activeTabName"
              ></List>
            </el-tab-pane>
            <el-tab-pane
              label="鲜品价格表"
              name="fresh_price_type"
            >
              <List
                v-if="activeName=='fresh_price_type'"
                ref="fresh_price_type"
                :queryParams="{...queryParams,priceType:'fresh_price_type'}"
                :activeTabName="activeTabName"
              ></List>
            </el-tab-pane>
            <el-tab-pane
              label="批发价格表"
              name="wholesale_price_type"
            >
              <List
                v-if="activeName=='wholesale_price_type'"
                ref="wholesale_price_type"
                :queryParams="{...queryParams,priceType:'wholesale_price_type'}"
                :activeTabName="activeTabName"
              ></List>
            </el-tab-pane>
          </el-tabs>

          <div class="tabs-right-search__wrapper">
            <div class="tabs-right-search__inner">
              <el-form
                :model="queryParams"
                size="small"
                :inline="true"
                label-width="90px"
              >
                <el-form-item label="">
                  <el-date-picker
                    v-model="queryParams.date"
                    type="date"
                    placeholder="选择日期"
                    size="small"
                    :format="'yyyy-MM-dd'"
                    :valueFormat="'yyyy-MM-dd'"
                    :style="{width: '240px'}"
                    :picker-options="datePickerOptions"
                    @change='onDatePickerChange'
                    :clearable="false"
                  ></el-date-picker>
                </el-form-item>
              </el-form>
            </div>
          </div>

          <div class="tabs_right_btns">
            <!-- <div class="right_text">
              <CurrentTime></CurrentTime>
            </div>
            <div class="right_text">
              单位：元/公斤
            </div> -->

            <el-upload
              ref="upload"
              class="upload-demo"
              :limit="1"
              accept=".xlsx, .xls"
              :headers="upload.headers"
              :action="upload.url"
              :disabled="upload.isUploading"
              :data="{priceType:activeName, factoryCode:this.queryParams.factoryCode}"
              :on-progress="handleFileUploadProgress"
              :on-success="handleFileSuccess"
              :show-file-list="false"
            >
              <el-button
                size="small"
                :loading="upload.isUploading"
              >导入</el-button>
            </el-upload>

            <el-button
              style="margin-left:10px"
              size="small"
              :loading="exportLoading"
              @click="handleExport('')"
            >导出</el-button>
            <!-- <el-button
              size="small"
              @click="getToday()"
            >今日报价</el-button> -->
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import { getDictDatas, DICT_TYPE } from '@/utils/dict';
import Screenfull from '@/components/Screenfull';
import { exportExcel, importExcel, getToday } from '@/api/Board/BusinessBoard';
import { productData } from '@/api/Board/common';
import { getBaseHeader } from '@/utils/request';
import {
  productTopType,
  producTtype,
  productSimple,
} from '@/api/Board/StockBoard';
import List from './list';
import {getUserProfile} from "@/api/system/user";
export default {
  // import引入的组件需要注入到对象中才能使用
  components: { List, Screenfull },
  // directives: {
  //   layout: {
  //     inserted,
  //   },
  // },
  data () {
    // 这里存放数据
    return {
      datePickerOptions: {
        disabledDate (time) {
          // 获取今天的日期
          const today = new Date();
          // 如果选择的日期在今天之后，则禁用
          return time.getTime() > today.getTime();
        },
      },
      searchProductTopTypeList: [],
      searchProductTypeList: [],
      searchProductNameList: [],
      exportLoading: false,
      listRef: [
        'market_price_type',
        'fresh_price_type',
        'wholesale_price_type',
      ],
      queryParams: {
        productId: '',
        productType: '',
        factoryCode: '',
        productTopTypeCode: '',
        productTypeCode: '',
        productName: '',
        productCode: '',
        _productName: '', // 存id
        date: this.$dayjs().format('YYYY-MM-DD'),
      },
      productNameDatas: [],
      statusDictDatas: getDictDatas(DICT_TYPE.CATEGORY_CLASSIFY),
      activeName: 'market_price_type',
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 是否更新已经存在的用户数据
        updateSupport: 0,
        // 设置上传的请求头部
        headers: getBaseHeader(),
        // 上传的地址
        url:
          process.env.VUE_APP_BASE_API + '/admin-api/system/board/price/import',
      },
      isFullScreen: true,
      activeTabName: "1",
      factoryOption: [],
    };
  },

  watch: {
    'queryParams.factoryCode' (newVal, oldVal) {
      console.log(newVal, oldVal);
      this.handleQuery();
    },
    'queryParams.productType' (newVal, oldVal) {
      console.log(newVal, oldVal);
      if (newVal === '') {
        this.productNameDatas = [];
      } else {
        this.queryParams.productId = '';
        this.getProductData();
      }
    },
    'queryParams.productTopTypeCode' (newVal, oldVal) {
      console.log(newVal, oldVal);
      if (newVal === '') {
        this.searchProductTypeList = [];
      } else {
        this.queryParams.productTypeCode = '';
        this.queryParams.productName = '';
        this.getSearchProducTtype();
      }
    },
    'queryParams.productTypeCode' (newVal, oldVal) {
      console.log(newVal, oldVal);
      if (newVal === '') {
        this.searchProductNameList = [];
      } else {
        this.queryParams.productId = '';
        this.getSearchProductSimple();
      }
    },
  },

  // 方法集合
  methods: {
    onProductNameChange (id) {
      this.queryParams.productName =
        this.searchProductNameList?.find((item) => item.id === id)?.name ??
        this.queryParams._productName; // 没找到取输入的
    },

    onDatePickerChange () {
      this.$refs[this.activeName].getList();
    },
    getSearchProductSimple () {
      productSimple({ type: this.queryParams.productTypeCode }).then((res) => {
        this.searchProductNameList = res.data;
      });
    },
    // 获取搜索品项分类
    getSearchProducTtype () {
      producTtype({ value: this.queryParams.productTopTypeCode }).then(
        (res) => {
          this.searchProductTypeList = res.data;
        }
      );
    },

    //获取商品大类
    getProductTopType () {
      productTopType().then((res) => {
        this.searchProductTopTypeList = res.data;
      });
    },

    getFactoryType () {
      const systemFactoryProduct = this.getDictDatas(
        DICT_TYPE.SYSTEM_FACTORY_PRODUCT
      );
      if (systemFactoryProduct && systemFactoryProduct.length) {
        systemFactoryProduct.forEach((item) => {
          //朝阳食品厂,喀左食品厂
          if (item.value === '1011' || item.value === '1021') {
            this.factoryOption.push(item);
          }
        });
        this.queryParams.factoryCode = this.factoryOption[0].value;
      }
    },

    checkUserInfo () {
      getUserProfile().then((res) => {
        this.userInfo = res.data;
        if ( this.factoryOption.some((factory) => { return factory.value === res.data.dept.id; })) {
          this.factoryOption.forEach((item) => {
            if (item.value === res.data.dept.id) {
              this.queryParams.factoryCode = item.value;
            }
          });
        /*} else {
          this.$notify.error({ title: '暂无页面权限' });*/
        }
      });
    },

    handleFileSuccess (response, file, fileList) {
      // console.log(response, file, fileList);
      if (response.code === 0) {
        this.$message({
          type: 'success',
          message: '导入成功',
        });

        this.$nextTick(() => {
          // 拼接提示语
          let data = response.data;
          let text = '创建成功数量：' + data.createRows.length;
          for (const username of data.createRows) {
            text += '<br />&nbsp;&nbsp;&nbsp;&nbsp;' + username;
          }
          text += '<br />更新成功数量：' + data.updateRows.length;
          for (const username of data.updateRows) {
            text += '<br />&nbsp;&nbsp;&nbsp;&nbsp;' + username;
          }
          text += '<br />更新失败数量：' + Object.keys(data.failureRows).length;
          for (const username in data.failureRows) {
            text +=
              '<br />&nbsp;&nbsp;&nbsp;&nbsp;' +
              username +
              '：' +
              '<br />&nbsp;&nbsp;&nbsp;&nbsp;' +
              data.failureRows[username];
          }
          this.$alert(text, '导入结果', {
            dangerouslyUseHTMLString: true,
            customClass: 'import-result-alert',
          });

          this.$refs[this.activeName]?.getList();
        });
      } else {
        this.$notify.error({
          title: response.msg,
        });
      }
      this.$refs.upload.clearFiles();
      this.upload.isUploading = false;
    },

    handleFileUploadProgress (event, file, fileList) {
      this.upload.isUploading = true;
    },

    async getToday () {
      const res = await getToday();
    },
    handleExport (type) {
      const queryParams = {
        ...this.queryParams,
        priceType: this.activeName,
      };
      this.$modal
        .confirm('是否确认导出?')
        .then(() => {
          this.exportLoading = true;
          return exportExcel(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '业务导出.xls');
          this.exportLoading = false;
        })
        .catch(() => { });
    },

    handleQuery () {
      // console.log(this.queryParams);
      // console.log(this.$refs.list);
      this.$nextTick(() => {
        this.$refs[this.activeName].getList();
      });
    },

    resetQuery () {
      this.queryParams.productId = '';
      if (this.factoryOption && this.factoryOption.length) {
        this.queryParams.factoryCode = this.factoryOption[0].value;
      }
      this.queryParams.productType = '';
      this.queryParams.productTopTypeCode = '';
      this.queryParams.productTypeCode = '';
      this.queryParams.productName = '';
      this.queryParams.productCode = '';
      this.queryParams._productName = '';

      this.$nextTick(() => {
        // this.$refs[item].getList();
        this.$refs[this.activeName].getList();
      });
    },
    handleClick (tab, event) {
      // console.log(tab, event);
      // this.$refs[this.activeName].$ready = true;
      // this.$refs.test_list.getList();
      this.queryParams.priceType = this.activeName;
    },
    async getProductData () {
      const query = {
        type: this.queryParams.productType,
      };
      const res = await productData(query);
      this.productNameDatas = res.data;
    },
    handleScreen () {
      this.$refs.screenIcon.click()
    },
    handleScreenToggle (val) {
      this.isFullScreen = val
      // console.log(val, 123);
    },
    handleCollapseChange () {
    }

  },

  // 生命周期 - 创建完成（可以访问当前this实例）
  created () {
    this.getProductTopType();
    this.getFactoryType();
    this.checkUserInfo();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted () { },
  beforeCreate () { }, // 生命周期 - 创建之前
  beforeMount () { }, // 生命周期 - 挂载之前
  beforeUpdate () { }, // 生命周期 - 更新之前
  updated () { }, // 生命周期 - 更新之后
  beforeDestroy () { }, // 生命周期 - 销毁之前
  destroyed () { }, // 生命周期 - 销毁完成
  activated () { }, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
// @import url(); 引入公共css类
.tabs-right-search__wrapper {
  position: absolute;
  top: 15px;
  left: 460px;
  display: inline-block;
  width: 10px;
  height: 10px;
}
.component_title {
  padding: 10px 30px 0 20px;
}
::v-deep .el-collapse-item__content {
  padding-bottom: 0 !important;
}
</style>
