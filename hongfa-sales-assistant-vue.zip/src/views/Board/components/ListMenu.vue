<!-- 快捷导航 -->
<template>
  <div>
    <VueDraggableResizable
      :parent="false"
      :resizable="false"
      :w="96"
      :h="70"
      :x="draggableX"
      :y="0"
    >
      <div class='list_menu'>
        <div
          class="menu_header can_click"
          @click="showMenu"
        >快速导航
          <img
            style="visibility: hidden;"
            @click.stop="closeMenu"
            class="close_btn"
            src="@/assets/images/quickMenu/close.png"
            alt=""
          />
        </div>
        <div
          class="menu_content"
          :class="{'shwo_menu':isShow}"
        >
          <a
            class="menu_item can_click"
            href="#"
            v-for="(item,index) in menuData"
            :key="index"
            v-scroll-to="'#'+item.label+item.code"
            @click="menuItemClick(item, index)"
          >
            {{ item.label }}
          </a>
          <!-- :v-scroll-to="'#'+item.label" -->
        </div>

        <a
          herf="#"
          v-scroll-to="'.main-container'"
          class="menu_footer can_click"
          @click="clickToTop"
        >
          返回顶部

          <img
            class="back_btn"
            src="@/assets/images/quickMenu/back.png"
            alt=""
          >
        </a>
      </div>
    </VueDraggableResizable>
  </div>
</template>

<script>
import VueDraggableResizable from 'vue-draggable-resizable';

export default {
  props: {
    menuData: {
      type: Array,
      default: () => [],
    },
    isTableFixed: {
      type: Boolean,
      default: false,
    },
  },

  components: {
    VueDraggableResizable,
  },

  data() {
    return {
      isShow: false,
      draggableX: 0,
    };
  },

  created() {
    const viewportwidth =
      window.innerWidth ||
      document.documentElement.clientWidth ||
      document.body.clientWidth;

    this.draggableX = viewportwidth - 200 - 100 - 50;
  },

  methods: {
    menuItemClick(item, index) {
      if (this.isTableFixed) {
        const calCell = document.getElementById(`${item.label}${item.code}`);
        calCell.scrollIntoView();
        calCell.scrollIntoView(false);
        calCell.scrollIntoView({ block: 'start' });
        calCell.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
          inline: 'nearest',
        });
      }

      this.$emit('menuItemClick', {
        item,
        index,
      });
    },

    clickToTop() {
      if (this.isTableFixed) {
        try {
          const calCell = document.getElementsByTagName('tbody')[0];
          calCell.scrollIntoView();
          calCell.scrollIntoView(false);
          calCell.scrollIntoView({ block: 'start' });
          calCell.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'nearest',
          });
        } catch (error) {}
      }

      this.$emit('toTop');
    },

    showMenu() {
      console.log('打开menu');
      this.isShow = !this.isShow;
    },
    closeMenu() {
      console.log('关闭menu');
      this.isShow = false;
    },
  },
};
</script>

<style lang='scss' scoped>
.vdr {
  position: fixed;
  bottom: 20px;
  border: none;
}

.list_menu {
  // position: fixed;
  position: absolute;
  // bottom: 20px;
  bottom: 0;
  // right: 20px;
  right: 0;
  /* bottom: 50%;
  right: 50%; */

  width: 96px;
  height: auto;
  background: #ffffff;
  box-shadow: 0px 2px 5px 0px rgba(182, 182, 182, 0.25);
  border-radius: 6px 6px 6px 6px;
  border: 1px solid rgba(45, 122, 230, 0.16);

  .menu_header {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0 6px;
    font-weight: 400;
    font-size: 13px;
    color: #000000;
    line-height: 33px;
    height: 33px;
    border-bottom: 1px solid #39393905;
    .close_btn {
      margin-left: 4px;
      width: 16px;
      height: 16px;
    }
  }
  .menu_content {
    max-height: 0;
    /* max-height: 256px; */
    overflow-y: scroll;
    transition: all 1s ease;
    &.shwo_menu {
      max-height: 256px;
    }
    /* 隐藏滚动条 */
    &::-webkit-scrollbar {
      width: 0;
      height: 0;
    }
    .menu_item {
      margin: 10px 0;
      display: flex;
      justify-content: center;
      align-items: center;
      font-weight: 400;
      font-size: 14px;
      color: #696969;
      line-height: 15px;
      width: 100%;
      height: 26px;
      background: transparent;
      &:hover {
        color: #2d7ae6;
        background: #2d7ae605;
      }
    }
  }
  .menu_footer {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0 6px;
    font-weight: 400;
    font-size: 13px;
    color: #2d7ae6;
    line-height: 33px;
    height: 33px;
    border-top: 1px solid #39393905;
    .back_btn {
      margin-left: 4px;
      width: 16px;
      height: 16px;
    }
  }
}
</style>
