<!-- 浮动 -->
<template>
  <div
    :class="className"
    :style="{ height: height, width: width }"
  />
</template>

<script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '576px',
    },
    height: {
      type: String,
      default: '350px',
    },
    autoResize: {
      type: Boolean,
      default: true,
    },
    chartData: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val);
      },
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons');
      this.setOptions(this.chartData);
    },
    setOptions({ days, inventories, upperLimit, lowerLimit } = {}) {
      let legendData = ['库存'];
      let colorData = ['#0092FF'];
      let seriesData = [
        {
          name: '库存',
          smooth: true,
          type: 'line',
          itemStyle: {
            normal: {
              color: '#3888fa',
              lineStyle: {
                color: '#3888fa',
                width: 2,
              },
              areaStyle: {
                color: '#f3f8ff',
              },
            },
          },
          data: inventories,
          animationDuration: 2800,
          animationEasing: 'quadraticOut',
          // markLine: this.setMarkLine(upperLimit, lowerLimit),
        },
      ];

      if (upperLimit !== null) {
        legendData.push('上限');
        colorData.push('#FF1B2C');
        const upperLimitData = inventories.map((item) => {
          return upperLimit;
        });

        seriesData.push({
          name: '上限',
          smooth: true,
          type: 'line',
          itemStyle: {
            normal: {
              color: '#ff0000',
              lineStyle: {
                color: '#ff0000',
                width: 2,
              },
              areaStyle: {
                color: '#f3f8ff',
              },
            },
          },
          data: upperLimitData,
          animationDuration: 2800,
          animationEasing: 'quadraticOut',
        });

        // console.log(upperLimit);
        // console.log(upperLimitData);
      }

      if (lowerLimit !== null) {
        legendData.push('下限');
        colorData.push('#FF1B2C');
        const lowerLimitData = inventories.map((item) => {
          return lowerLimit;
        });

        seriesData.push({
          name: '下限',
          smooth: true,
          type: 'line',
          itemStyle: {
            normal: {
              color: '#ff0000',
              lineStyle: {
                color: '#ff0000',
                width: 2,
              },
              areaStyle: {
                color: '#f3f8ff',
              },
            },
          },
          data: lowerLimitData,
          animationDuration: 2800,
          animationEasing: 'quadraticOut',
        });

        // console.log(lowerLimit);
        // console.log(lowerLimitData);
      }

      // console.log(seriesData);
      this.chart.setOption(
        {
          xAxis: {
            data: days,
            boundaryGap: false,
            axisLabel: {
              margin: 20,
              color: '#333333', // x 轴轴标签颜色
            },
            axisLine: {
              lineStyle: {
                color: '#333333', // x 轴轴线颜色
              },
            },
          },
          grid: {
            left: 40,
            right: 40,
            bottom: 10,
            // top: 30,
            containLabel: true,
          },
          tooltip: {
            trigger: 'axis',
            // axisPointer: {
            //   type: 'cross',
            // },
            // padding: [5, 10],
          },
          yAxis: {
            name: '库存(吨)',
            // data: ['0', '20', '40', '60', '80', '100'],
            axisTick: {
              show: false,
            },
            axisLabel: {
              color: '#333333', // y 轴轴标签颜色
            },
            axisLine: {
              lineStyle: {
                color: '#333333', // y 轴轴线颜色
              },
            },
          },
          legend: {
            data: legendData,
          },
          color: colorData,
          series: seriesData,
        },
        {
          notMerge: true,
        }
      );
    },

    setMarkLine(max, min) {
      let limit = [];
      if (max) {
        let maxData = {
          name: 'max',
          yAxis: max,
        };
        limit.push(maxData);
      }
      if (min) {
        let minData = {
          name: 'min',
          yAxis: min,
        };
        limit.push(minData);
      }
      return {
        data: limit,
        lineStyle: {
          color: '#ff0000',
        },
      };
    },
  },
};
</script>
