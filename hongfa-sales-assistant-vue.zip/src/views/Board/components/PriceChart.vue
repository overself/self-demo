<!-- 浮动 -->
<template>
  <div :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '576px',
    },
    height: {
      type: String,
      default: '350px',
    },
    autoResize: {
      type: Boolean,
      default: true,
    },
    chartData: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val);
      },
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons');
      this.setOptions(this.chartData);
      // this.chart.dispatchAction({ type: 'highlight', dataIndex: 0 });
    },
    setOptions({ days, prices, outBounds } = {}) {
      this.chart.setOption({
        tooltip: {
          trigger: 'axis',
        },
        legend: {},
        grid: {
          left: 40,
          right: 40,
          bottom: 10,
          // top: 30,
          containLabel: true,
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          axisLabel: {
            margin: 20,
            color: '#333333', // x 轴轴标签颜色
          },
          axisLine: {
            lineStyle: {
              color: '#333333', // x 轴轴线颜色
            },
          },
          data: days,
        },
        yAxis: [
          {
            name: '单价(¥)',
            type: 'value',
            axisLabel: {
              formatter: '¥{value}元/吨',
              color: '#333333', // y 轴轴标签颜色
            },
            axisLine: {
              lineStyle: {
                color: '#333333', // y 轴轴线颜色
              },
            },
          },
          // {
          //   name: '出库量',
          //   type: 'value',
          //   alignTicks: true,
          //   axisLabel: {
          //     formatter: '{value}吨',
          //     color: '#333333', // y 轴轴标签颜色
          //   },
          //   axisLine: {
          //     lineStyle: {
          //       color: '#333333', // y 轴轴线颜色
          //     },
          //   },
          // },
        ],
        color: ['#4FC05A', '#0092FF'],
        series: [
          {
            name: '单价',
            type: 'line',
            data: prices,
          },
          // {
          //   name: '出库量',
          //   type: 'line',
          //   yAxisIndex: 1,
          //   data: outBounds,
          // },
        ],
      });
    },
  },
};
</script>
