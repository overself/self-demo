<!-- 价格库存看板 -->
<template>
  <div class="list_wrap">
    <virtual-scroll :data="tableData" :item-size="42" key-prop="_id"
      @change="(virtualList) => virtualData = virtualList" :virtualized="true">
      <el-table ref="hookTable1" class="table1" :loading="loading" stripe key="_id" :data="virtualData"
        :span-method="objectSpanMethod" :cell-style="addClass" :height="tableHeight" border
        @sort-change="handleFrontendSort" row-key="_id">
        <el-table-column prop="typeName" label="类名" header-align="center" align="center" width="40" fixed="left" />
        <el-table-column prop="hierarchyName" header-align="center" align="center" width="320px" fixed="left">
          <template #header>
            <div class="custom-header" @click="handleCustomSort('hierarchyName')">
              <span>产品层次</span>
              <div class="sort-icons">
                <i class="el-icon-caret-top"
                  :class="{ active: sortConfig.field === 'hierarchyName' && sortConfig.order === 'asc' }"></i>
                <i class="el-icon-caret-bottom"
                  :class="{ active: sortConfig.field === 'hierarchyName' && sortConfig.order === 'desc' }"></i>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="spec" label="产品规格" header-align="center" align="center" width="95px" />
        <el-table-column prop="totalAmount" header-align="center" align="center" width="180px">
          <template #header>
            <div class="custom-header" @click="handleCustomSort('totalAmount')">
              <div style="display: inline-block; vertical-align: middle;">
                <div>库存合计: </div>
                <div>{{ displayTotalAmount.toFixed(1) }}(吨)</div>
              </div>
              <div class="sort-icons">
                <i class="el-icon-caret-top"
                  :class="{ active: sortConfig.field === 'totalAmount' && sortConfig.order === 'asc' }"></i>
                <i class="el-icon-caret-bottom"
                  :class="{ active: sortConfig.field === 'totalAmount' && sortConfig.order === 'desc' }"></i>
              </div>
            </div>
          </template>
          <template slot-scope="scope">
            <div>{{ scope.row.totalAmount | removeTrailingZeros }}</div>
          </template>
        </el-table-column>

        <el-table-column label="一厂" header-align="center" align="center">
          <template #header>
            <div>一厂: {{ bp1AvailableAmount.toFixed(1) }}(吨)</div>
          </template>
          <el-table-column prop="bp1BrandName" label="龙鸟" header-align="center" align="center" width="180px">
            <template #header>
              <div>龙鸟: {{ bp1AvailableAmount.toFixed(1) }}(吨)</div>
            </template>
            <el-table-column prop="bp1Available" label="可售" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('bp1Available')">
                  <span>可售</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'bp1Available' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'bp1Available' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="bp1Unrestricted" label="锁单" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('bp1Unrestricted')">
                  <span>锁单</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'bp1Unrestricted' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'bp1Unrestricted' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template></el-table-column>
            <el-table-column prop="bp1Quality" label="质检" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('bp1Quality')">
                  <span>质检</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'bp1Quality' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'bp1Quality' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="bp1Frozen" label="冻结" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('bp1Frozen')">
                  <span>冻结</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'bp1Frozen' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'bp1Frozen' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
          </el-table-column>
        </el-table-column>
        <el-table-column label="二厂" header-align="center" align="center">
          <template #header>
            <div>二厂: {{ bp2AvailableAmount.toFixed(1) }}(吨)</div>
          </template>
          <el-table-column prop="bp2BrandName" label="龙鸟" header-align="center" align="center" width="180px">
            <template #header>
              <div>龙鸟: {{ bp2AvailableAmount.toFixed(1) }}(吨)</div>
            </template>
            <el-table-column prop="bp2Available" label="可售" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('bp2Available')">
                  <span>可售</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'bp2Available' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'bp2Available' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="bp2Unrestricted" label="锁单" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('bp2Unrestricted')">
                  <span>锁单</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'bp2Unrestricted' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'bp2Unrestricted' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template></el-table-column>
            <el-table-column prop="bp2Quality" label="质检" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('bp2Quality')">
                  <span>质检</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'bp2Quality' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'bp2Quality' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="bp2Frozen" label="冻结" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('bp2Frozen')">
                  <span>冻结</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'bp2Frozen' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'bp2Frozen' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
          </el-table-column>
        </el-table-column>
        <el-table-column label="朝阳" header-align="center" align="center">
          <template #header>
            <div>朝阳: {{ cyAvailableAmount.toFixed(1) }}(吨)</div>
          </template>
          <el-table-column prop="cyBrandName" label="龙鸟" header-align="center" align="center" width="180px">
            <template #header>
              <div>龙鸟: {{ cyAvailableAmount.toFixed(1) }}(吨)</div>
            </template>
            <el-table-column prop="cyAvailable" label="可售" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('cyAvailable')">
                  <span>可售</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'cyAvailable' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'cyAvailable' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="cyUnrestricted" label="锁单" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('cyUnrestricted')">
                  <span>锁单</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'cyUnrestricted' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'cyUnrestricted' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="cyQuality" label="质检" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('cyQuality')">
                  <span>质检</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'cyQuality' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'cyQuality' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="cyFrozen" label="冻结" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('cyFrozen')">
                  <span>冻结</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'cyFrozen' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'cyFrozen' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
          </el-table-column>
        </el-table-column>
        <el-table-column label="喀左" header-align="center" align="center">
          <template #header>
            <div>喀左: {{ kzAvailableAmount.toFixed(1) }}(吨)</div>
          </template>
          <el-table-column prop="kzLxLxBrandName1" label="凌翔" header-align="center" align="center" width="180px">
            <template #header>
              <div>凌翔: {{ kzLxAvailableAmount.toFixed(1) }}(吨)</div>
            </template>
            <el-table-column prop="kzLxAvailable" label="可售" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('kzAvailable')">
                  <span>可售</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'kzAvailable' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'kzAvailable' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="kzLxUnrestricted" label="锁单" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('kzUnrestricted')">
                  <span>锁单</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'kzUnrestricted' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'kzUnrestricted' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="kzLxQuality" label="质检" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('kzQuality')">
                  <span>质检</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'kzQuality' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'kzQuality' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="kzLxFrozen" label="冻结" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('kzFrozen')">
                  <span>冻结</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'kzFrozen' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'kzFrozen' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
          </el-table-column>
          <el-table-column prop="kzYyLxBrandName1" label="远赢" header-align="center" align="center" width="180px">
            <template #header>
              <div>远赢: {{ kzYyAvailableAmount.toFixed(1) }}(吨)</div>
            </template>
            <el-table-column prop="kzYyAvailable" label="可售" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('kzAvailable')">
                  <span>可售</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'kzAvailable' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'kzAvailable' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="kzYyUnrestricted" label="锁单" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('kzUnrestricted')">
                  <span>锁单</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'kzUnrestricted' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'kzUnrestricted' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="kzYyQuality" label="质检" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('kzQuality')">
                  <span>质检</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'kzQuality' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'kzQuality' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="kzYyFrozen" label="冻结" header-align="center" align="center" width="110px">
              <template #header>
                <div class="custom-header" @click="handleCustomSort('kzFrozen')">
                  <span>冻结</span>
                  <div class="sort-icons">
                    <i class="el-icon-caret-top"
                      :class="{ active: sortConfig.field === 'kzFrozen' && sortConfig.order === 'asc' }"></i>
                    <i class="el-icon-caret-bottom"
                      :class="{ active: sortConfig.field === 'kzFrozen' && sortConfig.order === 'desc' }"></i>
                  </div>
                </div>
              </template>
            </el-table-column>
          </el-table-column>
        </el-table-column>
      </el-table>
    </virtual-scroll>
  </div>
</template>

<script>
import { listDataRealtime } from '@/api/Board/PriceBoard';
import VirtualScroll from 'el-table-virtual-scroll';
import * as XLSX from 'xlsx-js-style';
import ListMenu from '../components/ListMenu';
import PriceChart from '../components/PriceChart';
import Stock from '../components/Stock';

export default {
  components: { VirtualScroll, Stock, ListMenu, PriceChart },
  props: {
    queryParams: {
      type: Object,
      default: () => {
        return {
          productCode: '',
          productName: '',
          kindCode: '',
          productType: '',
          inventoryDate: '',
          pageNo: 1,
          pageSize: 100,
        };
      },
    },
    activeTabName: {
      type: String,
      default: () => {
        return '0';
      },
    },
  },

  data() {
    return {
      virtualData: [],
      activeRow: {},
      chartLoading: false,
      priceVisible: false,
      stockVisible: false,
      loading: true,
      stockDateOption: 'seven_day',
      priceDateOption: 'seven_day',
      dateOptions: [
        {
          value: 'seven_day',
          label: '7天',
        },
        {
          value: 'fifteen_day',
          label: '15天',
        },
        {
          value: 'thirty_day',
          label: '30天',
        },
      ],
      tableData: [],
      tableData1: [],
      tableData2: [],
      tableHeight: 0,
      stockData: {
        days: [],
        inventories: [],
        lowerLimit: null,
        upperLimit: null,
      },
      priceData: {
        days: [],
        outBounds: [],
        prices: [],
      },
      menuData: [],
      typeData: [],
      calcListData: [],
      calcListData2: [],
      showUnrestrictedInv: false,
      showQualityInv: false,
      showFrozenInv: false,
      closePopoverOutsideNums: 0,
      displayTotalAmount: 0,
      bp1AvailableAmount: 0,
      bp2AvailableAmount: 0,
      cyAvailableAmount: 0,
      kzAvailableAmount: 0,
      kzLxAvailableAmount: 0,
      kzYyAvailableAmount: 0,
      sortProp: { prop: 'productName', order: 'ascending' },
      checkRepeatObj: {},
      // 自定义排序配置
      sortConfig: {
        field: null,    // 当前排序字段
        order: null,    // 当前排序方向：'asc' | 'desc' | null
      },
      currentSortField: 'productName',
      currentSort: 'ASC',
      tableKey: 0,
      // 分页相关
      pageNo: 1,
      pageSize: 500,
      allData: [], // 存储所有加载的数据
      isLoadingMore: false,
      hasMoreData: true,
      loadingTimer: null,
      currentLoadingPage: 1, // 当前正在加载的页数
    };
  },

  computed: {
    handleClick(tab, event) {
      // console.log(tab, event);
    },
  },
  watch: {
    activeTabName(val) {
      this.calTableHeight();
    },
  },
  created() {
    this.calTableHeight();
    // 移除初始排序设置，使用前端排序
    this.getList();
    window.addEventListener('resize', this.calTableHeight);
  },

  mounted() {
    this.calcCatData();
  },

  beforeDestroy() {
    this.closePopoverOutsideNums = 0;
    document.removeEventListener('click', this.closePopoverOutside);
    window.removeEventListener('resize', this.calTableHeight);
    // 清理加载定时器
    if (this.loadingTimer) {
      clearTimeout(this.loadingTimer);
    }
  },

  methods: {
    getRowKey(row) {
      /** 检查row.id是否有重复的缓存对象 */
      if (!this.checkRepeatObj) {
        this.checkRepeatObj = {};
      }
      if (row) {
        if (row.id) {
          if (this.checkRepeatObj[row._id]) {
            if (!row._secondId) {
              row._secondId = Math.random() + row._id;
            }
            /** 方便根据key重用元素 */
            return row._secondId;
          } else {
            this.checkRepeatObj[row._id] = 1;
            return row._id + Math.random();
          }
        }
        // console.log('row.id为空')
        if (!row._secondId) {
          row._secondId = Math.random() + row._id;
        }
        return row._secondId;
      } else {
        // console.log('row为空')
        return Math.random() + row._id;
      }
    },
    calTableHeight() {
      const viewportHeight =
        window.innerHeight ||
        document.documentElement.clientHeight ||
        document.body.clientHeight;
      this.tableHeight =
        this.activeTabName == '1'
          ? viewportHeight - 50 - 20 - 41 - 20 - 10 - 36 - 63 - 18
          : viewportHeight - 50 - 20 - 41 - 20 - 10 - 36 - 10; // 36是tag 63是搜索区域
      this.$nextTick(() => {
        this.$refs?.hookTable1.doLayout();
      });
    },

    exportExcel(type) {
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.table_to_sheet(this.$refs.hookTable1.$el);
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      const wsheet1 = wb.Sheets["Sheet1"];
      // 设置特定列为文本格式
      const textColumns = { 'B': '品项编码' };

      Object.keys(textColumns).forEach(col => {
        for (let i = 2; i <= 10000000; i++) { // 数据行从第2行开始
          const cellAddress = col + i;
          if (wsheet1[cellAddress]) {
            alert("wsheet1[cellAddress]=" + wsheet1[cellAddress].toString());
            // 方法1：设置单元格类型为字符串
            wsheet1[cellAddress].t = 's';
            // 方法2：设置数字格式为文本（可选）
            wsheet1[cellAddress].z = '@';
          }
        }
      });
      XLSX.writeFile(wb, '价格库存看板.xlsx');
    },

    closePopoverOutside(event) {
      this.$nextTick(() => {
        if (
          this.$refs.pricePop &&
          !this.$refs.pricePop.$el.contains(event.target) &&
          this.priceVisible
        ) {
          this.priceVisible = false;
          document.removeEventListener('click', this.closePopoverOutside);
        }

        if (
          this.$refs.stockPop &&
          !this.$refs.stockPop.$el.contains(event.target) &&
          this.stockVisible
        ) {
          this.stockVisible = false;
          document.removeEventListener('click', this.closePopoverOutside);
        }
      });
    },

    handleChangeUnrestrictedInv() {
      this.showUnrestrictedInv = !this.showUnrestrictedInv;
      // 重新加载数据，因为显示类型改变了
      this.refreshData();
    },
    handleChangeQualityInv() {
      this.showQualityInv = !this.showQualityInv;
      // 重新加载数据，因为显示类型改变了
      this.refreshData();
    },
    handleChangeFrozenInv() {
      this.showFrozenInv = !this.showFrozenInv;
      // 重新加载数据，因为显示类型改变了
      this.refreshData();
    },

    handleFrontendSort({ column, prop, order }) {
      // Element UI 内部排序完成后，objectSpanMethod 会自动基于新顺序重新计算合并
      // 只需要触发表格重新渲染即可
      this.$nextTick(() => {
        this.$refs?.hookTable1?.doLayout();
      });
    },

    // 刷新数据 - 重新从第一页开始加载
    refreshData() {
      this.getList(null, true);
    },

    // 手动触发加载更多
    loadMore() {
      if (this.hasMoreData && !this.isLoadingMore) {
        this.getList(null, false);
      }
    },

    // 停止加载
    stopLoading() {
      this.hasMoreData = false;
      this.isLoadingMore = false;
      this.loading = false;
    },

    async getList(e, isInitial = true) {
      if (isInitial) {
        // 初始加载，重置所有数据
        this.pageNo = 1;
        this.currentLoadingPage = 1;
        this.allData = [];
        this.hasMoreData = true;
        this.loading = true;
        this.tableData = [];
      }

      if (!this.hasMoreData || this.isLoadingMore) {
        return;
      }

      this.isLoadingMore = true;
      this.currentLoadingPage = this.pageNo;

      try {
        const params = {
          ...this.queryParams,
          pageNo: this.pageNo,
          pageSize: this.pageSize
        };

        // 移除排序参数，使用前端排序
        delete params.sortField;
        delete params.sort;

        const res = await listDataRealtime(params);

        if (res.data && res.data.length > 0) {
          // 处理新数据
          res.data.forEach((item, k) => {
            item._id = item.spec + item.hierarchyCode + k;
          });

          // 立即合并到所有数据中
          this.allData = [...this.allData, ...res.data];

          // 立即更新表格显示数据
          this.tableData = [...this.allData];

          // 立即重新计算统计数据并渲染
          this.calcCatData(e);

          // 立即触发表格重新渲染
          this.$nextTick(() => {
            this.$refs?.hookTable1?.doLayout();
          });

          // 检查是否还有更多数据
          if (res.data.length < this.pageSize) {
            this.hasMoreData = false;
          } else {
            this.pageNo++;
            // 继续加载下一页，给用户一些时间看到当前页的渲染效果
            setTimeout(() => {
              this.getList(e, false);
            }, 50); // 增加间隔，让用户看到每页的加载效果
          }
        } else {
          this.hasMoreData = false;
        }

      } catch (error) {
        console.error('加载数据失败:', error);
        this.hasMoreData = false;
      } finally {
        this.isLoadingMore = false;

        // 如果是初始加载的第一页，关闭主loading
        if (isInitial) {
          this.loading = false;
        }

        // 如果没有更多数据了，确保所有loading状态都关闭
        if (!this.hasMoreData) {
          this.loading = false;
        }
      }
    },

    // 处理分类相关数据
    calcCatData(e) {
      // 重置统计数据
      this.bp1AvailableAmount = 0;
      this.bp2AvailableAmount = 0;
      this.cyAvailableAmount = 0;
      this.kzAvailableAmount = 0;
      this.kzLxAvailableAmount = 0;
      this.kzYyAvailableAmount = 0;
      this.displayTotalAmount = 0;
      this.menuData = [];
      this.typeData = [];

      // 安全转数字：遇到空串、字母、null、undefined 一律变 0
      const toNum = v => {
        const n = Number(v);
        return Number.isFinite(n) ? n : 0;
      };

      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];

        // 确保每个item都有_id
        if (!item._id) {
          item._id = item.code + Math.random();
        }

        // 计算各厂库存总和
        const bp1Total = toNum(item.bp1Available) + toNum(item.bp1Unrestricted) + toNum(item.bp1Quality) + toNum(item.bp1Frozen);
        const bp2Total = toNum(item.bp2Available) + toNum(item.bp2Unrestricted) + toNum(item.bp2Quality) + toNum(item.bp2Frozen);
        const cyTotal = toNum(item.cyAvailable) + toNum(item.cyUnrestricted) + toNum(item.cyQuality) + toNum(item.cyFrozen);
        const kzLxTotal = toNum(item.kzLxAvailable) + toNum(item.kzLxUnrestricted) + toNum(item.kzLxQuality) + toNum(item.kzLxFrozen);
        const kzYyTotal = toNum(item.kzYyAvailable) + toNum(item.kzYyUnrestricted) + toNum(item.kzYyQuality) + toNum(item.kzYyFrozen);

        // 累加到总计
        this.bp1AvailableAmount += bp1Total;
        this.bp2AvailableAmount += bp2Total;
        this.cyAvailableAmount += cyTotal;
        this.kzAvailableAmount += kzLxTotal + kzYyTotal;
        this.kzLxAvailableAmount += kzLxTotal;
        this.kzYyAvailableAmount += kzYyTotal;

        // 计算单行总计
        const totalAmount = bp1Total + bp2Total + cyTotal + kzLxTotal + kzYyTotal;
        item.totalAmount = totalAmount.toFixed(2);
        this.displayTotalAmount += totalAmount;

        // 收集类型数据（去重）
        const existingType = this.typeData.find(typeItem => typeItem.value === item.type);
        if (!existingType) {
          this.typeData.push({
            label: item.typeName,
            value: item.type,
          });
        }
      }

      if (!e) {
        this.$emit('menuData', this.typeData);
      }
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0 || column.property === 'productSpec' || column.property === 'productName' ||
        column.property === '_rightData.productName' || column.property === '_rightData.productSpec') {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;height:40px;';
      }
      if (!column.property.includes('.') && row[column.property] == null) {
        row[column.property] = '-';
      }
    },

    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        // 基于当前表格显示顺序动态计算合并
        return this.calculateSpanForTypeName(rowIndex);
      }
      if (column.property === 'code') {
        // 基于当前表格显示顺序动态计算合并
        return this.calculateSpanForProductCode(rowIndex);
      }
    },

    // 动态计算产品类型的合并
    calculateSpanForTypeName(rowIndex) {
      const currentRow = this.tableData[rowIndex];
      if (!currentRow) return { rowspan: 1, colspan: 1 };

      const currentTypeName = currentRow.typeName;

      // 检查是否是该类型的第一行
      if (rowIndex > 0 && this.tableData[rowIndex - 1].typeName === currentTypeName) {
        return { rowspan: 0, colspan: 0 };
      }

      // 计算该类型有多少连续行
      let spanCount = 1;
      for (let i = rowIndex + 1; i < this.tableData.length; i++) {
        if (this.tableData[i].typeName === currentTypeName) {
          spanCount++;
        } else {
          break;
        }
      }

      return { rowspan: spanCount, colspan: 1 };
    },

    // 动态计算产品代码的合并
    calculateSpanForProductCode(rowIndex) {
      const currentRow = this.tableData[rowIndex];
      if (!currentRow) return { rowspan: 1, colspan: 1 };

      const currentCode = currentRow.code;

      // 检查是否是该产品代码的第一行
      if (rowIndex > 0 && this.tableData[rowIndex - 1].code === currentCode) {
        return { rowspan: 0, colspan: 0 };
      }

      // 计算该产品代码有多少连续行
      let spanCount = 1;
      for (let i = rowIndex + 1; i < this.tableData.length; i++) {
        if (this.tableData[i].code === currentCode) {
          spanCount++;
        } else {
          break;
        }
      }

      return { rowspan: spanCount, colspan: 1 };
    },

    // 自定义排序处理
    handleCustomSort(field) {
      // 切换排序状态
      if (this.sortConfig.field === field) {
        // 同一字段：无排序 -> 升序 -> 降序 -> 无排序
        if (this.sortConfig.order === null) {
          this.sortConfig.order = 'asc';
        } else if (this.sortConfig.order === 'asc') {
          this.sortConfig.order = 'desc';
        } else {
          this.sortConfig.order = null;
        }
      } else {
        // 不同字段：直接设为升序
        this.sortConfig.field = field;
        this.sortConfig.order = 'asc';
      }

      // 执行排序
      this.applySorting();
    },

    // 应用排序
    applySorting() {
      if (!this.sortConfig.field || !this.sortConfig.order) {
        // 无排序状态，恢复原始顺序
        this.tableData = [...this.allData];
      } else {
        // 执行排序
        this.tableData = [...this.allData].sort((a, b) => {
          return this.customSortMethod(a, b, this.sortConfig.field, this.sortConfig.order);
        });
      }

      // 重新计算合并信息
      this.calcCatData('sort');

      // 强制表格重新渲染
      this.tableKey++;

      this.$nextTick(() => {
        this.$refs?.hookTable1?.doLayout();
      });
    },

    // 自定义排序方法
    customSortMethod(a, b, field, order) {
      // 首先按 type 分组排序
      const typeA = a.type || '';
      const typeB = b.type || '';

      if (typeA !== typeB) {
        // 按 type 字段进行分组排序
        return typeA.toString().localeCompare(typeB.toString(), 'zh-CN', { numeric: true });
      }

      // 在同一分组内按指定字段排序
      let result = 0;

      if (field === 'name') {
        const nameA = (a.name || '').toString();
        const nameB = (b.name || '').toString();
        result = nameA.localeCompare(nameB, 'zh-CN', { numeric: true });
      } else if (field === 'totalAmount') {
        const amountA = parseFloat(a.totalAmount) || 0;
        const amountB = parseFloat(b.totalAmount) || 0;
        result = amountA - amountB;
      } else if (field.includes('Available') || field.includes('Unrestricted') || field.includes('Quality') || field.includes('Frozen')) {
        // 库存数量字段（可售、锁单、质检、冻结）
        const amountA = parseFloat(a[field]) || 0;
        const amountB = parseFloat(b[field]) || 0;
        result = amountA - amountB;
      }

      // 根据排序方向调整结果
      return order === 'desc' ? -result : result;
    },
  },
};
</script>

<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}

.cat_text {
  margin: auto;
  width: 14px;
}

.pop_text {
  color: #2d7ae6;
}

.table-placeholder {
  position: relative;
  display: flex;

  &::before {
    position: absolute;
    display: flex;
    justify-content: center;
    align-items: center;
    content: '-';
    width: 100%;
    height: 100%;
  }

  .table-placeholder-inner {
    visibility: hidden;
  }
}

::v-deep .el-table--medium .el-table__cell {
  padding: 1px 0 !important;
}

::v-deep .el-table__cell {
  height: 40px !important;
}

.table1 {
  // position: relative;
  // flex: 0 0 49vw;
  // z-index: 1;

  // ::v-deep th.gutter {
  //   display: none;
  //   width: 0 !important;
  // }
}

.table2 {
  flex: 0 0 49vw;
  margin-left: -62px;
  border-left: none;
}

.green-text,
.green_text {
  color: #6ac768 !important;
}

// 自定义排序样式
.custom-header {
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  user-select: none;

  &:hover {
    color: #409EFF;
  }

  .sort-icons {
    display: flex;
    flex-direction: column;
    margin-left: 4px;

    i {
      font-size: 12px;
      color: #c0c4cc;
      line-height: 1;

      &.active {
        color: #409EFF;
      }

      &:first-child {
        margin-bottom: -2px;
      }
    }
  }
}

.loading-more {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  color: #409EFF;
  font-size: 14px;
  background-color: #f0f9ff;
  border: 1px solid #b3d8ff;
  border-radius: 4px;
  margin: 10px 0;

  .loading-content {
    display: flex;
    align-items: center;

    i {
      margin-right: 8px;
      font-size: 16px;
    }
  }
}

.load-complete {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 16px;
  color: #909399;
  font-size: 12px;
  background-color: #f5f7fa;
  border-top: 1px solid #e4e7ed;
}

// 加载状态样式
.loading-status {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  margin: 10px 0;
  background: linear-gradient(90deg, #f0f9ff 0%, #e6f7ff 100%);
  border: 1px solid #b3d8ff;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: linear-gradient(90deg, #e6f7ff 0%, #d1f2ff 100%);
    border-color: #91d5ff;
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(24, 144, 255, 0.15);
  }

  .loading-content {
    display: flex;
    align-items: center;
    color: #1890ff;
    font-size: 14px;
    font-weight: 500;

    i {
      margin-right: 8px;
      font-size: 16px;
      animation: rotate 1s linear infinite;
    }
  }

  .loading-action {
    .el-button {
      border-radius: 4px;
    }
  }
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
}

// 合计行样式
::v-deep .el-table__footer-wrapper {
  .el-table__footer {
    .el-table__cell {
      &:first-child {
        font-weight: bold;
        color: #409EFF;
      }

      &:nth-child(2) {
        color: #67C23A;
        font-size: 12px;
      }
    }
  }
}
</style>
