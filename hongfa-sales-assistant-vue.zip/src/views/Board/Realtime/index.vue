<!-- 价格库存看板 -->
<template>
  <div class="app-container Board">

    <el-collapse accordion v-model="activeTabName" @change="handleCollapseChange">
      <el-collapse-item name="1">
        <template slot="title">
          <div class="component_title">实时库存看板
            <div class="title_right_btns" @click.stop="handleScreen">
              <screenfull id="screenfull" class="right-menu-item hover-effect" ref="screenIcon"
                @screenToggle="handleScreenToggle" />{{ isFullScreen ? '全屏' : '退出全屏' }}
            </div>
          </div>
        </template>
        <div class="search_wrap">

          <!-- 搜索工作栏 -->
          <BaseSearchContainer :column="searchColumn" :params="queryParams" @onSearch="handleQuery"
            @onReset="handleReset">
          </BaseSearchContainer>
        </div>
      </el-collapse-item>
    </el-collapse>

    <div class="content_wrap">
      <List ref="list" :queryParams="queryParams" @menuData="getMenuData" />
    </div>

  </div>
</template>

<script>
import { productData } from '@/api/Board/common';
import Screenfull from '@/components/Screenfull';
import { DICT_TYPE, getDictDatas } from '@/utils/dict';

import List from './list';
export default {
  components: { List, Screenfull },
  data() {
    return {
      exportLoading: false,
      queryParams: {
        productCode: '',
        hierarchyName: '',
        kindCode: '',
        productType: '',
        inventoryDate: this.$dayjs().format("YYYY-MM-DD"),
        pageNo: 1,
        pageSize: 100,
      },
      productNameDatas: [],
      typeList: [],
      statusDictDatas: getDictDatas(DICT_TYPE.CATEGORY_CLASSIFY),
      activeName: 'list',
      datePickerOptions: {
        disabledDate(time) {
          // 获取今天的日期
          const today = new Date();
          // 如果选择的日期在今天之后，则禁用
          return time.getTime() > today.getTime();
        },
      },
      tableColumnCheckedList1: [],
      tableColumnCheckedList2: [],
      tableColumnCheckedList3: [],
      tableColumnCheckedList4: [],
      searchColumn: [
        {
          label: '产品层次',
          prop: 'hierarchyName',
          type: 'input',
          search: true,
        },
        {
          label: '品项分类',
          prop: 'productType',
          type: 'select',
          search: true,
          disabled: false,
          dicData: this.typeList,
        },
      ],
      isFullScreen: true,
      activeTabName: '0',
    };
  },

  watch: {
    'queryParams.productType'(newVal, oldVal) {
      console.log(newVal, oldVal);
      if (newVal === '') {
        this.productNameDatas = [];
      } else {
        this.queryParams.productId = '';
        this.getProductData();
      }
    },
    typeList: {
      immediate: true,
      handler(newVal, oldVal) {
        let newArr = [];
        this.searchColumn = [
          {
            label: '品项分类',
            prop: 'productType',
            type: 'select',
            search: true,
            disabled: false,
            dicData: newVal,
          },
          {
            label: '产品层次',
            prop: 'hierarchyName',
            type: 'input',
            search: true,
          },
        ];
      },
    },
  },

  methods: {
    getMenuData(e) {
      //   console.log('获取', e);
      this.typeList = e;
    },
    // onProductCodeChange() {
    //   this.$refs[this.activeName].handleChangeProductCode();
    // },
    // onUnrestrictedInvChange() {
    //   this.$refs[this.activeName].handleChangeUnrestrictedInv();
    //   this.$nextTick(() => {
    //     this.$refs[this.activeName].getList();
    //   });
    // },
    // onQualityInvChange() {
    //   this.$refs[this.activeName].handleChangeQualityInv();
    //   this.$nextTick(() => {
    //     this.$refs[this.activeName].getList();
    //   });
    // },
    // onFrozenInvChange() {
    //   this.$refs[this.activeName].handleChangeFrozenInv();
    //   this.$nextTick(() => {
    //     this.$refs[this.activeName].getList();
    //   });
    // },

    // onShowZeroChange() {
    //   this.queryParams.isShowZero = this.queryParams._isShowZero ? 1 : 0;
    //   this.$nextTick(() => {
    //     this.$refs[this.activeName].getList();
    //   });
    // },

    // onDatePickerChange() {
    //   this.$refs[this.activeName].getList();
    // },

    // handleExport(type) {
    //   this.$refs[this.activeName].exportExcel(type);
    // },

    handleQuery() {
      this.$nextTick(() => {
        this.$refs[this.activeName].getList('select');
      });
    },

    handleReset() {
      this.queryParams.productId = '';
      this.queryParams.productType = '';
      this.queryParams.hierarchyName = '';
      this.queryParams.priceDate = this.$dayjs().format('YYYY-MM-DD');

      this.$nextTick(() => {
        this.$refs[this.activeName].getList();
      });
    },

    // handleClick(tab, event) {
    //   this.queryParams.priceType = this.activeName;
    //   this.queryParams.productType = '';
    //   this.tableColumnCheckedList1 = [];
    //   this.tableColumnCheckedList2 = [];
    //   this.tableColumnCheckedList3 = [];
    //   this.tableColumnCheckedList4 = [];
    //   this.queryParams.isShowZero = 0;
    //   this.queryParams._isShowZero = false;
    // },

    async getProductData() {
      const query = {
        type: this.queryParams.productType,
      };
      const res = await productData(query);
      this.productNameDatas = res.data;
    },
    handleScreen() {
      this.$refs.screenIcon.click();
    },
    handleScreenToggle(val) {
      this.isFullScreen = val;
    },
    handleCollapseChange() {
    },
  },
};
</script>

<style lang="scss" scoped>
// @import url(); 引入公共css类
.Board {
  height: 100%;
}

.tabs-right-search__wrapper {
  position: absolute;
  top: 15px;
  left: 435px;
  display: inline-block;
  width: 10px;
  height: 10px;
}

.component_title {
  padding: 10px 30px 0 20px;
}

::v-deep .el-collapse-item__content {
  padding-bottom: 0 !important;
}
</style>
