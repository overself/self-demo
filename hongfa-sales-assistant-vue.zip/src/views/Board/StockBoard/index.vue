<!-- 库存看板编辑 -->
<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <el-collapse
          accordion
          v-model="activeTabName"
          @change="handleCollapseChange"
        >
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">库存编辑
                <div
                  class="title_right_btns"
                  @click.stop="handleScreen"
                >
                  <screenfull
                    id="screenfull"
                    class="right-menu-item hover-effect"
                    ref="screenIcon"
                    @screenToggle="handleScreenToggle"
                  />{{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">

              <el-form
                :model="queryParams"
                ref="queryForm"
                size="small"
                :inline="true"
                label-width="68px"
              >
                <el-form-item
                  label="品项大类"
                  prop="productType"
                >
                  <el-select
                    filterable
                    clearable
                    v-model="queryParams.productTopTypeCode"
                    placeholder="请选择"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="dict in searchProductTopTypeList"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="品项分类"
                  prop="productType"
                >
                  <el-select
                    filterable
                    clearable
                    v-model="queryParams.productTypeCode"
                    placeholder="请选择"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="dict in searchProductTypeList"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="品项名称"
                  prop="productId"
                >
                  <el-select
                    filterable
                    clearable
                    allow-create
                    v-model="queryParams.productName"
                    placeholder="请选择"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="dict in searchProductNameList"
                      :key="dict.id"
                      :label="dict.name"
                      :value="dict.name"
                    >
                      <span class="st-name-spec">{{dict.name}} / {{dict.spec}}</span>
                    </el-option>
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="品项编码"
                  prop="productCode"
                >
                  <el-input
                    v-model="queryParams.productCode"
                    placeholder="请输入"
                    clearable
                    style="width: 240px"
                  ></el-input>
                </el-form-item>

                <!-- <el-form-item
              label="选择日期"
              prop="priceDate"
            >
              <el-date-picker
                v-model="queryParams.priceDate"
                style="width: 240px"
                value-format="yyyy-MM-dd"
                type="date"
                placeholder="选择日期"
              />
            </el-form-item> -->
                <el-form-item>
                  <el-button
                    icon="el-icon-search"
                    @click="handleQuery"
                  >查询</el-button>
                  <el-button
                    icon="el-icon-refresh"
                    @click="resetQuery"
                  >重置</el-button>
                </el-form-item>
              </el-form>
            </div>
          </el-collapse-item>
        </el-collapse>

        <div class="content_wrap">
          <el-tabs
            class="st-rect-tabs"
            v-model="activeName"
            @tab-click="handleClick"
          >
            <el-tab-pane
              v-for="tab in factoryList"
              :key="tab.value"
              :label="tab.label"
              :name="tab.value"
            >
              <List
                v-if="activeName==tab.value"
                :ref="tab.value"
                :queryParams="{...queryParams,factoryType:tab.value}"
                :activeTabName="activeTabName"
              ></List>
            </el-tab-pane>
          </el-tabs>

          <div
            class="tabs-right-search__wrapper"
            :style="`left: ${tabsWidth + 30}px;`"
          >
            <div class="tabs-right-search__inner">
              <el-form
                :model="queryParams"
                size="small"
                :inline="true"
                label-width="90px"
              >
                <el-form-item label="">
                  <el-date-picker
                    v-model="queryParams.date"
                    type="date"
                    placeholder="选择日期"
                    size="small"
                    :format="'yyyy-MM-dd'"
                    :valueFormat="'yyyy-MM-dd'"
                    :style="{width: '240px'}"
                    :picker-options="datePickerOptions"
                    @change='onDatePickerChange'
                    :clearable="false"
                  ></el-date-picker>
                </el-form-item>
              </el-form>
            </div>
          </div>

          <div class="tabs_right_btns">
            <!-- <div class="right_text">
              <CurrentTime></CurrentTime>
            </div> -->
            <!-- <div class="right_text">
              单位：元/公斤
            </div> -->

            <el-radio
              v-model="queryParams.range"
              :label=0
            >全部</el-radio>

            <el-radio
              v-model="queryParams.range"
              :label="1"
            >我的</el-radio>

            <!-- <el-radio
              v-model="queryParams.range"
              :label="0"
            >无权限</el-radio> -->

            <!-- <el-button
              style="margin-left: 10px"
              size="small"
              @click="addStock('')"
              v-if="permi.hasPermi('system:board-inventory:create')"
            >新增品项</el-button> -->

            <el-upload
              ref="upload"
              class="upload-demo"
              style="margin-left: 10px"
              :limit="1"
              accept=".xlsx, .xls"
              :headers="upload.headers"
              :action="upload.url"
              :disabled="upload.isUploading"
              :data="{factoryType:activeName}"
              :on-progress="handleFileUploadProgress"
              :on-success="handleFileSuccess"
              :show-file-list="false"
            >
              <el-button
                size="small"
                :loading="upload.isUploading"
              >导入</el-button>
            </el-upload>

            <el-button
              style="margin-left:10px"
              size="small"
              :loading="exportLoading"
              @click="handleExport('')"
            >导出</el-button>
            <!-- <el-button
              size="small"
              @click="getToday()"
            >今日报价</el-button> -->
          </div>
        </div>
      </el-col>
    </el-row>

    <!--新增&&编辑-->
    <el-dialog
      :title="title"
      :visible.sync="open"
      width="500px"
      append-to-body
    >
      <el-form
        ref="ruleForm"
        :model="form"
        :rules="rules"
        label-width="125px"
      >
        <el-form-item
          label="品项编码"
          prop="code"
        >
          <el-select
            placeholder="请选择"
            v-model="form.code"
            style="width: 100%"
            :remote-method="productCodeRemoteMethod"
            :loading="productCodeLoading"
            filterable
            remote
          >
            <el-option
              v-for="(item) in productCodeList"
              :key="item.id"
              :label="item.code"
              :value="item.code"
              @click.native="selectProductCode(item)"
            />
          </el-select>
        </el-form-item>

        <el-form-item
          label="品项名称"
          prop="productId"
        >
          <el-select
            placeholder="请选择"
            v-model="form.productId"
            style="width: 100%"
            :remote-method="productNameRemoteMethod"
            :loading="productNameLoading"
            filterable
            remote
          >
            <el-option
              v-for="item in productNameList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
              @click.native="selectProductName(item)"
            >
              <span class="st-name-spec">{{item.name}} / {{item.spec}}</span>
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item
          label="详细规格"
          prop="spec"
        >
          <el-input
            v-model="form.spec"
            disabled
            placeholder="系统带出"
          />
        </el-form-item>

        <el-form-item
          label="品项分类"
          prop="productType"
        >
          <el-select
            placeholder="系统带出"
            v-model="form.productType"
            disabled
            style="width: 100%"
            @change="changeType"
          >
            <el-option
              v-for="dict in productTypeList"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item
          label="品项大分类"
          prop="topType"
        >
          <el-select
            placeholder="系统带出"
            v-model="form.topType"
            disabled
            style="width: 100%"
            @change="changeTopType"
          >
            <el-option
              v-for="dict in productTopTypeList"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item
          label="库存(吨)"
          prop="amount"
        >
          <el-input
            v-model="form.amount"
            placeholder="请输入库存(吨)"
          />
        </el-form-item>
        <el-form-item label="库存备注">
          <el-input
            v-model="form.remark"
            placeholder="请输入库存备注"
          />
        </el-form-item>
      </el-form>

      <div
        slot="footer"
        class="dialog-footer"
      >
        <el-button
          type="primary"
          @click="submitForm('ruleForm')"
        >确 定</el-button>
        <el-button @click="open = false">取 消</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="导入数据确认"
      :visible.sync="showDialog"
      width="1000px"
      append-to-body
    >
      <div class="import-title">总计导入条{{importTotalSize}}记录, 总库存为{{removeTrailingZeros(importTotalAmount.toFixed(5)) }}吨</div>
      <div
        v-loading="upload.isUploading ||importLoading"
        :element-loading-text="importLoading?'导入中':'数据校验中'"
        element-loading-spinner="el-icon-loading"
      >
        <div class="content_wrap">
          <el-tabs
            v-model="activeImportName"
            @tab-click="handleImportTabChange"
          >
            <el-tab-pane
              v-for="item in tabList"
              :key="item.id"
              :label="item.label +'('+item.size+')'"
              :name="item.id"
            >
              <el-table
                ref="table"
                :data="importRecordsData"
                border
                style="width: 100%;"
                max-height="320"
                show-overflow-tooltip
                :cell-style="addClass"
              >

                <el-table-column
                  prop="no"
                  label="行号"
                  header-align="center"
                  align="center"
                  show-overflow-tooltip
                ></el-table-column>

                <el-table-column
                  prop="productCode"
                  label="品项编码"
                  header-align="center"
                  min-width="100"
                  align="center"
                  show-overflow-tooltip
                ></el-table-column>

                <el-table-column
                  prop="productName"
                  label="品项"
                  header-align="center"
                  align="center"
                  width="290"
                  show-overflow-tooltip
                >
                </el-table-column>

                <el-table-column
                  prop="productSpec"
                  label="详细规格"
                  header-align="center"
                  align="center"
                  show-overflow-tooltip
                ></el-table-column>
                <el-table-column
                  prop="amount"
                  label="库存（吨）"
                  header-align="center"
                  align="center"
                  show-overflow-tooltip
                ></el-table-column>
                <el-table-column
                  prop="message"
                  label="错误信息"
                  header-align="center"
                  align="center"
                  width="200"
                  show-overflow-tooltip
                ></el-table-column>
              </el-table>
            </el-tab-pane>

          </el-tabs>
          <p>库存导入说明:</p>
          <p>品项编码错误:表格中编码在系统不存在，无法导入</p>
          <p>导入重复:导入表格中存在编码+品名+备注重复的行，无法导入</p>
          <p>品名规格不匹配:根据导入的编码与系统中品项对比，检查到品名和规格有不一致的情况，请确认。</p>
          <p>覆盖他人导入:检测到品项已被其他人导入，确认是否覆盖导入</p>

        </div>
        <div
          slot="footer"
          class="dialog-footer-import"
        >
          <el-button
            type="primary"
            @click="handleImport"
          >确认导入</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getDictDatas, DICT_TYPE } from '@/utils/dict';
import Screenfull from '@/components/Screenfull';
import {
  exportExcel,
  importExcel,
  getToday,
  productTopType,
  producTtype,
  productSimple,
  inventoryCreate,
} from '@/api/Board/StockBoard';
import { productData } from '@/api/Board/common';
import { getBaseHeader } from '@/utils/request';
import permi from '@/plugins/auth.js';
import List from './list';
import { getUserProfile } from '@/api/system/user';
import tabsMixin from '@/mixin/tabs.js';
import { getAccessToken } from '@/utils/auth';
import axios from 'axios';
export default {
  components: { List, Screenfull },
  mixins: [tabsMixin],
  // directives: {
  //   layout: {
  //     inserted,
  //   },
  // },
  data () {
    // 这里存放数据
    return {
      permi,
      form: {
        code: '',
        spec: '',
        remark: '',
      },
      title: '新增品项',
      productTopTypeList: [],
      productTypeList: [],
      productNameList: [],
      productCodeList: [],
      searchProductTopTypeList: [],
      searchProductTypeList: [],
      searchProductNameList: [],
      productCodeLoading: false,
      productNameLoading: false,
      open: false,
      exportLoading: false,
      queryParams: {
        productId: '',
        productType: '',
        productTopTypeCode: '',
        productTypeCode: '',
        productName: '',
        factoryType: '',
        productCode: '',
        range: 0,
        date: this.$dayjs().format('YYYY-MM-DD'),
        // priceDate: this.$dayjs().format('YYYY-MM-DD'),
      },
      productNameDatas: [],
      statusDictDatas: getDictDatas(DICT_TYPE.CATEGORY_CLASSIFY),
      datePickerOptions: {
        disabledDate (time) {
          // 获取今天的日期
          const today = new Date();
          // 如果选择的日期在今天之后，则禁用
          return time.getTime() > today.getTime();
        },
      },
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 是否更新已经存在的用户数据
        updateSupport: 0,
        // 设置上传的请求头部
        headers: getBaseHeader(),
        // 上传的地址
        url:
          process.env.VUE_APP_BASE_API +
          '/admin-api/system/board/inventory/import/check',
      },
      userInfo: {},
      factoryOption: [
        {
          label: '北票食品二厂',
          value: '1002',  //'bp_2_factory',
          id: 202,
        },
        {
          label: '朝阳食品厂',
          value: '1011',  //'cy_factory',
          id: 205,
        },
        {
          // label: '喀左工厂(龙鸟)',
          label: '喀左食品厂',
          value: '1021',  //'kz_factory_ln',
          id: 203,
        },
        // {
        //   // label: '喀左工厂(远赢)',
        //   label: '喀左',
        //   value: 'kz_factory_yy',
        //   id: 204,
        // },
        {
          label: '北票食品一厂',
          value: '1001',  //'bp_1_factory',
          id: 201,
        },
      ],
      factoryList: [],
      tabList: [
        {
          label: '数据合格',
          id: 'rightRecords',
          size: 0,
        },
        {
          label: '无编码记录',
          id: 'noCodeRecords',
          size: 0,
        },
        {
          label: '品项编码错误',
          id: 'errorCodeRecords',
          size: 0,
        },
        {
          label: '导入重复',
          id: 'repeatCodeRecords',
          size: 0,
        },
        {
          label: '品名规格不匹配',
          id: 'errorNmaeRecords',
          size: 0,
        },
        {
          label: '覆盖他人导入',
          id: 'coverRecords',
          size: 0,
        },
      ],
      activeName: '',
      rules: {
        topType: [
          {
            required: true,
            message: '请选择品项大分类',
            trigger: ['change', 'blur'],
          },
        ],
        productType: [
          {
            required: true,
            message: '请选择品项分类',
            trigger: ['change', 'blur'],
          },
        ],
        productId: [
          {
            required: true,
            message: '请选择品项名称',
            trigger: ['change', 'blur'],
          },
        ],
        spec: [{ required: true, message: '详细规格', trigger: 'blur' }],
        code: [
          { required: true, message: '品项编码', trigger: ['change', 'blur'] },
        ],
        amount: [{ required: true, message: '请输入库存', trigger: 'blur' }],
      },
      isFullScreen: true,
      activeTabName: '1',
      showDialog: false,
      token: '',
      importRecordsData: [],
      activeImportName: 'rightRecords',
      importData: [],
      file: undefined,
      importTotalSize: 0,
      importTotalAmount: 0,
      importLoading: false,
    };
  },

  watch: {
    'queryParams.range' (newVal, oldVal) {
      //   console.log(newVal, oldVal);
      this.$nextTick(() => {
        // this.$refs[this.activeName][0].getList();
        this.handleGetList();
      });
    },
    'queryParams.productType' (newVal, oldVal) {
      //   console.log(newVal, oldVal);
      if (newVal === '') {
        this.productNameDatas = [];
      } else {
        this.queryParams.productId = '';
        this.getProductData();
      }
    },
    'queryParams.productTopTypeCode' (newVal, oldVal) {
      //   console.log(newVal, oldVal);
      if (newVal === '') {
        this.searchProductTypeList = [];
      } else {
        this.queryParams.productTypeCode = '';
        this.queryParams.productName = '';
        this.getSearchProducTtype();
      }
    },
    'queryParams.productTypeCode' (newVal, oldVal) {
      //   console.log(newVal, oldVal);
      if (newVal === '') {
        this.searchProductNameList = [];
      } else {
        this.queryParams.productId = '';
        this.getSearchProductSimple();
      }
    },

    open (val) {
      if (!val) {
        this.form = {
          code: '',
          spec: '',
        };

        this.productCodeList = [];
        this.productNameList = [];
        this.$refs.ruleForm.resetFields();
      }
    },
  },

  created () {
    const systemFactoryProduct = this.getDictDatas(
      DICT_TYPE.SYSTEM_FACTORY_PRODUCT
    );

    if (systemFactoryProduct && systemFactoryProduct.length) {
      this.queryParams.factoryType = systemFactoryProduct[0].value;
      this.activeName = systemFactoryProduct[0].value;
    }
    this.getUserInfo();
    this.getProductTopType();
    // console.log( getAccessToken());
    this.token = getAccessToken();
  },

  methods: {
    productCodeRemoteMethod (query) {
      if (query !== '') {
        this.productCodeLoading = true;

        productSimple({
          code: query,
        }).then((res) => {
          this.productCodeLoading = false;
          this.productCodeList = res.data;
        });
      } else {
        this.productCodeList = [];
      }
    },

    productNameRemoteMethod (query) {
      if (query !== '') {
        this.productNameLoading = true;

        productSimple({
          name: query,
        }).then((res) => {
          this.productNameLoading = false;
          this.productNameList = res.data;
        });
      } else {
        this.productNameList = [];
      }
    },

    handleGetList () {
      const ref = this.$refs[this.activeName];
      ref && ref.length && ref[0].getList();
    },

    onDatePickerChange () {
      // this.$refs[this.activeName].getList();
      this.handleGetList();
    },

    getUserInfo () {
      getUserProfile().then((res) => {
        this.userInfo = res.data;
        // console.log('factoryOption', this.factoryOption);
        if (
          this.factoryOption.some((i) => {
            return i.id == res.data.dept.id;
          })
        ) {
          //   console.log('存在');
          this.factoryOption.forEach((item) => {
            if (item.id == res.data.dept.id) {
              // console.log('存在', item);
              this.factoryList.push(item);
              this.activeName = item.value;
            }
          });

          this.$_getTabsRect();
        } else {
          //   this.$message.error('暂无页面权限');
          this.$notify.error({ title: '暂无页面权限' });
        }
      });
    },
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          //   delete this.form.code;
          //   delete this.form.spec;
          //   delete this.form.topType;
          //   delete this.form.productType;
          this.form.factoryType = this.activeName;
          inventoryCreate(this.form).then((res) => {
            this.$message({
              message: '新增成功',
              type: 'success',
            });
            this.open = false;
            this.$nextTick(() => {
              this.handleGetList();
              //   console.log('resswss', res);

              setTimeout(() => {
                let ele = document.getElementById(res.data);
                ele.scrollIntoView(); // 等同于ele.scrollIntoView(true)
                ele.scrollIntoView(false);
                ele.scrollIntoView({ block: 'center' });
                ele.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center',
                  inline: 'nearest',
                });
              }, 600);
            });
          });
        }
      });
    },

    selectProductCode (item) {
      this.form.productId = item.id;
      this.form.spec = item.spec;
      this.form.productType = item.productTypeCode;
      this.form.topType = item.productTopTypeCode;

      this.getProducTtype();
      this.getProductSimple({
        name: item.name,
        code: item.code,
      });
    },

    // 品项名称选择
    selectProductName (item) {
      this.form.code = item.code;
      this.form.spec = item.spec;
      this.form.productType = item.productTypeCode;
      this.form.topType = item.productTopTypeCode;

      this.getProducTtype();
      productSimple({
        name: item.name,
        code: item.code,
      }).then((res) => {
        this.productCodeList = res.data;
      });
    },

    // 大类切换
    changeTopType () {
      //   console.log('form', this.form);
      this.form.productType = '';
      this.form.productId = '';
      this.form.code = '';
      this.form.spec = '';
      this.getProducTtype();
    },

    // 品项分类切换
    changeType () {
      this.form.productId = '';
      this.form.code = '';
      this.form.spec = '';
      this.getProductSimple({
        type: this.form.productType,
        isEnable: 1,
        businessStatus: 1,
        factoryType: this.activeName,
      });
    },

    addStock () {
      this.open = true;
    },
    addClass ({ row, column, rowIndex, columnIndex }) {
      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },
    // 获取品项名称
    getProductSimple (params) {
      productSimple(params).then((res) => {
        this.productNameList = res.data;
      });
    },

    getSearchProductSimple () {
      productSimple({ type: this.queryParams.productTypeCode }).then((res) => {
        this.searchProductNameList = res.data;
      });
    },

    // 获取品项分类
    getProducTtype () {
      producTtype({ value: this.form.topType }).then((res) => {
        this.productTypeList = res.data;
      });
    },

    // 获取搜索品项分类
    getSearchProducTtype () {
      producTtype({ value: this.queryParams.productTopTypeCode }).then(
        (res) => {
          this.searchProductTypeList = res.data;
        }
      );
    },

    //获取商品大类
    getProductTopType () {
      productTopType().then((res) => {
        this.productTopTypeList = res.data;
        this.searchProductTopTypeList = res.data;
      });
    },

    handleFileSuccess (response, file, fileList) {
      //   console.log(response, 'response');

      this.importTotalAmount = 0;
      let arr = []
      this.file = file;
      if (response.code === 0) {
        this.importData = JSON.parse(JSON.stringify(response.data));
        this.importRecordsData = response.data[this.activeImportName];
        this.tabList[0].size = response.data['rightRecords'].length
        this.tabList[1].size = response.data['noCodeRecords'].length
        this.tabList[2].size = response.data['errorCodeRecords'].length
        this.tabList[3].size = response.data['repeatCodeRecords'].length
        this.tabList[4].size = response.data['errorNmaeRecords'].length
        this.tabList[5].size = response.data['coverRecords'].length
        arr = [
          ...response.data.coverRecords,
          ...response.data.errorCodeRecords,
          ...response.data.errorNmaeRecords,
          ...response.data.noCodeRecords,
          ...response.data.repeatCodeRecords,
          ...response.data.rightRecords,
        ];

        this.importTotalSize = arr.length;
        arr.map((item) => {
          this.importTotalAmount += Number(item.amount);
        });
        // console.log(arr, this.importTotalSize, this.importTotalAmount);
        // console.log(this.importRecordsData, this.activeImportName);

        //   this.$message({
        //     type: 'success',
        //     message: '导入成功',
        //   });

        //   this.$nextTick(() => {
        //     // this.$refs[this.activeName].getList();

        //     // 拼接提示语
        //     let data = response.data;
        //     let text = '创建成功数量：' + data.createRows.length;
        //     for (const username of data.createRows) {
        //       text += '<br />&nbsp;&nbsp;&nbsp;&nbsp;' + username;
        //     }
        //     text += '<br />更新成功数量：' + data.updateRows.length;
        //     for (const username of data.updateRows) {
        //       text += '<br />&nbsp;&nbsp;&nbsp;&nbsp;' + username;
        //     }
        //     text += '<br />更新失败数量：' + Object.keys(data.failureRows).length;
        //     for (const username in data.failureRows) {
        //       text +=
        //         '<br />&nbsp;&nbsp;&nbsp;&nbsp;' +
        //         username +
        //         '：' +
        //         '<br />&nbsp;&nbsp;&nbsp;&nbsp;' +
        //         data.failureRows[username];
        //     }
        //     this.$alert(text, '导入结果', {
        //       dangerouslyUseHTMLString: true,
        //       customClass: 'import-result-alert',
        //     });
        //     this.handleGetList();
        //   });
        this.showDialog = true;
        this.activeImportName = 'rightRecords'
      } else {
        this.$notify.error({
          title: response.msg,
        });
        this.showDialog = false;
      }

      this.$refs.upload.clearFiles();
      this.upload.isUploading = false;
      this.importLoading = false;
    },

    handleImport () {
      this.importLoading = true;
      const formData = new FormData();
      formData.append('file', this.file.raw);
      formData.append('factoryType', this.activeName);
      axios
        .post(
          process.env.VUE_APP_BASE_API +
          '/admin-api/system/board/inventory/import',
          formData,
          {
            headers: {
              Authorization: 'Bearer' + ' ' + this.token,
              'Content-Type': 'multipart/form-data',
            },
          }
        )
        .then((res) => {
          if (res.data.code == 0) {
            this.$message({
              type: 'success',
              message: '导入成功',
            });
            this.$nextTick(() => {
              this.handleGetList();
            });
          } else {
            this.$notify.error({
              title: res.data.msg,
            });
          }
          this.importLoading = false;
          this.showDialog = false;
        })
        .catch((e) => {
          console.log(e, 'e');
        });
    },
    handleFileUploadProgress (event, file, fileList) {
      this.upload.isUploading = true;
      this.importLoading = false;
      this.showDialog = true;
      this.activeImportName = 'rightRecords'
    },
    async getToday () {
      const res = await getToday();
    },
    handleExport (type) {
      const queryParams = {
        ...this.queryParams,
        factoryType: this.activeName,
      };
      this.$modal
        .confirm('是否确认导出?')
        .then(() => {
          this.exportLoading = true;
          return exportExcel(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '库存编辑导出.xls');
          this.exportLoading = false;
        })
        .catch(() => { });
    },
    handleQuery () {
      //   console.log(this.queryParams);
      //   console.log(this.$refs.list);
      this.$nextTick(() => {
        // this.$refs[this.activeName][0].getList();
        this.handleGetList();
      });
    },

    resetQuery () {
      this.queryParams.productId = '';
      this.queryParams.productType = '';
      this.queryParams.productTopTypeCode = '';
      this.queryParams.productTypeCode = '';
      this.queryParams.productName = '';
      this.queryParams.productCode = '';
      this.queryParams.range = 0;
      // this.queryParams.priceDate = this.$dayjs().format('YYYY-MM-DD');
      // console.log('点击了重置', this.queryParams);
      this.$nextTick(() => {
        // this.$refs[this.activeName][0].getList();
        this.handleGetList();
      });
    },

    handleClick (tab, event) {
      //   console.log(tab, event);
      // this.$refs[this.activeName].$ready = true;
      // this.$refs.test_list.getList();
      this.queryParams.factoryType = this.activeName;
    },
    handleImportTabChange (tab, event) {
      this.importRecordsData = this.importData[this.activeImportName];
    },
    async getProductData () {
      const query = {
        type: this.queryParams.productType,
      };
      const res = await productData(query);
      this.productNameDatas = res.data;
    },
    handleScreen () {
      this.$refs.screenIcon.click();
    },
    handleScreenToggle (val) {
      this.isFullScreen = val;
      // console.log(val, 123);
    },
    handleCollapseChange () {
      // this.$refs['market_price_type'].calTableHeight()
    },
    removeTrailingZeros (number) {
      if (number == '-') return '-'
      let numberString = number.toString();
      numberString = numberString.replace(/(?:\.0*|(\.\d+?)0+)$/, "$1");
      return parseFloat(numberString)
    }
  },
};
</script>

<style lang="scss" scoped>
// @import url(); 引入公共css类
.tabs-right-search__wrapper {
  position: absolute;
  top: 15px;
  // right: 700px;
  display: inline-block;
  width: 10px;
  height: 10px;
}
.component_title {
  padding: 10px 30px 0 20px;
}
::v-deep .el-collapse-item__content {
  padding-bottom: 0 !important;
}
::v-deep .el-dialog .el-dialog__body {
  max-height: 710px !important;
}
.dialog-footer-import {
  display: flex;
  justify-content: flex-end;
}
</style>
