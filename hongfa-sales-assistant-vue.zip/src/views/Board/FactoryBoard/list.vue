<!-- 工厂产量列表 -->
<template>
  <div class="list_wrap">
    <el-table
      :data="tableData"
      :span-method="objectSpanMethod"
      border
      style="width: 100%;"
      :cell-style="addClass"
      v-loading="loading"
    >
      <!-- <el-table-column prop="id" label="ID" width="180"> </el-table-column> -->
      <el-table-column
        prop="productTypeName"
        label="类名"
        header-align="center"
        align="center"
        width="62"
      >
        <template slot-scope="scope">
          <div
            :id="scope.row.domId+scope.row.domIdx"
            class="cat_mao"
            :ref="scope.$index"
          ></div>
          <div class="cat_text">
            {{ scope.row.productTypeName||'-' }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="productName"
        label="品名"
        header-align="center"
        align="center"
      >
      </el-table-column>
      <el-table-column
        prop="productSpec"
        label="件（kg）"
        header-align="center"
        align="center"
      ><template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input
              v-model="scope.row.newRow.productSpec"
              placeholder="请填写"
            ></el-input>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.productSpec}}</div>

        </template></el-table-column>
      <el-table-column
        prop="outputAmount"
        label="产量（吨）"
        header-align="center"
        align="center"
      ><template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input-number
              style="width:100%"
              :controls="false"
              :step="0.001"
              :precision="3"
              v-model="scope.row.newRow.outputAmount"
              @input.native="changeInputPt2($event,3)"
              placeholder="请填写"
            ></el-input-number>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.outputAmount|weightFormat}}</div>

        </template></el-table-column>

      <el-table-column
        prop="outputRemark"
        label="产量备注"
        header-align="center"
        align="center"
      ><template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input
              v-model="scope.row.newRow.outputRemark"
              placeholder="请填写"
            ></el-input>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.outputRemark}}</div>

        </template></el-table-column>
      <el-table-column
        label="操作"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="handleEdit(scope.row,scope.$index)"
          >{{scope.row.isEdit?'保存':'编辑'}}</el-button>

        </template>
      </el-table-column>
    </el-table>
    <ListMenu :menuData="menuData"></ListMenu>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import ListMenu from '../components/ListMenu';
import { listData, updateData } from '@/api/Board/FactoryBoard';

export default {
  // import引入的组件需要注入到对象中才能使用
  components: { ListMenu },
  props: {
    queryParams: {
      type: Object,
      default: () => {
        return {
          productId: '',
          productType: '',
          factoryType: '',
          // priceDate: '',
        };
      },
    },
  },
  data() {
    // 这里存放数据
    return {
      loading: true,
      tableData: [],
      stockData: {
        xData: [
          '2024-5-1',
          '2024-5-2',
          '2024-5-3',
          '2024-5-4',
          '2024-5-5',
          '2024-5-6',
          '2024-5-7',
        ],
        yData: [0, 100, 200, 300, 400, 500, 600],
        max: 200,
        min: 20,
      },
      menuData: [],
      calcListData: [],
    };
  },
  // 监听属性 类似于data概念
  computed: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
  },
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    handleEdit(row, rowIdx) {
      // 编辑
      if (row.isEdit) {
        // 保存
        console.log(row.newRow);
        // this.$set(this.tableData, rowIdx, { ...row, ...row.newRow });
        // this.tableData[rowIdx] = row.newRow;

        const newDate = { id: row.id, ...row.newRow };
        this.updateDataFunc(newDate).then(() => {
          row.isEdit = false;
          this.$message({
            type: 'success',
            message: '保存成功',
          });
        });
        row.productSpec = row.newRow.productSpec;
        row.outputAmount = row.newRow.outputAmount;
        row.lowerLimit = row.newRow.lowerLimit;
        row.outputRemark = row.newRow.outputRemark;
        row.upperLimit = row.newRow.upperLimit;
        console.log(this.tableData);
      } else {
        // 编辑
        row.isEdit = true;
      }
    },
    async updateDataFunc(data) {
      await updateData(data);
    },
    async getList() {
      // console.log(this.queryParams);
      this.loading = true;
      const res = await listData(this.queryParams);
      res.data.map((item) => {
        item.isEdit = false;
        item.newRow = {
          productSpec: item.productSpec,
          outputAmount: item.outputAmount,
          lowerLimit: item.lowerLimit,
          outputRemark: item.outputRemark,
          upperLimit: item.upperLimit,
        };
      });
      this.tableData = res.data;
      this.calcCatData();
      this.loading = false;
    },
    // 处理分类相关数据
    calcCatData() {
      this.calcListData = [];
      this.menuData = [];
      let calcListDataIdx = 0;
      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];
        // console.log(item);
        if (index === 0) {
          item.domId = item.productTypeName;
          item.domIdx = calcListDataIdx;
          this.calcListData.push(1);
          this.menuData.push({
            label: item.productTypeName,
            code: calcListDataIdx,
          });
        } else {
          if (item.productType !== this.tableData[index - 1].productType) {
            calcListDataIdx++;
            item.domId = item.productTypeName;
            item.domIdx = calcListDataIdx;
            this.calcListData.push(1);
            this.menuData.push({
              label: item.productTypeName,
              code: calcListDataIdx,
            });
          } else {
            item.domId = item.productType + index;
            this.calcListData[calcListDataIdx]++;
          }
        }
      }
      // console.log(this.tableData);
      // console.log(this.calcListData);
      // console.log(this.menuData);
    },
    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      }
      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },
    toTop() {
      // console.log(this.$refs);
      // this.$scrollTo(this.$refs[0]);
      this.calcCatData();
    },

    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        // console.log(row, column, rowIndex, columnIndex);
        if (row.productTypeName === row.domId) {
          return {
            rowspan: this.calcListData[row.domIdx],
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {
    this.getList();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.calcCatData();
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}
.pop_text {
  color: #2d7ae6;
}
</style>
