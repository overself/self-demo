<!-- 工厂产量编辑 -->
<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <div class="search_wrap">
          <div class="component_title">工厂产量编辑

            <div class="title_right_btns">
              <screenfull
                id="screenfull"
                class="right-menu-item hover-effect"
              />全屏
            </div>
          </div>
          <el-form
            :model="queryParams"
            ref="queryForm"
            size="small"
            :inline="true"
            label-width="68px"
          >
            <el-form-item
              label="品类名称"
              prop="productType"
            >
              <el-select
                filterable
                clearable
                v-model="queryParams.productType"
                placeholder="请选择"
                style="width: 240px"
              >
                <el-option
                  v-for="dict in statusDictDatas"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>

            <el-form-item
              label="品项名称"
              prop="productId"
            >
              <el-select
                filterable
                clearable
                v-model="queryParams.productId"
                placeholder="请选择"
                style="width: 240px"
              >
                <el-option
                  v-for="dict in productNameDatas"
                  :key="dict.id"
                  :label="dict.name"
                  :value="dict.id"
                >
                  <span class="st-name-spec">{{dict.name}} / {{dict.spec}}</span>
                </el-option>
              </el-select>
            </el-form-item>

            <!-- <el-form-item
              label="选择日期"
              prop="priceDate"
            >
              <el-date-picker
                v-model="queryParams.priceDate"
                style="width: 240px"
                value-format="yyyy-MM-dd"
                type="date"
                placeholder="选择日期"
              />
            </el-form-item> -->
            <el-form-item>
              <el-button
                icon="el-icon-search"
                @click="handleQuery"
              >查询</el-button>
              <el-button
                icon="el-icon-refresh"
                @click="resetQuery"
              >重置</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="content_wrap">
          <el-tabs
            v-model="activeName"
            @tab-click="handleClick"
          >
            <el-tab-pane
              v-for="tab in factoryOption"
              :key="tab.value"
              :label="tab.label"
              :name="tab.value"
            >
              <List
                v-if="activeName==tab.value"
                :ref="tab.value"
                :queryParams="{...queryParams,factoryType:tab.value}"
              ></List>
            </el-tab-pane>
          </el-tabs>
          <div class="tabs_right_btns">
            <div class="right_text">
              <CurrentTime></CurrentTime>
            </div>
            <div class="right_text">
              单位：元/公斤
            </div>

            <el-upload
              ref="upload"
              class="upload-demo"
              :limit="1"
              accept=".xlsx, .xls"
              :headers="upload.headers"
              :action="upload.url"
              :disabled="upload.isUploading"
              :data="{factoryType:activeName}"
              :on-progress="handleFileUploadProgress"
              :on-success="handleFileSuccess"
              :show-file-list="false"
            >
              <el-button size="small">导入</el-button>
            </el-upload>
            <el-button
              style="margin-left:10px"
              size="small"
              :loading="exportLoading"
              @click="handleExport('')"
            >导出</el-button>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import { getDictDatas, DICT_TYPE } from '@/utils/dict';
import Screenfull from '@/components/Screenfull';
import { exportExcel } from '@/api/Board/FactoryBoard';
import { productData } from '@/api/Board/common';
import { getBaseHeader } from '@/utils/request';

import List from './list';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: { List, Screenfull },
  // directives: {
  //   layout: {
  //     inserted,
  //   },
  // },
  data() {
    // 这里存放数据
    return {
      exportLoading: false,
      queryParams: {
        productId: '',
        productType: '',
        // priceDate: this.$dayjs().format('YYYY-MM-DD'),
      },
      productNameDatas: [],
      statusDictDatas: getDictDatas(DICT_TYPE.CATEGORY_CLASSIFY),
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 是否更新已经存在的用户数据
        updateSupport: 0,
        // 设置上传的请求头部
        headers: getBaseHeader(),
        // 上传的地址
        url:
          process.env.VUE_APP_BASE_API +
          '/admin-api/system/board/output/import',
      },
      factoryOption: getDictDatas(DICT_TYPE.SYSTEM_FACTORY),
      activeName: getDictDatas(DICT_TYPE.SYSTEM_FACTORY)[0].value,
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {
    'queryParams.productType'(newVal, oldVal) {
      console.log(newVal, oldVal);
      if (newVal === '') {
        this.productNameDatas = [];
      } else {
        this.queryParams.productId = '';
        this.getProductData();
      }
    },
  },
  // 方法集合
  methods: {
    handleFileSuccess(response, file, fileList) {
      console.log(response, file, fileList);
      if (response.code === 0) {
        this.$message({
          type: 'success',
          message: '导入成功',
        });
        this.$nextTick(() => {
          this.$refs[this.activeName].getList();
        });
      } else {
        this.$notify.error({
          title: response.msg,
        });
      }
      this.$refs.upload.clearFiles();
      this.upload.isUploading = false;
    },
    handleFileUploadProgress(event, file, fileList) {
      this.upload.isUploading = true;
    },
    handleExport(type) {
      const queryParams = {
        ...this.queryParams,
        factoryType: this.activeName,
      };
      this.$modal
        .confirm('是否确认导出?')
        .then(() => {
          this.exportLoading = true;
          return exportExcel(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '业务导出.xls');
          this.exportLoading = false;
        })
        .catch(() => {});
    },
    handleQuery() {
      console.log(this.queryParams);
      console.log(this.$refs.list);
      this.$nextTick(() => {
        this.$refs[this.activeName][0].getList();
      });
    },
    resetQuery() {
      this.queryParams.productId = '';
      this.queryParams.productType = '';
      // this.queryParams.priceDate = this.$dayjs().format('YYYY-MM-DD');
      console.log('点击了重置', this.queryParams);
      this.$nextTick(() => {
        this.$refs[this.activeName][0].getList();
      });
    },
    handleClick(tab, event) {
      console.log(tab, event);
      // this.$refs[this.activeName].$ready = true;
      // this.$refs.test_list.getList();
      this.queryParams.factoryType = this.activeName;
    },
    async getProductData() {
      const query = {
        type: this.queryParams.productType,
      };
      const res = await productData(query);
      this.productNameDatas = res.data;
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
// @import url(); 引入公共css类
</style>
