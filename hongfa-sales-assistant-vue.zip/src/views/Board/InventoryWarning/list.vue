<!-- 价格看板编辑列表 -->
<template>
  <div class="list_wrap">
    <el-table
      ref="hookTable"
      :data="tableData"
      :span-method="objectSpanMethod"
      border
      style="width: 100%;"
      :cell-style="addClass"
      v-loading="loading"
      :height="tableHeight"
    >
      <!-- <el-table-column prop="id" label="ID" width="180"> </el-table-column> -->
      <el-table-column
        prop="productTopTypeName"
        label="品项大类"
        header-align="center"
        align="center"
        width="100"
      >
        <template slot-scope="scope">
          <div
            :id="scope.row.domId+scope.row.domIdx"
            class="cat_mao"
            :ref="scope.$index"
          ></div>
          <div class="cat_text">
            {{ scope.row.productTopTypeName||'-' }}
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="productTypeCode"
        label="品类编码"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="productTypeName"
        label="品项分类"
        header-align="center"
        align="center"
      > <template slot-scope="scope">
          <div
            :id="scope.row.domIds+scope.row.domIdxs"
            class="cat_mao"
            :ref="scope.$index"
          ></div>
          <div class="cat_text">
            {{ scope.row.productTypeName||'-' }}
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="productCode"
        label="品项编码"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="productName"
        label="品项"
        header-align="center"
        align="center"
        width="230"
      >
      </el-table-column>
      <el-table-column
        prop="productSpec"
        label="详细规格"
        header-align="center"
        align="center"
      ><template slot-scope="scope">
          {{scope.row.productSpec}}

        </template></el-table-column>
      <!-- <el-table-column
        prop="amount"
        label="库存（吨）"
        header-align="center"
        align="center"
      ><template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input-number
              style="width:100%"
              :controls="false"
              :step="0.001"
              :precision="3"
              v-model="scope.row.newRow.amount"
              @input.native="changeInputPt2($event,3)"
              placeholder="请填写"
            ></el-input-number>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.amount|weightFormat}}</div>

        </template></el-table-column> -->

      <!-- <el-table-column
        prop="remark"
        label="库存备注"
        header-align="center"
        align="center"
      ><template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input
              v-model="scope.row.newRow.remark"
              placeholder="请填写"
              maxlength="10"
              show-word-limit
            ></el-input>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.remark}}</div>

        </template></el-table-column> -->
      <el-table-column
        prop="lowerLimit"
        label="库存下限"
        header-align="center"
        align="center"
      ><template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input-number
              style="width:100%"
              :controls="false"
              :step="0.001"
              :precision="3"
              v-model="scope.row.newRow.lowerLimit"
              placeholder="请填写"
            ></el-input-number>
            <!-- @input.native="changeInputPt2($event,3)" -->
          </div>
          <div
            class=""
            v-else
          >{{scope.row.lowerLimit|weightFormat}}</div>
        </template></el-table-column>

      <el-table-column
        prop="upperLimit"
        label="库存上限"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <!-- <el-input-number
              style="width:100%"
              :controls="false"
              :step="0.001"
              :precision="3"
              v-model="scope.row.newRow.upperLimit"
              @input.native="changeInputPt2($event,3)"
              placeholder="请填写"
            ></el-input-number> -->
            <el-input-number
              style="width:100%"
              :controls="false"
              :step="0.01"
              :precision="3"
              v-model="scope.row.newRow.upperLimit"
              placeholder="请填写"
            ></el-input-number>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.upperLimit|weightFormat}}</div>
        </template>
      </el-table-column>

      <el-table-column
        label="操作"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <el-button
            v-if="permi.hasPermi('system:board-inventory:warnupdate')"
            type="text"
            :disabled="editDisabled()"
            style="border: none; background-color: transparent;"
            @click="handleEdit(scope.row,scope.$index)"
          >{{scope.row.isEdit?'保存':'编辑'}}</el-button>
          <span v-else>暂无权限</span>
        </template>
      </el-table-column>
    </el-table>

    <ListMenu
      :menuData="menuData"
      isTableFixed
    ></ListMenu>

    <el-dialog
      title="确认删除此行库存数据？"
      :visible.sync="visible"
      width="520px"
      append-to-body
      top="30vh"
    >
      <div>删除后，价格编辑页，价格库存看板页，会同步删除此品项，请谨慎操作！</div>
      <div
        slot="footer"
        class="dialog-footer"
      >
        <el-button
          type="primary"
          @click="deleteRow"
        >确 定</el-button>
        <el-button @click="visible = false">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
  
<script>
import ListMenu from '../components/ListMenu';
import {
  inventoryList,
  warnupdate,
  inventoryCreate,
  inventoryDelete,
} from '@/api/Board/StockBoard';
import { deepClone } from '@/utils';
import permi from '@/plugins/auth.js';

export default {
  components: { ListMenu },
  props: {
    queryParams: {
      type: Object,
      default: () => {
        return {
          productId: '',
          productType: '',
          factoryType: '',
          // priceDate: '',
        };
      },
    },
    activeTabName: {
      type: String,
      default: () => {
        return "1"
      },
    },
  },

  data () {
    // 这里存放数据
    return {
      permi,
      visible: false,
      loading: true,
      tableData: [],
      stockData: {
        xData: [
          '2024-5-1',
          '2024-5-2',
          '2024-5-3',
          '2024-5-4',
          '2024-5-5',
          '2024-5-6',
          '2024-5-7',
        ],
        yData: [0, 100, 200, 300, 400, 500, 600],
        max: 200,
        min: 20,
      },
      menuData: [],
      calcListData: [],
      calcListDatas: [],
      rowId: null,
      tableHeight: 0,
    };
  },
  watch: {
    activeTabName (val) {
      this.calTableHeight()
    },
  },
  // 监听属性 类似于data概念
  computed: {
    handleClick (tab, event) {
      console.log(tab, event);
    },
  },

  created () {
    this.calTableHeight();
    this.getList();

    window.addEventListener('resize', this.calTableHeight);
  },

  mounted () {
    this.calcCatData();
    this.calcCatData2();
  },

  beforeDestroy () {
    window.removeEventListener('resize', this.calTableHeight);
  },

  methods: {
    calTableHeight () {
      const viewportHeight =
        window.innerHeight ||
        document.documentElement.clientHeight ||
        document.body.clientHeight;
      // this.tableHeight = viewportHeight - 50 - 20 - 41 - 55 - 20 - 10 - 36 - 60; // 36是tag
      this.tableHeight = this.activeTabName == '1' ? viewportHeight - 50 - 20 - 41 - 55 - 20 - 10 - 36 - 60 - 18 : viewportHeight - 50 - 20 - 41 - 55 - 20 - 10 - 36 - 10; // 36是tag 63是搜索区域
      this.$nextTick(() => {
        this.$refs?.hookTable.doLayout();
      });
    },

    editDisabled () {
      return !this.$dayjs(this.queryParams.date).isSame(this.$dayjs(), 'day');
    },

    // 删除行
    deleteItem (row, index) {
      if (row.isCopy) {
        this.tableData.splice(index, 1);
        this.calcCatData();
        this.calcCatData2();
      } else {
        this.visible = true;
        this.rowId = row.id;
      }
    },
    deleteRow (row) {
      inventoryDelete({ id: this.rowId }).then((res) => {
        this.$message({
          message: '删除成功',
          type: 'success',
        });
        this.visible = false;
        this.getList();
      });
    },
    // 复制行
    copyItem (row, index) {
      // console.log('复制前', this.tableData);
      const newRow = deepClone(row);
      newRow.isCopy = true;
      this.tableData.splice(index + 1, 0, newRow);
      // console.log('复制后', this.tableData);
      this.calcCatData();
      this.calcCatData2();
      // arr.splice(2, 0, 5);
    },
    handleEdit (row, rowIdx) {
      // 编辑
      if (row.isEdit) {
        if (row.isCopy) {
          const newDate = { id: row.id, ...row.newRow };
          newDate.productId = row.productId;
          newDate.factoryType = this.queryParams.factoryType;
          inventoryCreate(newDate).then((res) => {
            row.isCopy = false;
            row.isEdit = false;
            this.$message({
              message: '新增成功',
              type: 'success',
            });
            this.getList();
          });
        } else {
          // 保存
          console.log(row.newRow);
          // this.$set(this.tableData, rowIdx, { ...row, ...ro  w.newRow });
          // this.tableData[rowIdx] = row.newRow;
          if (row.newRow.lowerLimit > row.newRow.upperLimit) {
            this.$notify.error({ title: '下限不能超过上限' });
            return;
          }
          const newDate = { id: row.id, ...row.newRow };

          this.updateDataFunc(newDate).then(() => {
            row.isEdit = false;
            this.$message({
              type: 'success',
              message: '保存成功',
            });
          });
          row.productName = row.newRow.productName;
          row.productSpec = row.newRow.productSpec;
          row.amount = row.newRow.amount;
          row.lowerLimit = row.newRow.lowerLimit;
          row.remark = row.newRow.remark;
          row.upperLimit = row.newRow.upperLimit;
          console.log(this.tableData);
        }
      } else {
        // 编辑
        row.isEdit = true;
      }
    },
    async updateDataFunc (data) {
      await warnupdate(data);
    },

    async getList () {
      console.log(this.queryParams);
      this.loading = true;
      const res = await inventoryList(this.queryParams);
      res.data.map((item) => {
        item.isEdit = false;
        item.isCopy = false;
        item.newRow = {
          productName: item.productName,
          productSpec: item.productSpec,
          amount: item.amount,
          lowerLimit: item.lowerLimit,
          remark: item.remark,
          upperLimit: item.upperLimit,
        };
      });
      this.tableData = res.data;
      this.calcCatData();
      this.calcCatData2();
      this.loading = false;
    },

    // 处理分类相关数据
    calcCatData () {
      this.calcListData = [];
      this.menuData = [];
      let calcListDataIdx = 0;
      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];
        // console.log(item);
        if (index === 0) {
          item.domId = item.productTopTypeName;
          item.domIdx = calcListDataIdx;
          this.calcListData.push(1);
          this.menuData.push({
            label: item.productTopTypeName,
            code: calcListDataIdx,
          });
        } else {
          if (
            item.productTypeCode !== this.tableData[index - 1].productTypeCode
          ) {
            calcListDataIdx++;
            item.domId = item.productTopTypeName;
            item.domIdx = calcListDataIdx;
            this.calcListData.push(1);
            this.menuData.push({
              label: item.productTopTypeName,
              code: calcListDataIdx,
            });
          } else {
            item.domId = item.productTypeCode + index;
            this.calcListData[calcListDataIdx]++;
          }
        }
      }
      // console.log(this.tableData);
      // console.log(this.calcListData);
      // console.log(this.menuData);
    },

    calcCatData2 () {
      this.calcListDatas = [];
      this.menuData = [];
      let calcListDataIdx = 0;
      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];
        // console.log(item);
        if (index === 0) {
          item.domIds = item.productTypeName;
          item.domIdxs = calcListDataIdx;
          this.calcListDatas.push(1);
          this.menuData.push({
            label: item.productTypeName,
            code: calcListDataIdx,
          });
        } else {
          if (
            item.productTypeCode !== this.tableData[index - 1].productTypeCode
          ) {
            calcListDataIdx++;
            item.domIds = item.productTypeName;
            item.domIdxs = calcListDataIdx;
            this.calcListDatas.push(1);
            this.menuData.push({
              label: item.productTypeName,
              code: calcListDataIdx,
            });
          } else {
            item.domIds = item.productTypeCode + index;
            this.calcListDatas[calcListDataIdx]++;
          }
        }
      }
      // console.log(this.tableData);
      // console.log(this.calcListData);
      // console.log(this.menuData);
    },

    addClass ({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0 || columnIndex === 4 || columnIndex === 5) {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      }
      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },
    toTop () {
      // console.log(this.$refs);
      // this.$scrollTo(this.$refs[0]);
      this.calcCatData();
      this.calcCatData2();
    },

    objectSpanMethod ({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        // console.log(row, column, rowIndex, columnIndex);
        if (row.productTopTypeName === row.domId) {
          return {
            rowspan: this.calcListData[row.domIdx],
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }

      if (columnIndex === 1 || columnIndex === 2) {
        // console.log('calcListData', this.calcListData);
        if (row.productTypeName === row.domIds) {
          return {
            rowspan: this.calcListDatas[row.domIdxs],
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }
    },
  },
};
</script>
  <style lang="scss" scoped>
::v-deep .el-dialog {
  margin-top: 30vh !important;
}
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}
.pop_text {
  color: #2d7ae6;
}
</style>
  