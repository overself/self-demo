<!-- 库存看板编辑 -->
<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <el-collapse
          accordion
          v-model="activeTabName"
          @change="handleCollapseChange"
        >
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">库存预警编辑
                <div
                  class="title_right_btns"
                  @click.stop="handleScreen"
                >
                  <screenfull
                    id="screenfull"
                    class="right-menu-item hover-effect"
                    ref="screenIcon"
                    @screenToggle="handleScreenToggle"
                  />{{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">

              <el-form
                :model="queryParams"
                ref="queryForm"
                size="small"
                :inline="true"
                label-width="68px"
              >
                <el-form-item
                  label="品项大类"
                  prop="productType"
                >
                  <el-select
                    filterable
                    clearable
                    v-model="queryParams.productTopTypeCode"
                    placeholder="请选择"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="dict in searchProductTopTypeList"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="品项分类"
                  prop="productType"
                >
                  <el-select
                    filterable
                    clearable
                    v-model="queryParams.productTypeCode"
                    placeholder="请选择"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="dict in searchProductTypeList"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="品项名称"
                  prop="productId"
                >
                  <el-select
                    filterable
                    clearable
                    allow-create
                    v-model="queryParams.productName"
                    placeholder="请选择"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="dict in searchProductNameList"
                      :key="dict.id"
                      :label="dict.name"
                      :value="dict.name"
                    >
                      <span class="st-name-spec">{{dict.name}} / {{dict.spec}}</span>
                    </el-option>
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="品项编码"
                  prop="productCode"
                >
                  <el-input
                    v-model="queryParams.productCode"
                    placeholder="请输入"
                    clearable
                    style="width: 240px"
                  ></el-input>
                </el-form-item>

                <!-- <el-form-item
                label="选择日期"
                prop="priceDate"
              >
                <el-date-picker
                  v-model="queryParams.priceDate"
                  style="width: 240px"
                  value-format="yyyy-MM-dd"
                  type="date"
                  placeholder="选择日期"
                />
              </el-form-item> -->

                <el-form-item>
                  <el-button
                    icon="el-icon-search"
                    @click="handleQuery"
                  >查询</el-button>
                  <el-button
                    icon="el-icon-refresh"
                    @click="resetQuery"
                  >重置</el-button>
                </el-form-item>
              </el-form>
            </div>
          </el-collapse-item>
        </el-collapse>

        <div class="content_wrap">
          <el-tabs
            v-model="activeName"
            @tab-click="handleClick"
          >
            <el-tab-pane
              v-for="tab in factoryOption"
              :key="tab.value"
              :label="tab.label"
              :name="tab.value"
            >
              <List
                v-if="activeName==tab.value"
                :ref="tab.value"
                :queryParams="{...queryParams,factoryType:tab.value}"
                :activeTabName="activeTabName"
              ></List>
            </el-tab-pane>
          </el-tabs>

       <!--   <div class="tabs-right-search__wrapper">
            <div class="tabs-right-search__inner">
              <el-form
                :model="queryParams"
                size="small"
                :inline="true"
                label-width="90px"
              >
                <el-form-item label="">
                  <el-date-picker
                    v-model="queryParams.date"
                    type="date"
                    placeholder="选择日期"
                    size="small"
                    :format="'yyyy-MM-dd'"
                    :valueFormat="'yyyy-MM-dd'"
                    :style="{width: '240px'}"
                    :picker-options="datePickerOptions"
                    @change='onDatePickerChange'
                    :clearable="false"
                  ></el-date-picker>
                </el-form-item>
              </el-form>
            </div>
          </div> -->
          <div class="tabs_right_btns">
            <!-- <div class="right_text">
                <CurrentTime></CurrentTime>
              </div> -->
            <!-- <div class="right_text">
                单位：元/公斤
              </div> -->

            <!-- <el-upload
                ref="upload"
                class="upload-demo"
                :limit="1"
                accept=".xlsx, .xls"
                :headers="upload.headers"
                :action="upload.url"
                :disabled="upload.isUploading"
                :data="{factoryType:activeName}"
                :on-progress="handleFileUploadProgress"
                :on-success="handleFileSuccess"
                :show-file-list="false"
              >
                <el-button size="small">导入</el-button>
              </el-upload> -->
            <!-- <el-button
              style="margin-left:10px"
              size="small"
              @click="addStock('')"
              v-if="permi.hasPermi('system:board-inventory:create')"
            >新增品项</el-button>
            <el-button
              style="margin-left:10px"
              size="small"
              :loading="exportLoading"
              @click="handleExport('')"
            >导出</el-button> -->
            <!-- <el-button
                size="small"
                @click="getToday()"
              >今日报价</el-button> -->
          </div>
        </div>
      </el-col>
    </el-row>
    <!--新增&&编辑-->
    <el-dialog
      :title="title"
      :visible.sync="open"
      width="500px"
      append-to-body
    >
      <el-form
        ref="ruleForm"
        :model="form"
        :rules="rules"
        label-width="125px"
      >
        <el-form-item
          label="品项大分类"
          prop="topType"
        >
          <el-select
            placeholder="请选择"
            v-model="form.topType"
            style="width: 100%"
            @change="changeTopType"
          >
            <el-option
              v-for="dict in productTopTypeList"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          label="品项分类"
          prop="productType"
        >
          <el-select
            placeholder="请选择"
            v-model="form.productType"
            style="width: 100%"
            @change="changeType"
          >
            <el-option
              v-for="dict in productTypeList"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          label="品项名称"
          prop="productId"
        >
          <el-select
            placeholder="请选择"
            v-model="form.productId"
            style="width: 100%"
          >
            <el-option
              v-for="dict in productNameList"
              :key="dict.id"
              :label="dict.name"
              :value="dict.id"
              @click.native="selectProductName(dict.code,dict.spec)"
            >
              <span class="st-name-spec">{{dict.name}} / {{dict.spec}}</span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          label="品项编码"
          prop="code"
        >
          <el-input
            v-model="form.code"
            disabled
            placeholder="系统带出"
          />
        </el-form-item>
        <el-form-item
          label="详细规格"
          prop="spec"
        >
          <el-input
            v-model="form.spec"
            disabled
            placeholder="系统带出"
          />
        </el-form-item>
        <el-form-item label="库存(吨)">
          <el-input
            v-model="form.amount"
            placeholder="请输入库存(吨)"
          />
        </el-form-item>
        <el-form-item label="库存备注">
          <el-input
            v-model="form.remark"
            placeholder="请输入库存备注"
          />
        </el-form-item>
      </el-form>
      <div
        slot="footer"
        class="dialog-footer"
      >
        <el-button
          type="primary"
          @click="submitForm('ruleForm')"
        >确 定</el-button>
        <el-button @click="open = false">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import { getDictDatas, DICT_TYPE } from '@/utils/dict';
import Screenfull from '@/components/Screenfull';
import {
  exportExcel,
  importExcel,
  getToday,
  productTopType,
  producTtype,
  productSimple,
  inventoryCreate,
} from '@/api/Board/StockBoard';
import { productData } from '@/api/Board/common';
import { getBaseHeader } from '@/utils/request';
import permi from '@/plugins/auth.js';
import List from './list';

export default {
  // import引入的组件需要注入到对象中才能使用
  components: { List, Screenfull },
  // directives: {
  //   layout: {
  //     inserted,
  //   },
  // },
  data () {
    // 这里存放数据
    return {
      permi,
      form: {
        code: '',
        spec: '',
      },
      title: '新增品项',
      productTopTypeList: [],
      productTypeList: [],
      productNameList: [],

      searchProductTopTypeList: [],
      searchProductTypeList: [],
      searchProductNameList: [],

      open: false,
      exportLoading: false,
      queryParams: {
        productId: '',
        productType: '',
        productTopTypeCode: '',
        productTypeCode: '',
        productName: '',
        productCode: '',
        factoryType: getDictDatas(DICT_TYPE.SYSTEM_FACTORY_PRODUCT)[0].value,
        date: this.$dayjs().format('YYYY-MM-DD'),
        // priceDate: this.$dayjs().format('YYYY-MM-DD'),
      },
      datePickerOptions: {
        disabledDate (time) {
          // 获取今天的日期
          const today = new Date();
          // 如果选择的日期在今天之后，则禁用
          return time.getTime() > today.getTime();
        },
      },
      productNameDatas: [],
      statusDictDatas: getDictDatas(DICT_TYPE.CATEGORY_CLASSIFY),
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 是否更新已经存在的用户数据
        updateSupport: 0,
        // 设置上传的请求头部
        headers: getBaseHeader(),
        // 上传的地址
        url:
          process.env.VUE_APP_BASE_API +
          '/admin-api/system/board/inventory/import',
      },
      // factoryOption: getDictDatas(DICT_TYPE.SYSTEM_FACTORY_PRODUCT),
      factoryOption: [
        { label: '北票二厂', value: 'bp_2_factory' },
        { label: '朝阳工厂', value: 'cy_factory' },
        { label: '喀左工厂', value: 'kz_factory_ln' },
        // { label: '喀左工厂(远赢)', value: 'kz_factory_yy' },
        { label: '北票一厂', value: 'bp_1_factory' },
      ],
      activeName: getDictDatas(DICT_TYPE.SYSTEM_FACTORY_PRODUCT)[0].value,
      rules: {
        topType: [
          { required: true, message: '请选择品项大分类', trigger: 'blur' },
        ],
        productType: [
          { required: true, message: '请选择品项分类', trigger: 'blur' },
        ],
        productId: [
          { required: true, message: '请选择品项名称', trigger: 'blur' },
        ],
        spec: [{ required: true, message: '详细规格', trigger: 'blur' }],
        code: [{ required: true, message: '品项编码', trigger: 'blur' }],
      },
      isFullScreen: true,
      activeTabName: "1"
    };
  },

  watch: {
    'queryParams.productType' (newVal, oldVal) {
      // console.log(newVal, oldVal);
      if (newVal === '') {
        this.productNameDatas = [];
      } else {
        this.queryParams.productId = '';
        this.getProductData();
      }
    },
    'queryParams.productTopTypeCode' (newVal, oldVal) {
      // console.log(newVal, oldVal);
      if (newVal === '') {
        this.searchProductTypeList = [];
      } else {
        this.queryParams.productId = '';
        this.getSearchProducTtype();
      }
    },
    'queryParams.productTypeCode' (newVal, oldVal) {
      // console.log(newVal, oldVal);
      if (newVal === '') {
        this.searchProductNameList = [];
      } else {
        this.queryParams.productId = '';
        this.getSearchProductSimple();
      }
    },

    open (val) {
      if (!val) {
        this.form = {
          code: '',
          spec: '',
        };
        this.$refs.ruleForm.resetFields();
      }
    },
  },

  // 生命周期 - 创建完成（可以访问当前this实例）
  created () {
    this.getProductTopType();
  },

  methods: {
    onDatePickerChange () {
      try {
        this.$refs[this.activeName][0].getList();
      } catch (error) { }
    },
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          delete this.form.code;
          delete this.form.spec;
          delete this.form.topType;
          delete this.form.productType;
          this.form.factoryType = this.queryParams.factoryType;
          inventoryCreate(this.form).then((res) => {
            this.$message({
              message: '新增成功',
              type: 'success',
            });
            this.open = false;
            this.getProductData();
          });
        }
      });
    },
    // 品项名称选择
    selectProductName (code, spec) {
      this.form.code = code;
      this.form.spec = spec;
      // console.log('form', this.form);
      //   console.log('code', code);
      //   console.log('spec', spec);
    },
    // 大类切换
    changeTopType () {
      // console.log('form', this.form);
      this.getProducTtype();
    },
    // 品项分类切换
    changeType () {
      this.getProductSimple();
    },
    addStock () {
      this.open = true;
    },
    // 获取品项名称
    getProductSimple () {
      productSimple({ type: this.form.productType }).then((res) => {
        this.productNameList = res.data;
      });
    },
    getSearchProductSimple () {
      productSimple({ type: this.queryParams.productTypeCode }).then((res) => {
        this.searchProductNameList = res.data;
      });
    },
    // 获取品项分类
    getProducTtype () {
      producTtype({ value: this.form.topType }).then((res) => {
        this.productTypeList = res.data;
      });
    },

    // 获取搜索品项分类
    getSearchProducTtype () {
      producTtype({ value: this.queryParams.productTopTypeCode }).then(
        (res) => {
          this.searchProductTypeList = res.data;
        }
      );
    },

    //获取商品大类
    getProductTopType () {
      productTopType().then((res) => {
        this.productTopTypeList = res.data;
        this.searchProductTopTypeList = res.data;
      });
    },

    handleFileSuccess (response, file, fileList) {
      // console.log(response, file, fileList);
      if (response.code === 0) {
        this.$message({
          type: 'success',
          message: '导入成功',
        });
        this.$nextTick(() => {
          this.$refs[this.activeName].getList();
        });
      } else {
        this.$notify.error({
          title: response.msg,
        });
      }
      this.$refs.upload.clearFiles();
      this.upload.isUploading = false;
    },
    handleFileUploadProgress (event, file, fileList) {
      this.upload.isUploading = true;
    },
    async getToday () {
      const res = await getToday();
    },
    handleExport (type) {
      const queryParams = {
        ...this.queryParams,
        factoryType: this.activeName,
      };
      this.$modal
        .confirm('是否确认导出?')
        .then(() => {
          this.exportLoading = true;
          return exportExcel(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '业务导出.xls');
          this.exportLoading = false;
        })
        .catch(() => { });
    },
    handleQuery () {
      // console.log(this.queryParams);
      // console.log(this.$refs.list);
      this.$nextTick(() => {
        this.$refs[this.activeName][0].getList();
      });
    },

    resetQuery () {
      this.queryParams.productId = '';
      this.queryParams.productType = '';
      this.queryParams.productTopTypeCode = '';
      this.queryParams.productTypeCode = '';
      this.queryParams.productName = '';
      this.queryParams.productCode = '';
      // this.queryParams.priceDate = this.$dayjs().format('YYYY-MM-DD');
      // console.log('点击了重置', this.queryParams);
      this.$nextTick(() => {
        this.$refs[this.activeName][0].getList();
      });
    },

    handleClick (tab, event) {
      // console.log(tab, event);
      // this.$refs[this.activeName].$ready = true;
      // this.$refs.test_list.getList();
      this.queryParams.factoryType = this.activeName;
    },
    async getProductData () {
      const query = {
        type: this.queryParams.productType,
      };
      const res = await productData(query);
      this.productNameDatas = res.data;
    },
    handleScreen () {
      this.$refs.screenIcon.click()
    },
    handleScreenToggle (val) {
      this.isFullScreen = val
      // console.log(val, 123);
    },
    handleCollapseChange () {
    }
  },
};
</script>
  <style lang="scss" scoped>
// @import url(); 引入公共css类
.tabs-right-search__wrapper {
  position: absolute;
  top: 15px;
  left: 560px;
  display: inline-block;
  width: 10px;
  height: 10px;
}
.component_title {
  padding: 10px 30px 0 20px;
}
::v-deep .el-collapse-item__content {
  padding-bottom: 0 !important;
}
</style>
