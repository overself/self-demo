<!-- 价格库存看板 -->
<template>
  <div class="app-container Board">
    <!-- 搜索工作栏 -->
    <el-row :gutter="20">
      <!--部门数据-->
      <!--用户数据-->
      <el-col :span="24" :xs="24">
        <el-collapse accordion v-model="activeTabName" @change="handleCollapseChange">
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">价格库存看板
                <div class="title_right_btns" @click.stop="handleScreen">
                  <screenfull id="screenfull" class="right-menu-item hover-effect" ref="screenIcon"
                    @screenToggle="handleScreenToggle" />{{ isFullScreen ? '全屏' : '退出全屏' }}
                </div>
              </div>
            </template>
            <div class="search_wrap">

              <!-- 搜索工作栏 -->
              <BaseSearchContainer :column="searchColumn" :params="queryParams" @onSearch="handleQuery"
                @onReset="handleReset">
              </BaseSearchContainer>
            </div>
          </el-collapse-item>
        </el-collapse>
        <div class="content_wrap">
          <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="市场价格表" name="market_price_type">
              <List v-if="activeName == 'market_price_type'" ref="market_price_type"
                :queryParams="{ ...queryParams, priceType: 'market_price_type' }" @menuData="getMenuData"
                :activeTabName="activeTabName"></List>
            </el-tab-pane>
            <el-tab-pane label="鲜品价格表" name="fresh_price_type">
              <List v-if="activeName == 'fresh_price_type'" ref="fresh_price_type"
                :queryParams="{ ...queryParams, priceType: 'fresh_price_type' }" @menuData="getMenuData"
                :activeTabName="activeTabName"></List>
            </el-tab-pane>

            <el-tab-pane label="批发价格表" name="wholesale_price_type">
              <List v-if="activeName == 'wholesale_price_type'" ref="wholesale_price_type"
                :queryParams="{ ...queryParams, priceType: 'wholesale_price_type' }" @menuData="getMenuData"
                :activeTabName="activeTabName"></List>
            </el-tab-pane>
          </el-tabs>

          <div class="tabs-right-search__wrapper">
            <div class="tabs-right-search__inner">
              <el-form :model="queryParams" size="small" :inline="true" label-width="90px">
                <el-form-item label="">
                  <el-date-picker v-model="queryParams.priceDate" type="date" placeholder="选择日期" size="small"
                    :format="'yyyy-MM-dd'" :valueFormat="'yyyy-MM-dd'" :style="{ width: '200px' }"
                    :picker-options="datePickerOptions" clearable @change='onDatePickerChange'></el-date-picker>
                </el-form-item>
              </el-form>
            </div>
          </div>

          <div class="tabs_right_btns">
            <!-- <el-checkbox-group v-model="tableColumnCheckedList3"
              style="height: 38px; margin-right: 20px; padding-top: 8px;" @change="onProductCodeChange">
              <el-checkbox label="1">显示品项编码</el-checkbox>
            </el-checkbox-group> -->
            <el-checkbox-group v-model="tableColumnCheckedList1"
              style="height: 38px; margin-right: 20px; padding-top: 8px;" @change="onUnrestrictedInvChange">
              <el-checkbox label="1">显示锁单库存</el-checkbox>
            </el-checkbox-group>
            <el-checkbox-group v-model="tableColumnCheckedList2"
              style="height: 38px; margin-right: 20px; padding-top: 8px;" @change="onQualityInvChange">
              <el-checkbox label="2">显示质检库存</el-checkbox>
            </el-checkbox-group>
            <el-checkbox-group v-model="tableColumnCheckedList4"
              style="height: 38px; margin-right: 20px; padding-top: 8px;" @change="onFrozenInvChange">
              <el-checkbox label="1">显示冻结库存</el-checkbox>
            </el-checkbox-group>
            <el-checkbox-group v-model="queryParams._isShowZero"
              style="height: 38px; margin-right: 10px; padding-top: 8px;" @change="onShowZeroChange">
              <el-checkbox label="1">显示库存为0</el-checkbox>
            </el-checkbox-group>
            <el-button v-hasPermi="['system:board-price:export']" style="margin-left:10px" size="small"
              :loading="exportLoading" @click="handleExport">导出</el-button>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { productData } from '@/api/Board/common';
import Screenfull from '@/components/Screenfull';
import { DICT_TYPE, getDictDatas } from '@/utils/dict';

import List from './list';
export default {
  components: { List, Screenfull },
  data() {
    return {
      exportLoading: false,
      listRef: [
        'market_price_type',
        'fresh_price_type',
        'wholesale_price_type',
      ],
      queryParams: {
        productId: '',
        productType: '',
        priceDate: this.$dayjs().format('YYYY-MM-DD'),
        hierarchyName: '',
        isShowZero: 0,
        productTypeCode: '',
        _isShowZero: false,
        sortField: 'hierarchyName',
        sort: 'ASC',
      },
      productNameDatas: [],
      typeList: [],
      statusDictDatas: getDictDatas(DICT_TYPE.CATEGORY_CLASSIFY),
      activeName: 'market_price_type',
      datePickerOptions: {
        disabledDate(time) {
          // 获取今天的日期
          const today = new Date();
          // 如果选择的日期在今天之后，则禁用
          return time.getTime() > today.getTime();
        },
      },
      tableColumnCheckedList1: [],
      tableColumnCheckedList2: [],
      tableColumnCheckedList3: [],
      tableColumnCheckedList4: [],
      searchColumn: [
        {
          label: '产品层次',
          prop: 'hierarchyName',
          type: 'input',
          search: true,
        },
        {
          label: '品项分类',
          prop: 'productTypeCode',
          type: 'select',
          search: true,
          disabled: false,
          dicData: this.typeList,
        },
      ],
      isFullScreen: true,
      activeTabName: '0',
    };
  },

  watch: {
    'queryParams.productType'(newVal, oldVal) {
      console.log(newVal, oldVal);
      if (newVal === '') {
        this.productNameDatas = [];
      } else {
        this.queryParams.productId = '';
        this.getProductData();
      }
    },
    typeList: {
      immediate: true,
      handler(newVal, oldVal) {
        let newArr = [];
        this.searchColumn = [
          {
            label: '品项分类',
            prop: 'productTypeCode',
            type: 'select',
            search: true,
            disabled: false,
            dicData: newVal,
          },
          {
            label: '产品层次',
            prop: 'hierarchyName',
            type: 'input',
            search: true,
          },
        ];
      },
    },
  },

  methods: {
    getMenuData(e) {
      //   console.log('获取', e);
      this.typeList = e;
    },
    // onProductCodeChange() {
    //   this.$refs[this.activeName].handleChangeProductCode();
    // },
    onUnrestrictedInvChange() {
      this.$refs[this.activeName].handleChangeUnrestrictedInv();
    },
    onQualityInvChange() {
      this.$refs[this.activeName].handleChangeQualityInv();
    },
    onFrozenInvChange() {
      this.$refs[this.activeName].handleChangeFrozenInv();
    },

    onShowZeroChange() {
      this.queryParams.isShowZero = this.queryParams._isShowZero ? 1 : 0;
      this.$nextTick(() => {
        this.$refs[this.activeName].getList();
      });
    },

    onDatePickerChange() {
      this.$refs[this.activeName].getList();
    },

    handleExport(type) {
      this.$refs[this.activeName].exportExcel(type);
    },

    handleQuery() {
      this.$nextTick(() => {
        this.$refs[this.activeName].getList('select');
      });
    },

    handleReset() {
      this.queryParams.productId = '';
      this.queryParams.productType = '';
      this.queryParams.hierarchyName = '';
      this.queryParams.priceDate = this.$dayjs().format('YYYY-MM-DD');

      this.$nextTick(() => {
        this.$refs[this.activeName].getList();
      });
    },

    handleClick(tab, event) {
      this.queryParams.priceType = this.activeName;
      this.queryParams.productTypeCode = '';
      this.tableColumnCheckedList1 = [];
      this.tableColumnCheckedList2 = [];
      this.tableColumnCheckedList3 = [];
      this.tableColumnCheckedList4 = [];
      this.queryParams.isShowZero = 0;
      this.queryParams._isShowZero = false;
    },

    async getProductData() {
      const query = {
        type: this.queryParams.productType,
      };
      const res = await productData(query);
      this.productNameDatas = res.data;
    },
    handleScreen() {
      this.$refs.screenIcon.click();
    },
    handleScreenToggle(val) {
      this.isFullScreen = val;
    },
    handleCollapseChange() {
    },
  },
};
</script>

<style lang="scss" scoped>
// @import url(); 引入公共css类
.Board {
  height: 100%;
}

.tabs-right-search__wrapper {
  position: absolute;
  top: 15px;
  left: 435px;
  display: inline-block;
  width: 10px;
  height: 10px;
}

.component_title {
  padding: 10px 30px 0 20px;
}

::v-deep .el-collapse-item__content {
  padding-bottom: 0 !important;
}
</style>
