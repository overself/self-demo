<!-- 价格库存看板 -->
<template>
  <div class="list_wrap">
    <el-popover v-model="priceVisible" ref="pricePop" placement="top-start" width="600" trigger="manual" @show="getPriceChart(activeRow._isTable2 ? activeRow._rightData.productId : activeRow.productId,
      activeRow._isTable2 ? activeRow._rightData._factoryCode : activeRow._factoryCode)">
      <div v-loading="chartLoading">
        <div class="chart_wrap">
          <div class="chart_title">价格趋势</div>
          <div class="chart_control">
            <el-radio-group v-model="priceDateOption" size="mini" @input="dateOptionChange('price', activeRow._isTable2 ? activeRow._rightData.productId : activeRow.productId,
              activeRow._isTable2 ? activeRow._rightData._factoryCode : activeRow._factoryCode)">
              <el-radio-button v-for="(item, index) in dateOptions" :key="index" :label="item.value">{{ item.label }}
              </el-radio-button>
            </el-radio-group>
          </div>
        </div>
        <PriceChart :chart-data="priceData"></PriceChart>
      </div>
    </el-popover>

    <el-popover v-model="stockVisible" ref="stockPop" placement="top-start" width="600" trigger="manual" @show="getStockChart(activeRow._isTable2 ? activeRow._rightData.productId : activeRow.productId,
      activeRow._isTable2 ? activeRow._rightData._factoryCode : activeRow._factoryCode)">
      <div v-loading="chartLoading">
        <div class="chart_wrap">
          <div class="chart_title">库存趋势</div>
          <div class="chart_control">
            <el-radio-group v-model="stockDateOption" size="mini" @input="dateOptionChange('stock', activeRow._isTable2 ? activeRow._rightData.productId : activeRow.productId,
              activeRow._isTable2 ? activeRow._rightData._factoryCode : activeRow._factoryCode)">
              <el-radio-button v-for="(item, index) in dateOptions" :key="index" :label="item.value">{{ item.label }}
              </el-radio-button>
            </el-radio-group>
          </div>
        </div>
        <stock :chart-data="stockData"></stock>
      </div>
    </el-popover>

    <div v-loading="loading">
      <!-- <virtual-scroll :data="tableData" :item-size="42" key-prop="productCode"
        @change="(virtualList) => virtualData = virtualList" :virtualized="true"> -->
      <el-table ref="hookTable1" class="table1" key="productCode" :data="tableData" :span-method="objectSpanMethod"
        :cell-style="addClass" :height="tableHeight" border :row-key="getRowKey">
        <el-table-column prop="productTypeName" label="类名" header-align="center" align="center" width="40" fixed="left">
          <template slot-scope="scope">
            <div :id="scope.row.domId + scope.row.domIdx" class="cat_mao" :ref="scope.$index"></div>
            <div>
              {{ scope.row.productTypeName || '-' }}
            </div>
          </template>
        </el-table-column>

        <el-table-column v-if="showProductCode" prop="productCode" label="品项编码" width="140" header-align="center"
          align="center" fixed="left"></el-table-column>

        <el-table-column prop="productName" header-align="center" align="center" width="320px" fixed="left">
          <template #header>
            <div class="custom-header" @click="handleCustomSort('productName')">
              <span>品项</span>
              <div class="sort-icons">
                <i class="el-icon-caret-top"
                  :class="{ active: sortConfig.field === 'productName' && sortConfig.order === 'asc' }"></i>
                <i class="el-icon-caret-bottom"
                  :class="{ active: sortConfig.field === 'productName' && sortConfig.order === 'desc' }"></i>
              </div>
            </div>
          </template>
        </el-table-column>

        <!-- <el-table-column
          prop="productSpec"
          label="详细规格"
          header-align="center"
          align="center"
          width="95px"
        ></el-table-column> -->
        <el-table-column prop="totalAmount" header-align="center" align="center" width="180px">
          <template #header>
            <div class="custom-header" @click="handleCustomSort('totalAmount')">
              <div style="display: inline-block; vertical-align: middle;">
                <div>库存合计: </div>
                <div>{{ displayTotalAmount.toFixed(3) }}(吨)</div>
              </div>
              <div class="sort-icons">
                <i class="el-icon-caret-top"
                  :class="{ active: sortConfig.field === 'totalAmount' && sortConfig.order === 'asc' }"></i>
                <i class="el-icon-caret-bottom"
                  :class="{ active: sortConfig.field === 'totalAmount' && sortConfig.order === 'desc' }"></i>
              </div>
            </div>
          </template>
          <template slot-scope="scope">
            <div :class="scope.row.totalAmount !== '-' ? 'pop_text can_click' : ''"
              :style="{ color: scope.row.bp1FactoryInvIsUpdate == 1 ? '#6ac768' : '#000000' }" v-popover:stockPop
              @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, 'ALL', scope.row.totalAmount) }">{{
                scope.row.totalAmount | removeTrailingZeros }}
            </div>
          </template>
        </el-table-column>


        <el-table-column prop="bp1AvailableAmount" label="一厂" header-align="center" align="center">
          <template #header>
            <div>一厂: {{ bp1AvailableAmount.toFixed(3) }}(吨)</div>
          </template>
          <el-table-column prop="bp1Price" header-align="center" align="center" width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp1Price')">
                <span>价格</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp1Price' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp1Price' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
            <template slot-scope="scope">
              <span class="pop_text can_click"
                :class="scope.row.pb1PriceUpd == 1 && scope.row.bp1Price !== '-' ? 'green-text' : ''" v-popover:pricePop
                @click="(e) => { showPop(e, 'pricePop', scope.row, undefined, scope.row.bp1Factory, scope.row.bp1Price) }">
                {{ scope.row.bp1Price | moneyFormat }}
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="bp1AdjustRange" label="调幅" header-align="center" align="center" width="94px">
            <template slot-scope="scope">
              <div class="adjustRange_class">
                <span class="red" v-if="scope.row.bp1AdjustRange > 0">↑</span>
                <span class="green" v-if="scope.row.bp1AdjustRange < 0">↓</span>
                {{ scope.row.bp1AdjustRange | moneyFormat }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="bp1AvailableAmount" label="可售" header-align="center" align="center" width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp1AvailableAmount')">
                <span>可售</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp1AvailableAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp1AvailableAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
            <template slot-scope="scope">
              <div :class="{
                can_click: scope.row.bp1AvailableAmount !== '-', green_text: scope.row.bp1InvUpd == 1
                  && scope.row.bp1AvailableAmount !== '-'
              }" v-popover:stockPop @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, '1001') }">{{
                scope.row.bp1AvailableAmount |
                removeTrailingZeros }}</div>
            </template>
          </el-table-column>
          <el-table-column v-if="showUnrestrictedInv" prop="bp1UnrestrictedAmount" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp1UnrestrictedAmount')">
                <span>锁单</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp1UnrestrictedAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp1UnrestrictedAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="showQualityInv" prop="bp1QualityAmount" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp1QualityAmount')">
                <span>质检</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp1QualityAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp1QualityAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="showFrozenInv" prop="bp1FrozenAmount" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp1FrozenAmount')">
                <span>冻结</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp1FrozenAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp1FrozenAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
        </el-table-column>
        <el-table-column prop="bp2AvailableAmount" label="二厂" header-align="center" align="center">
          <template #header>
            <div>二厂: {{ bp2AvailableAmount.toFixed(3) }}(吨)</div>
          </template>
          <el-table-column prop="bp2Price" header-align="center" align="center" width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp2Price')">
                <span>价格</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp2Price' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp2Price' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
            <template slot-scope="scope">
              <span class="pop_text can_click"
                :class="scope.row.pb2PriceUpd == 1 && scope.row.bp2Price !== '-' ? 'green-text' : ''" v-popover:pricePop
                @click="(e) => { showPop(e, 'pricePop', scope.row, undefined, scope.row.bp2Factory, scope.row.bp2Price) }">
                {{ scope.row.bp2Price | moneyFormat }}
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="bp2AdjustRange" label="调幅" header-align="center" align="center" width="94px">
            <template slot-scope="scope">
              <div class="adjustRange_class">
                <span class="red" v-if="scope.row.bp2AdjustRange > 0">↑</span>
                <span class="green" v-if="scope.row.bp2AdjustRange < 0">↓</span>
                {{ scope.row.bp2AdjustRange | moneyFormat }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="bp2AvailableAmount" header-align="center" align="center" width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp2AvailableAmount')">
                <span>可售</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp2AvailableAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp2AvailableAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
            <template slot-scope="scope">
              <div :class="{
                can_click: scope.row.bp2AvailableAmount !== '-', green_text: scope.row.bp2InvUpd == 1
                  && scope.row.bp2AvailableAmount !== '-'
              }" v-popover:stockPop @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, '1002') }">{{
                scope.row.bp2AvailableAmount |
                removeTrailingZeros }}</div>
            </template>
          </el-table-column>
          <el-table-column v-if="showUnrestrictedInv" prop="bp2UnrestrictedAmount" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp2UnrestrictedAmount')">
                <span>锁单</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp2UnrestrictedAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp2UnrestrictedAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="showQualityInv" prop="bp2QualityAmount" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp2QualityAmount')">
                <span>质检</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp2QualityAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp2QualityAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="showFrozenInv" prop="bp2FrozenAmount" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('bp2FrozenAmount')">
                <span>冻结</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'bp2FrozenAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'bp2FrozenAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
        </el-table-column>
        <el-table-column prop="cyAvailableAmount" label="朝阳" header-align="center" align="center">
          <template #header>
            <div>朝阳: {{ cyAvailableAmount.toFixed(3) }}(吨)</div>
          </template>
          <el-table-column prop="cyPrice" header-align="center" align="center" width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('cyPrice')">
                <span>价格</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'cyPrice' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'cyPrice' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
            <template slot-scope="scope">
              <span class="pop_text can_click"
                :class="scope.row.cyPriceUpd == 1 && scope.row.cyPrice !== '-' ? 'green-text' : ''" v-popover:pricePop
                @click="(e) => { showPop(e, 'pricePop', scope.row, undefined, scope.row.cyFactory, scope.row.cyPrice) }">
                {{ scope.row.cyPrice | moneyFormat }}
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="cyAdjustRange" label="调幅" header-align="center" align="center" width="94px">
            <template slot-scope="scope">
              <div class="adjustRange_class">
                <span class="red" v-if="scope.row.cyAdjustRange > 0">↑</span>
                <span class="green" v-if="scope.row.cyAdjustRange < 0">↓</span>
                {{ scope.row.cyAdjustRange | moneyFormat }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="cyAvailableAmount" header-align="center" align="center" width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('cyAvailableAmount')">
                <span>可售</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'cyAvailableAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'cyAvailableAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
            <template slot-scope="scope">
              <div :class="{
                can_click: scope.row.cyAvailableAmount !== '-', green_text: scope.row.cyInvUpd == 1
                  && scope.row.cyAvailableAmount !== '-'
              }" v-popover:stockPop @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, '1011') }">{{
                scope.row.cyAvailableAmount |
                removeTrailingZeros }}</div>
            </template>
          </el-table-column>
          <el-table-column v-if="showUnrestrictedInv" prop="cyUnrestrictedAmount" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('cyUnrestrictedAmount')">
                <span>锁单</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'cyUnrestrictedAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'cyUnrestrictedAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="showQualityInv" prop="cyQualityAmount" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('cyQualityAmount')">
                <span>质检</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'cyQualityAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'cyQualityAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="showFrozenInv" prop="cyFrozenAmount" header-align="center" align="center" width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('cyFrozenAmount')">
                <span>冻结</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'cyFrozenAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'cyFrozenAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
        </el-table-column>
        <el-table-column prop="kzAvailableAmount" label="喀左" header-align="center" align="center">
          <template #header>
            <div>喀左: {{ kzAvailableAmount.toFixed(3) }}(吨)</div>
          </template>
          <el-table-column prop="kzPrice" header-align="center" align="center" width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('kzPrice')">
                <span>价格</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'kzPrice' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'kzPrice' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
            <template slot-scope="scope">
              <span class="pop_text can_click"
                :class="scope.row.kzPriceUpd == 1 && scope.row.kzPrice !== '-' ? 'green-text' : ''" v-popover:pricePop
                @click="(e) => { showPop(e, 'pricePop', scope.row, undefined, scope.row.kzFactory, scope.row.kzPrice) }">
                {{ scope.row.kzPrice | moneyFormat }}
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="kzAdjustRange" label="调幅" header-align="center" align="center" width="94px">
            <template slot-scope="scope">
              <div class="adjustRange_class">
                <span class="red" v-if="scope.row.kzAdjustRange > 0">↑</span>
                <span class="green" v-if="scope.row.kzAdjustRange < 0">↓</span>
                {{ scope.row.kzAdjustRange | moneyFormat }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="kzAvailableAmount" header-align="center" align="center" width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('kzAvailableAmount')">
                <span>可售</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'kzAvailableAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'kzAvailableAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
            <template slot-scope="scope">
              <div :class="{
                can_click: scope.row.kzAvailableAmount !== '-', green_text: scope.row.kzInvUpd == 1
                  && scope.row.kzAvailableAmount !== '-'
              }" v-popover:stockPop @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, '1021') }">{{
                scope.row.kzAvailableAmount |
                removeTrailingZeros }}</div>
            </template>
          </el-table-column>
          <el-table-column v-if="showUnrestrictedInv" prop="kzUnrestrictedAmount" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('kzUnrestrictedAmount')">
                <span>锁单</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'kzUnrestrictedAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'kzUnrestrictedAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="showQualityInv" prop="kzQualityAmount" label="质检" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('kzQualityAmount')">
                <span>质检</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'kzQualityAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'kzQualityAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column v-if="showFrozenInv" prop="kzFrozenAmount" label="冻结" header-align="center" align="center"
            width="94px">
            <template #header>
              <div class="custom-header" @click="handleCustomSort('kzFrozenAmount')">
                <span>质检</span>
                <div class="sort-icons">
                  <i class="el-icon-caret-top"
                    :class="{ active: sortConfig.field === 'kzFrozenAmount' && sortConfig.order === 'asc' }"></i>
                  <i class="el-icon-caret-bottom"
                    :class="{ active: sortConfig.field === 'kzFrozenAmount' && sortConfig.order === 'desc' }"></i>
                </div>
              </div>
            </template>
          </el-table-column>
        </el-table-column>

      </el-table>
      <!-- </virtual-scroll> -->
    </div>

  </div>
</template>

<script>
import { getPriceChart, getStockChart, listData } from '@/api/Board/PriceBoard';
import debounce from '@/utils/debounce.js';
import * as XLSX from 'xlsx-js-style';
import ListMenu from '../components/ListMenu';
import PriceChart from '../components/PriceChart';
import Stock from '../components/Stock';
import VirtualScroll from 'el-table-virtual-scroll'

export default {
  components: { VirtualScroll, Stock, ListMenu, PriceChart },
  props: {
    queryParams: {
      type: Object,
      default: () => {
        return {
          productId: '',
          productType: '',
          priceType: '',
          priceDate: '',
        };
      },
    },
    activeTabName: {
      type: String,
      default: () => {
        return '0';
      },
    },
  },

  data() {
    return {
      virtualData: [],
      spanInfo: {},
      activeRow: {},
      chartLoading: false,
      priceVisible: false,
      stockVisible: false,
      loading: true,
      stockDateOption: 'seven_day',
      priceDateOption: 'seven_day',
      dateOptions: [
        {
          value: 'seven_day',
          label: '7天',
        },
        {
          value: 'fifteen_day',
          label: '15天',
        },
        {
          value: 'thirty_day',
          label: '30天',
        },
      ],
      tableData: [],
      tableData1: [],
      tableData2: [],
      tableHeight: 0,
      stockData: {
        days: [],
        inventories: [],
        lowerLimit: null,
        upperLimit: null,
      },
      priceData: {
        days: [],
        outBounds: [],
        prices: [],
      },
      menuData: [],
      typeData: [],
      calcListData: [],
      calcListData2: [],
      showProductCode: false,
      showUnrestrictedInv: false,
      showQualityInv: false,
      showFrozenInv: false,
      closePopoverOutsideNums: 0,
      displayTotalAmount: 0,
      bp1AvailableAmount: 0,
      bp2AvailableAmount: 0,
      cyAvailableAmount: 0,
      kzAvailableAmount: 0,
      sortProp: { prop: 'productName', order: 'ascending' },
      checkRepeatObj: {},
      // 自定义排序配置
      sortConfig: {
        field: null,    // 当前排序字段
        order: null,    // 当前排序方向：'asc' | 'desc' | null
      },
      currentSortField: 'productName',
      currentSort: 'ASC',
      tableKey: 0,
      // 分页相关
      pageNo: 1,
      pageSize: 200,
      allData: [], // 存储所有加载的数据
      isLoadingMore: false,
      hasMoreData: true,
      loadingTimer: null,
      currentLoadingPage: 1, // 当前正在加载的页数
    };
  },

  computed: {
    handleClick(tab, event) {
      // console.log(tab, event);
    },
  },
  watch: {
    activeTabName(val) {
      this.calTableHeight();
    },
  },
  created() {
    this.calTableHeight();
    // 移除初始排序设置，使用前端排序
    this.getList();
    window.addEventListener('resize', this.calTableHeight);
  },

  mounted() {
    this.calcCatData();
  },

  beforeDestroy() {
    this.closePopoverOutsideNums = 0;
    document.removeEventListener('click', this.closePopoverOutside);
    window.removeEventListener('resize', this.calTableHeight);
    // 清理加载定时器
    if (this.loadingTimer) {
      clearTimeout(this.loadingTimer);
    }
  },

  methods: {

    getRowKey(row) {
      /** 检查row.id是否有重复的缓存对象 */
      if (!this.checkRepeatObj) {
        this.checkRepeatObj = {};
      }
      if (row) {
        if (row.id) {
          if (this.checkRepeatObj[row._id]) {
            if (!row._secondId) {
              row._secondId = Math.random() + row._id;
            }
            /** 方便根据key重用元素 */
            return row._secondId;
          } else {
            this.checkRepeatObj[row._id] = 1;
            return row._id + Math.random();
          }
        }
        // console.log('row.id为空')
        if (!row._secondId) {
          row._secondId = Math.random() + row._id;
        }
        return row._secondId;
      } else {
        // console.log('row为空')
        return Math.random() + row._id;
      }
    },
    calTableHeight() {
      const viewportHeight =
        window.innerHeight ||
        document.documentElement.clientHeight ||
        document.body.clientHeight;
      this.tableHeight =
        this.activeTabName == '1'
          ? viewportHeight - 50 - 20 - 41 - 55 - 20 - 10 - 36 - 63 - 18
          : viewportHeight - 50 - 20 - 41 - 55 - 20 - 10 - 36 - 10; // 36是tag 63是搜索区域
      this.$nextTick(() => {
        this.$refs?.hookTable1.doLayout();
      });
    },

    exportExcel(type) {
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.table_to_sheet(this.$refs.hookTable1.$el);
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      const wsheet1 = wb.Sheets["Sheet1"];
      // 设置特定列为文本格式
      const textColumns = { 'B': '品项编码' };

      Object.keys(textColumns).forEach(col => {
        for (let i = 2; i <= 10000000; i++) { // 数据行从第2行开始
          const cellAddress = col + i;
          if (wsheet1[cellAddress]) {
            // alert("wsheet1[cellAddress]="+wsheet1[cellAddress].toString());
            // 方法1：设置单元格类型为字符串
            wsheet1[cellAddress].t = 's';
            // 方法2：设置数字格式为文本（可选）
            wsheet1[cellAddress].z = '@';
          }
        }
      });
      XLSX.writeFile(wb, '价格库存看板.xlsx');
    },

    closePopoverOutside(event) {
      this.$nextTick(() => {
        if (
          this.$refs.pricePop &&
          !this.$refs.pricePop.$el.contains(event.target) &&
          this.priceVisible
        ) {
          this.priceVisible = false;
          document.removeEventListener('click', this.closePopoverOutside);
        }

        if (
          this.$refs.stockPop &&
          !this.$refs.stockPop.$el.contains(event.target) &&
          this.stockVisible
        ) {
          this.stockVisible = false;
          document.removeEventListener('click', this.closePopoverOutside);
        }
      });
    },

    handleChangeProductCode() {
      this.showProductCode = !this.showProductCode;
      this.$nextTick(() => {
        this.$refs.hookTable1.doLayout();
      });
    },
    handleChangeUnrestrictedInv() {
      this.showUnrestrictedInv = !this.showUnrestrictedInv;
    },
    handleChangeQualityInv() {
      this.showQualityInv = !this.showQualityInv;
    },
    handleChangeFrozenInv() {
      this.showFrozenInv = !this.showFrozenInv;
    },


    // 鼠标移入显示
    showPop(e, popRef, row, flag, factoryCode, displayPrice) {
      if (popRef === 'pricePop' && row.price === '-') return;
      if (popRef === 'stockPop') {
        if (row.totalAmount === '-' || row.totalAmount === null) {
          return;
        }
        if (
          (factoryCode === '' || factoryCode === '1001') &&
          (row.bp1AvailableAmount === '-' || row.bp1AvailableAmount === null)
        )
          return;
        if (factoryCode === '1002' && row.bp2AvailableAmount === '-') return;
        if (factoryCode === '1011' && row.cyAvailableAmount === '-') return;
        if (factoryCode === '1021' && row.kzAvailableAmount === '-') return;
      }
      debounce(() => {
        this.showPopAfter(e, popRef, row, flag, factoryCode);
      }, 300);
    },

    showPopAfter(e, popRef, row, flag, factoryCode) {
      document.removeEventListener('click', this.closePopoverOutside);
      if (flag === undefined) {
        delete row._isTable2;
      } else {
        row._isTable2 = true;
      }
      row._factoryCode = factoryCode;
      this.activeRow = row;
      // console.log("this.activeRow======", this.activeRow);
      switch (popRef) {
        case 'pricePop':
          this.stockVisible = false;
          if (this.priceVisible) {
            this.priceVisible = false;
          } else {
            this.$refs[popRef].doDestroy(true);
            this.$nextTick(() => {
              this.$refs[popRef].referenceElm = e.target;
              this.priceVisible = true;
              setTimeout(() => {
                document.addEventListener('click', this.closePopoverOutside);
              }, 300);
            });
          }

          break;

        case 'stockPop':
          this.priceVisible = false;
          if (this.stockVisible) {
            this.stockVisible = false;
          } else {
            this.$refs[popRef].doDestroy(true);
            this.$nextTick(() => {
              this.$refs[popRef].referenceElm = e.target;
              this.stockVisible = true;
              setTimeout(() => {
                document.addEventListener('click', this.closePopoverOutside);
              }, 300);
            });
          }
          break;
        default:
          break;
      }
    },

    // 鼠标移出隐藏
    hiddenPop(e, popRef) {
      this.activeRow = {};
      this.stockVisible = false;
      this.priceVisible = false;
    },

    async getStockChart(productId, factoryCode, idx) {
      this.chartLoading = true;
      const { fromDate, toDate } = this.calLatelyDate(this.stockDateOption);

      let data = {
        dateSpan: this.stockDateOption,
        priceType: this.queryParams.priceType,
        //inventoryRemark: this.activeRow._isTable2 ? this.activeRow._rightData.inventoryRemark : this.activeRow.inventoryRemark,
        productCode: this.activeRow.productCode,
        productId,
        factoryCode,
        fromDate,
        toDate,
      };

      const res = await getStockChart(data);
      this.stockData = res.data;
      this.chartLoading = false;
    },

    async getPriceChart(productId, factoryCode, idx) {
      this.chartLoading = true;
      const { fromDate, toDate } = this.calLatelyDate(this.priceDateOption);
      let data = {
        dateSpan: this.priceDateOption,
        priceType: this.queryParams.priceType,
        //inventoryRemark: this.activeRow._isTable2? this.activeRow._rightData.inventoryRemark : this.activeRow.inventoryRemark,
        productCode: this.activeRow.productCode,
        productId,
        factoryCode,
        fromDate,
        toDate,
      };
      const res = await getPriceChart(data);
      this.priceData = res.data;
      this.chartLoading = false;
    },

    calLatelyDate(type) {
      let today = this.$dayjs();

      switch (type) {
        case 'seven_day':
          let sevenDaysAgo = today.subtract(6, 'day'); // 因为包含今天，所以是减去6天
          let sevenDaysStart = sevenDaysAgo.startOf('day').format('YYYY-MM-DD');
          let sevenDaysEnd = today.endOf('day').format('YYYY-MM-DD');

          return {
            fromDate: sevenDaysStart,
            toDate: sevenDaysEnd,
          };

        case 'fifteen_day':
          let fifteenDaysAgo = today.subtract(14, 'day');
          let fifteenDaysStart = fifteenDaysAgo
            .startOf('day')
            .format('YYYY-MM-DD');
          let fifteenDaysEnd = today.endOf('day').format('YYYY-MM-DD');
          return {
            fromDate: fifteenDaysStart,
            toDate: fifteenDaysEnd,
          };

        case 'thirty_day':
          let thirtyDaysAgo = today.subtract(29, 'day');
          let thirtyDaysStart = thirtyDaysAgo
            .startOf('day')
            .format('YYYY-MM-DD');
          let thirtyDaysEnd = today.endOf('day').format('YYYY-MM-DD');
          return {
            fromDate: thirtyDaysStart,
            toDate: thirtyDaysEnd,
          };
      }
    },

    dateOptionChange(type, productId, factoryCode) {
      switch (type) {
        case 'stock':
          this.getStockChart(productId, factoryCode);
          break;
        case 'price':
          this.getPriceChart(productId, factoryCode);
          break;
        default:
          break;
      }
    },
    // 自定义排序处理
    handleCustomSort(field) {
      // 切换排序状态
      if (this.sortConfig.field === field) {
        // 同一字段：无排序 -> 升序 -> 降序 -> 无排序
        if (this.sortConfig.order === null) {
          this.sortConfig.order = 'asc';
        } else if (this.sortConfig.order === 'asc') {
          this.sortConfig.order = 'desc';
        } else {
          this.sortConfig.order = null;
        }
      } else {
        // 不同字段：直接设为升序
        this.sortConfig.field = field;
        this.sortConfig.order = 'asc';
      }

      // 执行排序
      this.applySorting();
    },

    // 应用排序
    applySorting() {
      if (!this.sortConfig.field || !this.sortConfig.order) {
        // 无排序状态，恢复原始顺序
        this.tableData = [...this.allData];
      } else {
        // 执行排序
        this.tableData = [...this.allData].sort((a, b) => {
          return this.customSortMethod(a, b, this.sortConfig.field, this.sortConfig.order);
        });
      }

      // 重新计算合并信息
      this.calcCatData('sort');

      // 强制表格重新渲染
      this.tableKey++;

      this.$nextTick(() => {
        this.$refs?.hookTable1?.doLayout();
      });
    },

    // 自定义排序方法
    customSortMethod(a, b, field, order) {
      // 首先按 typeSort 分组
      const typeSortA = a.typeSort || 0;
      const typeSortB = b.typeSort || 0;

      if (typeSortA !== typeSortB) {
        return typeSortA - typeSortB;
      }

      // 在同一分组内按指定字段排序
      let result = 0;

      if (field === 'productName') {
        const nameA = (a.productName || '').toString();
        const nameB = (b.productName || '').toString();
        result = nameA.localeCompare(nameB, 'zh-CN', { numeric: true });
      } else if (field === 'totalAmount') {
        const amountA = parseFloat(a.totalAmount) || 0;
        const amountB = parseFloat(b.totalAmount) || 0;
        result = amountA - amountB;
      } else if (field.includes('Price')) {
        // 价格字段
        const priceA = a[field];
        const priceB = b[field];

        // 处理 '-' 值
        if (priceA === '-' && priceB === '-') return 0;
        if (priceA === '-') return order === 'asc' ? -1 : 1;
        if (priceB === '-') return order === 'asc' ? 1 : -1;

        const numA = parseFloat(priceA) || 0;
        const numB = parseFloat(priceB) || 0;
        result = numA - numB;
      } else if (field.includes('Amount')) {
        // 库存数量字段（可售、锁单、质检、冻结）
        const amountA = parseFloat(a[field]) || 0;
        const amountB = parseFloat(b[field]) || 0;
        result = amountA - amountB;
      }

      // 根据排序方向调整结果
      return order === 'desc' ? -result : result;
    },

    // 手动触发加载更多
    loadMore() {
      if (this.hasMoreData && !this.isLoadingMore) {
        this.getList(null, false);
      }
    },

    // 停止加载
    stopLoading() {
      this.hasMoreData = false;
      this.isLoadingMore = false;
      this.loading = false;
    },





    async getList(e, isInitial = true) {
      if (isInitial) {
        // 初始加载，重置所有数据
        this.pageNo = 1;
        this.currentLoadingPage = 1;
        this.allData = [];
        this.hasMoreData = true;
        this.loading = true;
        this.tableData = [];
      }

      if (!this.hasMoreData || this.isLoadingMore) {
        return;
      }

      this.isLoadingMore = true;
      this.currentLoadingPage = this.pageNo;

      try {
        const unrestricted = this.showUnrestrictedInv ? 1 : 0;
        const quality = this.showQualityInv ? 2 : 0;
        const frozen = this.showFrozenInv ? 4 : 0;

        const params = {
          ...this.queryParams,
          showDataType: unrestricted | quality | frozen,
          pageNo: this.pageNo,
          pageSize: this.pageSize
        };

        // 移除排序参数，使用前端排序
        delete params.sortField;
        delete params.sort;

        const res = await listData(params);

        if (res.data && res.data.length > 0) {
          // 处理新数据
          res.data.forEach((item) => {
            item._id = item.productCode + Math.random();
          });

          // 合并到所有数据中
          this.allData = [...this.allData, ...res.data];

          // 立即更新表格显示数据
          this.tableData = [...this.allData];

          // 立即重新计算统计数据并渲染
          this.calcCatData(e);

          // 立即触发表格重新渲染
          this.$nextTick(() => {
            this.$refs?.hookTable1?.doLayout();
          });

          // 检查是否还有更多数据
          if (res.data.length < this.pageSize) {
            this.hasMoreData = false;
          } else {
            this.pageNo++;
            // 继续加载下一页，给用户一些时间看到当前页的渲染效果
            setTimeout(() => {
              this.getList(e, false);
            }, 50); // 增加间隔，让用户看到每页的加载效果
          }
        } else {
          this.displayTotalAmount = 0;
          this.bp1AvailableAmount = 0;
          this.bp2AvailableAmount = 0;
          this.cyAvailableAmount = 0;
          this.kzAvailableAmount = 0;
          this.hasMoreData = false;
        }

      } catch (error) {
        console.error('加载数据失败:', error);
        this.hasMoreData = false;
      } finally {
        this.isLoadingMore = false;

        // 如果是初始加载的第一页，关闭主loading
        if (isInitial) {
          this.loading = false;
        }

        // 如果没有更多数据了，确保所有loading状态都关闭
        if (!this.hasMoreData) {
          this.loading = false;
        }
      }
    },

    // 处理分类相关数据
    calcCatData(e) {
      // 重置所有合并相关的数据
      this.calcListData = [];
      this.calcListData2 = [];
      this.menuData = [];
      this.typeData = [];
      let calcListDataIdx = 0;
      let calcListDataIdx2 = 0;
      this.bp1AvailableAmount = 0;
      this.bp2AvailableAmount = 0;
      this.cyAvailableAmount = 0;
      this.kzAvailableAmount = 0;
      this.displayTotalAmount = 0;
      // ---------- 工具 ----------
      // 安全转数字：遇到空串、字母、null、undefined 一律变 0
      const toNum = v => {
        const n = Number(v);
        return Number.isFinite(n) ? n : 0;
      };

      // 统一求和：把 4 个维度按开关加总
      const sumInv = (row, prefix) => {
        const keys = [
          { key: `${prefix}AvailableAmount`, always: true },
          { key: `${prefix}UnrestrictedAmount`, show: this.showUnrestrictedInv },
          { key: `${prefix}QualityAmount`, show: this.showQualityInv },
          { key: `${prefix}FrozenAmount`, show: this.showFrozenInv }
        ];
        return keys.reduce((sum, { key, always, show }) => {
          if (always || show) return sum + toNum(row[key]);
          return sum;
        }, 0);
      };

      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];
        // 1. 库存汇总
        const bp1 = sumInv(item, 'bp1');
        const bp2 = sumInv(item, 'bp2');
        const cy = sumInv(item, 'cy');
        const kz = sumInv(item, 'kz');

        // console.log('bp1', bp1)
        this.bp1AvailableAmount += bp1;
        this.bp2AvailableAmount += bp2;
        this.cyAvailableAmount += cy;
        this.kzAvailableAmount += kz;

        item.totalAmount = bp1 + bp2 + cy + kz;
        // console.log(this.bp1AvailableAmount*1 , this.bp2AvailableAmount*1 , this.cyAvailableAmount*1 , this.kzAvailableAmount*1)
        this.displayTotalAmount += item.totalAmount;

        if (index === 0) {
          item.domId = item.productTypeName;
          item.domIdx = calcListDataIdx;
          item._domId = item.productTypeName;
          item._productCodeId = item.productCode;
          item._productCodeIdx = calcListDataIdx2;

          this.calcListData.push(1);
          this.calcListData2.push(1);
          this.menuData.push({
            label: item.productTypeName,
            code: calcListDataIdx,
          });
          let isIn = this.typeData.find((typeItem) => typeItem.value === item.productType);
          if (!isIn) {
            this.typeData.push({
              label: item.productTypeName,
              value: item.productType,
            });
          }
        } else {
          if (item.productTypeName !== this.tableData[index - 1].productTypeName) {
            calcListDataIdx++;

            item.domId = item.productTypeName;
            item.domIdx = calcListDataIdx;
            item._domId = item.productTypeName;

            this.calcListData.push(1);
            this.menuData.push({
              label: item.productTypeName,
              code: calcListDataIdx,
            });
            let isIn = this.typeData.find((typeItem) => typeItem.value === item.productType);
            if (!isIn) {
              this.typeData.push({
                label: item.productTypeName,
                value: item.productType,
              });
            }
          } else {
            item.domId = item.productTypeName + index;
            item._domId = item.productTypeName;
            this.calcListData[calcListDataIdx]++;
          }

          if (item.productCode !== this.tableData[index - 1].productCode) {
            calcListDataIdx2++;

            item._productCodeId = item.productCode;
            item._productCodeIdx = calcListDataIdx2;
            this.calcListData2.push(1);
          } else {
            item._productCodeId = item.productCode;
            this.calcListData2[calcListDataIdx2]++;
          }
        }
      }

      if (!e) {
        this.$emit('menuData', this.typeData);
      }
    },

    splitAndAlign(originalArray, categoryField) {
      const categoryCount = {};
      originalArray.forEach((item) => {
        const category = item[categoryField];
        if (categoryCount[category]) {
          categoryCount[category]++;
        } else {
          categoryCount[category] = 1;
        }
      });

      const array1 = [];
      const array2 = [];

      Object.keys(categoryCount).forEach((category) => {
        const count = categoryCount[category];
        const halfCount = Math.ceil(count / 2);

        let countInArray1 = 0;
        let countInArray2 = 0;

        originalArray.forEach((item) => {
          if (item[categoryField] === category) {
            if (countInArray1 < halfCount) {
              array1.push(item);
              countInArray1++;
            } else {
              array2.push(item);
              countInArray2++;
            }
          }
        });

        while (countInArray2 < halfCount) {
          array2.push({
            isPlaceholder: true,
          });
          countInArray2++;
        }
      });

      return [array1, array2];
    },

    formatTableDomIndex(arr) {
      let calcListDataIdx = 0;
      this.calcListData = [];

      for (let index = 0; index < arr.length; index++) {
        const item = arr[index];

        if (index === 0) {
          item.domIdx = calcListDataIdx;
          this.calcListData.push(1);
        } else {
          if (item.productType !== arr[index - 1].productType) {
            calcListDataIdx++;
            item.domIdx = calcListDataIdx;
            this.calcListData.push(1);
          } else {
            item.domId = item.productType + index;
            item._domId = item.productTypeName;
            this.calcListData[calcListDataIdx]++;
          }
        }
      }
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0 || column.property === 'productSpec' || column.property === 'productName' ||
        column.property === '_rightData.productName' || column.property === '_rightData.productSpec') {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;height:40px;';
      }
      if (!column.property.includes('.') && row[column.property] == null) {
        row[column.property] = '-';
      }
    },

    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        // 基于当前表格显示顺序动态计算合并
        return this.calculateSpanForProductType(rowIndex);
      }
      if (column.property === 'productCode' || column.property === 'productName') {
        // 基于当前表格显示顺序动态计算合并
        return this.calculateSpanForProductCode(rowIndex, column.property);
      }
    },

    // 动态计算产品类型的合并
    calculateSpanForProductType(rowIndex) {
      const currentRow = this.tableData[rowIndex];
      if (!currentRow) return { rowspan: 1, colspan: 1 };

      const currentTypeName = currentRow.productTypeName;

      // 检查是否是该类型的第一行
      if (rowIndex > 0 && this.tableData[rowIndex - 1].productTypeName === currentTypeName) {
        return { rowspan: 0, colspan: 0 };
      }

      // 计算该类型有多少连续行
      let spanCount = 1;
      for (let i = rowIndex + 1; i < this.tableData.length; i++) {
        if (this.tableData[i].productTypeName === currentTypeName) {
          spanCount++;
        } else {
          break;
        }
      }

      return { rowspan: spanCount, colspan: 1 };
    },

    // 动态计算产品代码的合并
    calculateSpanForProductCode(rowIndex, property) {
      const currentRow = this.tableData[rowIndex];
      if (!currentRow) return { rowspan: 1, colspan: 1 };

      const currentCode = currentRow.productCode;

      // 检查是否是该产品代码的第一行
      if (rowIndex > 0 && this.tableData[rowIndex - 1].productCode === currentCode) {
        return { rowspan: 0, colspan: 0 };
      }

      // 计算该产品代码有多少连续行
      let spanCount = 1;
      for (let i = rowIndex + 1; i < this.tableData.length; i++) {
        if (this.tableData[i].productCode === currentCode) {
          spanCount++;
        } else {
          break;
        }
      }

      return { rowspan: spanCount, colspan: 1 };
    },
  },
};
</script>

<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}

.cat_text {
  margin: auto;
  width: 14px;
}

.pop_text {
  color: #2d7ae6;
}

.table-placeholder {
  position: relative;
  display: flex;

  &::before {
    position: absolute;
    display: flex;
    justify-content: center;
    align-items: center;
    content: '-';
    width: 100%;
    height: 100%;
  }

  .table-placeholder-inner {
    visibility: hidden;
  }
}

::v-deep .el-table--medium .el-table__cell {
  padding: 1px 0 !important;
}

::v-deep .el-table__cell {
  height: 40px !important;
}

.table1 {
  // position: relative;
  // flex: 0 0 49vw;
  // z-index: 1;

  // ::v-deep th.gutter {
  //   display: none;
  //   width: 0 !important;
  // }
}

.table2 {
  flex: 0 0 49vw;
  margin-left: -62px;
  border-left: none;
}

.green-text,
.green_text {
  color: #6ac768 !important;
}

// 自定义排序样式
.custom-header {
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  user-select: none;

  &:hover {
    color: #409EFF;
  }

  .sort-icons {
    display: flex;
    flex-direction: column;
    margin-left: 4px;

    i {
      font-size: 12px;
      color: #c0c4cc;
      line-height: 1;

      &.active {
        color: #409EFF;
      }

      &:first-child {
        margin-bottom: -2px;
      }
    }
  }
}

// 加载状态样式
.loading-status {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  margin: 10px 0;
  background: linear-gradient(90deg, #f0f9ff 0%, #e6f7ff 100%);
  border: 1px solid #b3d8ff;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: linear-gradient(90deg, #e6f7ff 0%, #d1f2ff 100%);
    border-color: #91d5ff;
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(24, 144, 255, 0.15);
  }

  .loading-content {
    display: flex;
    align-items: center;
    color: #1890ff;
    font-size: 14px;
    font-weight: 500;

    i {
      margin-right: 8px;
      font-size: 16px;
      animation: rotate 1s linear infinite;
    }
  }

  .loading-action {
    .el-button {
      border-radius: 4px;
    }
  }
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
}

.loading-more {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  color: #409EFF;
  font-size: 14px;
  background-color: #f0f9ff;
  border: 1px solid #b3d8ff;
  border-radius: 4px;
  margin: 10px 0;

  .loading-content {
    display: flex;
    align-items: center;

    i {
      margin-right: 8px;
      font-size: 16px;
    }
  }
}

.load-complete {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 15px;
  color: #909399;
  font-size: 12px;
  background-color: #f5f7fa;
  border-top: 1px solid #e4e7ed;
}
</style>
