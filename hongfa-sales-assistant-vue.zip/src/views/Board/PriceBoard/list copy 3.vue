<template>
  <div>

    <vxe-table ref="tableRef" height="600" border :virtual-y-config="{ enabled: true, gt: 0 }"
      :virtual-x-config="{ enabled: true, gt: 0 }" align="center">
      <vxe-column field="productTypeName" title="类名" width="40" fixed="left">
        <template slot-scope="scope">
          <div>
            {{ scope.row.productTypeName || '-' }}
          </div>
        </template>
      </vxe-column>

      <vxe-column field="productCode" title="品项编码" width="140" fixed="left"></vxe-column>

      <vxe-column field="productName" width="320px" fixed="left">
        <template #header>
          <div class="custom-header">
            <span>品项</span>
          </div>
        </template>
      </vxe-column>

      <vxe-column field="totalAmount" width="180px">
        <template #header>
          <div class="custom-header">
            <div style="display: inline-block; vertical-align: middle;">
              <div>库存合计: </div>
              <div>{{ displayTotalAmount.toFixed(3) }}(吨)</div>
            </div>
          </div>
        </template>
        <template slot-scope="scope">
          <div :class="scope.row.totalAmount !== '-' ? 'pop_text can_click' : ''"
            :style="{ color: scope.row.bp1FactoryInvIsUpdate == 1 ? '#6ac768' : '#000000' }" v-popover:stockPop
            @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, 'ALL', scope.row.totalAmount) }">{{
              scope.row.totalAmount | removeTrailingZeros }}
          </div>
        </template>
      </vxe-column>


      <vxe-colgroup title="一厂">
        <template #header>
          <div>一厂: {{ bp1AvailableAmount.toFixed(3) }}(吨)</div>
        </template>
        <vxe-column field="bp1Price" width="94px">
          <template #header>
            <div class="custom-header">
              <span>价格</span>

            </div>
          </template>
          <template slot-scope="scope">
            <span class="pop_text can_click"
              :class="scope.row.pb1PriceUpd == 1 && scope.row.bp1Price !== '-' ? 'green-text' : ''" v-popover:pricePop
              @click="(e) => { showPop(e, 'pricePop', scope.row, undefined, scope.row.bp1Factory, scope.row.bp1Price) }">
              {{ scope.row.bp1Price | moneyFormat }}
            </span>
          </template>
        </vxe-column>
        <vxe-column field="bp1AdjustRange" title="调幅" width="94px">
          <template slot-scope="scope">
            <div class="adjustRange_class">
              <span class="red" v-if="scope.row.bp1AdjustRange > 0">↑</span>
              <span class="green" v-if="scope.row.bp1AdjustRange < 0">↓</span>
              {{ scope.row.bp1AdjustRange | moneyFormat }}
            </div>
          </template>
        </vxe-column>
        <vxe-column field="bp1AvailableAmount" title="可售" width="94px">
          <template #header>
            <div class="custom-header">
              <span>可售</span>

            </div>
          </template>
          <template slot-scope="scope">
            <div :class="{
              can_click: scope.row.bp1AvailableAmount !== '-', green_text: scope.row.bp1InvUpd == 1
                && scope.row.bp1AvailableAmount !== '-'
            }" v-popover:stockPop @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, '1001') }">{{
              scope.row.bp1AvailableAmount |
              removeTrailingZeros }}</div>
          </template>
        </vxe-column>
        <vxe-column field="bp1UnrestrictedAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>锁单</span>

            </div>
          </template>
        </vxe-column>
        <vxe-column v-if="showQualityInv" field="bp1QualityAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>质检</span>

            </div>
          </template>
        </vxe-column>
        <vxe-column v-if="showFrozenInv" field="bp1FrozenAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>冻结</span>

            </div>
          </template>
        </vxe-column>
      </vxe-colgroup>
      <vxe-colgroup title="二厂">
        <template #header>
          <div>二厂: {{ bp2AvailableAmount.toFixed(3) }}(吨)</div>
        </template>
        <vxe-column field="bp2Price" width="94px">
          <template #header>
            <div class="custom-header">
              <span>价格</span>

            </div>
          </template>
          <template slot-scope="scope">
            <span class="pop_text can_click"
              :class="scope.row.pb2PriceUpd == 1 && scope.row.bp2Price !== '-' ? 'green-text' : ''" v-popover:pricePop
              @click="(e) => { showPop(e, 'pricePop', scope.row, undefined, scope.row.bp2Factory, scope.row.bp2Price) }">
              {{ scope.row.bp2Price | moneyFormat }}
            </span>
          </template>
        </vxe-column>
        <vxe-column field="bp2AdjustRange" title="调幅" width="94px">
          <template slot-scope="scope">
            <div class="adjustRange_class">
              <span class="red" v-if="scope.row.bp2AdjustRange > 0">↑</span>
              <span class="green" v-if="scope.row.bp2AdjustRange < 0">↓</span>
              {{ scope.row.bp2AdjustRange | moneyFormat }}
            </div>
          </template>
        </vxe-column>
        <vxe-column field="bp2AvailableAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>可售</span>

            </div>
          </template>
          <template slot-scope="scope">
            <div :class="{
              can_click: scope.row.bp2AvailableAmount !== '-', green_text: scope.row.bp2InvUpd == 1
                && scope.row.bp2AvailableAmount !== '-'
            }" v-popover:stockPop @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, '1002') }">{{
              scope.row.bp2AvailableAmount |
              removeTrailingZeros }}</div>
          </template>
        </vxe-column>
        <vxe-column v-if="showUnrestrictedInv" field="bp2UnrestrictedAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>锁单</span>

            </div>
          </template>
        </vxe-column>
        <vxe-column v-if="showQualityInv" field="bp2QualityAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>质检</span>

            </div>
          </template>
        </vxe-column>
        <vxe-column v-if="showFrozenInv" field="bp2FrozenAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>冻结</span>

            </div>
          </template>
        </vxe-column>
      </vxe-colgroup>
      <vxe-colgroup title="朝阳">
        <template #header>
          <div>朝阳: {{ cyAvailableAmount.toFixed(3) }}(吨)</div>
        </template>
        <vxe-column field="cyPrice" width="94px">
          <template #header>
            <div class="custom-header">
              <span>价格</span>

            </div>
          </template>
          <template slot-scope="scope">
            <span class="pop_text can_click"
              :class="scope.row.cyPriceUpd == 1 && scope.row.cyPrice !== '-' ? 'green-text' : ''" v-popover:pricePop
              @click="(e) => { showPop(e, 'pricePop', scope.row, undefined, scope.row.cyFactory, scope.row.cyPrice) }">
              {{ scope.row.cyPrice | moneyFormat }}
            </span>
          </template>
        </vxe-column>
        <vxe-column field="cyAdjustRange" title="调幅" width="94px">
          <template slot-scope="scope">
            <div class="adjustRange_class">
              <span class="red" v-if="scope.row.cyAdjustRange > 0">↑</span>
              <span class="green" v-if="scope.row.cyAdjustRange < 0">↓</span>
              {{ scope.row.cyAdjustRange | moneyFormat }}
            </div>
          </template>
        </vxe-column>
        <vxe-column field="cyAvailableAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>可售</span>

            </div>
          </template>
          <template slot-scope="scope">
            <div :class="{
              can_click: scope.row.cyAvailableAmount !== '-', green_text: scope.row.cyInvUpd == 1
                && scope.row.cyAvailableAmount !== '-'
            }" v-popover:stockPop @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, '1011') }">{{
              scope.row.cyAvailableAmount |
              removeTrailingZeros }}</div>
          </template>
        </vxe-column>
        <vxe-column v-if="showUnrestrictedInv" field="cyUnrestrictedAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>锁单</span>

            </div>
          </template>
        </vxe-column>
        <vxe-column v-if="showQualityInv" field="cyQualityAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>质检</span>

            </div>
          </template>
        </vxe-column>
        <vxe-column v-if="showFrozenInv" field="cyFrozenAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>冻结</span>

            </div>
          </template>
        </vxe-column>
      </vxe-colgroup>
      <vxe-colgroup title="喀左">
        <template #header>
          <div>喀左: {{ kzAvailableAmount.toFixed(3) }}(吨)</div>
        </template>
        <vxe-column field="kzPrice" width="94px">
          <template #header>
            <div class="custom-header">
              <span>价格</span>

            </div>
          </template>
          <template slot-scope="scope">
            <span class="pop_text can_click"
              :class="scope.row.kzPriceUpd == 1 && scope.row.kzPrice !== '-' ? 'green-text' : ''" v-popover:pricePop
              @click="(e) => { showPop(e, 'pricePop', scope.row, undefined, scope.row.kzFactory, scope.row.kzPrice) }">
              {{ scope.row.kzPrice | moneyFormat }}
            </span>
          </template>
        </vxe-column>
        <vxe-column field="kzAdjustRange" title="调幅" width="94px">
          <template slot-scope="scope">
            <div class="adjustRange_class">
              <span class="red" v-if="scope.row.kzAdjustRange > 0">↑</span>
              <span class="green" v-if="scope.row.kzAdjustRange < 0">↓</span>
              {{ scope.row.kzAdjustRange | moneyFormat }}
            </div>
          </template>
        </vxe-column>
        <vxe-column field="kzAvailableAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>可售</span>

            </div>
          </template>
          <template slot-scope="scope">
            <div :class="{
              can_click: scope.row.kzAvailableAmount !== '-', green_text: scope.row.kzInvUpd == 1
                && scope.row.kzAvailableAmount !== '-'
            }" v-popover:stockPop @click="(e) => { showPop(e, 'stockPop', scope.row, undefined, '1021') }">{{
              scope.row.kzAvailableAmount |
              removeTrailingZeros }}</div>
          </template>
        </vxe-column>
        <vxe-column v-if="showUnrestrictedInv" field="kzUnrestrictedAmount" width="94px">
          <template #header>
            <div class="custom-header">
              <span>锁单</span>

            </div>
          </template>
        </vxe-column>
        <vxe-column v-if="showQualityInv" field="kzQualityAmount" title="质检" width="94px">
          <template #header>
            <div class="custom-header">
              <span>质检</span>

            </div>
          </template>
        </vxe-column>
        <vxe-column v-if="showFrozenInv" field="kzFrozenAmount" title="冻结" width="94px">
          <template #header>
            <div class="custom-header">
              <span>质检</span>

            </div>
          </template>
        </vxe-column>
      </vxe-colgroup>

    </vxe-table>
  </div>
</template>

<script>
import { getPriceChart, getStockChart, listData } from '@/api/Board/PriceBoard';
export default {
  props: {
    queryParams: {
      type: Object,
      default: () => {
        return {
          productId: '',
          productType: '',
          priceType: '',
          priceDate: '',
        };
      },
    },
    activeTabName: {
      type: String,
      default: () => {
        return '0';
      },
    },
  },
  data() {
    return {
      loading: false,
      activeRow: {},
      chartLoading: false,
      priceVisible: false,
      stockVisible: false,
      loading: true,
      stockDateOption: 'seven_day',
      priceDateOption: 'seven_day',
      dateOptions: [
        { value: 'seven_day', label: '7天', },
        { value: 'fifteen_day', label: '15天', },
        { value: 'thirty_day', label: '30天', },
      ],
      tableData: [],
      tableHeight: 0,
      stockData: {
        days: [],
        inventories: [],
        lowerLimit: null,
        upperLimit: null,
      },
      priceData: {
        days: [],
        outBounds: [],
        prices: [],
      },
      menuData: [],
      typeData: [],
      calcListData: [],
      calcListData2: [],
      showProductCode: false,
      showUnrestrictedInv: false,
      showQualityInv: false,
      showFrozenInv: false,
      closePopoverOutsideNums: 0,
      displayTotalAmount: 0,
      bp1AvailableAmount: 0,
      bp2AvailableAmount: 0,
      cyAvailableAmount: 0,
      kzAvailableAmount: 0,
      pageNo: 1,
      pageSize: 500,
    };
  },
  methods: {
    // 模拟行数据
    async loadList(rowSize) {
      const $table = this.$refs.tableRef;
      this.loading = true;
      // setTimeout(() => {
      const dataList = [];
      let res = await listData({ priceDate: '2025-09-27', priceType: 'market_price_type', isShowZero: 1, showDataType: 0, pageNo: 1, pageSize: 500 })
      this.loading = false;
      if ($table) {
        const startTime = Date.now();
        $table.reloadData(res.data).then(() => {
          console.log(`加载时间 ${Date.now() - startTime} 毫秒`)
        });
      }
      // }, 50);
    }
  },
  mounted() {
    this.loadList(50);
  }
};
</script>
