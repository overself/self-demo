<!-- 测试页面 -->
<template>
  <div class="">
    测试页面

    <el-table
      :data="tableData"
      :span-method="objectSpanMethod"
      border
      style="width: 100%; margin-top: 20px"
    >
      <!-- <el-table-column prop="id" label="ID" width="180"> </el-table-column> -->
      <el-table-column
        prop="catName"
        label="类名"
      >
        <template slot-scope="scope">
          <div :ref="scope.$index">
            {{ scope.row.catName }}{{ scope.$index }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="name"
        label="品名"
      > </el-table-column>
      <el-table-column
        prop="amount1"
        label="件（KG）"
      > </el-table-column>
      <el-table-column
        prop="amount2"
        label="库存（吨）"
      > </el-table-column>
      <el-table-column
        prop="amount3"
        label="库存备注（元）"
      > </el-table-column>
      <el-table-column
        prop="amount4"
        label="归属工厂/库存（吨）"
      > </el-table-column>
      <el-table-column
        prop="amount5"
        label="归属工厂/库存（吨）"
      > </el-table-column>
      <el-table-column
        prop="amount6"
        label="归属工厂/库存（吨）"
      > </el-table-column>
      <el-table-column
        prop="amount7"
        label="归属工厂/库存（吨）"
      > </el-table-column>
      <el-table-column
        prop="amount8"
        label="详细规格"
      > </el-table-column>
      <el-table-column
        prop="amount9"
        label="价格（￥）"
      > </el-table-column>
      <el-table-column
        prop="amount10"
        label="调幅（￥）"
      > </el-table-column>
      <el-table-column
        prop="amount11"
        label="价格备注"
      > </el-table-column>
    </el-table>
    <el-button @click="toTop">回滚</el-button>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';

export default {
  // import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    // 这里存放数据
    return {
      tableData: [
        {
          id: '12987122',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '129871221',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '129871222',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '1298712213',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '1298712214',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '1298712215',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '1298712216',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '1298712217',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '1298712218',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '1298712219',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '12987122110',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '12987122110',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '12987122110',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '12987122110',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '12987122110',
          catName: '整鸡类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '12987122110',
          catName: '腿类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
        {
          id: '12987122110',
          catName: '腿类',
          name: '白条（14-22）',
          amount1: 20,
          amount2: 31.2,
          amount3: '库存备注',
          amount4: '一厂/18',
          amount5: '二厂/11',
          amount6: '朝阳/16',
          amount7: '喀左/16',
          amount8: '20kg/袋',
          amount9: '12.80',
          amount10: '0.6',
          amount11: '价格备注',
        },
      ],
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    toTop() {
      console.log(this.$refs);
      this.$scrollTo(this.$refs[0]);
    },
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      if (rowIndex % 2 === 0) {
        if (columnIndex === 0) {
          return [1, 2];
        } else if (columnIndex === 1) {
          return [0, 0];
        }
      }
    },

    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex % 2 === 0) {
          return {
            rowspan: 2,
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
// @import url(); 引入公共css类
</style>
