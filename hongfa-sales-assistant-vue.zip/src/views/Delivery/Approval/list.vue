<!-- 批价订单 -->
<template>
  <div class="">
    <el-table
      :data="tableData"
      border
      style="width: 100%;"
      :cell-style="addClass"
      v-loading="loading"
    >
      <el-table-column
        prop="orderNo"
        label="单据编号"
        header-align="center"
        align="center"
      >
      <template slot-scope="scope">
          <router-link
            class="link"
            :to="{ path: `/sales-delivery/info/${scope.row.id}`, }"
          >{{scope.row.orderNo}}</router-link>
        </template>
      </el-table-column>
      <el-table-column
        prop="orderDate"
        label="日期"
        header-align="center"
      > </el-table-column>

      <el-table-column
        prop="customerName"
        label="客户"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <router-link
            class="link"
            :to="{ path: `/client-control/info/${scope.row.customerId}`, }"
          >{{scope.row.customerName}}</router-link>
        </template>
      </el-table-column>

      <el-table-column
        prop="productName"
        label="品项"
        header-align="center"
        align="center"
        width="230"
      ></el-table-column>

      <el-table-column
        prop="productSpec"
        label="规格"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="priceMarket"
        label="标价"
        header-align="center"
        align="center"
      ></el-table-column>


      <el-table-column
        prop="approvePrice"
        label="差价"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="priceTax"
        label="含税单价(元)"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="allAmount"
        label="销售量(吨)"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="sum"
        label="销售额(元)"
        header-align="center"
        align="center"
      ></el-table-column>


      <el-table-column
        prop="shortFall"
        label="差额(元)"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="salePerson"
        label="归属销售"
        header-align="center"
        align="center"
      > </el-table-column>

      <el-table-column
        prop="departmentName"
        label="业务部门"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="customerTypeName"
        label="客户分类"
        header-align="center"
        align="center"
      > </el-table-column>

      <el-table-column
        prop="sendCustomerName"
        label="送货客户"
        header-align="center"
        align="center"
      ></el-table-column>
        <!-- v-if="columns[5].visible" -->
      <el-table-column
        prop="channelType"
        label="区域"
        header-align="center"
        align="center"
        width="130"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.locationProvince && scope.row.locationCity">{{scope.row.locationProvince}}/{{scope.row.locationCity}}</span>
          <span v-else-if="scope.row.locationProvince">{{scope.row.locationProvince}}</span>
          <span v-else-if="scope.row.locationCity">{{scope.row.locationCity}}</span>
          <span v-else>-</span>
        </template>
      </el-table-column>

      <el-table-column
        prop="customerCode"
        label="客户编码"
        header-align="center"
        align="center"
      ></el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="queryParams.pageNo"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
  </div>
</template>

// <script>
// import { list } from '@/api/delivery/salesDelivery/index';
// import { deepClone } from '@/utils';
import { list, exportList } from '@/api/delivery/approval/index';
export default {
  props: {
    queryParams: {
      type: Object,
      default: () => {},
    },
    formatQueryParams: {
      type: Function,
    },
  },

  data() {
    // 这里存放数据
    return {
      loading: false,
      tableData: [],
      total: 0,
      menuData: [],
      calcListData: [],
    };
  },

  methods: {
    addClass({ row, column, rowIndex, columnIndex }) {
      // if (columnIndex === 0) {
      //   return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      // }

      if (row[column.property] == null || row[column.property] === '') {
        row[column.property] = '-';
      }
    },

    getList() {
      this.loading = true;
      let params = this.formatQueryParams(this.queryParams);

      list(params)
        .then((res) => {
          this.loading = false;
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.total;
        })
        .catch(() => {
          this.loading = false;
        });
    },
  },
};
</script>

<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}

.link {
  text-decoration: initial;
  color: #0000ff;

  &:link {
    color: #0000ff;
  }

  // &:visited {
  //   color: purple;
  // }
}
</style>
