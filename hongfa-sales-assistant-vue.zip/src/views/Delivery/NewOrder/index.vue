<!-- 新客订单 -->
<template>
  <div class="app-container Board">

    <el-row :gutter="20">
      <el-col :span="24" :xs="24">
        <el-collapse accordion v-model="activeTabName" @change="handleCollapseChange">
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">新客订单
                <div class="title_right_btns" @click.stop="handleScreen">
                  <screenfull id="screenfull" class="right-menu-item hover-effect" ref="screenIcon" @screenToggle="handleScreenToggle" />
                  {{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">

              <!-- 搜索工作栏 -->
              <BaseSearchContainer :column="searchColumn" :params="queryParams" @datePickerChange="onDatePickerChange"
                @cityChange="onCityChange" @onSearch="handleQuery" @onReset="handleReset">
                <template #btnsRight>
                  <el-button icon="el-icon-download" @click="handleExport">导出</el-button>
                </template>
                <template #customerType>
                  <el-select v-model="queryParams.customerType" placeholder="请选择客户分类" clearable filterable style="width: 240px;"
                    @change="onCustomerTypeChange">
                    <el-option v-for="item in customerTypeList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </template>

                <template #customerName>
                  <el-select v-model="queryParams.customerName" placeholder="请选择客户名称" clearable filterable allow-create
                    style="width: 240px;" @change="onCustomerNameChange">
                    <el-option v-for="item in customerNameList" :key="item.id" :label="item.name" :value="item.name">
                    </el-option>
                  </el-select>
                </template>

                <template #sendCustomerName>
                  <el-select v-model="queryParams.sendCustomerName" placeholder="请选择送货客户名称" clearable filterable allow-create
                    style="width: 240px;">
                    <el-option v-for="item in sendCustomerNameList" :key="item.id" :label="item.name" :value="item.name">
                    </el-option>
                  </el-select>
                </template>

                <template #_productCategory>
                  <el-select v-model="queryParams._productCategory" placeholder="请选择品类" clearable filterable style="width: 240px;"
                    @change="onProductCategoryChange">
                    <el-option v-for="item in productCategoryList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                  </el-select>
                </template>

                <template #_productName>
                  <el-select v-model="queryParams._productName" placeholder="请选择品项" clearable filterable allow-create style="width: 240px;"
                    @change="onProductNameChange">
                    <el-option v-for="item in productCodeList" :key="item.id" :label="item.name" :value="item.id">
                      <span class="st-name-spec">{{item.name}} / {{item.spec}}</span>
                    </el-option>
                  </el-select>
                </template>

                <template #deptId>
                  <el-select clearable v-model="queryParams.deptId" placeholder="请选择业务部门" style="width: 240px"  @change="changeDeptId">
                    <el-option v-for="item in clientAreaOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </template>

                <template #saleUserId>
                  <el-select clearable v-model="queryParams.saleUserId" placeholder="请选择归属销售" style="width: 240px"
                    :disabled="activeName == 2">
                    <el-option v-for="item in belongListOp" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                  </el-select>
                </template>

              </BaseSearchContainer>
            </div>
          </el-collapse-item>
        </el-collapse>
        <el-row class="row-btm">
          <div id="clientOut" style="height:260px;width:100%;" />
        </el-row>
        <CrudHeader>
          <template slot="left">
            <el-tabs v-model="activeName" @tab-click="handleClick">
              <el-tab-pane v-for="(item, index) in tabs" :key="index" :label="item.label" :name="item.sendValue"></el-tab-pane>
            </el-tabs>
          </template>

          <!-- <template slot="rightBtns">
            <el-button size="small" style="margin-top:-15px" @click="handleExport" :loading="exportLoading"
              v-hasPermi="['system:outbound-neworder:export']">导出</el-button>
          </template> -->

          <template slot="list">
            <List ref="hookList" :queryParams="queryParams" :formatQueryParams="formatQueryParams" />
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import * as echarts from 'echarts';
  require('echarts/theme/macarons'); // echarts theme
  import resize from '@/views/dashboard/mixins/resize';
  import Screenfull from '@/components/Screenfull';
  import List from './list';
  import { getUserProfile } from '@/api/system/user';
  import {
    getCustomerOptions,
    getProductOptions,
    newOrderLabel,
    exportList,
  } from '@/api/delivery/newOrder/index';
  import {
    getTimeConfig
  } from '@/api/teamwork/Performance';
  import { deepClone } from '@/utils';
  import { getBelong } from '@/api/Client/index';

  const queryParamsCommon = {
    pageNo: 1,
    pageSize: 20,
    deptId: '',
    saleUserId: '',
    customerName: '',
    // productCode: '',
    productName: '',
    allAmount: null,
    allSum: null,
    locationProvinceCode: null,
    locationCityCode: null,
    tabType: '',
    isApprovePrice: null,
    customerType: '',
    _productCategory: '',
    _orderDate: [],
    _allAmount1: '',
    _allAmount2: '',
    _allSum1: '',
    _allSum2: '',
    _locationCity: [],
    _productName: '',
  };

  export default {
    name: 'SalesDelivery',
    components: {
      List,
      Screenfull,
    },
    mixins: [resize],
    data() {
      return {
        timeArr: [],
        clientChart: null,
        clientData: {},
        userInfo: {},
        exportLoading: false,
        // 时间选择默认1个月
        queryParams: deepClone(queryParamsCommon),
        activeName: '',
        tabs: [],
        deliveryAreaDatas: [{
            label: '全部大区',
            value: 'all',
            sendValue: '1',
          },
          {
            label: '我的',
            value: 'self',
            sendValue: '2',
          },
          {
            label: '宏发一区',
            value: 'zone1',
            sendValue: '101',
          },
          {
            label: '宏发二区',
            value: 'zone2',
            sendValue: '102',
          },
          {
            label: '宏发三区',
            value: 'zone3',
            sendValue: '103',
          },
        ],
        tableData: [],
        total: 0,
        customerTypeList: this.getDictDatas('customer_type'),
        customerNameList: [],
        sendCustomerNameList: [],
        productCategoryList: this.getDictDatas('category_classify'),
        productCodeList: [],
        searchColumn: [{
            label: '业务部门',
            prop: 'deptId',
            type: 'select',
            search: true,
            disabled: false,
            dicData: [],
          },
          {
            label: '归属销售',
            // prop: 'salePerson',
            prop: 'saleUserId',
            type: 'input',
            search: true,
          },
          {
            label: '归属工厂',
            key: 'FACTORY',
            prop: 'factories',
            index: [],
            type: 'select',
            search: true,
            multiple: true,
            dicData: [], // 字典
          },
          {
            // 插槽
            label: '客户分类',
            prop: 'customerType',
            type: 'input',
            search: true,
            dicData: [],
          },
          {
            label: '业务日期',
            prop: '_orderDate',
            type: 'daterange',
            search: true,
            // clearable: false,
          },
          {
            label: '所在地区',
            prop: '_locationCity',
            type: 'city',
            search: true,
            cascaderProp: {
              checkStrictly: true,
            },
          },
        ],
        belongListAll: [],
        belongListOp: [],
        allClientAreaOptions: this.getDictDatas('hfywbm'),
        clientAreaOptions: this.getDictDatas('hfywbm'),
        exportMaxMonth: 6,
        isFullScreen: true,
        activeTabName: '1',
      };
    },

    watch: {
      '$route': { // $route可以用引号，也可以不用引号
        async handler(to, from) {
        await this.getBelong();
          if (to.query && to.query.area) {
            this.queryParams.deptId = to.query.area
            this.belongListAll.forEach((res) => {
              if (res.deptId == this.queryParams.deptId) {
                this.belongListOp.push(res);
              }
            });
          }
          if (to.query && to.query.saleUserId) {
            this.queryParams.saleUserId = to.query.saleUserId
            this.queryParams.customerType = 'khfl6'
          }
          if (to.query && to.query.orderMonth) {
            let yearmonth = to.query.orderMonth;
            let year = yearmonth.slice(0, 4);
            let month = yearmonth.slice(5, 7);
            await getTimeConfig({
                year: year,
                month: month,
              })
              .then((res) => {
                if (res.data.length > 0) {
                  let resData = res.data[0]
                  if (resData.oneWeek) {
                    this.queryParams._orderDate = [resData.oneWeek.slice(0, 10),resData.fourWeek.slice(11, 21)];
                    this.queryParams.orderDate = `${resData.oneWeek.slice(0, 10)},${resData.fourWeek.slice(11, 21)}`;
                  } else {
                    this.queryParams._orderDate = [];
                  }
                } else {
                  this.queryParams._orderDate = [];
                }
              })
          }else{
            this.setDefaultMonth();
          }
          this.handleClick();
        },
        deep: true, // 深度观察监听
        immediate: true, // 第一次初始化渲染就可以监听到
      },
      activeTabName: {
        handler(newVal, oldVal) {
          if (newVal != '1' && this.queryParams.pageSize < 20) {
            this.queryParams.pageNo = 1;
            this.queryParams.pageSize = 20;
            this.$refs.hookList.getList();
          }
        },
        deep: true,
        // immediate: true,
      },
    },
    beforeDestroy() {
      if (this.clientChart) {
        this.clientChart.dispose();
        this.clientChart = null;
      }
    },
    created() {
      this.searchColumn.forEach((item) => {
        if (item.key == 'FACTORY') {
          // 归属工厂
          this.selectListFormat('factory', item);
        }
      });
    },

    methods: {
      changeDeptId(){
          this.belongListOp = [];
          this.queryParams.saleUserId = '';
          this.belongListAll.forEach((res) => {
            if (res.deptId == this.queryParams.deptId) {
              this.belongListOp.push(res);
            }
          });
          console.log("this.belongListOp", this.belongListOp)
          this.$forceUpdate()
      },
      getData() {
        return new Promise((resolve, reject) => {
          newOrderLabel(this.queryParams).then((res) => {
            if (res.code == 0) {
              resolve(res.data);
            }
          });
        });
      },
      //客户柱形图
      async clientInitChart() {
        this.clientData = []
        this.timeArr = []
        let data = await this.getData();
        data.forEach(item => {
          this.clientData.push(item.totalAmount)
          this.timeArr.push(item.salePerson)
        })
        // this.timeArr = data.totalAmount;
        // this.clientData = data.salPerson;
        this.clientChart = echarts.init(document.getElementById('clientOut'), 'macarons');
        this.clientChart.setOption({
          legend: {
            right: 30,
          },
          tooltip: {
            trigger: 'axis',
          },
          color: ['#0092ff'],
          xAxis: {
            type: 'category',
            data: this.timeArr,
          },
          yAxis: {
            type: 'value'
          },
          series: [{
            name: '订单量',
            data: this.clientData,
            type: 'bar',
            barWidth: '20%',
          }, ],
        });
      },
      getBeforeDate(n) {
        var n = n;
        var d = new Date();
        var year = d.getFullYear();
        var mon = d.getMonth() + 1;
        var day = d.getDate();
        if (day <= n) {
          if (mon > 1) { mon = mon - 1; } else { year = year - 1;
            mon = 12; }
        }
        d.setDate(d.getDate() - n);
        year = d.getFullYear();
        mon = d.getMonth() + 1;
        day = d.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      selectListFormat(dicKey, item) {
        item.dicData = deepClone(this.getDictDatas(dicKey));
      },
      onProductNameChange(id) {
        this.queryParams.productName =
          this.productCodeList?.find((item) => item.id === id)?.name ??
          this.queryParams._productName; // 没找到取输入的
      },
      handleExport() {
        const queryParams = this.formatQueryParams(this.queryParams);

        if (queryParams.orderDate) {
          const orderDateArr = queryParams.orderDate.split(',');
          const startDateY = this.$dayjs(orderDateArr[0]).year();
          const startDateM = this.$dayjs(orderDateArr[0]).month() + 1;
          const endDateY = this.$dayjs(orderDateArr[1]).year();
          const endDateM = this.$dayjs(orderDateArr[1]).month() + 1;

          if (
            this.$dayjs(`${endDateY}-${endDateM}`).diff(
              this.$dayjs(`${startDateY}-${startDateM}`),
              'month'
            ) > this.exportMaxMonth
          ) {
            this.$notify.error({
              title: `时间范围不允许超过${this.exportMaxMonth}个月`,
            });
            return;
          }
        } else {
          this.$notify.error({ title: '请填写时间范围' });
          return;
        }

        this.exportLoading = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList(queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '新客订单.xls');
            this.exportLoading = false;
          })
          .catch(() => {
            this.exportLoading = false;
          });
      },

      onDatePickerChange(e) {
        this.queryParams.orderDate = e ? `${e[0]},${e[1]}` : '';
      },

      onCityChange(e) {
        this.queryParams.locationProvinceCode = e[0];
        this.queryParams.locationCityCode = e[1];
      },

      onCustomerNameChange(e) {
        getCustomerOptions({
          parentCustomerName: e,
        }).then((res) => {
          this.sendCustomerNameList = res.data;
        });
      },

      onProductCategoryChange(e) {
        this.queryParams.productCode = '';

        getProductOptions({
          type: e,
        }).then((res) => {
          this.productCodeList = res.data;
        });
      },
      handleQuery() {
        this.queryParams.pageNo = 1;
        this.$refs.hookList.getList();
        this.clientInitChart();
      },

      handleReset() {
        this.queryParams = deepClone(queryParamsCommon);
        this.handleClick();
      },

      handleClick(tab, event) {
        // console.log('activeName', this.activeName);
        this.formatParamsArea();
        this.$nextTick(() => {
          this.queryParams.pageNo = 1;
          this.$refs.hookList.getList();
          this.clientInitChart();
        });
      },

      formatQueryParams(queryParams) {
        let params = deepClone(queryParams);

        if (params._allAmount1 != '' && params._allAmount2 != '') {
          // params.allAmount = `${params._allAmount1},${params._allAmount2}`;
          params.allAmount = `${(params._allAmount1 * 1000).toFixed(3)},${(
          params._allAmount2 * 1000
        ).toFixed(3)}`;
        }

        if (params._allSum1 != '' && params._allSum2 != '') {
          params.allSum = `${params._allSum1},${params._allSum2}`;
        }

        delete params._orderDate;
        delete params._locationCity;

        return params;
      },
      onCustomerTypeChange(e) {
        this.queryParams.customerName = '';

        getCustomerOptions({
          type: e,
        }).then((res) => {
          this.customerNameList = res.data;
        });
      },
      formatParamsArea() {
        // this.queryParams.tabType = this.activeName;
      },


      async getBelong() {
        const res = await getBelong({ isSale: true });
        this.belongListAll = res.data;
      },

      displayBelongArea() {
        let resultItem = this.userInfo.posts.find((item) => item.id == 1); // 总监

        if (resultItem) {
          let column = deepClone(this.searchColumn);

          column.find((item) => item.label == '归属大区').search = true;

          this.searchColumn = column;
        }
      },

      setDefaultMonth() {
        this.queryParams._orderDate = [this.getBeforeDate(7), this.getBeforeDate(0)];
        this.queryParams.orderDate = `${this.getBeforeDate(7)},${this.getBeforeDate(0)}`;
      },
      handleScreen() {
        this.$refs.screenIcon.click();
      },
      handleScreenToggle(val) {
        this.isFullScreen = val;
        // console.log(val, 123);
      },
      handleCollapseChange() {
        // this.$refs['market_price_type'].calTableHeight()
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .list_wrap {
    margin-top: 0 !important;
  }

  .component_title {
    padding: 10px 30px 0 20px;
  }

  ::v-deep .el-collapse-item__content {
    padding-bottom: 0 !important;
  }
</style>
