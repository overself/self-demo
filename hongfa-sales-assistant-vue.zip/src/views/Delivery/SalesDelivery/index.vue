<!-- 销售出库 -->
<template>
  <div class="app-container Board">

    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <el-collapse
          accordion
          v-model="activeTabName"
          @change="handleCollapseChange"
        >
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">销售出库
                <div
                  class="title_right_btns"
                  @click.stop="handleScreen"
                >
                  <screenfull
                    id="screenfull"
                    class="right-menu-item hover-effect"
                    ref="screenIcon"
                    @screenToggle="handleScreenToggle"
                  />{{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">

              <!-- 搜索工作栏 -->
              <BaseSearchContainer
                :column="searchColumn"
                :params="queryParams"
                @datePickerChange="onDatePickerChange"
                @cityChange="onCityChange"
                @onSearch="handleQuery"
                @onReset="handleReset"
              >
              <template #btnsRight>
                  <el-button icon="el-icon-download" @click="handleExport">导出</el-button>
                </template>
                <template #customerType>
                  <el-select
                    v-model="queryParams.customerType"
                    placeholder="请选择客户分类"
                    clearable
                    filterable
                    style="width: 240px;"
                    @change="onCustomerTypeChange"
                  >
                    <el-option
                      v-for="item in customerTypeList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </template>

                <template #customerName>
                  <el-select
                    v-model="queryParams.customerName"
                    placeholder="请选择客户名称"
                    clearable
                    filterable
                    allow-create
                    style="width: 240px;"
                    @change="onCustomerNameChange"
                  >
                    <el-option
                      v-for="item in customerNameList"
                      :key="item.id"
                      :label="item.name"
                      :value="item.name"
                    >
                    </el-option>
                  </el-select>
                </template>

                <template #sendCustomerName>
                  <el-select
                    v-model="queryParams.sendCustomerName"
                    placeholder="请选择送货客户名称"
                    clearable
                    filterable
                    allow-create
                    style="width: 240px;"
                  >
                    <el-option
                      v-for="item in sendCustomerNameList"
                      :key="item.id"
                      :label="item.name"
                      :value="item.name"
                    >
                    </el-option>
                  </el-select>
                </template>

                <template #_productCategory>
                  <el-select
                    v-model="queryParams._productCategory"
                    placeholder="请选择品类"
                    clearable
                    filterable
                    style="width: 240px;"
                    @change="onProductCategoryChange"
                  >
                    <el-option
                      v-for="item in productCategoryList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </template>

                <template #_productName>
                  <el-select
                    v-model="queryParams._productName"
                    placeholder="请选择品项"
                    clearable
                    filterable
                    allow-create
                    style="width: 240px;"
                    @change="onProductNameChange"
                  >
                    <el-option
                      v-for="item in productCodeList"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id"
                    >
                      <span class="st-name-spec">{{item.name}} / {{item.spec}}</span>
                    </el-option>
                  </el-select>
                </template>

                <template #deptId>
                  <el-select
                    clearable
                    v-model="queryParams.deptId"
                    placeholder="请选择业务部门"
                    style="width: 240px"
                    :disabled="activeName == 2"
                  >
                    <el-option
                      v-for="item in clientAreaOptions"
                      :key="item.value"
                      :value="item.value"
                      :label="item.label"
                    ></el-option>
                  </el-select>
                </template>

                <template #saleUserId>
                  <el-select
                    clearable
                    v-model="queryParams.saleUserId"
                    placeholder="请选择归属销售"
                    style="width: 240px"
                    :disabled="activeName == 2"
                  >
                    <el-option
                      v-for="item in belongListOp"
                      :key="item.id"
                      :value="item.id"
                      :label="item.nickname"
                    ></el-option>
                  </el-select>
                </template>
              </BaseSearchContainer>
            </div>
          </el-collapse-item>
        </el-collapse>

        <CrudHeader>
          <template slot="left">
            <el-tabs
              v-model="activeName"
              @tab-click="handleClick"
            >
              <el-tab-pane
                v-for="(item, index) in tabs"
                :key="index"
                :label="item.label"
                :name="item.sendValue"
              ></el-tab-pane>
            </el-tabs>
          </template>

          <!-- <template slot="rightBtns">
            <el-button
              size="small"
              @click="handleExport"
              :loading="exportLoading"
              v-hasPermi="['system:outbound-order:export']"
            >导出</el-button>
          </template> -->

          <template slot="list">
            <List
              ref="hookList"
              :queryParams="queryParams"
              :formatQueryParams="formatQueryParams"
            />
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import Screenfull from '@/components/Screenfull';
import List from './list';
import { getUserProfile } from '@/api/system/user';
import {
  getCustomerOptions,
  getProductOptions,
  exportList,
} from '@/api/delivery/salesDelivery/index';
import { deepClone } from '@/utils';
import { getBelong } from '@/api/Client/index';

const queryParamsCommon = {
  pageNo: 1,
  pageSize: 20,
  deptId: '',
  saleUserId: '',
  customerName: '',
  // productCode: '',
  productName: '',
  allAmount: null,
  allSum: null,
  locationProvinceCode: null,
  locationCityCode: null,
  tabType: '',
  isApprovePrice: null,
  customerType: '',
  _productCategory: '',
  _orderDate: [],
  allAmount1: '',
  allAmount2: '',
  _allSum1: '',
  _allSum2: '',
  _locationCity: [],
  _productName: '',
  isApprovePrice:3,
};

export default {
  name: 'SalesDelivery',
  components: {
    List,
    Screenfull,
  },

  data() {
    return {
      userInfo: {},
      exportLoading: false,
      // 时间选择默认1个月
      queryParams: deepClone(queryParamsCommon),
      activeName: '',
      tabs: [],
      deliveryAreaDatas: [
        // {
        //   label: '全部大区',
        //   value: 'all',
        //   sendValue: '1',
        // },
        // {
        //   label: '我的',
        //   value: 'self',
        //   sendValue: '2',
        // },
        {
          label: '宏发一区',
          value: 'zone1',
          sendValue: '101',
        },
        {
          label: '宏发二区',
          value: 'zone2',
          sendValue: '102',
        },
        {
          label: '宏发三区',
          value: 'zone3',
          sendValue: '103',
        },
      ],
      tableData: [],
      total: 0,
      customerTypeList: this.getDictDatas('customer_type'),
      customerNameList: [],
      sendCustomerNameList: [],
      productCategoryList: this.getDictDatas('category_classify'),
      productCodeList: [],
      searchColumn: [
        {
          // 插槽
          label: '客户分类',
          prop: 'customerType',
          type: 'input',
          search: true,
          dicData: [],
        },
        {
          label: '客户名称',
          prop: 'customerName',
          type: 'input',
          search: true,
          dicData: [],
        },
        {
          // 插槽
          label: '送货客户',
          prop: 'sendCustomerName',
          type: 'input',
          search: true,
          dicData: [],
        },
        {
          label: '所在地区',
          prop: '_locationCity',
          type: 'city',
          search: true,
          cascaderProp: {
            checkStrictly: true,
          },
        },
        {
          label: '业务部门',
          prop: 'deptId',
          type: 'select',
          search: true,
          disabled: false,
          dicData: [],
        },
        {
          label: '归属销售',
          // prop: 'salePerson',
          prop: 'saleUserId',
          type: 'input',
          search: true,
        },
        {
          label: '联系人',
          prop: 'customerContactName',
          type: 'input',
          search: true,
        },
        // {
        //   label: '渠道类型',
        //   prop: 'channelType',
        //   type: 'select',
        //   search: true,
        //   dicUrl: '/system/channel/simple-list',
        //   dicQuery: {
        //     status: 1,
        //   },
        //   dicData: [],
        // },
        {
          label: '时间选择',
          prop: '_orderDate',
          type: 'daterange',
          search: true,
          // clearable: false,
        },
        {
          label: '单据编号',
          prop: 'orderNo',
          type: 'input',
          search: true,
        },
        // {
        //   // 插槽
        //   label: '品类',
        //   prop: '_productCategory',
        //   type: 'select',
        //   search: true,
        //   dicData: [],
        // },
        // {
        //   label: '品项',
        //   prop: '_productName',
        //   type: 'select',
        //   search: true,
        //   dicData: [],
        // },
        {
          label: '出库量区间',
          // prop: 'name',
          startProp: 'allAmount1',
          startUnit: '吨',
          endProp: 'allAmount2',
          endUnit: '吨',
          type: 'inputRange',
          search: true,
          startInputType: 'number',
          endInputType: 'number',
          startInputMin: 0,
          endInputMin: 0,
        },
        {
          label: '出库额区间',
          // prop: 'name',
          startProp: '_allSum1',
          startUnit: '元',
          endProp: '_allSum2',
          endUnit: '元',
          type: 'inputRange',
          search: true,
          startInputType: 'number',
          endInputType: 'number',
        },
        {
          label: '是否批价',
          prop: 'isApprovePrice',
          type: 'select',
          search: true,
          dicData: [
            { label: '是', value: 1 },
            { label: '否', value: 0 },
            { label: '全部', value: 3 },
          ],
        },
      ],
      belongListAll: [],
      belongListOp: [],
      allClientAreaOptions: this.getDictDatas('hfywbm'),
      clientAreaOptions: this.getDictDatas('hfywbm'),
      exportMaxMonth: 6,
      isFullScreen: true,
      activeTabName: '1',
    };
  },

  watch: {
    'queryParams.deptId'(newVal, oldVal) {
      this.belongListOp = [];
      this.queryParams.saleUserId = '';

      this.belongListAll.forEach((res) => {
        if (res.deptId == newVal) {
          this.belongListOp.push(res);
        }
      });
    },
    activeTabName: {
      handler(newVal, oldVal) {
        if (newVal != '1' && this.queryParams.pageSize < 20) {
          this.queryParams.pageNo = 1;
          this.queryParams.pageSize = 20;
          this.$refs.hookList.getList();
        }
      },
      deep: true,
      // immediate: true,
    },
  },

  created() {
    // 默认一个月
    this.setDefaultMonth();
    this.getBelong();
    this.getUserInfo();
  },

  methods: {
    onProductNameChange(id) {
      this.queryParams.productName =
        this.productCodeList?.find((item) => item.id === id)?.name ??
        this.queryParams._productName; // 没找到取输入的
    },

    handleExport() {
      const queryParams = this.formatQueryParams(this.queryParams);

      if (queryParams.orderDate) {
        // const orderDateArr = queryParams.orderDate.split(',');
        // const startDateY = this.$dayjs(orderDateArr[0]).year();
        // const startDateM = this.$dayjs(orderDateArr[0]).month() + 1;
        // const endDateY = this.$dayjs(orderDateArr[1]).year();
        // const endDateM = this.$dayjs(orderDateArr[1]).month() + 1;

        // if (
        //   this.$dayjs(`${endDateY}-${endDateM}`).diff(
        //     this.$dayjs(`${startDateY}-${startDateM}`),
        //     'month'
        //   ) > this.exportMaxMonth
        // ) {
        //   this.$notify.error({
        //     title: `时间范围不允许超过${this.exportMaxMonth}个月`,
        //   });
        //   return;
        // }
      } else {
        this.$notify.error({ title: '请填写时间范围' });
        return;
      }

      this.exportLoading = true;
      this.$modal
        .confirm('是否确认导出数据项?')
        .then(() => {
          return exportList(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '销售出库.xls');
          this.exportLoading = false;
        })
        .catch(() => {
          this.exportLoading = false;
        });
    },

    onDatePickerChange(e) {
      this.queryParams.orderDate = e ? `${e[0]},${e[1]}` : '';
    },

    onCityChange(e) {
      this.queryParams.locationProvinceCode = e[0];
      this.queryParams.locationCityCode = e[1];
    },

    onCustomerTypeChange(e) {
      this.queryParams.customerName = '';

      getCustomerOptions({
        type: e,
      }).then((res) => {
        this.customerNameList = res.data;
      });
    },

    onCustomerNameChange(e) {
      getCustomerOptions({
        parentCustomerName: e,
      }).then((res) => {
        this.sendCustomerNameList = res.data;
      });
    },

    onProductCategoryChange(e) {
      this.queryParams.productCode = '';

      getProductOptions({
        type: e,
      }).then((res) => {
        this.productCodeList = res.data;
      });
    },

    toFilter() {
      this.$router.push({
        path: '/sales-delivery/filter',
      });
    },

    handleQuery() {
      // console.log(this.queryParams);
      if (this.queryParams.allAmount1 != '') {
        if (this.queryParams.allAmount2 == '') {
          this.$message.warning('请输入完整出库量区间');
          return;
        }
      }

      if (this.queryParams._allAmount2 != '') {
        if (this.queryParams._allAmount1 == '') {
          this.$message.warning('请输入完整出库量区间');
          return;
        }
      }

      if (
        this.queryParams.allAmount1 != '' &&
        this.queryParams.allAmount2 != ''
      ) {
        if (this.queryParams.allAmount2 < this.queryParams.allAmount1) {
          this.$message.warning('出库量区间后者必须大于前者');
          return;
        }
      }

      if (this.queryParams._allSum1 != '') {
        if (this.queryParams._allSum2 == '') {
          this.$message.warning('请输入完整出库额区间');
          return;
        }
      }

      if (this.queryParams._allSum2 != '') {
        if (this.queryParams._allSum1 == '') {
          this.$message.warning('请输入完整出库额区间');
          return;
        }
      }

      if (this.queryParams._allSum1 != '' && this.queryParams._allSum2 != '') {
        if (this.queryParams._allSum2 < this.queryParams._allSum1) {
          this.$message.warning('出库额区间后者必须大于前者');
          return;
        }
      }

      if (
        this.queryParams._productCategory != '' &&
        this.queryParams.productName == ''
      ) {
        this.$message.warning('请选择品项');
        return;
      }

      this.queryParams.pageNo = 1;
      this.$refs.hookList.getList();
    },

    handleReset() {
      this.queryParams = deepClone(queryParamsCommon);
      this.setDefaultMonth();
      this.handleClick();


      // this.formatParamsArea();
      // this.queryParams.pageNo = 1;
      // this.$refs.hookList.getList();
    },

    handleClick(tab, event) {
      // console.log('activeName', this.activeName);

      this.formatParamsArea();

      if (this.activeName == 1) {
        this.clientAreaOptions = this.getDictDatas('hfywbm');
        this.queryParams.deptId = '';
      }
      else if (this.activeName == 2) {
        this.queryParams.deptId = '';
      }
      else {
        this.clientAreaOptions = [];
        this.allClientAreaOptions.forEach((it) => {
          if (it.value == this.activeName) {
            this.clientAreaOptions.push(it);
          }
        });
        this.queryParams.deptId = this.activeName;
      }

      this.$nextTick(() => {
        this.queryParams.pageNo = 1;
        this.$refs.hookList.getList();
      });
    },

    formatQueryParams(queryParams) {
      let params = deepClone(queryParams);

      if (params.allAmount1 != '' && params.allAmount2 != '') {
        // params.allAmount = `${params._allAmount1},${params._allAmount2}`;
        params.allAmount = `${(params.allAmount1 * 1000).toFixed(3)},${(
          params.allAmount2 * 1000
        ).toFixed(3)}`;
      }

      if (params._allSum1 != '' && params._allSum2 != '') {
        params.allSum = `${params._allSum1},${params._allSum2}`;
      }

      delete params._orderDate;
      delete params._locationCity;

      return params;
    },

    formatParamsArea() {
      this.queryParams.tabType = this.activeName;
    },

    getUserInfo() {
      this.tabs = [];
      getUserProfile().then((res) => {
        this.userInfo = res.data;
        this.deliveryAreaDatas.map((item) => {
          if (res.data.permissionTabs.includes(item.value)) {
            this.tabs.push(item);
          }
        });

        // 根据岗位隐藏归属大区搜索
        // this.displayBelongArea();

        // this.activeName = this.tabs[0].sendValue;
        this.activeName = 1;
        this.handleClick();
        // this.formatParamsArea();
        // this.$refs.hookList.getList();
      });
    },

    async getBelong() {
      const res = await getBelong({ isSale: true });
      this.belongListAll = res.data;
    },

    displayBelongArea() {
      let resultItem = this.userInfo.posts.find((item) => item.id == 1); // 总监

      if (resultItem) {
        let column = deepClone(this.searchColumn);

        column.find((item) => item.label == '归属大区').search = true;

        this.searchColumn = column;
      }
    },

    setDefaultMonth() {
      const today = this.$dayjs().startOf('day').format('YYYY-MM-DD');
      const oneMonthBefore = this.$dayjs()
        .subtract(1, 'month')
        .startOf('day')
        .format('YYYY-MM-DD');

      this.queryParams._orderDate = [oneMonthBefore, today];
      this.queryParams.orderDate = `${oneMonthBefore},${today}`;
    },
    handleScreen() {
      this.$refs.screenIcon.click();
    },
    handleScreenToggle(val) {
      this.isFullScreen = val;
      // console.log(val, 123);
    },
    handleCollapseChange() {
      // this.$refs['market_price_type'].calTableHeight()
    },
  },
};
</script>

<style lang="scss" scoped>
::v-deep .list_wrap {
  margin-top: 0 !important;
}
.component_title {
  padding: 10px 30px 0 20px;
}
::v-deep .el-collapse-item__content {
  padding-bottom: 0 !important;
}
</style>
