<!-- 出库单明细汇总 -->
<template>
  <div class="app-container Board">

    <!-- 搜索工作栏 -->
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <el-collapse
          accordion
          v-model="activeTabName"
          @change="handleCollapseChange"
        >
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">出库单明细汇总
                <div
                  class="title_right_btns"
                  @click.stop="handleScreen"
                >
                  <screenfull
                    id="screenfull"
                    class="right-menu-item hover-effect"
                    ref="screenIcon"
                    @screenToggle="handleScreenToggle"
                  />{{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">

              <!-- 搜索工作栏 -->
              <Filtrate
                ref='hookFiltrate'
                v-show="showSearch"
                :queryParams="queryParams"
                @onSearch="onSearch"
                @onReset="onReset"
                @radioChange="onRadioChange"
                @toggleCollapse="toggleCollapse"
              />
            </div>
          </el-collapse-item>
        </el-collapse>

        <CrudHeader>
          <template slot="rightBtns">
            <right-toolbar
              :showSearch.sync="showSearch"
              @queryTable="getList"
              :columns="columns"
            ></right-toolbar>

            <div style="margin-left: 10px;">
              <!-- <el-button
                v-hasPermi="['system:outbound-order-detail:calculate']"
                size="small"
                @click="dialogVisible = true;"
              >结果计算</el-button> -->
              <el-button
                v-hasPermi="['system:outbound-order-detail:export']"
                size="small"
                :loading="exportLoading"
                @click="handleExport"
              >导出</el-button>
            </div>
          </template>

          <template slot="list">
            <el-table
              ref="hookTable"
              :data="tableData"
              border
              :cell-style="addClass"
              style="width: 100%;"
              v-loading="loading"
              :height="tableHeight"
            >
              <!-- <el-table-column
                type="selection"
                width="55"
              ></el-table-column> -->

              <el-table-column
                prop="orderNo"
                label="单据编号"
                header-align="center"
                align="center"
              >
              <template slot-scope="scope">
                <router-link
                  class="link"
                  :to="{ path: `/sales-delivery/info/${scope.row.orderId}`, }"
                >{{scope.row.orderNo}}</router-link>
              </template></el-table-column>

              <el-table-column
                prop="orderDate"
                label="业务日期"
                header-align="center"
                align="center"
                width="100"
              >
                <template #header>
                  <div>业务日期</div>
                  <div>(出库日期)</div>
                </template>
              </el-table-column>

              <el-table-column
                prop="productCode"
                label="品项编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="productName"
                label="品项名称"
                header-align="center"
                align="center"
                width="230"
              ></el-table-column>

              <el-table-column
                prop="productSpec"
                label="详细规格"
                header-align="center"
                align="center"
              ></el-table-column>

              <!-- <el-table-column
                prop="customerContactName"
                label="联系人"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="customerContactTelephone"
                label="联系方式"
                header-align="center"
                align="center"
              ></el-table-column> -->

              <!-- <el-table-column
                prop="channelType"
                label="渠道分类"
                header-align="center"
                align="center"
              > </el-table-column> -->

              <!-- <el-table-column
                prop="channelType"
                label="所在地区"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <span v-if="scope.row.locationProvince && scope.row.locationCity">{{scope.row.locationProvince}}/{{scope.row.locationCity}}</span>
                  <span v-else-if="scope.row.locationProvince">{{scope.row.locationProvince}}</span>
                  <span v-else-if="scope.row.locationCity">{{scope.row.locationCity}}</span>
                  <span v-else>-</span>
                </template>
              </el-table-column> -->

              <!-- <el-table-column
                prop="orderDate"
                label="订单日期"
                header-align="center"
                align="center"
              > </el-table-column> -->

              <!-- 要处理成吨 返的是kg -->
              <el-table-column
                prop="amount"
                label="出库量（吨）"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.amount | weightFormat(true) | removeTrailingZeros}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="priceTax"
                label="含税单价（元）"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.priceTax | moneyFormat}}</span>
                </template>
              </el-table-column>

              <!-- <el-table-column
                prop="allSum"
                label="出库额（元）"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.allSum | moneyFormat}}</span>
                </template>
              </el-table-column> -->

              <el-table-column
                prop="sumTax"
                label="单品出库额"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.sumTax | moneyFormat}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="isApprovePrice"
                label="是否批价"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <div v-if="isAssignMonth(scope.row)">N/A</div>

                  <div v-else>
                    <div v-if="scope.row.isApprovePrice === true">
                      <div style="color: #FF0000">是</div>
                      <div>{{scope.row.approvePrice}}</div>
                    </div>
                    <span v-else>否</span>
                  </div>
                </template>
              </el-table-column>

              <el-table-column
                prop="sendCustomerCode"
                label="送货客户编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="sendCustomerName"
                label="送货客户名称"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="channelType"
                label="客户所在区域"
                header-align="center"
                align="center"
                width="130"
              >
                <template slot-scope="scope">
                  <span v-if="scope.row.locationProvince && scope.row.locationCity">{{scope.row.locationProvince}}/{{scope.row.locationCity}}</span>
                  <span v-else-if="scope.row.locationProvince">{{scope.row.locationProvince}}</span>
                  <span v-else-if="scope.row.locationCity">{{scope.row.locationCity}}</span>
                  <span v-else>-</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="customerCode"
                label="客户编码"
                header-align="center"
                align="center"
              >
              <template slot-scope="scope">
                <router-link
                  class="link"
                  :to="{ path: `/client-control/info/${scope.row.customerId}`, }"
                >{{scope.row.customerCode}}</router-link>
              </template></el-table-column>

              <el-table-column
                prop="customerName"
                label="客户名称"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="customerTypeName"
                label="客户分类"
                header-align="center"
                align="center"
              > </el-table-column>

              <el-table-column
                prop="factory"
                label="归属工厂"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <span>{{formatRowFactory(scope.row.factory)}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="departmentName"
                label="业务部门"
                header-align="center"
                align="center"
              ></el-table-column>

              <!-- <el-table-column
                prop="area"
                label="归属大区"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <div>{{areaObj[scope.row.area]}}</div>
                </template>
              </el-table-column> -->

              <el-table-column
                prop="salePerson"
                label="归属销售"
                header-align="center"
                align="center"
              > </el-table-column>

              <el-table-column
                prop="status"
                label="单据状态"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <span>{{getDictDataLabel('base_status', scope.row.status)}}</span>
                </template>
              </el-table-column>

              <!-- <el-table-column
                prop="busType"
                label="业务类型"
                header-align="center"
                align="center"
              ></el-table-column> -->

              <!-- <el-table-column
                prop="payType"
                label="付款方式"
                header-align="center"
                align="center"
              ></el-table-column> -->

              <el-table-column
                prop="productUnit"
                label="计量单位"
                header-align="center"
                align="center"
              ></el-table-column>

              <!-- 动态表头start -->
              <el-table-column
                prop="orderNo"
                label="单据编号(EAS)"
                header-align="center"
                align="center"
                v-if="columns[0].visible"
              ></el-table-column>

              <el-table-column
                prop="orderDate"
                label="业务日期"
                header-align="center"
                align="center"
                v-if="columns[1].visible"
              ></el-table-column>

              <el-table-column
                prop="status"
                label="单据状态"
                header-align="center"
                align="center"
                v-if="columns[2].visible"
              >
                <span>{{getDictDataLabel('base_status', scope.row.transType)}}</span>
              </el-table-column>

              <!-- <el-table-column
                prop="busType"
                label="业务类型"
                header-align="center"
                align="center"
                v-if="columns[3].visible"
              ></el-table-column> -->

              <!-- <el-table-column
                prop="transType"
                label="事务类型"
                header-align="center"
                align="center"
                v-if="columns[4].visible"
              ></el-table-column> -->

              <el-table-column
                prop="payType"
                label="付款方式"
                header-align="center"
                align="center"
                v-if="columns[3].visible"
              ></el-table-column>

              <el-table-column
                prop="sendCustomerCode"
                label="送货客户编码"
                header-align="center"
                align="center"
                v-if="columns[4].visible"
              ></el-table-column>

              <el-table-column
                prop="sendCustomerName"
                label="送货客户"
                header-align="center"
                align="center"
                v-if="columns[5].visible"
              ></el-table-column>

              <el-table-column
                prop="no"
                label="行号"
                header-align="center"
                align="center"
                v-if="columns[6].visible"
              ></el-table-column>

              <el-table-column
                prop="changeType"
                label="更新类型"
                header-align="center"
                align="center"
                v-if="columns[7].visible"
              ></el-table-column>

              <el-table-column
                prop="productCode"
                label="物料编码"
                header-align="center"
                align="center"
                v-if="columns[8].visible"
              ></el-table-column>

              <el-table-column
                prop="productName"
                label="物料名称"
                header-align="center"
                align="center"
                v-if="columns[9].visible"
              ></el-table-column>

              <el-table-column
                prop="productSpec"
                label="详细规格"
                header-align="center"
                align="center"
                v-if="columns[10].visible"
              ></el-table-column>

              <el-table-column
                prop="productUnit"
                label="计量单位"
                header-align="center"
                align="center"
                v-if="columns[11].visible"
              ></el-table-column>

              <el-table-column
                prop="amount"
                label="出库数量"
                header-align="center"
                align="center"
                v-if="columns[12].visible"
              ></el-table-column>

              <el-table-column
                prop="priceTax"
                label="含税单价"
                header-align="center"
                align="center"
                v-if="columns[13].visible"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.priceTax | moneyFormat}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="sumTax"
                label="价税合计"
                header-align="center"
                align="center"
                v-if="columns[14].visible"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.sumTax | moneyFormat}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="price"
                label="单价"
                header-align="center"
                align="center"
                v-if="columns[15].visible"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.price | moneyFormat}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="sum"
                label="金额"
                header-align="center"
                align="center"
                v-if="columns[16].visible"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.sum | moneyFormat}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="tax"
                label="税率"
                header-align="center"
                align="center"
                v-if="columns[17].visible"
              ></el-table-column>

              <el-table-column
                prop="taxSum"
                label="税额"
                header-align="center"
                align="center"
                v-if="columns[18].visible"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.taxSum | moneyFormat}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="batch"
                label="批次"
                header-align="center"
                align="center"
                v-if="columns[19].visible"
              ></el-table-column>

              <el-table-column
                prop="warehouse"
                label="仓库"
                header-align="center"
                align="center"
                v-if="columns[20].visible"
              ></el-table-column>

              <el-table-column
                prop="warehouseOrg"
                label="库存组织"
                header-align="center"
                align="center"
                v-if="columns[21].visible"
              ></el-table-column>

              <el-table-column
                prop="realCost"
                label="实际成本"
                header-align="center"
                align="center"
                v-if="columns[22].visible"
              ></el-table-column>

              <el-table-column
                prop="cancelNumber"
                label="已核销数量"
                header-align="center"
                align="center"
                v-if="columns[23].visible"
              ></el-table-column>

              <el-table-column
                prop="salePerson"
                label="销售员"
                header-align="center"
                align="center"
                v-if="columns[24].visible"
              ></el-table-column>

              <el-table-column
                prop="allSumTax"
                label="总价税合计"
                header-align="center"
                align="center"
                v-if="columns[25].visible"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.allSumTax | moneyFormat}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="signAccount"
                label="记账标志"
                header-align="center"
                align="center"
                v-if="columns[26].visible"
              ></el-table-column>

              <el-table-column
                prop="credentialNo"
                label="凭证号"
                header-align="center"
                align="center"
                v-if="columns[27].visible"
              ></el-table-column>

              <el-table-column
                prop="allSum"
                label="总金额"
                header-align="center"
                align="center"
                v-if="columns[28].visible"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.allSum | moneyFormat}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="allAmount"
                label="总数量"
                header-align="center"
                align="center"
                v-if="columns[29].visible"
              >
                <template slot-scope="scope">
                  <span>{{scope.row.allAmount | weightFormat(true)}}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="department"
                label="部门"
                header-align="center"
                align="center"
                v-if="columns[30].visible"
              ></el-table-column>

              <el-table-column
                prop="assistUnit"
                label="辅助计量单位"
                header-align="center"
                align="center"
                v-if="columns[31].visible"
              ></el-table-column>

              <el-table-column
                prop="assistNumber"
                label="辅助数量"
                header-align="center"
                align="center"
                v-if="columns[32].visible"
              ></el-table-column>

              <el-table-column
                prop="carNo"
                label="车牌号"
                header-align="center"
                align="center"
                v-if="columns[33].visible"
              ></el-table-column>

              <el-table-column
                prop="transType"
                label="渠道类型"
                header-align="center"
                align="center"
                v-if="columns[34].visible"
              >
                <template slot-scope="scope">
                  <span v-if="scope.row.transType =='010'">普通销售出库</span>
                  <span v-if="scope.row.transType =='019'">销售发货待检出库</span>
                  <span v-if="scope.row.transType =='011'">普通销售退货</span>
                </template>
              </el-table-column>
              <el-table-column
                prop="busType"
                label="业务类型"
                header-align="center"
                align="center"
                v-if="columns[35].visible"
              >
                <template slot-scope="scope">
                  <span v-if="scope.row.busType ==210">普通销售</span>
                  <span v-if="scope.row.busType ==211">普通销售退货</span>
                </template>
              </el-table-column>
              <!-- <el-table-column
                prop="carNo"
                label="挂号"
                header-align="center"
                align="center"
                v-if="columns[2].visible"
              ></el-table-column> -->

              <!-- <el-table-column
                prop="department"
                label="雏苗来源类型"
                header-align="center"
                align="center"
                v-if="columns[2].visible"
              ></el-table-column> -->

              <!-- <el-table-column
                prop="department"
                label="雏苗领用单分录物料"
                header-align="center"
                align="center"
                v-if="columns[2].visible"
              ></el-table-column> -->

              <!-- <el-table-column
                prop="allAmount"
                label="毛鸡入库组织(食品厂)"
                header-align="center"
                align="center"
                v-if="columns[2].visible"
              ></el-table-column> -->
            </el-table>

            <pagination
              v-show="total > 0 && filtrateV == 1"
              :total="total"
              :page.sync="quickParams.pageNo"
              :limit.sync="quickParams.pageSize"
              @pagination="getList"
            />

            <pagination
              v-show="total > 0 && filtrateV == 2"
              :total="total"
              :page.sync="queryParams.pageNo"
              :limit.sync="queryParams.pageSize"
              @pagination="getList"
            />
          </template>
        </CrudHeader>
      </el-col>
    </el-row>

    <!-- 结果计算 -->
    <el-dialog
      title="自定义结果计算"
      :visible.sync="dialogVisible"
      width="900px"
      append-to-body
    >
      <div>
        <el-table
          :data="calcTableData"
          border
          style="width: 100%;"
        >
          <el-table-column
            type="selection"
            width="55"
          ></el-table-column>

          <el-table-column
            prop="name"
            label="指标名称"
            header-align="center"
            align="center"
          ></el-table-column>

          <el-table-column
            prop="name"
            label="计算结果"
            header-align="center"
            align="center"
          ></el-table-column>
        </el-table>
      </div>

      <div
        slot="footer"
        class="between-footer"
      >
        <el-button type="text">恢复默认</el-button>

        <div>
          <el-button type="primary">开始计算</el-button>
          <el-button @click="dialogVisible = false;">取 消</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import 'dayjs/locale/zh-cn';
import Screenfull from '@/components/Screenfull';
import Filtrate from './components/filtrate';
import { list, exportList } from '@/api/delivery/summary/index';
import { deepClone } from '@/utils';

const queryParamsCommon = {
  pageNo: 1,
  pageSize: 20,
  factories: [],
  // areas: [],
  deptId: '',
  salePerson: '',
  _salePerson: '',
  channelNames: [],
  productTypes: '',
  productName: '',
  warningStatus: [],
  signIds: [],
  customerName: '',
  sendCustomerName: '',
  locationProvinceCode: '',
  locationCityCode: '',
  isApprovePrice: null,
  _orderDate: [],
  _amount1: '',
  _amount2: '',
  _sumTax1: '',
  _sumTax2: '',
  _locationCity: [],
  _productName: '',
};

export default {
  components: {
    Screenfull,
    Filtrate,
  },

  data() {
    return {
      quarterOfYear: require('dayjs/plugin/quarterOfYear'),
      loading: false,
      showSearch: true,
      dialogVisible: false,
      filtrateV: '2',
      quickParams: {
        pageNo: 1,
        pageSize: 20,
      },
      queryParams: deepClone(queryParamsCommon),
      total: 0,
      tableData: [],
      columns: [
        { key: 0, label: `单据编号(EAS)`, visible: false },
        { key: 1, label: `业务日期`, visible: false },
        { key: 2, label: `单据状态`, visible: false },
        { key: 3, label: `付款方式`, visible: false },
        { key: 4, label: `送货客户编码`, visible: false },
        { key: 5, label: `送货客户`, visible: false },
        { key: 6, label: `行号`, visible: false },
        { key: 7, label: `更新类型`, visible: false },
        { key: 8, label: `物料编码`, visible: false },
        { key: 9, label: `物料名称`, visible: false },
        { key: 10, label: `详细规格`, visible: false },
        { key: 11, label: `计量单位`, visible: false },
        { key: 12, label: `出库数量`, visible: false },
        { key: 13, label: `含税单价`, visible: false },
        { key: 14, label: `价税合计`, visible: false },
        { key: 15, label: `单价`, visible: false },
        { key: 16, label: `金额`, visible: false },
        { key: 17, label: `税率`, visible: false },
        { key: 18, label: `税额`, visible: false },
        { key: 19, label: `批次`, visible: false },
        { key: 20, label: `仓库`, visible: false },
        { key: 21, label: `库存组织`, visible: false },
        { key: 22, label: `实际成本`, visible: false },
        { key: 23, label: `已核销数量`, visible: false },
        { key: 24, label: `销售员`, visible: false },
        { key: 25, label: `总价税合计`, visible: false },
        { key: 26, label: `记账标志`, visible: false },
        { key: 27, label: `凭证号`, visible: false },
        { key: 28, label: `总金额`, visible: false },
        { key: 29, label: `总数量`, visible: false },
        { key: 30, label: `部门`, visible: false },
        { key: 31, label: `辅助计量单位`, visible: false },
        { key: 32, label: `辅助数量`, visible: false },
        { key: 33, label: `车牌号`, visible: false },
        { key: 34, label: `渠道类型`, visible: false },
        { key: 35, label: `业务类型`, visible: false },
        // { key: 4, label: `事务类型`, visible: false },
      ],
      calcTableData: [], // 计算结果
      areaObj: {
        101: '宏发一区',
        102: '宏发二区',
        103: '宏发三区',
        '-': '-',
      },
      tableHeight: 0,
      exportMaxMonth: 6,
      exportLoading: false,
      isFullScreen: true,
      activeTabName: '1',
    };
  },

  watch: {
    '$route': { // $route可以用引号，也可以不用引号
                handler(to, from){
                  if(to.query && to.query.salePerson){
                    this.queryParams._salePerson=to.query.salePerson
                    this.queryParams.salePerson=to.query.salePerson
                  }
                  if(to.query && to.query.productName){
                    this.queryParams._productName=to.query.productName
                    this.queryParams.productName=to.query.productName
                  }
                  if(to.query && to.query.customerName){
                    this.queryParams.customerName=to.query.customerName
                  }
                },
                deep: true, // 深度观察监听
                immediate: true, // 第一次初始化渲染就可以监听到
            },
    showSearch() {
      this.calTableHeight();
    },
  },

  created() {
    this.$dayjs.locale('zh-cn');
    this.$dayjs.extend(this.quarterOfYear);
    this.queryParams._orderDate = [this.getBeforeDate(30), this.getBeforeDate(0)]
  },

  mounted() {
    this.calTableHeight();
    this.getList();

    window.addEventListener('resize', this.calTableHeight);
  },

  beforeDestroy() {
    window.removeEventListener('resize', this.calTableHeight);
  },

  methods: {
    //获取时间
    getBeforeDate(n) {
      var n = n;
      var d = new Date();
      var year = d.getFullYear();
      var mon = d.getMonth() + 1;
      var day = d.getDate();
      if (day <= n) {
        if (mon > 1) {
          mon = mon - 1;
        } else {
          year = year - 1;
          mon = 12;
        }
      }
      d.setDate(d.getDate() - n);
      year = d.getFullYear();
      mon = d.getMonth() + 1;
      day = d.getDate();
      let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
      return s;
    },
    toggleCollapse(e) {
      // e: { type: 'quick' }
      this.calTableHeight();
    },

    calTableHeight() {
      const viewportHeight =
        window.innerHeight ||
        document.documentElement.clientHeight ||
        document.body.clientHeight;

      this.$nextTick(() => {
        const filtrateHeight =
          this.$refs.hookFiltrate.$el.getBoundingClientRect();

        this.tableHeight =
          this.filtrateV == 1
            ? 250
            : viewportHeight -
              50 -
              20 -
              41 -
              55 -
              20 -
              10 -
              36 -
              50 -
              filtrateHeight.height; // 36是tag

        this.$refs?.hookTable.doLayout();
      });
    },

    isAssignMonth(row) {
      return this.$dayjs(row.orderDate).isBefore(this.$dayjs('2024-07-08'));
    },

    onSearch(e) {
      // console.log(e);
      this.filtrateV = e.radioType;
      if (e.radioType == 1) {
        this.quickParams = e.params;
        this.quickParams.pageNo = 1;
        this.quickParams.pageSize = 20;
      } else {
        if (this.queryParams._amount1 != '') {
          if (this.queryParams._amount2 == '') {
            this.$message.warning('请输入完整出库量范围');
            return;
          }
        }

        if (this.queryParams._amount2 != '') {
          if (this.queryParams._amount1 == '') {
            this.$message.warning('请输入完整出库量范围');
            return;
          }
        }

        if (
          this.queryParams._amount1 != '' &&
          this.queryParams._amount2 != ''
        ) {
          if (
            Number(this.queryParams._amount2) <
            Number(this.queryParams._amount1)
          ) {
            this.$message.warning('出库量范围后者必须大于前者');
            return;
          }
        }

        if (this.queryParams._sumTax1 != '') {
          if (this.queryParams._sumTax2 == '') {
            this.$message.warning('请输入完整出库额范围');
            return;
          }
        }

        if (this.queryParams._sumTax2 != '') {
          if (this.queryParams._sumTax1 == '') {
            this.$message.warning('请输入完整出库额范围');
            return;
          }
        }

        if (
          this.queryParams._sumTax1 != '' &&
          this.queryParams._sumTax2 != ''
        ) {
          if (
            Number(this.queryParams._sumTax2) <
            Number(this.queryParams._sumTax1)
          ) {
            this.$message.warning('出库额范围后者必须大于前者');
            return;
          }
        }

        this.queryParams.pageNo = 1;
      }

      this.getList();
    },

    formatRowFactory(factoryCode) {
      if (factoryCode) {
        return this.getDictDataLabel('factory', factoryCode);
      }

      return '';
    },

    onReset(e) {
      if (this.filtrateV == 1) {
        this.quickParams = {
          pageNo: 1,
          pageSize: 20,
        };
      } else {
        this.queryParams = deepClone(queryParamsCommon);
        this.queryParams._orderDate = [this.getBeforeDate(30), this.getBeforeDate(0)]
      }

      this.getList();
    },

    onRadioChange(v) {
      this.filtrateV = v;

      if (v == 2) {
        this.queryParams.pageNo = 1;
      } else {
        this.quickParams.pageNo = 1;
      }

      this.calTableHeight();
    },

    handleExport() {
      if (this.filtrateV == 1) {
        this.$refs.hookFiltrate.$refs.hookQuick.handleQuery('quick');
      } else {
        this.$refs.hookFiltrate.$refs.hookQuery.handleQuery('condition');
      }

      let params = this.formatParams(
        this.filtrateV == 1 ? this.quickParams : this.queryParams
      );

      if (params.orderDate) {
        // const orderDateArr = params.orderDate.split(',');
        // const startDateY = this.$dayjs(orderDateArr[0]).year();
        // const startDateM = this.$dayjs(orderDateArr[0]).month() + 1;
        // const endDateY = this.$dayjs(orderDateArr[1]).year();
        // const endDateM = this.$dayjs(orderDateArr[1]).month() + 1;

        // if (
        //   this.$dayjs(`${endDateY}-${endDateM}`).diff(
        //     this.$dayjs(`${startDateY}-${startDateM}`),
        //     'month'
        //   ) > this.exportMaxMonth
        // ) {
        //   this.$notify.error({
        //     title: `时间范围不允许超过${this.exportMaxMonth}个月`,
        //   });
        //   return;
        // }
      } else {
        let title = this.filtrateV == 1 ? '请选择时间范围' : '请填写时间范围';
        this.$notify.error({ title });
        return;
      }

      // console.log(params);

      this.exportLoading = true;
      this.$modal
        .confirm('是否确认导出数据项?')
        .then(() => {
          return exportList(params);
        })
        .then((response) => {
          this.$download.excel(response, '出库单明细.xls');
          this.exportLoading = false;
        })
        .catch(() => {
          this.exportLoading = false;
        });
    },

    formatDate(index) {
      switch (index) {
        case '1': // 本周
          return this.getRangeDate('week');

        case '2': // 本月
          return this.getRangeDate('month');

        case '3': // 本季
          return this.getRangeDate('quarter');

        case '4': // 本年
          return this.getRangeDate('year');

        default:
          return '';
      }
    },

    formatParams(queryParams) {
      let params = deepClone(queryParams);

      // console.log(params);

      if (this.filtrateV == 1) {
        // quick
        params.amount = params._amount;
        params.sumTax = params._sumTax;

        // _orderDate 处理日期
        params.orderDate = this.formatDate(params._orderDate);
        Array.isArray(params.factories)
          ? (params.factories = params.factories.join(','))
          : false;
        // Array.isArray(params.areas)
        //   ? (params.areas = params.areas.join(','))
        //   : false;

        Array.isArray(params.channelNames)
          ? (params.channelNames = params.channelNames.join(','))
          : false;
        Array.isArray(params.productTypes)
          ? (params.productTypes = params.productTypes.join(','))
          : false;
        Array.isArray(params.warningStatus)
          ? (params.warningStatus = params.warningStatus.join(','))
          : false;

        for (let key in params) {
          if (params[key] == 'all') {
            delete params[key];
          }
        }
      } else {
        params.orderDate =
          params._orderDate && params._orderDate.length
            ? `${params._orderDate[0]},${params._orderDate[1]}`
            : '';

        if (params._amount1 != '' && params._amount2 != '') {
          params.amount = `${(params._amount1 * 1000).toFixed(3)},${(
            params._amount2 * 1000
          ).toFixed(3)}`;
        }

        if (params._sumTax1 != '' && params._sumTax2 != '') {
          params.sumTax = `${params._sumTax1},${params._sumTax2}`;
        }
      }

      return params;
    },

    getList() {
      this.loading = true;

      let params = this.formatParams(
        this.filtrateV == 1 ? this.quickParams : this.queryParams
      );

      list(params).then((res) => {
        this.tableData = res.data.list;
        this.total = res.data.total;
        this.loading = false;
      });
    },

    getRangeDate(type) {
      let start = this.$dayjs().startOf(type).format('YYYY-MM-DD');
      let end = this.$dayjs().endOf(type).format('YYYY-MM-DD');

      return `${start},${end}`;
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      if (
        column.property === 'productName' ||
        column.property === 'productSpec'
      ) {
        return 'background: #FAFAFB; font-weight: 600; font-size: 14px; color: #000000;line-height: 15px;';
      }

      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },
    handleScreen() {
      this.$refs.screenIcon.click();
    },
    handleScreenToggle(val) {
      this.isFullScreen = val;
      // console.log(val, 123);
    },
    handleCollapseChange() {
      // this.$refs['market_price_type'].calTableHeight()
    },
  },
};
</script>

<style lang="scss" scoped>

  .link {
    text-decoration: initial;
    color: #0000ff;

    &:link {
      color: #0000ff;
    }

    // &:visited {
    //   color: purple;
    // }
  }
.between-footer {
  display: flex;
  justify-content: space-between;
}
.component_title {
  padding: 10px 30px 0 20px;
}
::v-deep .el-collapse-item__content {
  padding-bottom: 0 !important;
}
</style>
