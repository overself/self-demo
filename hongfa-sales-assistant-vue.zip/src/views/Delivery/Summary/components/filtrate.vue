<template>
  <div class="filtrate-wrapper">
    <el-radio-group v-model="filtrateV">
      <el-radio label="2">条件查询</el-radio>
      <el-radio label="1">快速查询</el-radio>
    </el-radio-group>

    <div>
      <!-- 快速查询 -->
      <div v-show="filtrateV == 1">
        <BaseSearchContainer
          ref='hookQuick'
          type="quick"
          :column="filtrateList"
          @onSearch="handleQuery"
          @onReset="resetQuery"
        />
      </div>

      <!-- 条件查询 -->
      <div
        v-show="filtrateV == 2"
        style="padding-top: 10px;"
      >
        <BaseSearchContainer
          ref='hookQuery'
          labelWidth="105px"
          :column="queryList"
          :params="queryParams"
          is-collapse
          @cityChange="onCityChange"
          @toggleCollapse="toggleCollapse"
          @onSearch="handleQuery"
          @onReset="resetQuery"
        >
          <template #productTypes>
            <el-select
              v-model="queryParams.productTypes"
              placeholder="请选择品类"
              clearable
              filterable
              style="width: 240px;"
              @change="onProductCategoryChange"
            >
              <el-option
                v-for="item in productCategoryList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </template>

          <template #_productName>
            <el-select
              v-model="queryParams._productName"
              placeholder="请选择品项"
              clearable
              filterable
              allow-create
              style="width: 240px;"
              @change="onProductNameChange"
            >
              <el-option
                v-for="item in productCodeList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
                <span class="st-name-spec">{{item.name}} / {{item.spec}}</span>
              </el-option>
            </el-select>
          </template>

          <template #salePerson>
            <el-select
              clearable
              v-model="queryParams._salePerson"
              placeholder="请选择归属销售"
              style="width: 240px"
              filterable
              @change="onSalePersonChange"
            >
              <el-option
                v-for="item in belongListOp"
                :key="item.id"
                :value="item.id"
                :label="item.nickname"
              ></el-option>
            </el-select>
          </template>
        </BaseSearchContainer>
      </div>
    </div>
  </div>
</template>

<script>
import BaseSearchContainer from '@/components/BaseSearchContainer/index';
import { deepClone } from '@/utils';
import { getProductOptions } from '@/api/delivery/salesDelivery/index';
import { getBelong } from '@/api/Client/index';

export default {
  components: {
    BaseSearchContainer,
  },

  props: {
    queryParams: {
      type: Object,
      default: () => {},
    },
  },

  data() {
    return {
      filtrateV: '2',
      filtrateList: [
        {
          label: '归属工厂',
          key: 'FACTORY',
          prop: 'factories',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: true,
          dicData: [], // 字典
        },
        {
          label: '业务部门',
          prop: 'deptId',
          key: 'BELONG_AREA',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: false,
          // dicData: this.getDictDatas('hfywbm'),
          dicData: [],
        },
        {
          label: '客户分类',
          prop: 'customerTypes',
          key: 'CUSTOMER_TYPES',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: true,
          // dicData: this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE),
          dicData: [],
        },
        // {
        //   label: '销售渠道',
        //   prop: 'channelNames',
        //   key: 'CHANNEL',
        //   index: [],
        //   type: 'select',
        //   search: true,
        //   quick: true,
        //   multiple: true,
        //   dicUrl: '/system/channel/simple-list',
        //   dicQuery: {
        //     status: 1,
        //   },
        //   dicData: [], // 字典
        //   unshiftAll: true,
        // },
        {
          label: '品项分类',
          prop: 'productTypes', // 插槽级联
          key: 'CATEGORY',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: true,
          dicData: [], // 字典
        },
        {
          label: '客户状态',
          prop: 'warningStatus',
          key: 'CUSTOMER_STATUS',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: true,
          dicData: [
            { label: '全部', value: 'all' },
            { label: '计划预警', value: 'jh' },
            { label: '流失预警', value: 'ls' },
            { label: '跟进预警', value: 'gj' },
            { label: '出库量预警', value: 'ck' },
          ],
        },
        {
          label: '出库额范围',
          prop: '_sumTax',
          key: 'DELIVERY_RANGE',
          index: -1,
          startProp: 'sumTax1',
          startUnit: '元',
          endProp: 'sumTax2',
          endUnit: '元',
          type: 'inputRange',
          search: true,
          quick: true,
          dicData: [
            { label: '全部', value: 'all' },
            { label: '10万元以内', value: '0,100000' },
            { label: '10~30万元', value: '100000,300000' },
            { label: '30~50万元', value: '300000,500000' },
            { label: '50万元以上', value: '500000,10000000' },
          ],
        },
        {
          label: '客户标签',
          prop: 'signIds',
          key: 'CUSTOMER_TAG',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: true,
          unshiftAll: true,
          dicUrl: '/system/sign/simple-list',
          dicData: [], // 接口获取
        },
        {
          label: '业务日期',
          prop: '_orderDate',
          key: 'BUSINESS_DATE',
          index: -1,
          type: 'daterange',
          search: true,
          quick: true,
          dicData: [
            { label: '本周', value: '1' },
            { label: '本月', value: '2' },
            { label: '本季', value: '3' },
            { label: '本年', value: '4' },
          ],
        },
        {
          label: '销售量范围',
          prop: '_amount',
          key: 'SALES_RANGE',
          index: -1,
          startProp: 'amount1',
          startUnit: '吨',
          endProp: 'amount2',
          endUnit: '吨',
          type: 'inputRange',
          search: false,
          quick: true,
          dicData: [
            { label: '全部', value: 'all' },
            { label: '10吨以内', value: '0,10000' },
            { label: '10~30吨', value: '10000,30000' },
            { label: '30~50吨', value: '30000,50000' },
            { label: '50吨以上', value: '50000,1000000' },
          ],
        },
      ],
      queryList: [
        {
          label: '业务部门',
          prop: 'deptId',
          key: 'BELONG_AREA',
          index: [],
          type: 'select',
          search: true,
          quick: false,
          multiple: false,
          dicData: this.getDictDatas('hfywbm'),
        },
        {
          label: '归属销售',
          prop: 'salePerson',
          key: 'BELONG_AREA',
          index: [],
          type: 'input',
          search: true,
          quick: false,
        },
        {
          label: '归属工厂',
          key: 'FACTORY',
          prop: 'factories',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: true,
          dicData: [], // 字典
        },
        {
          label: '客户状态',
          prop: 'warningStatus',
          key: 'CUSTOMER_STATUS',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: true,
          dicData: [
            { label: '计划预警', value: 'jh' },
            { label: '流失预警', value: 'ls' },
            { label: '跟进预警', value: 'gj' },
            { label: '出库量预警', value: 'ck' },
          ],
        },
        {
          label: '客户标签',
          prop: 'signIds',
          key: 'CUSTOMER_TAG',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: true,
          dicUrl: '/system/sign/simple-list',
          dicData: [], // 接口获取
        },
        {
          label: '业务日期',
          prop: '_orderDate',
          key: 'BUSINESS_DATE',
          index: -1,
          type: 'daterange',
          search: true,
          quick: true,
          dicData: [],
        },
        {
          label: '品类',
          prop: 'productTypes', // 插槽级联
          key: 'CATEGORY',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: false,
          dicData: [], // 字典
        },
        {
          // 插槽
          label: '品项',
          prop: '_productName',
          key: '',
          index: [],
          type: 'select',
          search: true,
          quick: true,
          multiple: false,
          dicData: [], // 字典
        },
        {
          label: '客户名称',
          prop: 'customerName',
          index: [],
          type: 'input',
          search: true,
          quick: true,
        },
        {
          label: '送货客户名称',
          prop: 'sendCustomerName',
          index: [],
          type: 'input',
          search: true,
          quick: true,
        },
        {
          label: '所在区域',
          prop: '_locationCity',
          type: 'city',
          search: true,
          cascaderProp: {
            checkStrictly: true,
          },
        },
        {
          label: '是否批价',
          prop: 'isApprovePrice',
          type: 'select',
          search: true,
          dicData: [
            { label: '是', value: true },
            { label: '否', value: false },
          ],
        },
        {
          label: '单据编号',
          prop: 'orderNo',
          type: 'input',
          search: true,
        },
        {
          label: '出库量范围',
          prop: '_amount',
          key: 'SALES_RANGE',
          index: -1,
          startProp: '_amount1',
          startUnit: '吨',
          endProp: '_amount2',
          endUnit: '吨',
          type: 'inputRange',
          search: true,
          dicData: [
            { label: '10吨以内', value: '0,10000' },
            { label: '10~30吨', value: '10000,30000' },
            { label: '30~50吨', value: '30000,50000' },
            { label: '50吨以上', value: '50000,1000000' },
          ],
        },
        {
          label: '出库额范围',
          prop: '_sumTax',
          key: 'DELIVERY_RANGE',
          index: -1,
          startProp: '_sumTax1',
          startUnit: '元',
          endProp: '_sumTax2',
          endUnit: '元',
          type: 'inputRange',
          search: true,
          quick: true,
          dicData: [
            { label: '10万元以内', value: '0,100000' },
            { label: '10~30万元', value: '100000,300000' },
            { label: '30~50万元', value: '300000,500000' },
            { label: '50万元以上', value: '500000,10000000' },
          ],
        },
        // {
        //   label: '销售渠道',
        //   prop: 'channelNames',
        //   key: 'CHANNEL',
        //   index: [],
        //   type: 'select',
        //   search: true,
        //   quick: true,
        //   multiple: true,
        //   dicUrl: '/system/channel/simple-list',
        //   dicQuery: {
        //     status: 1,
        //   },
        //   dicData: [], // 字典
        // },
      ],
      productCategoryList: this.getDictDatas('category_classify'),
      productCodeList: [],
      belongListOp: [],
      belongListAll: [],
    };
  },

  watch: {
    filtrateV(newV) {
      if (newV == 2) {
        this.$refs.hookQuery.resetQuery('condition');
      } else {
        this.$refs.hookQuick.resetQuery('quick');
      }

      this.$emit('radioChange', newV);
    },
    'queryParams.deptId'(newVal, oldVal) {
      this.belongListOp = [];
      this.queryParams.salePerson = '';

      this.belongListAll.forEach((res) => {
        if (res.deptId == newVal) {
          this.belongListOp.push(res);
        }
      });
    },
  },

  created() {
    this.getBelong();

    this.filtrateList.forEach((item) => {
      if (item.key == 'FACTORY') {
        // 归属工厂
        this.filtrateListFormat('factory', item);
      }

      if (item.key == 'BELONG_AREA') {
        // 业务部门
        this.filtrateListFormat('hfywbm', item);
      }

      if (item.key == 'CUSTOMER_TYPES') {
        // 客户分类
        this.filtrateListFormat('customer_type', item);
      }

      if (item.key == 'CHANNEL') {
        // 销售渠道
        this.filtrateListFormat('sale_channel', item);
      }

      if (item.key == 'CATEGORY') {
        // 品类分类
        this.filtrateListFormat('category_classify', item);
      }
    });

    this.queryList.forEach((item) => {
      if (item.key == 'FACTORY') {
        // 归属工厂
        this.selectListFormat('factory', item);
      }

      if (item.key == 'CHANNEL') {
        // 销售渠道
        this.selectListFormat('sale_channel', item);
      }

      if (item.key == 'CATEGORY') {
        // 品类分类
        this.selectListFormat('category_classify', item);
      }
    });
  },

  methods: {
    toggleCollapse() {
      this.$emit('toggleCollapse', {
        type: 'condition',
      });
    },

    onProductNameChange(id) {
      this.queryParams.productName =
        this.productCodeList?.find((item) => item.id === id)?.name ??
        this.queryParams._productName; // 没找到取输入的
    },

    onCityChange(e) {
      this.queryParams.locationProvinceCode = e[0];
      this.queryParams.locationCityCode = e[1];
    },

    onSalePersonChange(id) {
      // console.log(id);
      this.queryParams.salePerson =
        this.belongListOp?.find((item) => item.id === id)?.nickname ?? '';
    },

    onRadioGroupChange() {
      this.$emit('typeChange', this.filtrateV);
    },

    onProductCategoryChange(e) {
      getProductOptions({
        type: e,
      }).then((res) => {
        this.productCodeList = res.data;
      });
    },

    handleQuery(e) {
      this.$emit('onSearch', {
        radioType: this.filtrateV,
        params: e,
      });
    },

    resetQuery() {
      this.$emit('onReset', {
        radioType: this.filtrateV,
      });
    },

    filtrateListFormat(dicKey, item) {
      let arr = deepClone(this.getDictDatas(dicKey));

      if (arr.length && arr[0].label != '全部') {
        arr.unshift({
          label: '全部',
          value: 'all',
        });
      }

      item.dicData = arr;
    },

    selectListFormat(dicKey, item) {
      item.dicData = deepClone(this.getDictDatas(dicKey));
    },

    async getBelong() {
      const res = await getBelong({ isSale: true });
      this.belongListAll = res.data;
    },
  },
};
</script>

<style lang="scss" scoped>
.filtrate-wrapper {
}
</style>
