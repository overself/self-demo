<template>
  <div class="app-container Board">
    <el-card class="box-card">
      <div
        slot="header"
        class="clearfix"
      >
        <span>基本信息</span>
        <el-button
          style="float: right;"
          size="small"
          @click="$router.back();"
        >返回</el-button>
      </div>

      <div>
        <el-descriptions
          title=""
          direction="vertical"
          :column="6"
          border
        >
          <el-descriptions-item label="单据编号">{{detail.orderNo}}</el-descriptions-item>
          <el-descriptions-item label="出库单日期">{{detail.orderDate}}</el-descriptions-item>
          <el-descriptions-item label="客户编码">{{detail.customerCode}}</el-descriptions-item>
          <el-descriptions-item label="客户名称">{{detail.customerName}}</el-descriptions-item>
          <el-descriptions-item label="客户分类">{{detail.customerTypeName}}</el-descriptions-item>
          <!-- <el-descriptions-item label="渠道类型">{{detail.channelType}}</el-descriptions-item> -->
          <!-- <el-descriptions-item label="出库单类型">{{detail.transType}}</el-descriptions-item> -->
          <!-- <el-descriptions-item label="客户联系人">{{detail.customerContact}}</el-descriptions-item> -->
          <!-- <el-descriptions-item label="联系方式">{{detail.customerContactTelephone}}</el-descriptions-item> -->
          <el-descriptions-item label="销售量(kg)">
            <span style="color: #ffcc00;">{{detail.allAmount | weightFormat(false, 2)}}kg</span>
          </el-descriptions-item>
          <el-descriptions-item label="出库单总金额(元)">
            <span style="color: #ffcc00;">￥{{detail.allSum | moneyFormat}}</span>
          </el-descriptions-item>
          <el-descriptions-item label="送货客户编码">{{detail.sendCustomerCode}}</el-descriptions-item>
          <el-descriptions-item label="送货客户名称">{{detail.sendCustomerName}}</el-descriptions-item>
          <el-descriptions-item label="付款方式">{{detail.payType}}</el-descriptions-item>
          <!-- <el-descriptions-item label="发票状态(预留)">暂无</el-descriptions-item> -->
        </el-descriptions>
      </div>
    </el-card>

    <el-card class="box-card">
      <div
        slot="header"
        class="clearfix"
      >
        <span>商品信息</span>
      </div>
      <div>
        <el-table
          :data="detail.orderProductDetails"
          border
          style="width: 100%;"
          :summary-method="getSummaries"
          :cell-style="addClass"
          show-summary
        >
          <el-table-column
            prop="factory"
            label="归属工厂"
            header-align="center"
            align="center"
          >
            <template slot-scope="scope">
              <span>{{objFactory[scope.row.factory]}}</span>
            </template>
          </el-table-column>

          <el-table-column
            prop="productCode"
            label="品项编码"
            header-align="center"
            align="center"
          ></el-table-column>

          <el-table-column
            prop="productName"
            label="品项名称"
            header-align="center"
            align="center"
            width="230"
          ></el-table-column>

          <el-table-column
            prop="productSpec"
            label="详细规格"
            header-align="center"
            align="center"
          ></el-table-column>

          <el-table-column
            prop="priceTax"
            label="价格表 单价(含税)"
            header-align="center"
            align="center"
          >
            <template slot-scope="scope">
              <span>{{scope.row.priceTax | moneyFormat}}元/kg</span>
            </template>
          </el-table-column>

          <el-table-column
            prop="approvePrice"
            label="出库单 单价(批价)"
            header-align="center"
            align="center"
          >
            <template slot-scope="scope">
              <div v-if="scope.row.isApprovePrice === true">
                <div style="color: #FF0000">是</div>
                <div>{{scope.row.approvePrice}}</div>
              </div>
              <span v-else>否</span>
            </template>
          </el-table-column>

          <el-table-column
            prop="amount"
            label="出库数量"
            header-align="center"
            align="center"
          >
            <template slot-scope="scope">
              <span>{{scope.row.amount | weightFormat(false, 2)}}kg</span>
            </template>
          </el-table-column>

          <el-table-column
            prop="sumTax"
            label="价税合计(元)"
            header-align="center"
            align="center"
          >
            <template slot-scope="scope">
              <span>￥{{scope.row.sumTax | moneyFormat}}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
  </div>
</template>

<script>
import { detail } from '@/api/delivery/returnOrder/index';

export default {
  data() {
    return {
      id: '',
      detail: {},
      objFactory: {
        bp_1_factory: '北票一厂',
        bp_2_factory: '北票二厂',
        cy_factory: '朝阳工厂',
        kz_ln_factory: '喀左工厂(龙鸟)',
        kz_yy_factory: '喀左工厂(远赢)',
        kz_factory: '喀左工厂',
        '-': '-',
      },
    };
  },

  created() {
    this.id = this.$route.params.orderId;
    this.getDetail();
  },

  methods: {
    getDetail() {
      detail(this.id).then((res) => {
        // console.log(res);
        this.detail = res.data;
      });
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 2 || columnIndex === 3) {
        return 'background: #FAFAFB; font-weight: 600; font-size: 14px; color: #000000;line-height: 15px;';
      }
      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },

    getSummaries(param) {
      const { columns, data } = param;
      const sums = [];

      columns.forEach((column, index) => {
        if (index === columns.length - 1) {
          const values = data.map((item) => Number(item[column.property]));
          if (!values.every((value) => isNaN(value))) {
            sums[index] = values.reduce((prev, curr) => {
              const value = Number(curr);
              if (!isNaN(value)) {
                return prev + curr;
              } else {
                return prev;
              }
            }, 0);
            sums[index] =
              '合计金额(元): ￥' +
              this.$options.filters.moneyFormat(Number(sums[index]));
          } else {
            sums[index] = 'N/A';
          }
        }
      });

      return sums;
    },
  },
};
</script>

<style lang="scss" scoped>
.box-card {
  margin-bottom: 8px;
}
</style>
