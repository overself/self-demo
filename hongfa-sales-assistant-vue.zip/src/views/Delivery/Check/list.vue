<!-- 价格库存看板 -->
<template>
  <div class="">
    <el-table
      :data="tableData"
      border
      style="width: 100%;"
      :cell-style="addClass"
      v-loading="loading"
    >
      <el-table-column
        prop="orderNo"
        label="单据编号"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <router-link
            class="link"
            :to="{ path: `/sales-delivery/info/${scope.row.id}`, }"
          >{{scope.row.orderNo}}</router-link>
        </template>
      </el-table-column>
      <el-table-column
        prop="orderDate"
        label="出库单日期"
        header-align="center"
        align="center"
      > </el-table-column>
      <el-table-column
        prop="customerName"
        label="客户简称"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <router-link
            class="link"
            :to="{ path: `/client-control/info/${scope.row.customerId}`, }"
          >{{scope.row.customerName}}</router-link>
        </template>
      </el-table-column>

      <!-- <el-table-column
        prop="customerCode"
        label="客户编码"
        header-align="center"
        align="center"
      > </el-table-column> -->

      <!-- <el-table-column
        prop="customerName"
        label="客户名称"
        header-align="center"
        align="center"
      > </el-table-column> -->

      <el-table-column
        prop="customerTypeName"
        label="客户分类"
        header-align="center"
        align="center"
      > </el-table-column>

      <!-- <el-table-column
        prop="sendCustomerCode"
        label="送货客户编码"
        header-align="center"
        align="center"
      > </el-table-column> -->

      <el-table-column
        prop="sendCustomerName"
        label="送货客户名称"
        header-align="center"
        align="center"
      > </el-table-column>

      <!-- 要处理成吨 返的是kg -->
      <el-table-column
        prop="allAmount"
        label="出库量（吨）"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <span>{{scope.row.allAmount | weightFormat(true) | removeTrailingZeros}}</span>
        </template>
      </el-table-column>

      <el-table-column
        prop="allSum"
        label="出库额（元）"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <span>{{scope.row.allSum | moneyFormat}}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="kingdeeSalePerson"
        label="EAS销售单 归属销售"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <span>{{scope.row.kingdeeSalePerson }}</span>
        </template>
      </el-table-column>

      <!-- <el-table-column
        prop="customerContactName"
        label="联系人"
        header-align="center"
        align="center"
      ></el-table-column> -->

      <!-- <el-table-column
        prop="departmentName"
        label="业务部门"
        header-align="center"
        align="center"
      ></el-table-column> -->

      <el-table-column
        prop="salePerson"
        label="助手系统 归属销售"
        header-align="center"
        align="center"
      > </el-table-column>

      <!-- <el-table-column
        prop="area"
        label="所属区域"
        header-align="center"
        align="center"
      >
      <template slot-scope="scope">
        <span v-if="scope.row.locationProvince && scope.row.locationCity">{{scope.row.locationProvince}}/{{scope.row.locationCity}}</span>
        <span v-else-if="scope.row.locationProvince">{{scope.row.locationProvince}}</span>
        <span v-else-if="scope.row.locationCity">{{scope.row.locationCity}}</span>
        <span v-else>-</span>
      </template>
      </el-table-column> -->

      <!-- <el-table-column
        prop="area"
        label="归属大区"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <span>{{scope.row.area || '宏发销售'}}</span>
        </template>
      </el-table-column> -->

      <!-- <el-table-column
        prop="isApprovePrice"
        label="是否批价"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div>
            <div v-if="scope.row.isApprovePrice === true">
              <div style="color: #FF0000">是</div>
              <div>{{scope.row.approvePrice}}</div>
            </div>
            <span v-else>否</span>
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="orderDate"
        label="出库单日期"
        header-align="center"
        align="center"
      > </el-table-column>

      <el-table-column
        label="操作"
        header-align="center"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template v-slot="scope">
          <el-button
            v-hasPermi="['system:outbound-order:query']"
            size="mini"
            type="text"
            @click="toDetail(scope.row.id)"
          >详情</el-button>
        </template>
      </el-table-column> -->
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="queryParams.pageNo"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
  </div>
</template>

<script>
import { list } from '@/api/delivery/salesDelivery/index';
// import { deepClone } from '@/utils';

export default {
  props: {
    queryParams: {
      type: Object,
      default: () => {},
    },
    formatQueryParams: {
      type: Function,
    },
  },

  data() {
    // 这里存放数据
    return {
      loading: false,
      tableData: [],
      total: 0,
      menuData: [],
      calcListData: [],
    };
  },

  methods: {
    toDetail(id) {
      this.$router.push({
        path: `/sales-delivery/info/${id}`,
      });
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      // if (columnIndex === 0) {
      //   return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      // }

      if (row[column.property] == null || row[column.property] === '') {
        row[column.property] = '-';
      }
    },

    getList() {
      this.loading = true;
      let params = this.formatQueryParams(this.queryParams);

      list(params)
        .then((res) => {
          this.loading = false;
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.total;
        })
        .catch(() => {
          this.loading = false;
        });
    },
  },
};
</script>

<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}

.link {
  text-decoration: initial;
  color: #0000ff;

  &:link {
    color: #0000ff;
  }

  // &:visited {
  //   color: purple;
  // }
}
</style>
