<template xmlns="">
  <div class="login-wrapper">
    <img
      class="login-bg"
      src="@/assets/images/bg.png"
      alt=""
      srcset=""
    >

    <div class="field-wrapper">
      <!-- 表单 -->
      <div class="field">
        <div class="title1">欢迎登录</div>
        <div class="title2">生食销售助手系统</div>

        <div class="field-form-wrapper">
          <img
            src="@/assets/images/login_form.png"
            alt=""
          >
        </div>

        <div class="form-cont">
          <div>
            <el-form
              ref="loginForm"
              :model="loginForm"
              :rules="LoginRules"
              class="login-form"
            >
              <div v-if="loginForm.loginType === 'uname'">
                <el-form-item
                  prop="username"
                  label="用户名"
                >
                  <el-input
                    style="width: 342px;"
                    v-model="loginForm.username"
                    type="text"
                    auto-complete="off"
                    placeholder="请输入用户名"
                  >
                    <img
                      slot="prefix"
                      class="el-input__icon input-icon login-input-icon"
                      src="@/assets/images/login_username.png"
                      alt=""
                    >
                    <!-- <svg-icon
                      slot="prefix"
                      icon-class="user"
                      class="el-input__icon input-icon"
                    /> -->
                  </el-input>
                </el-form-item>

                <el-form-item
                  prop="password"
                  label="密码"
                >
                  <el-input
                    v-model="loginForm.password"
                    type="password"
                    auto-complete="off"
                    placeholder="请输入密码"
                    style="width: 342px;"
                    @keyup.enter.native="getCode"
                  >
                    <img
                      slot="prefix"
                      class="el-input__icon input-icon login-input-icon"
                      src="@/assets/images/login_password.png"
                      alt=""
                    >
                    <!-- <svg-icon
                      slot="prefix"
                      icon-class="password"
                      class="el-input__icon input-icon"
                    /> -->
                  </el-input>
                </el-form-item>
                <!-- <el-checkbox
                  v-model="loginForm.rememberMe"
                  style="margin:0 0 25px 0;"
                >记住密码</el-checkbox> -->
              </div>

              <!-- 短信验证码登录 -->
              <div v-if="loginForm.loginType === 'sms'">
                <el-form-item prop="mobile">
                  <el-input
                    v-model="loginForm.mobile"
                    type="text"
                    auto-complete="off"
                    placeholder="请输入手机号"
                  >
                    <svg-icon
                      slot="prefix"
                      icon-class="phone"
                      class="el-input__icon input-icon"
                    />
                  </el-input>
                </el-form-item>
                <el-form-item prop="mobileCode">
                  <el-input
                    v-model="loginForm.mobileCode"
                    type="text"
                    auto-complete="off"
                    placeholder="短信验证码"
                    class="sms-login-mobile-code-prefix"
                    @keyup.enter.native="handleLogin"
                  >
                    <template>
                      <svg-icon
                        slot="prefix"
                        icon-class="password"
                        class="el-input__icon input-icon"
                      />
                    </template>
                    <template slot="append">
                      <span
                        v-if="mobileCodeTimer <= 0"
                        class="getMobileCode"
                        @click="getSmsCode"
                        style="cursor: pointer;"
                      >获取验证码</span>
                      <span
                        v-if="mobileCodeTimer > 0"
                        class="getMobileCode"
                      >{{ mobileCodeTimer }}秒后可重新获取</span>
                    </template>
                  </el-input>
                </el-form-item>
              </div>

              <!-- 下方的登录按钮 -->
              <el-form-item style="width:100%;">
                <el-button
                  :loading="loading"
                  size="medium"
                  type="primary"
                  class="login-btn"
                  @click.native.prevent="getCode"
                >
                  <span v-if="!loading">登 录</span>
                  <span v-else>登 录 中...</span>
                </el-button>
                <div style="display: flex;justify-content: center;margin-top: 20px;">
                  <div>
                    <span @click="open('apk')">
                      <el-avatar style="backgroundColor: #2b628b;margin-right: 30px;cursor:pointer;" size="small"><img src="@/assets/images/apkimg.png"></el-avatar>
                    </span>
                    <span @click="open('ios')">
                      <el-avatar style="backgroundColor: #548c81;cursor:pointer;" size="small"><img src="@/assets/images/apple.png"></el-avatar>
                    </span>
                  </div>
                </div>
              </el-form-item>

            </el-form>
          </div>
        </div>
      </div>
    </div>
<el-dialog
          title="安卓二维码"
          :visible="apkVisible"
          @close="apkVisible=false"
          width="16%"
        >
        <img src="@/assets/images/apk.png" alt="安卓二维码" class="logo_view">
        </el-dialog >
        <el-dialog
              title="苹果二维码"
              :visible="iosVisible"
              @close="iosVisible=false"
              width="16%"
            >
            <img src="@/assets/images/ios.png" alt="苹果二维码" class="logo_view">
            </el-dialog >
    <!-- 图形验证码 -->
    <Verify
      ref="verify"
      :captcha-type="'blockPuzzle'"
      :img-size="{width:'400px',height:'200px'}"
      @success="handleLogin"
    />

  </div>
</template>

<script>
import {
  getPassword,
  getUsername,
  getRememberMe,
  removePassword,
  removeRememberMe,
  removeUsername,
  setPassword,
  setRememberMe,
  setUsername,
} from '@/utils/auth';
import { getCaptchaEnable } from '@/utils/ruoyi';
import Verify from '@/components/Verifition/Verify';
import { resetUserPwd } from '@/api/system/user';

export default {
  name: 'Login',
  components: {
    Verify,
  },
  data() {
    return {
      apkVisible:false,
      iosVisible:false,
      codeUrl: '',
      captchaEnable: true,
      mobileCodeTimer: 0,
      loginForm: {
        loginType: 'uname',
        username: '',
        password: '',
        captchaVerification: '',
        mobile: '',
        mobileCode: '',
        rememberMe: false,
      },
      scene: 21,

      LoginRules: {
        username: [
          { required: true, trigger: 'blur', message: '用户名不能为空' },
        ],
        password: [
          { required: true, trigger: 'blur', message: '密码不能为空' },
        ],
        mobile: [
          { required: true, trigger: 'blur', message: '手机号不能为空' },
          {
            validator: function (rule, value, callback) {
              if (
                /^(?:(?:\+|00)86)?1(?:3[\d]|4[5-79]|5[0-35-9]|6[5-7]|7[0-8]|8[\d]|9[189])\d{8}$/.test(
                  value
                ) === false
              ) {
                callback(new Error('手机号格式错误'));
              } else {
                callback();
              }
            },
            trigger: 'blur',
          },
        ],
      },
      loading: false,
      redirect: undefined,
    };
  },
  created() {
    // 验证码开关
    this.captchaEnable = getCaptchaEnable();
    // 重定向地址
    this.redirect = this.$route.query.redirect
      ? decodeURIComponent(this.$route.query.redirect)
      : undefined;
    this.getCookie();
  },
  methods: {
    open(type){
      if(type=='apk'){
        this.apkVisible=true
      }else if(type=='ios'){
        this.iosVisible=true
      }
    },
    getCode() {
      // 情况一，未开启：则直接登录
      // if (!this.captchaEnable) {
         this.handleLogin({});
      //   return;
      // }

      // 情况二，已开启：则展示验证码；只有完成验证码的情况，才进行登录
      // 弹出验证码
      //this.$refs.verify.show();
    },
    getCookie() {
      const username = getUsername();
      const password = getPassword();
      const rememberMe = getRememberMe();
      this.loginForm = {
        ...this.loginForm,
        username: username ? username : this.loginForm.username,
        password: password ? password : this.loginForm.password,
        rememberMe: rememberMe ? getRememberMe() : false,
      };
    },
    handleLogin(captchaParams) {
      this.$refs.loginForm.validate((valid) => {
        if (valid) {
          this.loading = true;
          // 设置 Cookie
          if (this.loginForm.rememberMe) {
            setUsername(this.loginForm.username);
            setPassword(this.loginForm.password);
            setRememberMe(this.loginForm.rememberMe);
          } else {
            removeUsername();
            removePassword();
            removeRememberMe();
          }
          this.loginForm.captchaVerification =
            captchaParams.captchaVerification;
          // console.log("发起登录", this.loginForm);
          this.$store
            .dispatch(
              this.loginForm.loginType === 'sms' ? 'SmsLogin' : 'Login',
              this.loginForm
            )
            .then(() => {
              this.$router.push({ path: this.redirect || '/' }).catch(() => {});
            })
            .catch(() => {
              this.loading = false;
            });
        }
      });
    },

    /** ========== 以下为升级短信登录 ========== */
    getSmsCode() {
      if (this.mobileCodeTimer > 0) return;
      this.$refs.loginForm.validate((valid) => {
        if (!valid) return;
        sendSmsCode(
          this.loginForm.mobile,
          this.scene,
          this.loginForm.uuid,
          this.loginForm.code
        ).then((res) => {
          this.$modal.msgSuccess('获取验证码成功');
          this.mobileCodeTimer = 60;
          let msgTimer = setInterval(() => {
            this.mobileCodeTimer = this.mobileCodeTimer - 1;
            if (this.mobileCodeTimer <= 0) {
              clearInterval(msgTimer);
            }
          }, 1000);
        });
      });
    },
  },
};
</script>
<style lang="scss" scoped>
@import '~@/assets/styles/login.scss';

  .logo_view {
    height: 200px;
    width: 200px;
  }

.oauth-login {
  display: flex;
  align-items: center;
  cursor: pointer;
}
.oauth-login-item {
  display: flex;
  align-items: center;
  margin-right: 10px;
}
.oauth-login-item img {
  height: 25px;
  width: 25px;
}
.oauth-login-item span:hover {
  text-decoration: underline red;
  color: red;
}
.sms-login-mobile-code-prefix {
  :deep(.el-input__prefix) {
    top: 22%;
  }
}
</style>
