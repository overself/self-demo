<template>
  <div>
    <CrudHeader>
      <template slot="left">
        <el-tabs v-model="activeIn" @tab-click="tabClick">
          <el-tab-pane label="每周考核配置" name="1">
            <div class="list_wrap">
              <el-radio-group v-model="weekOutQuery.area" style="margin-bottom: 20px;" @change="changeFactory">
                <el-radio-button :label="item.name" v-for="(item, index) in factoryList" :key="item.name">{{item.label}}</el-radio-button>
              </el-radio-group>
              <BaseSearchContainer :column="searchColumn" :params="weekOutQuery" :show-reset-btn="false" @onSearch="onTableSearch">
              </BaseSearchContainer>
              <el-row :gutter="10" class="mb20">
                <el-col :span="1.5">
                  <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="addNewWeek('addWeek')">新增</el-button>
                </el-col>
              </el-row>
              <el-table :data="weekOutData" border style="width: 100%; margin-top: 20px;" v-loading="weekOutLoading"
                :span-method="objectSpanMethod">
                <el-table-column label="周" width="100" align="center">
                  <template slot-scope="scope">
                    <span v-if="scope.row.week==1">第一周</span>
                    <span v-else-if="scope.row.week==2">第二周</span>
                    <span v-else-if="scope.row.week==3">第三周</span>
                    <span v-else-if="scope.row.week==4">第四周</span>
                  </template>
                </el-table-column>
                <el-table-column prop="nickName" label="业务员" width="100" align="center"></el-table-column>
                <el-table-column prop="productName" label="品项" align="center"></el-table-column>
                <el-table-column prop="factoryName" label="工厂" align="center"></el-table-column>
                <el-table-column prop="rewardSales" label="任务量" align="center"></el-table-column>
                <el-table-column prop="rewardLine" label="基数" align="center"></el-table-column>
                <el-table-column prop="action" label="操作" align="center">
                  <template slot-scope="scope">
                    <el-button slot="reference" size="small" type="text" @click="editWeek(scope.row)" style="margin-right: 10px;">编辑
                    </el-button>
                    <el-popconfirm title="确定删除吗？" @confirm="deleteWeek(scope.row)">
                      <el-button slot="reference" size="small" type="text">删除</el-button>
                    </el-popconfirm>
                  </template>
                </el-table-column>
              </el-table>
              <!-- 新增/编辑 -->
              <el-dialog :title="weekType=='add'?'新增考核':'编辑考核'" :visible.sync="editWeekTrue" width="400px" append-to-body>
                <el-form :rules="weekRules" :model="addWeek" ref="addWeek" size="small" label-width="100px">
                  <el-form-item label="月份" prop="yearmonth">
                    <el-date-picker placeholder="请选择月份" :clearable="false" style="width: 240px" v-model="addWeek.yearmonth" type="month"
                      value-format="yyyy-MM">
                    </el-date-picker>
                  </el-form-item>
                  <el-form-item label="周" prop="week">
                    <el-select v-model="addWeek.week" placeholder="请选择周">
                      <el-option v-for="item in weekOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="业务员" prop="userId">
                    <el-select v-model="addWeek.userId" placeholder="请选择业务员" filterable>
                      <el-option v-for="item in belongList" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="品项" prop="productName">
                    <el-tooltip effect="dark" :content="addWeek.productName" placement="top">
                      <el-input v-model="addWeek.productName" disabled style="width: 240px">
                        <template slot="append"> <a @click="selectWeek()" style="color: blue;">选择品项</a></template>
                      </el-input>
                    </el-tooltip>
                  </el-form-item>
                  <el-form-item label="工厂" prop="factory">
                    <el-select multiple v-model="addWeek.factory" placeholder="请选择工厂" style="width: 240px" filterable clearable>
                      <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="任务量" prop="rewardSales">
                    <el-input-number :controls="false" :min="0" v-model="addWeek.rewardSales" placeholder="请输入额度" style="width: 240px" />
                  </el-form-item>
                  <el-form-item label="基数" prop="rewardLine">
                    <el-input-number :controls="false" :min="0" v-model="addWeek.rewardLine" placeholder="请输入提成" style="width: 240px" />
                  </el-form-item>
                  <!-- <el-form-item label="扣款" prop="fine">
                    <el-input-number :controls="false" :min="0" v-model="addWeek.fine" placeholder="请输入扣款" style="width: 240px" />
                  </el-form-item> -->
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button :loading="submitWeekLoading" type="primary" @click="submitNewWeek('addWeek')">确 定</el-button>
                  <el-button @click="closeNewWeek">取 消</el-button>
                </div>
              </el-dialog>
              <!-- 新增 -->
              <el-dialog title="选择品项" :visible.sync="openWeek" width="1200px" append-to-body @close="closeWeek">
                <el-form :model="weekInQuery" ref="weekInQuery" size="small" :inline="true" label-width="100px">
                  <el-form-item label="分类" prop="type">
                    <el-select clearable v-model="weekInQuery.type" placeholder="请选择分类" style="width: 140px">
                      <el-option v-for="item in searchProductTypeList" :key="item.value" :value="item.value" :label="item.label">
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="品项编码" prop="code">
                    <el-input v-model="weekInQuery.code" placeholder="请输入编码" clearable style="width: 240px" />
                  </el-form-item>
                  <el-form-item label="品项名称" prop="name">
                    <el-input v-model="weekInQuery.name" placeholder="请输入品项" clearable style="width: 240px" />
                  </el-form-item>
                  <el-form-item>
                    <el-button icon="el-icon-search" @click="getWeekInList(true)">查询</el-button>
                    <el-button icon="el-icon-refresh" @click="resetWeekInQuery">重置</el-button>
                  </el-form-item>
                </el-form>
                <el-table max-height="500" row-key="id" :data="weekInData" border style="width: 100%;" v-loading="weekLoading"
                  @selection-change="selectWeekRow" ref="selectWeekTable">
                  <!-- <el-table-column width="33" align="center">
                    <template slot-scope="scope">
                      <el-radio :label="scope.row.id" v-model="selectWeekId" @change="handleRadioChange(scope.row)">&nbsp;</el-radio>
                    </template>
                  </el-table-column> -->
                  <el-table-column type="selection" width="55" align="center" :reserve-selection="true" />
                  <el-table-column prop="productTypeName" width="100" label="品项分类" align="center"></el-table-column>
                  <el-table-column prop="code" label="品项编码" align="center"></el-table-column>
                  <el-table-column prop="name" label="品项名称" align="center"> </el-table-column>
                  <el-table-column prop="spec" label="详细规格" align="center"> </el-table-column>
                </el-table>
                <!-- <pagination v-show="weekInQuery.total>0" :total="weekInQuery.total" :page.sync="weekInQuery.pageNo"
                  :limit.sync="weekInQuery.pageSize" @pagination="getWeekInList(false)" /> -->
                <div slot="footer" class="dialog-footer">
                  <el-button type="primary" @click="submitWeekForm">确 定</el-button>
                  <el-button @click="closeWeek">取 消</el-button>
                </div>
              </el-dialog>
            </div>
          </el-tab-pane>
          <el-tab-pane label="品项提成配置" name="2">
            <div class="list_wrap">
              <el-radio-group v-model="goodsOutQuery.type" style="margin-bottom: 20px;" @change="changeClassify">
                <el-radio-button :label="item.name" v-for="(item, index) in classifyList" :key="index">{{item.label}}</el-radio-button>
              </el-radio-group>
              <el-form :model="goodsOutQuery" ref="goodsOutQuery" size="small" :inline="true" label-width="100px">
                <el-form-item label="分类" prop="productType">
                  <el-select clearable v-model="goodsOutQuery.productType" placeholder="请选择分类" style="width: 140px">
                    <el-option v-for="item in searchProductTypeList" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="品项编码" prop="productCode">
                  <el-input v-model="goodsOutQuery.productCode" placeholder="请输入编码" clearable style="width: 240px" />
                </el-form-item>
                <el-form-item label="品项名称" prop="productName">
                  <el-input v-model="goodsOutQuery.productName" placeholder="请输入品项" clearable style="width: 240px" />
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="getGoodsOutList(true)">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="resetGoodsOutQuery">重置</el-button>
                </el-form-item>
              </el-form>
              <el-row :gutter="10" class="mb20">
                <el-col :span="1.5">
                  <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="selectGoods('add')">新增</el-button>
                  <el-button type="text" size="medium" style="margin-left: 10px;" @click="selectGoods('confirm')">待确认品项<span
                      style="color: red;">{{queryConfirmData}}</span></el-button>
                </el-col>
              </el-row>
              <el-table :data="goodsOutData" border style="width: 100%;margin-top: 20px;" v-loading="goodsOutLoading">
                <el-table-column type="index" label="#" width="55" align="center" />
                <el-table-column prop="label" width="120" label="分类" align="center" />
                <el-table-column prop="productCode" label="品项编码" align="center" />
                <el-table-column prop="productName" label="品项名称" align="center" />
                <el-table-column prop="market" width="160" label="市场提成" align="center">
                  <template slot-scope="scope">
                    <el-input-number :controls="false" :min="0" class="def-input-number" :key='"goodsMarketInput"+scope.$index'
                      v-if="goodsRowIndex==scope.$index" v-model="scope.row.market" placeholder="请输入市场提成价格" style="width: 100%;">
                    </el-input-number>
                    <span v-else>{{scope.row.market}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="high" width="160" label="高端提成" align="center">
                  <template slot-scope="scope">
                    <el-input-number :controls="false" :min="0" class="def-input-number" :key='"goodsHighInput"+scope.$index'
                      v-if="goodsRowIndex==scope.$index" v-model="scope.row.high" placeholder="请输入高端提成价格" style="width: 100%;">
                    </el-input-number>
                    <span v-else>{{scope.row.high}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="action" width="200" label="操作" align="center" class-name="small-padding fixed-width">
                  <template slot-scope="scope">
                    <el-button slot="reference" v-if="goodsRowIndex!=scope.$index" size="small" type="text" style="margin-right: 10px;"
                      @click="editGoods(scope.$index)">编辑</el-button>
                    <el-button slot="reference" v-if="goodsRowIndex==scope.$index" size="small" type="text" style="margin-right: 10px;"
                      @click="saveGoods(scope.row)">保存</el-button>
                    <el-popconfirm v-else title="确定删除吗？" @confirm="deleteGoods(scope.row)">
                      <el-button slot="reference" size="small" type="text">删除</el-button>
                    </el-popconfirm>
                  </template>
                </el-table-column>
              </el-table>
              <pagination v-show="goodsOutQuery.total>0" :total="goodsOutQuery.total" :page.sync="goodsOutQuery.pageNo"
                :limit.sync="goodsOutQuery.pageSize" @pagination="getGoodsOutList()" />
              <!-- 选择品项 -->
              <el-dialog title="选择品项" :visible.sync="openGoods" width="1200px" append-to-body @close="closeGoods">
                <el-form :model="goodsInQuery" ref="goodsInQuery" size="small" :inline="true" label-width="100px">
                  <el-form-item label="分类" prop="type">
                    <el-select clearable v-model="goodsInQuery.type" placeholder="请选择分类" style="width: 140px">
                      <el-option v-for="item in searchProductTypeList" :key="item.value" :value="item.value" :label="item.label">
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="品项编码" prop="code" v-if="openGoodsType == 'add'">
                    <el-input v-model="goodsInQuery.code" placeholder="请输入编码" clearable style="width: 240px" />
                  </el-form-item>
                  <el-form-item label="品项名称" prop="name" v-if="openGoodsType == 'add'">
                    <el-input v-model="goodsInQuery.name" placeholder="请输入品项" clearable style="width: 240px" />
                  </el-form-item>
                  <el-form-item label="日期" prop="date" v-if="openGoodsType == 'confirm'">
                    <el-date-picker :clearable="false" @change="changeDate" style="width: 240px" v-model="goodsInQuery.dateRange"
                      type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="yyyy-MM-dd">
                    </el-date-picker>
                  </el-form-item>
                  <el-form-item>
                    <el-button icon="el-icon-search" @click="getGoodsInList(true)">查询</el-button>
                    <el-button icon="el-icon-refresh" @click="resetGoodsInQuery">重置</el-button>
                  </el-form-item>
                </el-form>
                <el-table row-key="id" :data="goodsData" border style="width: 100%;" v-loading="goodsLoading"
                  @selection-change="selectGoodsRow" ref="selectGoodsTable">
                  <el-table-column type="selection" width="55" align="center" :reserve-selection="true" />
                  <el-table-column type="index" width="50" label="序号" align="center"></el-table-column>
                  <el-table-column prop="productTypeName" width="100" label="品项分类" align="center"></el-table-column>
                  <el-table-column prop="code" label="品项编码" align="center"></el-table-column>
                  <el-table-column prop="name" label="品项名称" align="center"> </el-table-column>
                  <el-table-column prop="spec" label="详细规格" align="center"> </el-table-column>
                </el-table>
                <!-- <pagination v-show="goodsInQuery.total>0" :total="goodsInQuery.total" :page.sync="goodsInQuery.pageNo"
                  :limit.sync="goodsInQuery.pageSize" @pagination="getGoodsInList(false)" /> -->
                <div slot="footer" class="dialog-footer">
                  <el-button type="primary" @click="submitGoodsForm">确 定</el-button>
                  <el-button @click="closeGoods">取 消</el-button>
                </div>
              </el-dialog>
              <!-- 统一编辑价格 -->
              <el-dialog title="编辑价格" :visible.sync="editGoodsTrue" width="400px" append-to-body @close="closeNewGoods('addGoods')">
                <el-form :rules="goodsRules" :model="addGoods" ref="addGoods" size="small" label-width="100px">
                  <el-form-item label="市场提成" prop="market">
                    <el-input-number :controls="false" :min="0" v-model="addGoods.market" placeholder="请输入市场提成" style="width: 240px" />
                  </el-form-item>
                  <el-form-item label="高端提成" prop="high">
                    <el-input-number :controls="false" :min="0" v-model="addGoods.high" placeholder="请输入高端提成" style="width: 240px" />
                  </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button type="primary" @click="submitNewGoods('addGoods')">确 定</el-button>
                  <el-button @click="closeNewGoods('addGoods')">取 消</el-button>
                </div>
              </el-dialog>
            </div>
          </el-tab-pane>
          <el-tab-pane label="集团客户配置" name="3">
            <div class="list_wrap">
              <el-form :model="clientOutQuery" ref="clientOutQuery" size="small" :inline="true" label-width="100px">
                <el-form-item label="客户分类" prop="customerType">
                  <el-select clearable v-model="clientOutQuery.customerType" placeholder="请选择客户分类" style="width: 240px">
                    <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="归属销售" prop="userId">
                  <el-select v-model="clientOutQuery.userId" placeholder="请选择归属销售" style="width: 240px" filterable clearable>
                    <el-option v-for="item in belongListOp" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="客户编码" prop="customerCode">
                  <el-input v-model="clientOutQuery.customerCode" placeholder="请输入客户编码" clearable style="width: 240px" />
                </el-form-item>
                <el-form-item label="客户名称" prop="customerName">
                  <el-input v-model="clientOutQuery.customerName" placeholder="请输入客户名称" clearable style="width: 240px" />
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="getClientOutList(true)">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="resetClientOutQuery">重置</el-button>
                </el-form-item>
              </el-form>
              <el-row :gutter="10" class="mb20">
                <el-col :span="1.5">
                  <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="selectClient">新增</el-button>
                </el-col>
              </el-row>
              <el-table :data="clientOutData" border style="width: 100%; margin-top: 20px;" @cell-click="editClient"
                v-loading="clientOutLoading">
                <el-table-column type="index" label="#" width="55" align="center" />
                <el-table-column prop="customerCode" label="客户编码" align="center"></el-table-column>
                <el-table-column prop="customerName" label="客户名称" align="center"> </el-table-column>
                <el-table-column prop="label" label="客户分类" align="center"></el-table-column>
                <el-table-column prop="nickname" label="归属销售" align="center"> </el-table-column>
                <el-table-column prop="reward" label="提成价格" align="center">
                  <template slot-scope="scope">
                    <el-input-number :controls="false" :min="0" class="def-input-number" :ref='"clientInput"+scope.$index'
                      :key='"clientInput"+scope.$index' v-if="clientRowIndex==scope.$index" v-model="scope.row.reward" placeholder="请输入提成价格"
                      @blur="editClientBlur(scope.row)" style="width: 100%;"></el-input-number>
                    <span v-else>{{scope.row.reward?scope.row.reward:0}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="action" label="操作" align="center">
                  <template slot-scope="scope">
                    <el-popconfirm title="确定删除吗？" @confirm="deleteClient(scope.row)">
                      <el-button slot="reference" size="small" type="text">删除</el-button>
                    </el-popconfirm>
                  </template>
                </el-table-column>
              </el-table>
              <pagination v-show="clientOutQuery.total>0" :total="clientOutQuery.total" :page.sync="clientOutQuery.pageNo"
                :limit.sync="clientOutQuery.pageSize" @pagination="getClientOutList()" />
              <!-- 新增 -->
              <el-dialog title="选择客户" :visible.sync="openClient" width="1000px" append-to-body @close="closeClient">
                <el-form :model="clientInQuery" ref="clientInQuery" size="small" :inline="true" label-width="100px">
                  <el-form-item label="客户分类" prop="type">
                    <el-select clearable v-model="clientInQuery.type" placeholder="请选择客户分类" style="width: 240px">
                      <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="归属销售" prop="belongSale">
                    <el-select v-model="clientInQuery.belongSale" placeholder="请选择归属销售" style="width: 240px" filterable clearable>
                      <el-option v-for="item in belongListOp" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="客户编码" prop="code">
                    <el-input v-model="clientInQuery.code" placeholder="请输入客户编码" clearable style="width: 240px" />
                  </el-form-item>
                  <el-form-item label="客户名称" prop="name">
                    <el-input v-model="clientInQuery.name" placeholder="请输入客户名称" clearable style="width: 240px" />
                  </el-form-item>
                  <el-form-item>
                    <el-button icon="el-icon-search" @click="getClientInList(true)">查询</el-button>
                    <el-button icon="el-icon-refresh" @click="resetClientInQuery">重置</el-button>
                  </el-form-item>
                </el-form>
                <el-table row-key="id" :data="clientInData" border style="width: 100%;" v-loading="clientLoading"
                  @selection-change="selectClientRow" ref="selectClientTable">
                  <el-table-column type="selection" width="55" align="center" :reserve-selection="true" />
                  <el-table-column prop="code" label="客户编码" align="center"></el-table-column>
                  <el-table-column prop="name" label="客户名称" align="center"> </el-table-column>
                  <el-table-column prop="label" label="客户分类" align="center"></el-table-column>
                  <el-table-column prop="nickname" label="归属销售" align="center"> </el-table-column>
                </el-table>
                <pagination v-show="clientInQuery.total>0" :total="clientInQuery.total" :page.sync="clientInQuery.pageNo"
                  :limit.sync="clientInQuery.pageSize" @pagination="getClientInList(false)" />
                <div slot="footer" class="dialog-footer">
                  <el-button type="primary" @click="submitClientForm">确 定</el-button>
                  <el-button @click="closeClient">取 消</el-button>
                </div>
              </el-dialog>
              <!-- 编辑 -->
              <el-dialog title="编辑提成" :visible.sync="openInClient" width="400px" append-to-body @close="closeAddClient('addClient')">
                <el-form :rules="clientRules" :model="addClient" ref="addClient" size="small" label-width="100px">
                  <el-form-item label="提成" prop="reward">
                    <el-input-number :controls="false" :min="0" v-model="addClient.reward" placeholder="请输入提成" style="width: 240px" />
                  </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button :loading="submitClientLoading" type="primary" @click="submitClientInForm('addClient')">确 定</el-button>
                  <el-button @click="closeAddClient('addClient')">取 消</el-button>
                </div>
              </el-dialog>
            </div>
          </el-tab-pane>
          <el-tab-pane label="工厂客户配置" name="4">
            <div class="list_wrap">
              <el-form :model="customerOutQuery" ref="customerOutQuery" size="small" :inline="true" label-width="100px">
                <el-form-item label="工厂" prop="factory">
                  <el-select v-model="customerOutQuery.factory" placeholder="请选择工厂" style="width: 240px" filterable clearable>
                    <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="客户名称" prop="customerName">
                  <el-input v-model="customerOutQuery.customerName" placeholder="请输入客户名称" clearable style="width: 240px" />
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="getCustomerOutList(true)">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="resetCustomerOutQuery">重置</el-button>
                </el-form-item>
              </el-form>
              <el-row :gutter="10" class="mb20">
                <el-col :span="1.5">
                  <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="addNewCustomer('addCustomer')">新增</el-button>
                </el-col>
              </el-row>
              <el-table :data="customerOutData" border style="width: 100%; margin-top: 20px;" v-loading="customerOutLoading">
                <el-table-column type="index" label="#" width="55" align="center" />
                <el-table-column prop="label" label="工厂" align="center"></el-table-column>
                <el-table-column prop="customerName" label="客户" align="center"> </el-table-column>
                <el-table-column prop="nickname" label="归属销售" align="center"> </el-table-column>
                <el-table-column prop="rewardSales" label="额度" align="center"></el-table-column>
                <!-- <el-table-column prop="reward" label="提成" align="center"></el-table-column> -->
                <el-table-column prop="action" label="操作" align="center">
                  <template slot-scope="scope">
                    <el-button slot="reference" size="small" type="text" @click="editCustomer(scope.row)" style="margin-right: 10px;">编辑
                    </el-button>
                    <el-popconfirm title="确定删除吗？" @confirm="deleteCustomer(scope.row)">
                      <el-button slot="reference" size="small" type="text">删除</el-button>
                    </el-popconfirm>
                  </template>
                </el-table-column>
              </el-table>
              <pagination v-show="customerOutQuery.total>0" :total="customerOutQuery.total" :page.sync="customerOutQuery.pageNo"
                :limit.sync="customerOutQuery.pageSize" @pagination="getCustomerOutList()" />
              <!--    <el-dialog title="选择客户" :visible.sync="openCustomer" width="1000px" append-to-body>
                <el-form :model="customerInQuery" ref="customerInQuery" size="small" :inline="true" label-width="100px">
                  <el-form-item label="客户分类" prop="type">
                    <el-select clearable v-model="customerInQuery.type" placeholder="请选择客户分类" style="width: 240px">
                      <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="归属销售" prop="belongSale">
                    <el-select v-model="customerInQuery.belongSale" placeholder="请选择归属销售" style="width: 240px" filterable clearable>
                      <el-option v-for="item in belongListOp" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="客户编码" prop="code">
                    <el-input v-model="customerInQuery.code" placeholder="请输入客户编码" clearable style="width: 240px" />
                  </el-form-item>
                  <el-form-item label="客户名称" prop="name">
                    <el-input v-model="customerInQuery.name" placeholder="请输入客户名称" clearable style="width: 240px" />
                  </el-form-item>
                  <el-form-item>
                    <el-button icon="el-icon-search" @click="getCustomerInList(false,true)">查询</el-button>
                    <el-button icon="el-icon-refresh" @click="resetCustomerInQuery">重置</el-button>
                  </el-form-item>
                </el-form>
                <el-table row-key="id" :data="customerInData" border style="width: 100%;" v-loading="customerLoading">
                  <el-table-column width="33" align="center">
                    <template slot-scope="scope">
                      <el-radio :label="scope.row.id" v-model="selectCustomerId" @change="handleChangeCustomer(scope.row)">&nbsp;</el-radio>
                    </template>
                  </el-table-column>
                  <el-table-column prop="code" width="150" label="客户编码" align="center"></el-table-column>
                  <el-table-column prop="fullName" label="客户名称" align="center"> </el-table-column>
                  <el-table-column prop="typeName" width="150" label="客户分类" align="center"></el-table-column>
                  <el-table-column prop="belongSaleName" width="150" label="归属销售" align="center"> </el-table-column>
                </el-table>
                <pagination v-show="customerInQuery.total>0" :total="customerInQuery.total" :page.sync="customerInQuery.pageNo"
                  :limit.sync="customerInQuery.pageSize" @pagination="getCustomerInList(false)" />
                <div slot="footer" class="dialog-footer">
                  <el-button type="primary" @click="submitCustomerForm">确 定</el-button>
                  <el-button @click="closeCustomerForm">取 消</el-button>
                </div>
              </el-dialog> -->
              <el-dialog :title="customerType=='add'?'新增客户':'编辑客户'" :visible.sync="openInCustomer" width="400px" append-to-body>
                <el-form :rules="customerRules" :model="addCustomer" ref="addCustomer" size="small" label-width="100px">
                  <el-form-item label="工厂" prop="factory">
                    <el-select v-model="addCustomer.factory" placeholder="请选择工厂">
                      <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="归属销售" prop="userId">
                    <el-select v-model="addCustomer.userId" placeholder="请选择归属销售" style="width: 240px" filterable clearable
                      @change="changeUserId">
                      <el-option v-for="item in belongListOp" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="客户" prop="customerCode">
                    <el-select v-model="addCustomer.customerCode" placeholder="请选择客户" style="width: 240px" filterable clearable
                      @change="changeClient">
                      <el-option v-for="item in customerListOp" :key="item.code" :value="item.code" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                  <!-- <el-form-item label="客户" prop="customerName">
                    <el-input v-model="addCustomer.customerName" disabled style="width: 240px">
                      <template slot="append"> <a @click="selectCustomer()" style="color: blue;">选择客户</a></template>
                    </el-input>
                  </el-form-item> -->
                  <el-form-item label="额度" prop="rewardSales">
                    <el-input-number :controls="false" :min="0" v-model="addCustomer.rewardSales" placeholder="请输入额度" clearable
                      style="width: 240px" />
                  </el-form-item>
                  <!-- <el-form-item label="提成" prop="reward">
                    <el-input-number :min="0" v-model="addCustomer.reward" placeholder="请输入提成" clearable style="width: 240px" />
                  </el-form-item> -->
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button :loading="submitCustomerLoading" type="primary" @click="submitCustomerInForm('addCustomer')">确 定</el-button>
                  <el-button @click="closeCustomerInForm">取 消</el-button>
                </div>
              </el-dialog>
            </div>
          </el-tab-pane>
        </el-tabs>
      </template>
    </CrudHeader>
  </div>
</template>

<script>
  import {
    weekCreate,
    weekPage,
    weekDelete,
    weekUpdate,
    weekGet,
    goodsCreate,
    goodsPage,
    goodsDelete,
    goodsUpdate,
    clientCreate,
    clientPage,
    clientDelete,
    clientUpdate,
    customerCreate,
    customerPage,
    customerDelete,
    customerUpdate,
    customerGet,
    customerList,
    listData,
    getCustomer,
    queryProduct,
    queryConfirm
  } from '@/api/teamwork/Allocate/index';
  import {
    listData as listDataWeek,
  } from '@/api/system/addAppearance/index';
  import {
    getBelong,
  } from '@/api/Client/index';
  import {
    deepClone
  } from '@/utils';
  import BaseSearchContainer from "@/components/BaseSearchContainer";
  export default {
    components: {
      BaseSearchContainer,
    },
    data() {
      return {
        openGoodsType: '',
        queryConfirmData: 0,
        activeIn: '1', //tab
        weekOutQuery: { //周考核列表查询条件
          yearmonth: '',
          area: '101',
        },
        factoryList: [{ //大区数据
            label: '宏发一区',
            name: '101'
          },
          {
            label: '宏发二区',
            name: '102'
          },
          {
            label: '宏发三区',
            name: '103'
          },
          {
            label: '集团业务',
            name: '104'
          },
        ],
        searchColumn: [{ //周考核月份
          label: '月份',
          prop: 'yearmonth',
          placeholder: '选择月份',
          type: 'month',
          format: 'yyyy-MM',
          valueFormat: 'yyyy-MM',
          clearable: false,
          search: true,
        }, ],
        weekOutData: [], //周考核列表数据
        weekOutLoading: false, //周考核表格加载
        editWeekTrue: false, //新增编辑周考核弹窗
        submitWeekLoading: false,
        weekType: '', //判断新增编辑周考核弹窗
        weekRules: { //周考核新增编辑校验
          yearmonth: [{
            required: true,
            message: '请选择月份',
            trigger: 'change'
          }],
          week: [{
            required: true,
            message: '请选择周',
            trigger: 'change'
          }],
          userId: [{
            required: true,
            message: '请选择业务员',
            trigger: 'change'
          }],
          factory: [{
            required: true,
            message: '请选择工厂',
            trigger: 'change'
          }],
          productName: [{
            required: true,
            message: '请选择品项',
            trigger: 'blur'
          }],
          rewardSales: [{
            required: true,
            message: '请输入额度',
            trigger: 'blur'
          }],
          rewardLine: [{
            required: true,
            message: '请输入基数',
            trigger: 'blur'
          }],
          // fine: [{
          //   required: true,
          //   message: '请输入扣款',
          //   trigger: 'blur'
          // }],
        },
        addWeek: { //周考核新增编辑数据
          yearmonth: '',
          week: '',
          userId: '',
          rewardSales: 0,
          rewardLine: 0,
          productCodes: [],
          productName: '',
        },
        weekOptions: [{ //周数据
            label: '第一周',
            value: '1'
          },
          {
            label: '第二周',
            value: '2'
          },
          {
            label: '第三周',
            value: '3'
          },
          {
            label: '第四周',
            value: '4'
          },
        ],
        belongList: [], //业务员下拉框
        openWeek: false, //周考核品项弹窗
        searchProductTypeList: this.getDictDatas('category_classify'), //品项分类数据
        weekInQuery: { //周考核品项查询条件
          total: 0,
          pageSize: 100000,
          isEnable: 1,
          pageNo: 1,
          type: '',
          code: '',
          name: '',
        },
        weekInData: [], //周考核品项数据
        weekLoading: false, //周考核品项加载
        selectWeekRows: [],
        classifyList: [{ //品项类型
            label: '市场',
            name: '1'
          },
          {
            label: '集团',
            name: '2'
          },
        ],
        goodsOutQuery: { //品项列表查询
          total: 0,
          pageSize: 10,
          pageNo: 1,
          type: '1',
          productType: '',
          productCode: '',
          productName: '',
        },
        goodsOutData: [], //品项配置数据
        goodsOutLoading: false, //品项表格加载
        goodsRowIndex: -1, //编辑品项列表
        openGoods: false, //多选品相弹窗
        goodsInQuery: { //品项考核品项查询条件
          total: 0,
          pageSize: 10,
          isEnable: 1,
          pageNo: 1,
          type: '',
          code: '',
          name: '',
          dateRange: [],
        },
        goodsLoading: false, //多选品项表格加载
        goodsData: [], //多选品项表格数据
        selectGoodsRows: [], //品项多选数据
        editGoodsTrue: false, //编辑价格
        goodsRules: { //品项新增编辑校验
          market: [{
            required: true,
            message: '请输入市场提成',
            trigger: 'blur'
          }],
          high: [{
            required: true,
            message: '请输入高端提成',
            trigger: 'blur'
          }],
        },
        addGoods: { //品项新增编辑数据
          market: 0,
          high: 0,
        },
        customerListOp: [], //客户下拉框
        belongListOp: [], //归属销售下拉框
        clientTypes: [], //客户分类下拉框
        clientOutQuery: { //客户配置列表分页
          total: 0,
          pageSize: 10,
          pageNo: 1,
          customerType: '',
          customerCode: '',
          customerName: '',
          userId: '',
        },
        submitClientLoading: false,
        clientOutLoading: false,
        clientOutData: [], //客户列表数据
        clientRowIndex: -1, //编辑客户判断
        openClient: false, //客户弹窗
        clientInData: [], //客户弹窗列表数据
        clientInQuery: { //客户弹窗查询
          total: 0,
          pageSize: 10,
          pageNo: 1,
          dataType: 1,
          deptId: '',
          type: '',
          belongSale: '',
          code: '',
          name: '',
        },
        clientLoading: false,
        selectClientRows: [], //选择客户数据
        openInClient: false, //客户编辑弹窗
        addClient: { //编辑客户数据
          reward: 0,
        },
        clientRules: { //集团新增编辑校验
          reward: [{
            required: true,
            message: '请输入提成',
            trigger: 'blur'
          }],
        },
        customerOutQuery: { //市场客户配置列表分页
          total: 0,
          pageSize: 10,
          pageNo: 1,
          factory: '',
          customerName: '',
        },
        submitCustomerLoading: false,
        customerOutData: [], //市场客户列表数据
        customerOutLoading: false, //市场客户列表加载
        customerInQuery: { //客户弹窗查询
          total: 0,
          pageSize: 10,
          pageNo: 1,
          dataType: 1,
          deptId: '',
          type: '',
          belongSale: '',
          code: '',
          name: '',
        },
        openCustomer: false, //市场客户弹窗
        customerLoading: false, //市场客户加载
        customerInData: [], //市场客户数据
        selectCustomerId: '', //市场客户单选ID
        selectCustomerRow: {}, //市场客户单选行
        customerType: '', //判断新增编辑市场客户弹窗
        openInCustomer: false, //编辑市场客户弹窗
        addCustomer: { //市场客户新增编辑数据
          factory: '',
          customerName: '',
          customerCode: '',
          reward: 0,
          rewardSales: 0,
          userId: '',
        },
        customerRules: { //品项新增编辑校验
          factory: [{
            required: true,
            message: '请选择工厂',
            trigger: 'change'
          }],
          userId: [{
            required: true,
            message: '请选择归属销售',
            trigger: 'change'
          }],
          customerCode: [{
            required: true,
            message: '请选择客户',
            trigger: 'change'
          }],
          // reward: [{
          //   required: true,
          //   message: '请输入提成',
          //   trigger: 'blur'
          // }],
          rewardSales: [{
            required: true,
            message: '请输入额度',
            trigger: 'blur'
          }],
        },
        options: this.getDictDatas('factory'),
      };
    },
    watch: {
      'weekOutQuery.area': { //根据大区筛选业务员
        handler(newVal, oldVal) {
          this.belongList = [];
          this.belongListOp.forEach((res) => {
            if (res.deptId == newVal) {
              this.belongList.push(res);
            }
          });
        },
      },
      'addCustomer.userId': {
        handler(newVal, oldVal) {
          getCustomer({
            belongSale: newVal,
            isBelongSale: 1,
          }).then(
            (res) => {
              if (res.code == 0) {
                this.customerListOp = res.data;
              }
            }
          );
        },
      },
    },
    created() {
      this.weekOutQuery.yearmonth = this.getBeforeMonth(0); //默认周考核月份
      this.onTableSearch(); //获取周考核
      this.getBelong(); //获取业务员数据
      //查询客户分类下拉框数据
      this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
    },
    methods: {
      changeDate(e) {
        this.goodsInQuery.startDate = e[0]
        this.goodsInQuery.endDate = e[1]
      },
      changeUserId() {
        this.$set(this.addCustomer, "customerCode", '')
      },
      changeClient(e) {
        this.customerListOp.forEach(item => {
          if (e == item.code) {
            this.addCustomer.customerName = item.name
          }
        })
      },
      //切换标签栏
      tabClick() {
        if (this.activeIn == '1') {
          this.onTableSearch();
        } else if (this.activeIn == '2') {
          this.getGoodsOutList()
          this.queryConfirm()
        } else if (this.activeIn == '3') {
          this.getClientOutList()
        } else if (this.activeIn == '4') {
          this.getCustomerOutList()
        }
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon);
        return s;
      },
      //周考核选择大区
      changeFactory() {
        this.onTableSearch();
      },
      //获取所有业务员
      async getBelong() {
        const res = await getBelong({
          isSale: true
        });
        this.belongListOp = res.data;
        this.belongListOp.forEach((res) => {
          if (res.deptId == this.weekOutQuery.area) {
            this.belongList.push(res);
          }
        });
      },
      //获取周考核数据
      onTableSearch() {
        this.weekOutLoading = true
        weekPage(
          this.weekOutQuery
        ).then(
          (res) => {
            this.weekOutLoading = false
            this.weekOutData = res.data;
            const week1 = this.weekOutData.findIndex(item => item.week == 1)
            const week2 = this.weekOutData.findIndex(item => item.week == 2)
            const week3 = this.weekOutData.findIndex(item => item.week == 3)
            const week4 = this.weekOutData.findIndex(item => item.week == 4)
            const weekLong1 = this.weekOutData.filter(item => item.week == 1)
            const weekLong2 = this.weekOutData.filter(item => item.week == 2)
            const weekLong3 = this.weekOutData.filter(item => item.week == 3)
            const weekLong4 = this.weekOutData.filter(item => item.week == 4)
            if (week1 != -1 && weekLong1.length != 0) {
              this.weekOutData[week1].rowspan = weekLong1.length
            }
            if (week2 != -1 && weekLong2.length != 0) {
              this.weekOutData[week2].rowspan = weekLong2.length
            }
            if (week3 != -1 && weekLong3.length != 0) {
              this.weekOutData[week3].rowspan = weekLong3.length
            }
            if (week4 != -1 && weekLong4.length != 0) {
              this.weekOutData[week4].rowspan = weekLong4.length
            }
          }
        );
      },
      //周考核新增
      addNewWeek(formName) {
        this.weekType = 'add'
        this.editWeekTrue = true
        this.$nextTick(() => {
          this.$refs[formName].resetFields();
          this.addWeek = {
            yearmonth: '',
            week: '',
            userId: '',
            productName: '',
            rewardSales: 0,
            rewardLine: 0,
          }
        })
      },
      //编辑周考核数据
      editWeek(row) {
        weekGet({
          id: row.id
        }).then(
          (res) => {
            this.addWeek = res.data
            this.editWeekTrue = true
            this.weekType = 'edit'
          }
        );
      },
      //删除每周考核行数据
      deleteWeek(row) {
        weekDelete({
          id: row.id
        }).then(
          (res) => {
            if (res.code == 0) {
              this.$notify.success({
                title: '删除成功'
              });
              this.onTableSearch();
            }
          }
        );
      },
      //选择周考核品项数据
      selectWeek() {
        this.openWeek = true
        // this.getWeekInList(true)
      },
      //查询每周考核品项数据
      getWeekInList(flag) {
        if (flag) {
          this.weekInQuery.pageNo = 1
        }
        this.weekLoading = true
        listDataWeek(this.weekInQuery).then((res) => {
          this.weekLoading = false
          this.weekInData = res.data.list;
          this.weekInQuery.total = res.data.total;
          // if (flag) {
          //   this.openWeek = true
          // }
        });
      },
      //重置每周考核品项列表查询
      resetWeekInQuery() {
        this.weekInQuery = {
          total: 0,
          pageSize: 100000,
          isEnable: 1,
          pageNo: 1,
        }
        this.getWeekInList(true)
      },
      //新增周考核数据
      submitNewWeek(formName) {
        let data = this.addWeek
        data.area = this.weekOutQuery.area
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.submitWeekLoading = true
            if (this.weekType == 'add') {
              weekCreate(
                data
              ).then(
                (res) => {
                  this.submitWeekLoading = false
                  if (res.code == 0) {
                    this.editWeekTrue = false
                    this.onTableSearch();
                  }
                }
              ).catch(() => {
                this.submitWeekLoading = false
              });
            } else if (this.weekType == 'edit') {
              weekUpdate(
                this.addWeek
              ).then(
                (res) => {
                  this.submitWeekLoading = false
                  if (res.code == 0) {
                    this.editWeekTrue = false
                    this.onTableSearch();
                  }
                }
              ).catch(() => {
                this.submitWeekLoading = false
              });
            }
          } else {
            return false;
          }
        });
      },
      //关闭周考核弹窗
      closeNewWeek() {
        this.editWeekTrue = false
      },
      //选择每周考核品项
      handleRadioChange(row) {
        this.selectWeekId = row.id
        this.selectWeekRow = row
      },
      selectWeekRow(selection) {
        this.selectWeekRows = selection;
      },
      //选择周考核品项
      submitWeekForm() {
        this.addWeek.productCodes = []
        let productName = []
        this.selectWeekRows.forEach(item => {
          this.addWeek.productCodes.push(item.code)
          productName.push(item.name)
        })
        this.$set(this.addWeek, "productName", productName.join('，'))
        this.$refs['selectWeekTable'].clearSelection()
        this.openWeek = false
      },
      //关闭周考核品项弹窗
      closeWeek() {
        this.openWeek = false
        this.selectWeekId = ''
      },
      //品项选择工厂类别
      changeClassify() {
        this.getGoodsOutList()
        this.queryConfirm()
      },
      //查询品项配置列表
      getGoodsOutList(flag) {
        if (flag) {
          this.goodsOutQuery.pageNo = 1
        }
        this.goodsOutLoading = true
        goodsPage(
          this.goodsOutQuery
        ).then(
          (res) => {
            this.goodsOutLoading = false
            this.goodsOutData = res.data.records;
            this.goodsOutQuery.total = res.data.total;
          }
        );
      },
      queryConfirm() {
        queryConfirm({
          confirmProductType: this.goodsOutQuery.type,
        }).then(
          (res) => {
            this.queryConfirmData = res.data ? res.data : 0
          }
        );
      },
      //重置品项配置列表
      resetGoodsOutQuery() {
        this.goodsOutQuery = {
          pageSize: 10,
          pageNo: 1,
          productType: '',
          productCode: '',
          productName: '',
        }
        this.getGoodsOutList(true)
      },
      //编辑品项列表数据
      editGoods(index) {
        this.goodsRowIndex = index
      },
      //获取时间
      getBeforeDate(n) {
        var n = n;
        var d = new Date();
        var year = d.getFullYear();
        var mon = d.getMonth() + 1;
        var day = d.getDate();
        if (day <= n) {
          if (mon > 1) {
            mon = mon - 1;
          } else {
            year = year - 1;
            mon = 12;
          }
        }
        d.setDate(d.getDate() - n);
        year = d.getFullYear();
        mon = d.getMonth() + 1;
        day = d.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //选择品项（多选）
      selectGoods(type) {
        this.openGoodsType = type
        if (this.openGoodsType == 'confirm') {
          this.goodsInQuery.dateRange = [this.getBeforeDate(30), this.getBeforeDate(0)]
          this.goodsInQuery.startDate = this.goodsInQuery.dateRange[0]
          this.goodsInQuery.endDate = this.goodsInQuery.dateRange[1]
          this.getGoodsInList(true)
        }
        this.openGoods = true
      },
      //获取品项数据
      getGoodsInList(flag) {
        this.goodsInQuery.pageSize = 100000
        if (flag) {
          this.goodsInQuery.pageNo = 1
        }
        this.goodsLoading = true
        if (this.openGoodsType == 'add') {
          listDataWeek(this.goodsInQuery).then((res) => {
            this.goodsLoading = false
            this.goodsData = res.data.list;
            this.goodsInQuery.total = res.data.total;
          });
        } else if (this.openGoodsType == 'confirm') {
          queryProduct({
            confirmProductType: this.goodsOutQuery.type,
            ...this.goodsInQuery
          }).then((res) => {
            this.goodsLoading = false
            this.goodsData = res.data;
          });
        }
      },
      //重置品项查询数据
      resetGoodsInQuery() {
        this.goodsInQuery.dateRange = [this.getBeforeDate(30), this.getBeforeDate(0)]
        this.goodsInQuery.startDate = this.goodsInQuery.dateRange[0]
        this.goodsInQuery.endDate = this.goodsInQuery.dateRange[1]
        this.goodsInQuery = {
          total: 0,
          pageSize: 10,
          isEnable: 1,
          pageNo: 1,
        }
        this.getGoodsInList(true)
      },
      //编辑品项配置数据
      saveGoods(row) {
        goodsUpdate(
          row
        ).then(
          (res) => {
            if (res.code == 0) {
              this.goodsRowIndex = -1
              this.getGoodsOutList();
            }
          }
        );
      },
      //删除品项配置数据
      deleteGoods(row) {
        goodsDelete({
          id: row.id
        }).then(
          (res) => {
            if (res.code == 0) {
              this.$notify.success({
                title: '删除成功'
              });
              this.getGoodsOutList();
            }
          }
        );
      },
      selectGoodsRow(selection) {
        this.selectGoodsRows = selection;
      },
      //确定选择品项数据
      submitGoodsForm() {
        console.log("this.selectGoodsRows", this.selectGoodsRows)
        this.editGoodsTrue = true
      },
      //关闭选择品项弹窗
      closeGoods() {
        this.$refs['selectGoodsTable'].clearSelection()
        this.openGoods = false
      },
      //新增数据
      submitNewGoods(formName) {
        let data = []
        this.selectGoodsRows.forEach(item => {
          data.push({
            productType: item.productTypeCode,
            productCode: item.code,
            productName: item.name,
            market: this.addGoods.market,
            high: this.addGoods.high,
            type: this.goodsOutQuery.type,
          })
        })
        this.$refs[formName].validate((valid) => {
          if (valid) {
            goodsCreate(
              data
            ).then(
              (res) => {
                if (res.code == 0) {
                  this.$refs[formName].resetFields();
                  this.openGoods = false
                  this.editGoodsTrue = false
                  this.$refs['selectGoodsTable'].clearSelection()
                  this.getGoodsOutList();
                }
              }
            );
          } else {
            return false;
          }
        });
      },
      closeNewGoods(formName) {
        this.$refs[formName].resetFields();
        this.editGoodsTrue = false
      },
      //客户列表数据
      getClientOutList(flag) {
        if (flag) {
          this.clientOutQuery.pageNo = 1
        }
        this.clientOutLoading = true
        clientPage(
          this.clientOutQuery
        ).then(
          (res) => {
            this.clientOutLoading = false
            this.clientOutData = res.data.records;
            this.clientOutQuery.total = res.data.total;
          }
        );
      },
      //重置客户列表
      resetClientOutQuery() {
        this.clientOutQuery = {
          total: 0,
          pageSize: 10,
          pageNo: 1,
          customerType: '',
          customerCode: '',
          customerName: '',
          userId: '',
        }
        this.getClientOutList(true)
      },
      //删除客户数据
      deleteClient(row) {
        clientDelete({
          id: row.id
        }).then(
          (res) => {
            if (res.code == 0) {
              this.$notify.success({
                title: '删除成功'
              });
              this.getClientOutList();
            }
          }
        );
      },
      //选择客户
      selectClient() {
        this.getClientInList(true)
      },
      //客户弹窗列表数据
      async getClientInList(flag) {
        if (flag) {
          this.clientInQuery.pageNo = 1
        }
        this.clientLoading = true;
        const res = await listData(this.clientInQuery);
        this.clientInData = res.data.records;
        this.clientInQuery.total = res.data.total;
        this.clientLoading = false;
        if (flag) {
          this.openClient = true;
        }
      },
      //关闭选择客户弹窗
      closeClient() {
        this.$refs['selectClientTable'].clearSelection()
        this.openClient = false
      },
      //重置客户明细列表
      resetClientInQuery() {
        this.clientInQuery = { //客户配置列表分页
          total: 0,
          pageSize: 10,
          pageNo: 1,
          dataType: 1,
          deptId: '',
          type: '',
          belongSale: '',
          code: '',
          name: '',
        }
        this.getClientInList(true)
      },
      //选择客户数据
      selectClientRow(selection) {
        this.selectClientRows = selection;
      },
      //确定选择客户数据
      submitClientForm() {
        this.openInClient = true
      },
      //新增客户数据
      submitClientInForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let data = []
            this.selectClientRows.forEach(item => {
              data.push({
                userId: item.belongSale,
                customerType: item.type,
                customerCode: item.code,
                customerName: item.name,
                reward: this.addClient.reward,
              })
            })
            this.submitClientLoading = true
            clientCreate(
              data
            ).then(
              (res) => {
                this.submitClientLoading = false
                if (res.code == 0) {
                  this.openClient = false
                  this.openInClient = false
                  this.$refs['selectClientTable'].clearSelection()
                  this.addClient = {
                    reward: 0,
                  }
                  this.getClientOutList();
                }
              }
            ).catch(() => {
              this.submitClientLoading = false
            });
          } else {
            return false;
          }
        });
      },
      //关闭编辑客户价格弹
      closeAddClient(formName) {
        this.$refs[formName].resetFields();
        this.openInClient = false
      },
      //编辑客户提成价格
      editClient(row, column) {
        if (column.property == "reward") {
          let that = this
          const index = this.clientOutData.findIndex(item => item.id == row.id)
          this.clientRowIndex = index
          setTimeout(() => {
            that.$refs['clientInput' + index].focus()
          }, 100)
        }
      },
      //编辑客户提成价格失去焦点
      editClientBlur(row) {
        clientUpdate(
          row
        ).then(
          (res) => {
            if (res.code == 0) {
              this.clientRowIndex = -1
              this.getGoodsOutList();
            }
          }
        );
      },
      //查询市场提成列表
      getCustomerOutList(flag) {
        if (flag) {
          this.customerOutQuery.pageNo = 1
        }
        this.customerOutLoading = true
        customerPage(
          this.customerOutQuery
        ).then(
          (res) => {
            this.customerOutLoading = false
            this.customerOutData = res.data.records;
            this.customerOutQuery.total = res.data.total;
          }
        );
      },
      //重置客户列表
      resetCustomerOutQuery() {
        this.customerOutQuery = {
          total: 0,
          pageSize: 10,
          pageNo: 1,
          factory: '',
          customerName: '',
        }
        this.getCustomerOutList(true)
      },
      //新增弹窗
      addNewCustomer(formName) {
        this.customerType = 'add'
        this.openInCustomer = true
        this.$nextTick(() => {
          this.$refs[formName].resetFields();
          this.addCustomer = {
            factory: '',
            customerName: '',
            customerCode: '',
            reward: 0,
            rewardSales: 0,
            userId: '',
          }
        })
      },
      editCustomer(row) {
        customerGet({
          id: row.id
        }).then(
          (res) => {
            this.addCustomer = res.data
            this.openInCustomer = true
            this.customerType = 'edit'
          }
        );
      },
      deleteCustomer(row) {
        customerDelete({
          id: row.id
        }).then(
          (res) => {
            if (res.code == 0) {
              this.$notify.success({
                title: '删除成功'
              });
              this.getCustomerOutList(true);
            }
          }
        );
      },
      //选择客户
      selectCustomer() {
        this.getCustomerInList(true, true)
      },
      //市场客户弹窗列表数据
      async getCustomerInList(flag, flags) {
        if (flags) {
          this.customerInQuery.pageNo = 1
        }
        this.customerLoading = true;
        const res = await listData(this.customerInQuery);
        this.customerInData = res.data.list;
        this.customerInQuery.total = res.data.total;
        this.customerLoading = false;
        if (flag) {
          this.openCustomer = true;
        }
      },
      resetCustomerInQuery() {
        this.customerInQuery = { //客户配置列表分页
          total: 0,
          pageSize: 10,
          pageNo: 1,
          dataType: 1,
          deptId: '',
          type: '',
          belongSale: '',
          code: '',
          name: '',
        }
        this.getCustomerInList(false)
      },
      //选择市场客户
      handleChangeCustomer(row) {
        this.selectCustomerId = row.id
        this.selectCustomerRow = row
      },
      //选择市场客户
      submitCustomerForm() {
        this.openCustomer = false
        this.addCustomer.userId = this.selectCustomerRow.belongSale
        this.addCustomer.customerCode = this.selectCustomerRow.code
        this.addCustomer.customerName = this.selectCustomerRow.FullName
        this.selectCustomerId = ''
      },
      closeCustomerForm() {
        this.openCustomer = false
        this.selectCustomerId = ''
      },
      submitCustomerInForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.submitCustomerLoading = true
            if (this.customerType == 'add') {
              customerCreate(
                this.addCustomer
              ).then(
                (res) => {
                  this.submitCustomerLoading = false
                  if (res.code == 0) {
                    this.openInCustomer = false
                    this.getCustomerOutList(true);
                  }
                }
              ).catch(() => {
                this.submitCustomerLoading = false
              });
            } else if (this.customerType == 'edit') {
              customerUpdate(
                this.addCustomer
              ).then(
                (res) => {
                  this.submitCustomerLoading = false
                  if (res.code == 0) {
                    this.openInCustomer = false
                    this.getCustomerOutList(false);
                  }
                }
              ).catch(() => {
                this.submitCustomerLoading = false
              });
            }
          } else {
            return false;
          }
        });
      },
      closeCustomerInForm() {
        this.openInCustomer = false
      },
      //合并单元格
      objectSpanMethod({
        row,
        column,
        rowIndex,
        columnIndex
      }) {
        if (columnIndex === 0) {
          if (row.rowspan) {
            return {
              rowspan: row.rowspan,
              colspan: 1
            };
          } else {
            return {
              rowspan: 0,
              colspan: 0
            };
          }
        }
        // 周列
        // if (columnIndex === 1) {
        //   if (row.weekStart) {
        //     return {
        //       rowspan: row.weekRowspan,
        //       colspan: 1
        //     };
        //   } else {
        //     return {
        //       rowspan: 0,
        //       colspan: 0
        //     };
        //   }
        // }
      },
    },
  };
</script>
