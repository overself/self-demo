<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix box-card-header">
        <span style="flex: 1;">计划看板</span>
        <BaseSearchContainer :column="kanbanSearchColumn" :params="queryParams" :show-reset-btn="false" @onSearch="onKanbanSearch">
        </BaseSearchContainer>
      </div>
      <el-table :data="tableDataTop" border style="width: 100%;" v-loading="tableLoading">
        <el-table-column prop="area" label="大区" align="center" fixed />
        <el-table-column label="汇总" align="center" width="300" fixed>
          <el-table-column prop="hzPlan" label="计划" align="center" width="100" />
          <el-table-column prop="hzComplete" label="完成" align="center" width="100" />
          <el-table-column prop="hzFinish" label="达成率" align="center" width="100" />
        </el-table-column>
        <el-table-column label="一厂" align="center">
          <el-table-column prop="ycPlan" label="计划" align="center" />
          <el-table-column prop="ycComplete" label="完成" align="center" />
          <el-table-column prop="ycFinish" label="达成率" align="center" />
        </el-table-column>
        <el-table-column label="二厂" align="center">
          <el-table-column prop="ecPlan" label="计划" align="center" />
          <el-table-column prop="ecComplete" label="完成" align="center" />
          <el-table-column prop="ecFinish" label="达成率" align="center" />
        </el-table-column>
        <el-table-column label="朝阳" align="center">
          <el-table-column prop="cyPlan" label="计划" align="center" />
          <el-table-column prop="cyComplete" label="完成" align="center" />
          <el-table-column prop="cyFinish" label="达成率" align="center" />
        </el-table-column>
        <el-table-column label="喀左" align="center">
          <el-table-column prop="kzPlan" label="计划" align="center" />
          <el-table-column prop="kzComplete" label="完成" align="center" />
          <el-table-column prop="kzFinish" label="达成率" align="center" />
        </el-table-column>
      </el-table>
    </el-card>
    <el-card class="box-card">
      <div slot="header" class="clearfix box-card-header">
        <span style="flex: 1;"></span>
        <BaseSearchContainer :column="searchColumn" :params="tableParams" :show-reset-btn="false" @onSearch="onTableSearch">
          <template #departmentName>
            <el-select v-model="tableParams.area" placeholder="请选择大区" style="width: 140px" filterable clearable>
              <el-option v-for="item in clientAreaOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </template>
          <template #customerType>
            <el-select clearable v-model="tableParams.customerType" placeholder="请选择客户分类" style="width: 140px">
              <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </template>
        </BaseSearchContainer>
      </div>
      <el-table row-key="id" :data="tableData" border max-height="500" v-loading="loading" show-summary>
        <el-table-column prop="rank" width="50" label="排名" align="center" fixed></el-table-column>
        <el-table-column prop="nickName" label="业务员" min-width="100" align="center" fixed>
          <template slot-scope="scope">
            <a @click="toPersonal(scope.row)" style="color: #1890ff;">{{scope.row.nickName}}</a>
          </template>
        </el-table-column>
        <el-table-column label="汇总" align="center">
          <el-table-column prop="saleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
          <el-table-column label="计划量" min-width="100" align="center">
            <template v-slot="{row}">
              {{ row.monthSales }}
            </template>
          </el-table-column>
          <!-- <el-table-column label="完成量" min-width="100" align="center">
            <template v-slot="{row}">
              {{ row.monthCompleteSales }}
            </template>
          </el-table-column> -->
          <el-table-column label="达成率(%)" min-width="100" align="center">
            <template v-slot="{row}">
              {{ row.completeRation }}
            </template>
          </el-table-column>
          <el-table-column prop="orderNo" label="订单量" min-width="100" align="center"></el-table-column>
          <el-table-column prop="allCustomerCode" label="总客户" min-width="100" align="center"></el-table-column>
          <el-table-column prop="planCustomerCode" label="计划客户" min-width="100" align="center"></el-table-column>
          <el-table-column prop="customerCode" label="成交客户" min-width="100" align="center"></el-table-column>
          <el-table-column prop="newOrder" label="新客单" min-width="100" align="center"></el-table-column>
          <el-table-column prop="maxPriceConunt" label="高价单" min-width="100" align="center"></el-table-column>
          <el-table-column prop="minPriceConunt" label="低价单" min-width="100" align="center"></el-table-column>
          <el-table-column label="均单量(吨/单)" min-width="100" align="center">
            <template v-slot="{row}">
              {{ row.avgAmount }}
            </template>
          </el-table-column>
          <el-table-column label="均单价(元/单)" min-width="100" align="center">
            <template v-slot="{row}">
              {{ row.avgSum }}
            </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="朝阳" align="center">
          <el-table-column prop="saleAmountCy" label="销售量(吨)" min-width="100" align="center"></el-table-column>
          <el-table-column prop="cySales" label="计划量" min-width="100" align="center"></el-table-column>
          <el-table-column prop="cyCompleteSales" label="完成量" min-width="100" align="center"></el-table-column>
          <el-table-column prop="cyCompleteRation" label="达成率(%)" min-width="100" align="center"></el-table-column>
          <el-table-column prop="saleSumCy" label="总金额(万元)" min-width="100" align="center"></el-table-column>
        </el-table-column>
        <el-table-column label="喀左" align="center">
          <el-table-column prop="saleAmountKz" label="销售量(吨)" min-width="100" align="center"></el-table-column>
          <el-table-column prop="kzSales" label="计划量" min-width="100" align="center"></el-table-column>
          <el-table-column prop="kzCompleteSales" label="完成量" min-width="100" align="center"></el-table-column>
          <el-table-column prop="kzCompleteRation" label="达成率(%)" min-width="100" align="center"></el-table-column>
          <el-table-column prop="saleSumKz" label="总金额(万元)" min-width="100" align="center"></el-table-column>
        </el-table-column>
        <el-table-column label="一厂" align="center">
          <el-table-column prop="saleAmountYc" label="销售量(吨)" min-width="100" align="center"></el-table-column>
          <el-table-column prop="ycSales" label="计划量" min-width="100" align="center"></el-table-column>
          <el-table-column prop="ycCompleteSales" label="完成量" min-width="100" align="center"></el-table-column>
          <el-table-column prop="ycCompleteRation" label="达成率(%)" min-width="100" align="center"></el-table-column>
          <el-table-column prop="saleSumYc" label="总金额(万元)" min-width="100" align="center"></el-table-column>
        </el-table-column>
        <el-table-column label="二厂" min-width="100" align="center">
          <el-table-column prop="saleAmountEc" label="销售量(吨)" min-width="100" align="center"></el-table-column>
          <el-table-column prop="ecSales" label="计划量" min-width="100" align="center"></el-table-column>
          <el-table-column prop="ecCompleteSales" label="完成量" min-width="100" align="center"></el-table-column>
          <el-table-column prop="ecCompleteRation" label="达成率(%)" min-width="100" align="center"></el-table-column>
          <el-table-column prop="saleSumEc" label="总金额(万元)" min-width="100" align="center"></el-table-column>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script>
  import {
    deepClone
  } from '@/utils';
  import {
    getTimeConfig,
  } from '@/api/Analyse/Performance';
  import {
    getUserProfile
  } from '@/api/system/user';
  import {
    newComplete,
    getNewSalPersonAnalysis
  } from '@/api/teamwork/traceOverview/index';

  export default {
    data() {
      return {
        clientTypes: [], //客户分类下拉框
        clientAreaOptions: this.getDictDatas('hfywbm'), //业务部门
        tableDataTop: [],
        tableLoading: false,
        loading: false,
        queryParams: {
          saleYear: '',
          saleMonth: '',
          _date: '',
        },
        tableParams: {
          area: '',
          startYear: '',
          startMonth: '',
          endYear: '',
          endMonth: '',
          _date: [],
        },
        factoryList: this.getDictDatas('factory'),
        kanbanSearchColumn: [{
          label: '日期选择',
          prop: '_date',
          type: 'month',
          format: 'yyyy-MM',
          valueFormat: 'yyyy-MM',
          search: true,
        }, ],
        searchColumn: [{
            label: '大区',
            prop: 'departmentName',
            type: 'select',
            search: true,
            disabled: false,
            dicData: [],
          },
          {
            label: '客户分类',
            prop: 'customerType',
            type: 'select',
            search: true,
            disabled: false,
            dicData: [],
          },
          {
            label: '日期选择',
            prop: '_date',
            type: 'monthrange',
            search: true,
            format: 'yyyy-MM',
            valueFormat: 'yyyy-MM',
            clearable: false,
          },
        ],
        tableData: [],
      };
    },

    created() {
      this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
      this.getUser()
        .then((res) => {
          // 默认一个月
          this.setDefaultMonth()
        })
        .catch(() => {});
    },

    methods: {
      toPersonal(item) {
        this.$router.push({
          path: '/personal/salesman',
          query: {
            userId: item.saleUserId,
          },
        });
      },
      onKanbanSearch(e) {
        if (e) {
          const saleArr = e._date.split('-');
          this.queryParams.saleYear = saleArr[0];
          this.queryParams.saleMonth = saleArr[1];
        } else {
          this.queryParams.saleYear = '';
          this.queryParams.saleMonth = '';
        }
        this.getCompletedProgress();
      },

      async onTableSearch(e) {
        const startArr = e._date[0].split('-');
        const endArr = e._date[1].split('-');
        let startYear = startArr[0];
        let startMonth = startArr[1];
        let endYear = endArr[0];
        let endMonth = endArr[1];
        await getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.tableParams.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.tableParams.startDate = ''
              }
            } else {
              this.tableParams.startDate = ''
            }
          })
        await getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.tableParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.tableParams.endDate = ''
              }
            } else {
              this.tableParams.endDate = ''
            }
          })
        this.getList();
      },

      getCompletedProgress() {
        this.tableLoading = true
        newComplete(this.queryParams).then((res) => {
          this.tableLoading = false
          this.tableDataTop = res.data;
        });
      },

      getList() {
        if (!this.tableParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.tableParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法统计数据`
          });
          return;
        }
        this.loading = true;
        getNewSalPersonAnalysis(this.tableParams).then((res) => {
          this.loading = false;
          this.tableData = res.data;
        });
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      async setDefaultMonth() {
        let endDate = this.getBeforeMonth(0);
        this.tableParams._date = [endDate, endDate]
        this.queryParams._date = endDate
        this.queryParams.saleYear = endDate.slice(0, 4);
        this.queryParams.saleMonth = endDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        await getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.tableParams.startDate = resData.oneWeek.slice(0, 10)
                this.tableParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.tableParams.startDate = ''
                this.tableParams.endDate = ''
              }
            } else {
              this.tableParams.startDate = ''
              this.tableParams.endDate = ''
            }
          })
        this.getCompletedProgress();
        this.getList();
      },

      getUser() {
        return new Promise((resolve, reject) => {
          getUserProfile().then((res) => {
            if (res.data.posts.some((item) => item.id == 1)) {
              resolve(res);
            } else {
              this.$notify.error({
                title: '暂无权限查看'
              });
              reject();
            }
          });
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .el-scrollbar__wrap {
    overflow-x: scroll !important;
  }

  ::v-deep .el-scrollbar__bar.is-horizontal {
    height: 0 !important;
  }

  .title {
    font-size: 16px;
    font-weight: 700;
    margin-bottom: 10px;
  }

  .dept-name {
    font-size: 14px;
    font-weight: 700;
    margin-bottom: 10px;
  }

  .box-card-header {
    display: flex;
    justify-content: space-between;
  }

  ::v-deep .list_wrap {
    margin-top: 0 !important;
  }

  .ratio-item {
    display: flex;
    flex-direction: column;
    align-items: center;

    &.left {
      align-items: flex-start;
    }
  }

  .royalty-tips {
    margin: 15px 0;
    font-size: 14px;
    color: rgba(153, 153, 153, 1);
  }

  .link {
    text-decoration: initial;
    color: #0000ff;

    &:link {
      color: #0000ff;
    }

    // &:visited {
    //   color: purple;
    // }
  }

  .total-table {
    ::v-deep .el-table__header-wrapper {
      display: none;
    }

    ::v-deep .el-table__body-wrapper {
      display: none;
    }

    ::v-deep .el-table__body-wrapper {
      display: none;
    }

    ::v-deep .el-table__footer-wrapper {
      td {
        border-top: none;
      }
    }
  }

  .plan-complete__wrapper {
    display: flex;
    padding: 0 15px;

    &:nth-last-child(1) {
      margin-right: 0;
    }

    .plan-complete__main {
      flex: 0 0 425px;
      // margin-right: 40px;
      padding-right: 40px;
    }

    .title {
      margin-bottom: 17px;
      font-family: PingFang SC, PingFang SC;
      font-weight: 500;
      font-size: 16px;
      color: #000000;
      line-height: 19px;
    }

    .dept-name {
      margin-bottom: 9px;
      font-family: PingFang SC, PingFang SC;
      font-weight: 500;
      font-size: 14px;
      color: #000000;
      line-height: 16px;
    }

    .plan-nums__wrapper {
      display: flex;
      margin-bottom: 15px;

      .plan-nums_item {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-right: 10px;
        padding: 10px;
        border-radius: 4px;

        &:nth-last-child(1) {
          margin-right: 0;
        }

        &.blue {
          background-color: #f1f8ff;
        }

        &.green {
          background-color: #f1fff5;
        }

        .nums-item_label {
          font-family: PingFang SC, PingFang SC;
          font-weight: 400;
          font-size: 14px;
          color: #000000;
        }

        .nums-item_value {
          font-family: PingFang SC, PingFang SC;
          font-weight: 500;
          font-size: 18px;

          &.blue {
            color: #1b8fff;
          }

          &.green {
            color: #3d9a57;
          }
        }
      }
    }

    .factory-nums__wrapper {
      display: flex;

      .factory-nums_item {
        flex: 1;
        padding: 0 14px;
        border-right: 1px solid #f6f6f6;

        &:nth-child(1) {
          padding-left: 7px;
        }

        &:nth-child(2n) {
          border-right: none;
        }

        &:nth-last-child(1) {
          padding-right: 0;
          border-right: none;
        }

        .item-title {
          margin-bottom: 13px;
          font-family: PingFang SC, PingFang SC;
          font-weight: 400;
          font-size: 14px;
          color: #000000;
        }

        .item-nums {

          .item-nums_plan,
          .item-nums_complete {
            display: flex;
            flex-direction: column;
            font-family: PingFang SC, PingFang SC;
            font-weight: 400;
            font-size: 12px;
            color: #a8a8a8;

            .r {
              flex: 1;
              font-family: PingFang SC, PingFang SC;
              font-weight: 400;
              font-size: 16px;

              .black {
                color: #1b8fff;
              }

              .green {
                color: #4fc05a;
              }

              .unit {
                margin-left: 3px;
                font-family: PingFang SC, PingFang SC;
                font-weight: 400;
                font-size: 12px;
                color: #d3d3d3;
              }
            }
          }

          .item-nums_plan {
            margin-bottom: 7px;
          }

          .item-nums_complete {}
        }
      }
    }
  }
</style>
