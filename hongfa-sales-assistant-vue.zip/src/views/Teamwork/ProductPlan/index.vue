<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col :span="24" :xs="24">
        <el-collapse accordion v-model="activeTabName">
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">产量计划
                <div class="title_right_btns" @click.stop="handleScreen">
                  <screenfull id="screenfull" class="right-menu-item hover-effect" ref="screenIcon" @screenToggle="handleScreenToggle" />
                  {{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">
              <el-form ref="weekInQuery" size="small" :inline="true" label-width="80px">
                <el-form-item label="大区" prop="builtInParentDeptId">
                  <el-select clearable v-model="queryParams.builtInParentDeptId" placeholder="请选择大区" style="width: 240px">
                    <el-option v-if="item.label!='其它'" v-for="item in clientAreaOptions" :key="item.value" :value="item.value"
                      :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="月份" prop="accDate">
                  <el-date-picker style="width: 240px" :clearable="false" v-model="queryParams.accDate" type="month" value-format="yyyy-MM">
                  </el-date-picker>
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="handleQuery">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="handleReset">重置</el-button>
                </el-form-item>
              </el-form>
            </div>
          </el-collapse-item>
        </el-collapse>
        <CrudHeader>
          <template slot="list">
            <el-row class="row-btm">
              <div style="margin-bottom: 20px;">
                <div class="table-actions">
                  <div></div>
                  <div>
                    <el-button type="primary" icon="el-icon-plus" circle @click="clickAdd('add')"></el-button>
                  </div>
                </div>
                <el-table v-loading="tableLoading" :max-height="500" :data="data" border style="width: 100%;" show-summary
                  :span-method="objectSpanMethod">
                  <el-table-column prop="builtInParentDeptName" label="大区" align="center"></el-table-column>
                  <el-table-column prop="accDate" label="月份" align="center"></el-table-column>
                  <el-table-column prop="channelTypeName" label="渠道" align="center"></el-table-column>
                  <el-table-column prop="ycPlanSales" label="一厂计划量" align="center"></el-table-column>
                  <el-table-column prop="ycCompleteSales" label="一厂修正量" align="center"></el-table-column>
                  <el-table-column prop="ecPlanSales" label="二厂计划量" align="center"></el-table-column>
                  <el-table-column prop="ecCompleteSales" label="二厂修正量" align="center"></el-table-column>
                  <el-table-column prop="cyPlanSales" label="朝阳计划量" align="center"></el-table-column>
                  <el-table-column prop="cyCompleteSales" label="朝阳修正量" align="center"></el-table-column>
                  <el-table-column prop="kzPlanSales" label="喀左计划里" align="center"></el-table-column>
                  <el-table-column prop="kzCompleteSales" label="咯左修正量" align="center"></el-table-column>
                  <el-table-column prop="monthSales" label="计划量合计" align="center"></el-table-column>
                  <el-table-column prop="rowspanArea" label="大区合计(计划量)" align="center"></el-table-column>
                  <el-table-column label="操作" align="center" width="90px">
                    <template slot-scope="scope">
                      <el-button size="small" type="text" @click="clickAdd('edit',scope.row)" style="margin-right: 10px;">编辑</el-button>
                      <el-popconfirm title="确定删除吗？" @confirm="clickDel(scope.row)">
                        <el-button slot="reference" size="small" type="text">删除</el-button>
                      </el-popconfirm>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </el-row>
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
    <!-- 新增 -->
    <el-dialog :title="planType=='add'?'新增计划':'编辑计划'" :visible.sync="openAdd" width="1200px" append-to-body>
      <el-form :rules="planRules" :model="addPlan" ref="addPlan" size="small" :inline="true" label-width="100px">
        <el-form-item label="月份" prop="accDate">
          <el-date-picker style="width: 240px" v-model="addPlan.accDate" type="month" value-format="yyyy-MM">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="大区" prop="builtInParentDeptId">
          <el-select clearable v-model="addPlan.builtInParentDeptId" placeholder="请选择大区" style="width: 240px">
            <el-option v-for="item in clientAreaOptions" v-if="item.label!='其它'" :key="item.value" :value="item.value"
              :label="item.label"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <el-table row-key="id" :data="planData" border style="width: 100%;">
        <el-table-column prop="channelTypeName" label="渠道" align="center"></el-table-column>
        <el-table-column prop="ycPlanSales" label="一厂计划量" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.ycPlanSales" placeholder="请输入一厂计划量"
              style="width: 100%;" @blur="inputBlur(scope.row,scope.$index)"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="ycCompleteSales" label="一厂修正量" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.ycCompleteSales" placeholder="请输入一厂修正量"
              style="width: 100%;"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="ecPlanSales" label="二厂计划量" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.ecPlanSales" placeholder="请输入二厂计划量"
              style="width: 100%;" @blur="inputBlur(scope.row,scope.$index)"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="ecCompleteSales" label="二厂修正量" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.ecCompleteSales" placeholder="请输入二厂修正量"
              style="width: 100%;"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="cyPlanSales" label="朝阳计划量" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.cyPlanSales" placeholder="请输入朝阳计划量"
              style="width: 100%;" @blur="inputBlur(scope.row,scope.$index)"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="cyCompleteSales" label="朝阳修正量" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.cyCompleteSales" placeholder="请输入朝阳修正量"
              style="width: 100%;"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="kzPlanSales" label="喀左计划量" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.kzPlanSales" placeholder="请输入喀左计划量"
              style="width: 100%;" @blur="inputBlur(scope.row,scope.$index)"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="kzCompleteSales" label="喀左修正量" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.kzCompleteSales" placeholder="请输入喀左修正量"
              style="width: 100%;"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="monthSales" label="计划量合计" align="center"></el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitPlanForm('addPlan')">确 定</el-button>
        <el-button @click="openAdd = false">取 消</el-button>
      </div>
    </el-dialog>
    <!-- 新增 -->
    <el-dialog title="计划详情" :visible.sync="openDetail" width="1100px" append-to-body :close-on-click-modal="true">
      <el-form :model="detailPlan" ref="addPlan" size="small" :inline="true" label-width="100px">
        <el-form-item label="月份">
          <el-input v-model="detailPlan.yearmonth" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="客户">
          <el-input v-model="detailPlan.customerName" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="客户分类">
          <el-input v-model="detailPlan.customerTypeName" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="总计划">
          <el-input v-model="detailPlan.monthSales" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="完成量">
          <el-input v-model="detailPlan.monthCompleteSales" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="达成率(%)">
          <el-input v-model="detailPlan.completeRation" :disabled="true" style="width: 240px" />
        </el-form-item>
      </el-form>
      <el-table row-key="id" :data="planDetail" border style="width: 100%;">
        <!-- v-if="addPlan.customerType=='khfl6'" -->
        <el-table-column prop="factoryName" label="工厂" align="center"></el-table-column>
        <el-table-column label="第一周" align="center">
          <el-table-column prop="oneWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="oneWeekCompleteSales" label="完成" align="center"></el-table-column>
          <!-- <el-table-column prop="oneWeekCompleteRation" label="达成率(%)" align="center"></el-table-column> -->
        </el-table-column>
        <el-table-column label="第二周" align="center">
          <el-table-column prop="twoWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="twoWeekCompleteSales" label="完成" align="center"></el-table-column>
          <!-- <el-table-column prop="twoWeekCompleteRation" label="达成率(%)" align="center"></el-table-column> -->
        </el-table-column>
        <el-table-column label="第三周" align="center">
          <el-table-column prop="threeWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="threeWeekCompleteSales" label="完成" align="center"></el-table-column>
          <!-- <el-table-column prop="threeWeekCompleteRation" label="达成率(%)" align="center"></el-table-column> -->
        </el-table-column>
        <el-table-column label="第四周" align="center">
          <el-table-column prop="fourWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="fourWeekCompleteSales" label="完成" align="center"></el-table-column>
          <!-- <el-table-column prop="fourWeekCompleteRation" label="达成率(%)" align="center"></el-table-column> -->
        </el-table-column>
        <el-table-column label="本月" align="center">
          <el-table-column prop="monthSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="monthCompleteSales" label="完成" align="center"></el-table-column>
          <el-table-column prop="monthCompleteRation" label="达成率(%)" align="center"></el-table-column>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
  import Screenfull from '@/components/Screenfull'; //全屏
  import {
    create,
    page,
    update,
    deleteData,
    getData
  } from '@/api/teamwork/ProductPlan/index';
  import debounce from '@/utils/debounce.js';
  import {
    mapGetters
  } from 'vuex';
  import {
    getConfigMonth
  } from '@/api/personal/index';
  export default {
    name: 'ProductPlan',
    components: {
      Screenfull,
    },
    data() {
      return {
        clientAreaOptions: this.getDictDatas('hfywbm'), //业务部门
        isFullScreen: true, //全屏
        activeTabName: "1", //默认展开
        tableLoading: false,
        openAdd: false,
        openDetail: false,
        detailPlan: {},
        planDetail: [],
        addPlan: {
          accDate: '',
          builtInParentDeptId: '',
        },
        queryParams: {
          builtInParentDeptId: '',
          accDate: '',
        },
        planRules: { //品项新增编辑校验
          accDate: [{
            required: true,
            message: '请选择月份',
            trigger: 'change'
          }],
          builtInParentDeptId: [{
            required: true,
            message: '请选择大区',
            trigger: 'blur'
          }],
        },
        planData: [],
        planType: '',
        data: [],
      };
    },

    computed: {
      ...mapGetters(['userId']),
    },

    watch: {
      // 'params.userId': {
      //   handler(newV) {
      //     getCustomer({
      //       isBelongSale: 1,
      //       belongSale: newV,
      //     }).then(
      //       (res) => {
      //         if (res.code == 0) {
      //           this.clientList = res.data
      //         }
      //       })
      //   }
      // },
    },

    created() {
      this.queryParams.accDate = this.getBeforeMonth(0).slice(0, 7)
      this.handleQuery()
    },

    methods: {
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //合并单元格
      objectSpanMethod({
        row,
        column,
        rowIndex,
        columnIndex
      }) {
        if (columnIndex === 0 || columnIndex === 12) {
          if (row.rowspan) {
            return {
              rowspan: row.rowspan,
              colspan: 1
            };
          } else {
            return {
              rowspan: 0,
              colspan: 0
            };
          }
        }
      },
      //切换全屏
      handleScreen() {
        this.$refs.screenIcon.click()
      },
      //切换全屏
      handleScreenToggle(val) {
        this.isFullScreen = val
      },
      handleQuery() {
        this.tableLoading = true
        page(
          this.queryParams
        ).then((res) => {
          this.tableLoading = false
          this.data = res.data;
          // this.queryParams.total = res.data.total;
        });
      },
      handleReset() {
        this.queryParams.builtInParentDeptId = ''
        this.handleQuery()
      },
      toPersonal(item) {
        this.$router.push({
          path: '/personal/salesman',
          query: {
            userId: item.userId,
          },
        });
      },
      inputBlur(row, index) {
        let newRow = Object.assign({}, row) //浅拷贝赋值，新建指针
        newRow.monthSales = newRow.ycPlanSales + newRow.ecPlanSales + newRow.cyPlanSales + newRow.kzPlanSales
        this.planData.splice(index, 1, newRow)
        this.$forceUpdate()
      },
      submitPlanForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.planType == 'add') {
              create({
                ...this.addPlan,
                factoryList: this.planData,
              }).then(
                (res) => {
                  if (res.code == 0) {
                    this.openAdd = false
                    this.handleQuery()
                  }
                }
              );
            } else if (this.planType == 'edit') {
              update({
                ...this.addPlan,
                factoryList: this.planData,
              }).then(
                (res) => {
                  if (res.code == 0) {
                    this.openAdd = false
                    this.handleQuery()
                  }
                }
              );
            }
          } else {
            return false;
          }
        });
      },
      clickDetail(row) {
        listDetail({
          isFactoryTotal: 1,
          ...row,
          ...this.params,
        }).then((res) => {
          this.detailPlan = res.data
          this.detailPlan.yearmonth = this.detailPlan.saleYear + '-' + this.detailPlan.saleMonth
          this.planDetail = res.data.body
          this.openDetail = true
        });
      },
      clickAdd(type, row) {
        this.planType = type
        if (type == 'add') {
          this.addPlan.accDate = this.getBeforeMonth(0).slice(0, 7)
          this.addPlan.builtInParentDeptId = ''
          this.planData = [{
              channelTypeName: '市场',
              channelType: 1,
              ycPlanSales: 0,
              ycCompleteSales: 0,
              ecPlanSales: 0,
              ecCompleteSales: 0,
              cyPlanSales: 0,
              cyCompleteSales: 0,
              kzPlanSales: 0,
              kzCompleteSales: 0,
            }, {
              channelTypeName: '高端',
              channelType: 2,
              ycPlanSales: 0,
              ycCompleteSales: 0,
              ecPlanSales: 0,
              ecCompleteSales: 0,
              cyPlanSales: 0,
              cyCompleteSales: 0,
              kzPlanSales: 0,
              kzCompleteSales: 0,
            },
            {
              channelTypeName: '贸易',
              channelType: 3,
              ycPlanSales: 0,
              ycCompleteSales: 0,
              ecPlanSales: 0,
              ecCompleteSales: 0,
              cyPlanSales: 0,
              cyCompleteSales: 0,
              kzPlanSales: 0,
              kzCompleteSales: 0,
            },
          ]
          this.openAdd = true
        } else if (type == 'edit') {
          getData({
            accDate: row.accDate,
            builtInParentDeptId: row.builtInParentDeptId,
          }).then((res) => {
            this.addPlan = res.data
            this.planData = res.data.factoryList
            this.openAdd = true
          });
        }
      },
      clickDel(row) {
        deleteData({
          accDate: row.accDate,
          builtInParentDeptId: row.builtInParentDeptId,
          channelType: row.channelType,
        }).then((res) => {
          this.handleQuery()
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .el-table--medium .el-table__cell {
    padding: 0 !important;
  }

  ::v-deep .el-input.is-disabled .el-input__inner {
    color: #000;
  }

  .table-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
  }

  //去掉number输入框的上下箭头
  ::v-deep input::-webkit-outer-spin-button,
  ::v-deep input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  ::v-deep input[type='number'] {
    -moz-appearance: textfield;
  }

  ::v-deep .list_wrap {
    margin-top: 0 !important;
  }

  .cursor-p {
    color: #1890ff;
  }

  .component_title {
    padding: 10px 30px 0 20px;
  }

  ::v-deep .el-collapse-item__content {
    padding-bottom: 0 !important;
  }
</style>
