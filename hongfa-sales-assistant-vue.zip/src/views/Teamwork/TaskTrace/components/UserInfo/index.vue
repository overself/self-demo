<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix box-card-header">
        <span style="flex: 1;">任务追踪（部门）</span>
        <BaseSearchContainer :column="searchColumn" :params="salesParams" :show-reset-btn="false" @onSearch="onKanbanSearch">
          <template #deptId>
            <el-select clearable v-model="salesParams.deptId" placeholder="请选择业务部门" style="width: 240px">
              <el-option v-for="item in clientAreaOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </template>
          <template #btnsRight>
            <el-button @click="showTop">{{isShow?'收起':'展开'}}</el-button>
          </template>
        </BaseSearchContainer>
      </div>
      <el-row :gutter="20" v-if="isShow">
        <el-col :span="14">
          <el-table :data="tableData" border style="width: 100%;">
            <el-table-column v-for="item in tableColumn" :prop="item.value" :label="item.label" align="center"></el-table-column>
          </el-table>
        </el-col>
        <el-col :span="10">
          <el-table :data="tableData1" border style="width: 100%;" :show-header="true">
            <el-table-column prop="channel" label="渠道" align="center"></el-table-column>
            <el-table-column label="一厂" align="center">
              <el-table-column prop="ycPlan" label="计划" align="center"></el-table-column>
              <el-table-column prop="ycFinish" label="完成" align="center"></el-table-column>
            </el-table-column>
            <el-table-column label="二厂" align="center">
              <el-table-column prop="ecPlan" label="计划" align="center"></el-table-column>
              <el-table-column prop="ecFinish" label="完成" align="center"></el-table-column>
            </el-table-column>
            <el-table-column label="朝阳" align="center">
              <el-table-column prop="cyPlan" label="计划" align="center"></el-table-column>
              <el-table-column prop="cyFinish" label="完成" align="center"></el-table-column>
            </el-table-column>
            <el-table-column label="喀左" align="center">
              <el-table-column prop="kzPlan" label="计划" align="center"></el-table-column>
              <el-table-column prop="kzFinish" label="完成" align="center"></el-table-column>
            </el-table-column>
            <el-table-column label="合计" align="center">
              <el-table-column prop="hjPlan" label="计划" align="center"></el-table-column>
              <el-table-column prop="hjFinish" label="完成" align="center"></el-table-column>
            </el-table-column>
          </el-table>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script>
  import {
    getUserProfile
  } from '@/api/system/user';
  import {
    getConfigMonth,
    newListUp
  } from '@/api/personal/index';
  export default {
    name: 'PersonalUserInfo',
    data() {
      return {
        isShow: true,
        clientAreaOptions: this.getDictDatas('hfywbm'), //业务部门
        tableData: [],
        tableColumn: [],
        tableData1: [],
        searchColumn: [{
          label: '业务部门',
          prop: 'deptId',
          type: 'select',
          search: true,
          disabled: false,
          dicData: [],
        }, {
          label: '日期选择',
          prop: '_date',
          type: 'month',
          format: 'yyyy-MM',
          valueFormat: 'yyyy-MM',
          search: true,
        }, ],
        salesParams: {
          deptId: '',
          userId: '',
          saleYear: '',
          saleMonth: '',
          _date: '',
        },
      };
    },
    created() {
      if (this.$route.query.deptId) {
        this.salesParams.deptId = this.$route.query.deptId + '';
        if (this.$route.path == '/teamwork/task-trace') {
          if (
            this.salesParams.deptId != 100 &&
            this.salesParams.deptId != 101 &&
            this.salesParams.deptId != 102 &&
            this.salesParams.deptId != 103
          ) {
            this.$notify.error({
              title: '暂无权限查看'
            });
            return;
          } else {
            this.getUserInfo();
          }
        }
      } else {
        this.getUser();
      }
    },

    methods: {
      showTop() {
        this.isShow = !this.isShow
        if (this.isShow) {
          this.$emit('changeHeight', 500);
        } else {
          this.$emit('changeHeight', 600);
        }
      },
      onKanbanSearch(e) {
        if (e) {
          const saleArr = e._date.split('-');
          this.salesParams.saleYear = saleArr[0];
          this.salesParams.saleMonth = saleArr[1];
        } else {
          this.salesParams.saleYear = '';
          this.salesParams.saleMonth = '';
        }
        this.newListUp();
      },
      getUserInfo() {
        getConfigMonth().then((res) => {
          const year = res.data.year;
          const month = res.data.month;
          this.salesParams.saleYear = year;
          this.salesParams.saleMonth = month;
          this.salesParams._date = `${year}-${month}`;
          this.newListUp();
        });
      },
      getUser() {
        getUserProfile().then((res) => {
          this.salesParams.builtInParentDeptId = res.data.builtInParentDeptId;
          this.salesParams.deptId = res.data.builtInParentDeptId + '';
          let posts = res.data.posts[0].id
          if (res.data.builtInParentDeptId) {
            if (
              posts != 1 &&
              res.data.builtInParentDeptId != 100 &&
              res.data.builtInParentDeptId != 101 &&
              res.data.builtInParentDeptId != 102 &&
              res.data.builtInParentDeptId != 103
            ) {
              this.$notify.error({
                title: '暂无权限查看'
              });
              return;
            } else {
              this.$emit('userInfo', res.data);
              this.getUserInfo();
            }
          } else {
            this.$notify.error({
              title: '暂无权限查看'
            });
          }
        });
      },
      newListUp() {
        let data = this.salesParams
        data.isFactoryTotal = 1
        newListUp(data).then((res) => {
          this.tableColumn = res.data.beforeTitle;
          this.tableData = res.data.beforeBody;
          this.tableData1 = res.data.afterFactory;
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  .box-card-header {
    display: flex;
    justify-content: space-between;
  }

  .title {
    font-size: 16px;
    font-weight: 700;
    margin-bottom: 10px;
  }

  .user-info_wrapper {
    display: flex;
    align-items: flex-start;

    .el-avatar {
      flex: 0 0 50px;
      height: 50px;
    }
  }

  .process-wrapper {
    .process-item {
      display: flex;
      margin-bottom: 45px;

      &:nth-last-child(1) {
        margin-bottom: 0;
      }

      .el-progress.el-progress--line {
        flex: 1;
      }
    }
  }

  .ratio-item {
    display: flex;
    flex-direction: column;
    align-items: center;

    &.left {
      align-items: flex-start;
    }
  }

  .royalty-tips {
    margin: 15px 0;
    font-size: 14px;
    color: rgba(153, 153, 153, 1);
  }

  .dept-users_wrapper {
    display: flex;
    flex-wrap: wrap;
    height: 155px;
    overflow: scroll;

    .dept-user-item {
      margin-right: 28px;
      margin-bottom: 10px;
      font-size: 14px;
      cursor: pointer;
    }
  }

  .plan-complete__wrapper {
    flex: 0 0 574px;
    margin-right: 25px;

    .title {
      margin-bottom: 7px;
      font-family: PingFang SC, PingFang SC;
      font-weight: 500;
      font-size: 16px;
      color: #000000;
      line-height: 19px;
    }

    .plan-nums__wrapper {
      display: flex;
      margin-bottom: 15px;

      .plan-nums_item {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-right: 10px;
        padding: 10px;
        border-radius: 4px;

        &:nth-last-child(1) {
          margin-right: 0;
        }

        &.blue {
          background-color: #f1f8ff;
        }

        &.green {
          background-color: #f1fff5;
        }

        .nums-item_label {
          font-family: PingFang SC, PingFang SC;
          font-weight: 400;
          font-size: 14px;
          color: #000000;
        }

        .nums-item_value {
          font-family: PingFang SC, PingFang SC;
          font-weight: 500;
          font-size: 18px;

          &.blue {
            color: #1b8fff;
          }

          &.green {
            color: #3d9a57;
          }
        }
      }
    }

    .factory-nums__wrapper {
      display: flex;

      .factory-nums_item {
        flex: 1;
        padding: 0 10px;
        border-right: 1px solid #f6f6f6;

        &:nth-child(1) {
          padding-left: 0;
        }

        &:nth-last-child(1) {
          padding-right: 0;
          border-right: none;
        }

        .item-title {
          margin-bottom: 13px;
          font-family: PingFang SC, PingFang SC;
          font-weight: 400;
          font-size: 14px;
          color: #000000;
        }

        .item-nums {

          .item-nums_plan,
          .item-nums_complete {
            display: flex;
            align-items: center;
            font-family: PingFang SC, PingFang SC;
            font-weight: 400;
            font-size: 12px;
            color: #a8a8a8;

            .r {
              flex: 1;
              text-align: right;
              font-family: PingFang SC, PingFang SC;
              font-weight: 400;
              font-size: 16px;

              .black {
                color: #1b8fff;
              }

              .green {
                color: #4fc05a;
              }

              .unit {
                margin-left: 3px;
                font-family: PingFang SC, PingFang SC;
                font-weight: 400;
                font-size: 12px;
                color: #d3d3d3;
              }
            }
          }

          .item-nums_plan {
            margin-bottom: 7px;
          }

          .item-nums_complete {}
        }
      }
    }
  }

  .chain-growth__wrapper {
    margin-right: 25px;
    flex: 0 0 223px;

    .title {
      display: flex;
      align-items: center;
      justify-content: space-between;

      .ratio {
        font-family: PingFang SC, PingFang SC;
        font-weight: 500;
        font-size: 16px;
        color: #3d9a59;
      }
    }

    .ratio-item {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 7px;
    }
  }

  .user-info__wrapper {
    flex: 0 0 150px;
  }

  .el-divider--horizontal {
    margin: 29 0;
  }

  .el-form-item {
    margin-bottom: 0 !important;
  }
</style>
