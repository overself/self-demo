<template>
  <div>
    <UserInfo @userInfo="getUserInfo" :queryParams="queryParams" @changeHeight="changeHeight" />
    <CrudHeader>
      <template slot="left">
        <el-tabs v-model="activeName">
          <el-tab-pane v-for="(item, index) in tabs" :key="index" :label="item.label" :name="item.name">
            <div class="list_wrap">
              <Table :tableHeight="tableHeight" ref="hookTable" :data="tableData" :params="queryParams" :identity="manager"
                :weekDays="weekDays" />
            </div>
          </el-tab-pane>
        </el-tabs>
      </template>

      <template slot="rightBtns">
        <el-form ref="weekInQuery" size="small" :inline="true" label-width="80px">
          <el-form-item label="大区" prop="deptIdMore" v-if="posts==1">
            <el-select multiple v-model="queryParams.deptIdMore" placeholder="请选择大区" style="width: 180px" filterable>
              <el-option v-for="item in clientAreaOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="业务员" prop="userId" v-if="posts==1 || posts==2">
            <el-select v-model="queryParams.userId" placeholder="请选择业务员" style="width: 100px" filterable clearable>
              <el-option v-for="item in belongList" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="工厂" prop="factory">
            <el-select v-model="queryParams.factory" placeholder="请选择工厂" style="width: 100px" filterable clearable>
              <el-option v-for="item in factoriesOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="客户分类" prop="customerTypeMore">
            <el-select multiple clearable v-model="queryParams.customerTypeMore" placeholder="请选择客户分类" style="width: 100px">
              <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="月份" prop="_date">
            <el-date-picker style="width: 140px" :clearable="false" v-model="queryParams._date" type="month" @change="onElDatePickerChange"
              value-format="yyyy-MM">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button icon="el-icon-search" @click="handleQuery">查询</el-button>
            <el-button icon="el-icon-refresh" @click="handleReset">重置</el-button>
          </el-form-item>
        </el-form>
      </template>
    </CrudHeader>
  </div>
</template>

<script>
  import {
    getBelong
  } from '@/api/Client/index';
  import {
    deepClone
  } from '@/utils';
  import UserInfo from './components/UserInfo/index';
  import Table from '@/views/Personal/components/Table/index';
  import {
    manager
  } from '@/views/Personal/components/enum';
  import {
    mixins
  } from '@/views/Personal/components/mixins';
  import {
    getConfigMonth
  } from '@/api/personal/index';

  export default {
    mixins: [mixins],
    components: {
      UserInfo,
      Table,
    },

    data() {
      return {
        tableHeight: 500,
        manager,
        activeName: '1',
        tabs: [{
          label: '任务追踪',
          name: '1'
        }],
        tableData: [],
        clientAreaOptions: this.getDictDatas('hfywbm'), //业务部门
        factoriesOptions: this.getDictDatas('factory'), //归属工厂
        clientTypes: [], //客户分类下拉框
        belongListOp: [], //归属销售下拉框
        belongList: [], //归属销售下拉框
        queryParams: {
          deptIdMore: [],
          deptIds: '',
          customerTypeMore: [],
          userId: '',
          saleYear: '',
          saleMonth: '',
          _date: '',
          factory: '',
        },
        salesParams: {},
        posts: -1,
      };
    },
    watch: {
      'queryParams.deptIdMore': {
        handler(newVal, oldVal) {
          this.belongList = [];
          this.queryParams.userId = '';
          if (newVal) {
            newVal.forEach((e) => {
              this.belongListOp.forEach((res) => {
                if (res.deptId == e) {
                  this.belongList.push(res);
                }
              });
            })
          } else {
            this.belongList = this.belongListOp;
          }
        },
      },
    },
    created() {
      //查询客户分类下拉框数据
      this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
    },
    methods: {
      changeHeight(e) {
        this.tableHeight = e
      },
      //获取所有业务员
      async getBelong() {
        const res = await getBelong({
          isSale: true
        });
        this.belongListOp = res.data;
        if (this.queryParams.deptIdMore) {
          this.belongListOp.forEach((res) => {
            if (res.deptId == this.queryParams.deptIdMore[0]) {
              this.belongList.push(res);
            }
          });
        } else {
          this.belongList = this.belongListOp;
        }
      },
      onElDatePickerChange(e) {
        let dateArr = e.split('-');
        this.queryParams.saleYear = dateArr[0];
        this.queryParams.saleMonth = dateArr[1];
        this.$_getWeekDays(e).then(() => {
          this.$_getList();
        });
      },
      handleQuery() {
        this.queryParams.customerType = this.queryParams.customerTypeMore.join(',')
        this.queryParams.deptIds = this.queryParams.deptIdMore.join(',')
        this.$_getList();
      },
      handleReset() {
        if (this.posts == 1 || this.posts == 2) {
          this.queryParams.userId = ''
        }
        this.queryParams.factory = ''
        this.queryParams.customerTypeMore = []
        this.queryParams._date = this.queryParams.saleYear + '-' + this.queryParams.saleMonth
        this.$_getList();
      },
      getUserInfo(e) {
        this.queryParams.deptIdMore[0] = e.builtInParentDeptId + '';
        this.queryParams.deptIds = this.queryParams.deptIdMore.join(',')
        this.getBelong();
        getConfigMonth().then((res) => {
          const year = res.data.year;
          const month = res.data.month;
          this.queryParams.saleYear = year;
          this.queryParams.saleMonth = month;
          this.queryParams._date = `${year}-${month}`;
          this.salesParams.builtInParentDeptId = e.builtInParentDeptId;
          if (this.salesParams.builtInParentDeptId) {
            this.posts = e.posts[0].id
            if (this.posts == 1 || this.posts == 2) {
              this.queryParams.userId = '';
              this.queryParams.userName = '';
            } else if (this.posts == 3) {
              this.queryParams.userId = e.id;
              this.queryParams.userName = e.nickname;
            }
            this.$_getWeekDays(this.queryParams._date).then(() => {
              this.$_getList();
            });
          } else {
            this.$notify.error({
              title: '暂无权限查看列表'
            });
          }
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
</style>
