<!-- 追踪时间配置 -->
<template>
  <div class="app-container Board">

    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <div class="search_wrap">
          <div class="component_title">配置列表

            <div class="title_right_btns">
              <screenfull
                id="screenfull"
                class="right-menu-item hover-effect"
              />全屏
            </div>
          </div>
        </div>

        <CrudHeader>
          <template slot="left">
            <el-form :model="queryParams">
              <el-form-item label="选择配置列表">
                <el-date-picker
                  v-model="queryParams.year"
                  type="year"
                  placeholder="选择年"
                  format="yyyy"
                  valueFormat="yyyy"
                  @change="getList"
                ></el-date-picker>
              </el-form-item>
            </el-form>
          </template>

          <!-- v-hasPermi="['system:outbound-order:export']" -->

          <template slot="list">
            <el-table
              :data="tableData"
              border
              style="width: 100%;"
              :cell-style="addClass"
              v-loading="loading"
            >
              <el-table-column
                prop="month"
                label="月份"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="oneWeek"
                label="第一周"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <div
                    class="is_edit"
                    v-if="scope.row._isEditOne"
                  >
                    <date-picker
                      v-model="scope.row.newRow.oneWeek"
                      style="width: 100%;"
                      type="date"
                      range
                      placeholder="点击选择时间"
                      :lang="datePickerLang"
                      format="YYYY-MM-DD"
                      value-type="format"
                      clearable
                    ></date-picker>
                  </div>

                  <div
                    class=""
                    v-else
                    @dblclick="onColumnDbClick(scope.row, '_isEditOne', 'oneWeek')"
                  >{{scope.row.oneWeek}}</div>
                </template>
              </el-table-column>

              <el-table-column
                prop="twoWeek"
                label="第二周"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <div
                    class="is_edit"
                    v-if="scope.row._isEditTwo"
                  >
                    <date-picker
                      v-model="scope.row.newRow.twoWeek"
                      style="width: 100%;"
                      type="date"
                      range
                      placeholder="点击选择时间"
                      :lang="datePickerLang"
                      format="YYYY-MM-DD"
                      value-type="format"
                      clearable
                    ></date-picker>
                  </div>

                  <div
                    class=""
                    v-else
                    @dblclick="onColumnDbClick(scope.row, '_isEditTwo', 'twoWeek')"
                  >{{scope.row.twoWeek}}</div>
                </template>
              </el-table-column>

              <el-table-column
                prop="threeWeek"
                label="第三周"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <div
                    class="is_edit"
                    v-if="scope.row._isEditThree"
                  >
                    <date-picker
                      v-model="scope.row.newRow.threeWeek"
                      style="width: 100%;"
                      type="date"
                      range
                      placeholder="点击选择时间"
                      :lang="datePickerLang"
                      format="YYYY-MM-DD"
                      value-type="format"
                      clearable
                    ></date-picker>
                  </div>

                  <div
                    class=""
                    v-else
                    @dblclick="onColumnDbClick(scope.row, '_isEditThree', 'threeWeek')"
                  >{{scope.row.threeWeek}}</div>
                </template>
              </el-table-column>

              <el-table-column
                prop="fourWeek"
                label="第四周"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <div
                    class="is_edit"
                    v-if="scope.row._isEditFour"
                  >
                    <date-picker
                      v-model="scope.row.newRow.fourWeek"
                      style="width: 100%;"
                      type="date"
                      range
                      placeholder="点击选择时间"
                      :lang="datePickerLang"
                      format="YYYY-MM-DD"
                      value-type="format"
                      clearable
                    ></date-picker>
                  </div>

                  <div
                    class=""
                    v-else
                    @dblclick="onColumnDbClick(scope.row, '_isEditFour', 'fourWeek')"
                  >{{scope.row.fourWeek}}</div>
                </template>
              </el-table-column>

              <el-table-column
                label="操作"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <el-button
                    v-if="scope.row._isEditOne || scope.row._isEditTwo || scope.row._isEditThree || scope.row._isEditFour"
                    type="text"
                    style="border: none; background-color: transparent;"
                    :loading="scope.row._loading"
                    @click="handleSave(scope.row, scope.$index)"
                  >保存</el-button>

                  <span v-else>暂无操作</span>
                </template>
              </el-table-column>
            </el-table>
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import Screenfull from '@/components/Screenfull';
import { list, update } from '@/api/teamwork/configDate/index.js';
import { deepClone } from '@/utils';
import datePickerLang from '@/components/BaseSearchContainer/datePickerLang.js';

const queryParamsCommon = {
  year: '',
};

export default {
  name: 'SalesDelivery',
  components: {
    Screenfull,
  },

  data() {
    return {
      datePickerLang,
      userInfo: {},
      loading: false,
      exportLoading: false,
      queryParams: deepClone(queryParamsCommon),
      activeName: '',
      tabs: [],
      tableData: [],
      total: 0,
      customerTypeList: this.getDictDatas('customer_type'),
    };
  },

  created() {
    this.queryParams.year = `${this.$dayjs().year()}`;
    this.getList();
  },

  methods: {
    handleSave(row, index) {
      row._loading = true;

      let params = {
        id: row.id,
      };

      if (row._isEditOne) {
        params.oneWeek = row.newRow.oneWeek.join('-');
      }

      if (row._isEditTwo) {
        params.twoWeek = row.newRow.twoWeek.join('-');
      }

      if (row._isEditThree) {
        params.threeWeek = row.newRow.threeWeek.join('-');
      }

      if (row._isEditFour) {
        params.fourWeek = row.newRow.fourWeek.join('-');
      }

      update(params)
        .then((res) => {
          this.$message.success('保存成功');
          row._loading = false;
          this.getList();
        })
        .catch((err) => {
          row._loading = false;
        });
    },

    onColumnDbClick(row, key, displayKey) {
      if (row[displayKey] === '-' || row[displayKey] === null) {
        row[key] = true;
      } else {
        this.$notify.error({ title: '不可编辑' });
      }

      // // console.log(row);
      // if (this.isNotToday()) return;
      // row[key] = true;
      // this.$nextTick(() => {
      //   this.$refs[key]?.focus();
      // });
    },

    onEdit() {
      this.tableData.forEach((item) => {
        item._isEditOne = item.oneWeek === null;
        item._isEditTwo = item.twoWeek === null;
        item._isEditThree = item.threeWeek === null;
        item._isEditFour = item.fourWeek === null;
      });
    },

    formatDate(date) {
      const dateArr = date.split('-');
      const startDate = `${dateArr[0]}-${dateArr[1]}-${dateArr[2]}`;
      const endDate = `${dateArr[3]}-${dateArr[4]}-${dateArr[5]}`;

      return `${this.$dayjs(startDate).format('MM/DD')}-${this.$dayjs(
        endDate
      ).format('MM/DD')}`;
    },

    getList() {
      this.loading = true;
      console.log(this.queryParams);
      list(this.queryParams)
        .then((res) => {
          // console.log(res);
          this.loading = false;

          res.data.forEach((item) => {
            item._isEditOne = false;
            item._isEditTwo = false;
            item._isEditThree = false;
            item._isEditFour = false;
            item._isEdit = false;
            item._loading = false;

            item.oneWeek && (item.oneWeek = this.formatDate(item.oneWeek));
            item.twoWeek && (item.twoWeek = this.formatDate(item.twoWeek));
            item.threeWeek &&
              (item.threeWeek = this.formatDate(item.threeWeek));
            item.fourWeek && (item.fourWeek = this.formatDate(item.fourWeek));

            item.month = `${item.month}月`;
            item.newRow = {
              oneWeek: item.oneWeek,
              twoWeek: item.twoWeek,
              threeWeek: item.threeWeek,
              fourWeek: item.fourWeek,
            };
          });

          this.tableData = res.data;
        })
        .catch((err) => {
          this.loading = false;
        });
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },

    setDefaultMonth() {
      const today = this.$dayjs().startOf('day').format('YYYY-MM-DD');
      const oneMonthBefore = this.$dayjs()
        .subtract(1, 'month')
        .startOf('day')
        .format('YYYY-MM-DD');

      this.queryParams._orderDate = [oneMonthBefore, today];
      this.queryParams.orderDate = `${oneMonthBefore},${today}`;
    },
  },
};
</script>

<style lang="scss" scoped>
::v-deep .list_wrap {
  margin-top: 0 !important;
}
</style>
