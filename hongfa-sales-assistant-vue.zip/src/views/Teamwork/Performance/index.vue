<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col :span="24" :xs="24">
        <el-collapse accordion v-model="activeTabName">
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">业务员绩效
                <div class="title_right_btns" @click.stop="handleScreen">
                  <screenfull id="screenfull" class="right-menu-item hover-effect" ref="screenIcon" @screenToggle="handleScreenToggle" />
                  {{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">
              <el-form ref="weekInQuery" size="small" :inline="true" label-width="80px">
                <el-form-item label="大区" prop="area" v-if="posts==1">
                  <el-select clearable v-model="queryParams.area" placeholder="请选择大区" style="width: 240px">
                    <el-option v-for="item in clientAreaOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="业务员" prop="saleUserId">
                  <el-select filterable clearable v-model="queryParams.saleUserId" placeholder="请选择业务员" style="width: 240px">
                    <el-option v-for="dict in belongListOp" :key="dict.id" :label="dict.nickname" :value="dict.id" />
                  </el-select>
                </el-form-item>
                <el-form-item label="客户分类" prop="customerTypeMore">
                  <el-select multiple clearable v-model="queryParams.customerTypeMore" placeholder="请选择客户分类" style="width: 240px">
                    <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="月份" prop="dateRange">
                  <el-date-picker style="width: 240px" :clearable="false" v-model="queryParams.dateRange" type="monthrange"
                    @change="onDatePickerChange" value-format="yyyy-MM" range-separator="至" start-placeholder="开始月份" end-placeholder="结束月份">
                  </el-date-picker>
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="handleQuery">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="handleReset">重置</el-button>
                  <el-button icon="el-icon-download" :loading="exportLoading" @click="handleExport">导出</el-button>
                </el-form-item>
              </el-form>
            </div>
          </el-collapse-item>
        </el-collapse>
        <CrudHeader>
          <template slot="list">
            <el-table row-key="id" :data="tableData" border v-loading="tableLoading">
              <el-table-column prop="orderMonth" label="月份" min-width="100" align="center"></el-table-column>
              <el-table-column label="姓名" min-width="100" align="center">
                <template v-slot="{row}">
                  <router-link
                    :to="{path: '/personal/my-performance', query: {saleUserId:row.saleUserId,orderMonth:row.orderMonth,area:row.area,nickname:row.nickname,customerTypeMore:queryParams.customerTypeMore}}">
                    <span class="cursor-p">{{row.nickname}}</span>
                  </router-link>
                </template>
              </el-table-column>
              <el-table-column prop="areaName" label="大区" min-width="100" align="center"></el-table-column>
              <el-table-column label="销量" align="center">
                <el-table-column prop="saleAmount" label="总销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column label="新客单量" min-width="100" align="center">
                  <template v-slot="{row}">
                    <router-link
                      :to="{path: '/delivery/newOrder', query: {saleUserId:row.saleUserId,orderMonth:row.orderMonth,area:row.area}}">
                      <span class="cursor-p">{{row.newOrder}}</span>
                    </router-link>
                  </template>
                </el-table-column>
                <el-table-column label="高价单量" min-width="100" align="center">
                  <template v-slot="{row}">
                    <router-link
                      :to="{path: '/delivery/approval', query: {saleUserId:row.saleUserId,orderMonth:row.orderMonth,area:row.area}}">
                      <span class="cursor-p">{{row.totalHigh}}</span>
                    </router-link>
                  </template>
                </el-table-column>
                <el-table-column prop="monthSales" label="计划量(吨)" min-width="100" align="center"></el-table-column>
                <!-- <el-table-column prop="monthCompleteSales" label="完成量(吨)" min-width="100" align="center"></el-table-column> -->
                <el-table-column prop="completeRation" label="达成率(%)" min-width="100" align="center"></el-table-column>
              </el-table-column>
              <el-table-column label="提成" align="center">
                <el-table-column prop="customerReward" label="客户提成" min-width="100" align="center"></el-table-column>
                <el-table-column prop="goodsReward" label="品项提成" min-width="100" align="center"></el-table-column>
                <el-table-column prop="weekReward" label="周考核提成" min-width="100" align="center"></el-table-column>
              </el-table-column>
            </el-table>
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import {
    getUserProfile
  } from '@/api/system/user';
  import {
    getBelong
  } from '@/api/Client/index';
  import BaseSearchContainer from '@/components/BaseSearchContainer/index'; //搜索工作栏
  import Screenfull from '@/components/Screenfull'; //全屏
  import {
    getTimeConfig,
    getList,
    exportList,
  } from '@/api/teamwork/Performance';
  import {
    deepClone
  } from '@/utils';
  const queryParamsCommon = {
    startDate: '',
    endDate: '',
    area: '',
    saleUserId: '',
    dateRange: [],
    customerTypeMore: [],
  };
  export default {
    name: 'Performance',
    components: {
      Screenfull,
      BaseSearchContainer,
    },
    data() {
      return {
        clientTypes: [], //客户分类下拉框
        tableData: [],
        tableLoading: false,
        belongListAll: [],
        belongListOp: [], //归属销售
        exportLoading: false, //导出
        queryParams: deepClone(queryParamsCommon),
        clientAreaOptions: this.getDictDatas('hfywbm'), //业务部门
        exportMaxMonth: 6, //导出月份限制
        isFullScreen: true, //全屏
        activeTabName: "1", //默认展开
        posts: -1,
      };
    },

    watch: {
      'queryParams.area'(newVal, oldVal) {
        this.belongListOp = [];
        this.queryParams.saleUserId = '';
        if (newVal) {
          this.belongListAll.forEach((res) => {
            if (res.deptId == newVal) {
              this.belongListOp.push(res);
            }
          });
        } else {
          this.belongListOp = this.belongListAll
        }
      },
      activeTabName: {
        handler(newVal, oldVal) {
          if (newVal != '1' && this.queryParams.pageSize < 20) {
            this.queryParams.pageNo = 1
            this.queryParams.pageSize = 20
            this.$nextTick(() => {
              this.handleQuery();
            })
          }
        },
        deep: true,
      }
    },
    async created() {
      this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
      //归属销售
      this.getBelong();
      //获取商品大类
      let endDate = this.getBeforeMonth(0);
      this.queryParams.dateRange = [endDate, endDate];
      let endYear = endDate.slice(0, 4);
      let endMonth = endDate.slice(5, 7);
      await getTimeConfig({
          year: endYear,
          month: endMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.oneWeek) {
              this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              this.queryParams.endDate = resData.fourWeek.slice(11, 21)
            } else {
              this.queryParams.startDate = ''
              this.queryParams.endDate = ''
            }
          } else {
            this.queryParams.startDate = ''
            this.queryParams.endDate = ''
          }
        })
      this.getUser()
    },
    methods: {
      getUser() {
        getUserProfile().then((res) => {
          this.queryParams.area = res.data.builtInParentDeptId + '';
          this.posts = res.data.posts[0].id
          this.handleQuery();
        });
      },
      //归属销售
      async getBelong() {
        const res = await getBelong({
          isSale: true
        });
        this.belongListAll = res.data;
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //导出列表数据
      handleExport() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '业务员绩效.xls');
            this.exportLoading = false;
          })
          .catch(() => {
            this.exportLoading = false;
          });
      },
      onDatePickerChange(e) {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams.startDate = ''
              }
            } else {
              this.queryParams.startDate = ''
            }
          })
        getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.endDate = ''
            }
          })
      },
      handleQuery() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法统计数据`
          });
          return;
        }
        this.queryParams.customerTypes = this.queryParams.customerTypeMore.join(',')
        this.queryParams.pageNo = 1;
        this.tableLoading = true
        getList(
          this.queryParams
        ).then((res) => {
          this.tableLoading = false
          this.tableData = res.data;
          // this.queryParams.total = res.data.total;
        });
      },
      //重置
      async handleReset() {
        this.queryParams = deepClone(queryParamsCommon);
        this.queryParams.pageNo = 1;
        let endDate = this.getBeforeMonth(0);
        this.queryParams.dateRange = [endDate, endDate];
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        await getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.startDate = ''
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.startDate = ''
              this.queryParams.endDate = ''
            }
          })
        this.getUser()
      },
      //初始化导出数据
      formatQueryParams(queryParams) {
        let params = deepClone(queryParams);
        if (params._allAmount1 != '' && params._allAmount2 != '') {
          // params.allAmount = `${params._allAmount1},${params._allAmount2}`;
          params.allAmount = `${(params._allAmount1 * 1000).toFixed(3)},${(
          params._allAmount2 * 1000
        ).toFixed(3)}`;
        }
        if (params._allSum1 != '' && params._allSum2 != '') {
          params.allSum = `${params._allSum1},${params._allSum2}`;
        }
        delete params._orderDate;
        delete params._locationCity;
        return params;
      },
      //切换全屏
      handleScreen() {
        this.$refs.screenIcon.click()
      },
      //切换全屏
      handleScreenToggle(val) {
        this.isFullScreen = val
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .list_wrap {
    margin-top: 0 !important;
  }

  .cursor-p {
    color: #1890ff;
  }

  .component_title {
    padding: 10px 30px 0 20px;
  }

  ::v-deep .el-collapse-item__content {
    padding-bottom: 0 !important;
  }
</style>
