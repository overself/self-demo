<!-- 客户详情 -->
<template>
  <div class="app-container Board">
    <!-- 搜索工作栏 -->
    <el-row :gutter="20">
      <!--部门数据-->
      <!--用户数据-->
      <el-col
        :span="24"
        :xs="24"
      >
        <ControlHeader
          :showUpdateBtn="true"
          :clientData="clientInfo"
        ></ControlHeader>

        <div class="content_wrap">

          <el-tabs
            v-model="activeName"
            @tab-click="handleClick"
          >
            <el-tab-pane
              label="客户详情"
              name="first"
            >
              <div
                class="list_wrap"
                v-if="activeName === 'first'"
              >
                <ClientInfo
                  v-if="activeName === 'first'"
                  :clientInfo="clientInfo"
                  @getClient="getClient"
                ></ClientInfo>
              </div>
            </el-tab-pane>
            <!-- <el-tab-pane
              label="联系人"
              name="second"
            >
              <Link v-if="activeName === 'second'">
              </Link>
            </el-tab-pane> -->
            <el-tab-pane
              label="送货客户"
              name="secondHalf"
            >
              <Send v-if="activeName === 'secondHalf'">
              </Send>
            </el-tab-pane>
            <el-tab-pane
              label="客户画像"
              name="third"
              v-if="false"
            >
              <Picture
                v-if="activeName === 'third'"
                :clientCode="clientInfo.code"
              ></Picture>
            </el-tab-pane>
            <el-tab-pane
              label="跟进记录"
              name="fourth"
            >
              <Follow
                @toClientInfo="toClientInfo"
                :clientData="clientInfo"
                v-if="activeName === 'fourth'"
              ></Follow>
            </el-tab-pane>
            <el-tab-pane
              label="出库单记录"
              name="fifth"
              v-if="false"
            >
              <Out
                :clientCode="clientInfo.code"
                v-if="activeName === 'fifth'"
              ></Out>
            </el-tab-pane>
            <el-tab-pane
              label="客户更新日志"
              name="sixth"
            >
              <Log
                :clientId="clientId"
                v-if="activeName === 'sixth'"
              ></Log>
            </el-tab-pane>
          </el-tabs>
          <div class="tabs_right_btns">
            <!-- <el-button
              size="small"
              @click="handleSend"
            >指派客户</el-button>
            <el-button
              size="small"
              @click="handleOut"
            >导出</el-button> -->
          </div>
        </div>

      </el-col>

    </el-row>
    <!-- <div
      class="content_wrap"
      style="padding-top:0"
    >
      <div class="list_wrap">
        <List></List>
      </div>
    </div>
    <el-row>
      <el-col>
        <pagination
          :total="total"
          :page.sync="queryParams.pageNo"
          :limit.sync="queryParams.pageSize"
          @pagination="getList"
        />
      </el-col>
    </el-row> -->

  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import Screenfull from '@/components/Screenfull';
import ClientInfo from '../components/ClientInfo';
import List from './list';
import Link from '../components/Link';
import Send from '../components/Send';
import Picture from '../components/Picture/index';
import Follow from '../components/Follow';
import Out from '../components/Out';
import Log from '../components/Log.vue';
import ControlHeader from '../components/ContorlHeader';
import { getClient } from '@/api/Client/index';

export default {
  // import引入的组件需要注入到对象中才能使用
  name: 'ClientControlInfo',
  components: {
    List,
    Screenfull,
    ClientInfo,
    Link,
    Send,
    Picture,
    Follow,
    Out,
    ControlHeader,
    Log,
  },
  data() {
    // 这里存放数据
    return {
      total: 0,
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        username: undefined,
        mobile: undefined,
        status: undefined,
        deptId: undefined,
        createTime: [],
      },
      activeName: 'first',
      clientInfo: {},
      clientId: '',
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    toClientInfo() {
      this.activeName = 'first';
    },
    resetQuery() {},
    /*TODO：HWJ
    handleSend() {},
    handleOut() {},*/
    handleQuery() {},
    handleClick(tab, event) {
      //   console.log(tab, event);
    },
    async getClient() {
      const res = await getClient({ id: this.$route.params.clientId });
      this.clientInfo = res.data;
      //this.activeName = 'third'; TODO:HWJ
      this.activeName = 'first';
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {
    this.getClient();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.clientId = this.$route.params.clientId;
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
// @import url(); 引入公共css类
</style>
