<!-- 编辑客户 -->
<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <ControlHeader
          :showUpdateBtn="false"
          :clientData="companyForm"
        ></ControlHeader>

        <div
          class="component_title"
          style="margin-top:12px"
        >编辑客户
          <div class="title_disc"><span style="color: #D30607">*</span>为必填项</div>
        </div>
        <div class="component_class client_update">
          <div class="component_title">公司信息</div>
          <el-form
            :model="companyForm"
            ref="companyForm"
            :rules="companyRule"
            @submit.native.prevent
          >
            <el-card>
              <el-row :gutter="20">
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>客户编码
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="code"
                    >
                      <el-input
                        clearable
                        v-model="companyForm.code"
                        placeholder="请填写客户编码"
                        readonly
                        disabled
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>

                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>归属销售
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="belongSale"
                    >
                      <el-select v-model="companyForm.belongSale" readonly disabled
                                 placeholder="请选择归属销售"
                                 style="width:100%">
                        <el-option
                          v-for="dict in belongOptions"
                          :key="dict.userCode"
                          :label="dict.nickname"
                          :value="dict.userCode"
                        />
                      </el-select>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <!-- <span style="color: #D30607">*</span>归属大区 -->
                      <span>业务部门</span>
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="_area"
                    >
                      <span>{{ displayDeptName }}</span>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>

              <el-row :gutter="20">

                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>客户名称
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="name"
                    >
                      <el-input
                        clearable
                        v-model="companyForm.name"
                        placeholder="请填写客户名称"
                        readonly
                        disabled
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      所在区域
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="location"
                    >
                      <el-cascader
                        ref="cityRef"
                        filterable
                        style="width: 100%"
                        :placeholder="`请选择所在地区`"
                        v-model="location"
                        :options="cityOption"
                        @change="cityChange"
                        :props="{
                          checkStrictly: true,
                          label:'name',
                          value:'id'
                        }"
                      >
                      </el-cascader>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>客户分类
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="type"
                    >
                      <el-select readonly disabled
                                 v-model="companyForm.type"
                                 placeholder="请选择客户分类"
                                 style="width: 100%"
                      >
                        <el-option
                          v-for="item in clientTypes"
                          :key="item.value"
                          :value="item.value"
                          :label="item.label"
                        ></el-option>
                      </el-select>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>

              <el-row :gutter="20">
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>详细地址
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="locationDetail"
                    >
                      <el-input
                        clearable
                        v-model="companyForm.locationDetail"
                        maxlength="300"
                        show-word-limit
                        placeholder="请填写详细地址"
                        type="text"
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <!-- <span style="color: #D30607">*</span> -->
                      客户备注
                    </div>
                    <el-form-item class="register_item">
                      <el-input
                        clearable
                        v-model="companyForm.remark"
                        placeholder="请填写客户备注"
                        style
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>业务状态
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="code"
                    >
                      <el-input
                        clearable
                        placeholder="请填写业务状态"
                        readonly
                        :value="companyForm.businessStatus?'历史客户':'常用客户'"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <!-- <span style="color: #D30607">*</span> -->
                      客户标签
                    </div>
                    <el-form-item class="register_item">
                      <el-select
                        v-model="tags"
                        multiple
                        filterable
                        allow-create
                        default-first-option
                        placeholder="请选择标签"
                        style="width:100%"
                        @change="changeTags"
                      >
                        <el-option
                          v-for="item in options"
                          :key="item.id"
                          :label="item.name"
                          :value="item.id"
                          :disabled="item.status==0"
                        >
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      联系人
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="customerContactName"
                    >
                      <el-input
                        clearable
                        v-model="companyForm.customerContactName"
                        placeholder="请填写联系人"
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      联系方式
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="contactInfo"
                    >
                      <el-input
                        clearable
                        v-model="companyForm.contactInfo"
                        placeholder="请填写联系方式"
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      联系人邮箱
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="customerContactEmail"
                    >
                      <el-input
                        clearable
                        v-model="companyForm.customerContactEmail"
                        placeholder="请填写联系人邮箱"
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>
              <div>
                <el-button
                  size="small"
                  icon="el-icon-plus"
                  @click="addTag(item)"
                  v-for="(item, index) in options"
                  :key="index"
                  :disabled="tags.includes(item.id)||item.status==0"
                >{{ item.name }}
                </el-button>
              </div>
            </el-card>
          </el-form>
          <div class="footer_btn">
            <!-- <el-button type="info">重置</el-button> -->
            <el-button
              @click="submitForm('companyForm')"
              style="width:240px"
            >保存
            </el-button>
          </div>

        </div>
        <div
          class="component_title"
          style="margin-bottom:0"
        >联系人列表
          <div class="title_right_btns">
            <el-button
              size="small"
              @click="delAll"
            >删除
            </el-button>
            <el-button
              size="small"
              @click="addNewLink"
            >添加
            </el-button>
          </div>
        </div>
        <div class="content_wrap">
          <div class="list_wrap">
            <el-table
              v-loading="loading"
              :data="tableData"
              border
              @selection-change="handleSelectionChangePush"
              ref="multipleTable"
              :row-key="bindRowKeys"
              :cell-style="addClass"
            >
              <el-table-column
                type="selection"
                width="55"
                align="center"
                :reserve-selection="true"
              />
              <el-table-column
                label="姓名"
                align="center"
                prop="name"
              />
              <el-table-column
                label="性别"
                align="center"
                prop="sexStr"
              >
              </el-table-column>
              <el-table-column
                label="联系方式"
                align="center"
                prop="telephone"
              />
              <el-table-column
                label="联系人职位"
                align="center"
                prop="position"
              />
              <el-table-column
                label="联系人备注"
                align="center"
                prop="remark"
              />
              <el-table-column
                label="操作"
                align="center"
                width="260"
                class-name="small-padding fixed-width"
              >
                <template v-slot="scope">
                  <el-button
                    size="mini"
                    type="text"
                    icon="el-icon-edit"
                    v-if="!scope.row.isDefault"
                    @click="handleFollow(scope.row)"
                  >设为默认联系人
                  </el-button>
                  <el-button
                    size="mini"
                    type="text"
                    icon="el-icon-edit"
                    @click="handleDelete(scope.row)"
                  >删除
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
            <el-row>
              <el-col>
                <pagination
                  :total="total"
                  :page.sync="queryParams.pageNo"
                  :limit.sync="queryParams.pageSize"
                  @pagination="getList"
                />
              </el-col>
            </el-row>
          </div>
        </div>
        <el-dialog
          title="添加联系人"
          v-if="addVisible"
          :visible.sync="addVisible"
          width="500px"
        >
          <div class="flex_center">
            <el-form
              :model="linkForm"
              ref="linkForm"
              :rules="linkRule"
              @submit.native.prevent
            >
              <el-row :gutter="20">
                <el-col :span="24">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>联系人
                    </div>
                    <el-form-item
                      prop="name"
                      class="register_item"
                    >
                      <el-input
                        clearable
                        v-model="linkForm.name"
                        placeholder="请填写联系人"
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="24">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>联系人手机号码
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="telephone"
                    >
                      <el-input
                        clearable
                        v-model="linkForm.telephone"
                        placeholder="请填写手机号码"
                        style
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="24">
                  <div class="flex_row">
                    <div class="form_label">
                      <!-- <span style="color: #D30607">*</span> -->联系人职位
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="position"
                    >
                      <el-input
                        clearable
                        v-model="linkForm.position"
                        placeholder="请填写职位"
                        style
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="24">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>联系人性别
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="sex"
                    >
                      <el-select
                        v-model="linkForm.sex"
                        placeholder="请选择联系人性别"
                        style="width:100%"
                      >
                        <el-option
                          v-for="dict in sexDictDatas"
                          :key="parseInt(dict.value)"
                          :label="dict.label"
                          :value="parseInt(dict.value)"
                        />
                      </el-select>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="24">
                  <div class="flex_row">
                    <div class="form_label">
                      <!-- <span style="color: #D30607">*</span> -->联系人备注
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="remark"
                    >
                      <el-input
                        type="textarea"
                        :autosize="{ minRows: 2, maxRows: 4}"
                        maxlength="300"
                        show-word-limit
                        clearable
                        v-model="linkForm.remark"
                        placeholder="请填写联系人备注"
                        style
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>
            </el-form>
          </div>
          <span
            slot="footer"
            class="dialog-footer"
          >
                    <el-button
                      type="info"
                      @click="hiddenDialog"
                    >取 消</el-button>
                    <el-button
                      v-loading="submitLoading"
                      type="primary"
                      @click="submitConfirmLink"
                    >确 认</el-button>
                  </span>
        </el-dialog>
        <!-- <div class="component_class client_update"> -->
        <!-- <div class="component_title">联系人信息</div>
        <template v-if="customerContactList.length>0">

          <el-form
            v-for="(item,index) in customerContactList"
            :key="index"
            :model="item"
            :rules="linkRule"
            ref="linkRef"
            @submit.native.prevent
          >
            <el-card style="position:relative;padding-top:20px">
              <el-button
                class="delete_btn"
                type="danger"
                icon="el-icon-delete"
                circle
                @click="deleteLink(index)"
              ></el-button>

              <el-row :gutter="20">
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>联系人
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="name"
                    >
                      <el-input
                        clearable
                        v-model="item.name"
                        placeholder="请填写联系人"
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <span style="color: #D30607">*</span>联系方式
                    </div>
                    <el-form-item
                      class="register_item"
                      prop="telephone"
                    >
                      <el-input
                        clearable
                        v-model="item.telephone"
                        placeholder="请填写手机号码"
                        style
                      ></el-input>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="flex_row">
                    <div class="form_label">
                      <!-- <span style="color: #D30607">*</span> -->
        <!-- 职位
      </div>
      <el-form-item
        class="register_item"
        prop="position"
      >
        <el-input
          clearable
          v-model="item.position"
          placeholder="请填写职位"
          style
        ></el-input> -->
        <!-- <el-select
          v-model="item.position"
          clearable
          placeholder="请填写职位"
          style="width:100%"
        >
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select> -->
        <!-- </el-form-item>
      </div>
    </el-col>
  </el-row>
  <el-row :gutter="20">
    <el-col :span="8">
      <div class="flex_row">
        <div class="form_label">
          <span style="color: #D30607">*</span>
          性别
        </div>
        <el-form-item
          class="register_item"
          prop="sex"
        >
          <el-select
            v-model="item.sex"
            placeholder="请选择联系人性别"
            style="width:100%"
          >
            <el-option
              v-for="dict in sexDictDatas"
              :key="parseInt(dict.value)"
              :label="dict.label"
              :value="parseInt(dict.value)"
            />
          </el-select>
        </el-form-item>
      </div>
    </el-col>
    <el-col :span="16">
      <div class="flex_row">
        <div class="form_label"> -->
        <!-- <span style="color: #D30607">*</span> -->
        <!-- 备注
      </div>
      <el-form-item
        class="register_item"
        prop="remark"
      >
        <el-input
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 4}"
          maxlength="300"
          show-word-limit
          clearable
          v-model="item.remark"
          placeholder="请填写备注"
          style
        ></el-input>
      </el-form-item>
    </div>
  </el-col>
</el-row>
</el-card>

<div class="divider"></div>
</el-form>
</template>

<div>
<el-button
size="small"
icon="el-icon-plus"
@click="addNew"
>新增联系人</el-button>
</div>
</div> -->
      </el-col>
    </el-row>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import {deepClone} from '@/utils';
import {DICT_TYPE, getDictDatas} from '@/utils/dict';
import ControlHeader from '../components/ContorlHeader';
import {listData, addClient, setClient, delClient} from '@/api/Client/link';
import {
  getClient,
  getClientTags,
  getBelong,
  updateClient,
} from '@/api/Client/index';
import {getAreaTree} from '@/api/system/area';

const linkManObj = {
  // linkForm: {
  name: '',
  telephone: '',
  position: '',
  sex: '',
  remark: '',
  // },
  // linkRule: {
  //   name: [{ required: true, message: '请填写联系人', trigger: 'blur' }],
  //   telephone: [
  //     { required: true, message: '请填写手机号', trigger: 'blur' },
  //     {
  //       pattern:
  //         /^(?:(?:\+|00)86)?1(?:3[\d]|4[5-79]|5[0-35-9]|6[5-7]|7[0-8]|8[\d]|9[189])\d{8}$/,
  //       message: '请填写正确的手机号码',
  //       trigger: 'blur',
  //     },
  //   ],
  //   position: [
  //     {
  //       required: true,
  //       message: '请选择职位',
  //       trigger: ['blur', 'change'],
  //     },
  //   ],

  //   sex: [
  //     {
  //       required: true,
  //       message: "'请填写正确的邮箱地址",
  //       trigger: ['blur', 'change'],
  //     },
  //   ],
  //   remark: [
  //     {
  //       required: true,
  //       message: "'请填写联系人备注",
  //       trigger: ['blur', 'change'],
  //     },
  //   ],
  // },
};
export default {
  // import引入的组件需要注入到对象中才能使用
  name: 'ClientControlUpdate',
  components: {ControlHeader},
  data() {
    // 这里存放数据
    return {
      pickerOptions: {
        disabledDate(time) {
          const currentDate = new Date();
          const currentYear = currentDate.getFullYear();
          const currentMonth = currentDate.getMonth() + 1; // 月份是从0开始的，所以需要+1
          // 获取传入日期的年份和月份
          const year = time.getFullYear();
          const month = time.getMonth() + 1;
          // 判断年份和月份是否相同，不同则禁用
          return year !== currentYear || month !== currentMonth;
        },
      },
      tableData: [],
      addVisible: false,
      submitLoading: false,
      linkForm: {
        customerId: null,
        name: '',
        telephone: '',
        position: '',
        sex: null,
        remark: '',
      },
      linkRule: {
        name: [{required: true, message: '请填写联系人', trigger: 'blur'}],
        telephone: [
          {required: true, message: '请填写手机号', trigger: 'blur'},
          {
            pattern:
              /^(?:(?:\+|00)86)?1(?:3[\d]|4[5-79]|5[0-35-9]|6[5-7]|7[0-8]|8[\d]|9[189])\d{8}$/,
            message: '请填写正确的手机号码',
            trigger: 'blur',
          },
        ],
        // position: [
        //   {
        //     required: true,
        //     message: '请选择职位',
        //     trigger: ['blur', 'change'],
        //   },
        // ],

        sex: [
          {
            required: true,
            message: '请选择性别',
            trigger: ['blur', 'change'],
          },
        ],
        // remark: [
        //   {
        //     required: true,
        //     message: "'请填写联系人备注",
        //     trigger: ['blur', 'change'],
        //   },
        // ],
      },
      linkManSelect: [],
      loading: false,
      input: '',
      total: 0,
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        customerId: '',
      },
      areaObj: {
        101: '宏发一区',
        102: '宏发二区',
        103: '宏发三区',
      },
      cityOption: [],
      data: [
        {
          id: 1,
          label: '一级 1',
          children: [
            {
              id: 4,
              label: '二级 1-1',
              children: [
                {
                  id: 9,
                  label: '三级 1-1-1',
                },
                {
                  id: 10,
                  label: '三级 1-1-2',
                },
              ],
            },
          ],
        },
        {
          id: 2,
          label: '一级 2',
          children: [
            {
              id: 5,
              label: '二级 2-1',
            },
            {
              id: 6,
              label: '二级 2-2',
            },
          ],
        },
        {
          id: 3,
          label: '一级 3',
          children: [
            {
              id: 7,
              label: '二级 3-1',
            },
            {
              id: 8,
              label: '二级 3-2',
            },
          ],
        },
      ],
      defaultProps: {
        children: 'children',
        label: 'name',
        disabled: (item) => item.status == 0,
      },
      defaultExpandedKeys: [1, 2, 3],
      defaultcheckedKeys: [],
      pathOptions: [
        {
          value: 1,
          label: '东南',
          children: [
            {
              value: 2,
              label: '上海',
              children: [
                {value: 3, label: '普陀'},
                {value: 4, label: '黄埔'},
                {value: 5, label: '徐汇'},
              ],
            },
            {
              value: 7,
              label: '江苏',
              children: [
                {value: 8, label: '南京'},
                {value: 9, label: '苏州'},
                {value: 10, label: '无锡'},
              ],
            },
            {
              value: 12,
              label: '浙江',
              children: [
                {value: 13, label: '杭州'},
                {value: 14, label: '宁波'},
                {value: 15, label: '嘉兴'},
              ],
            },
          ],
        },
        {
          value: 17,
          label: '西北',
          children: [
            {
              value: 18,
              label: '陕西',
              children: [
                {value: 19, label: '西安'},
                {value: 20, label: '延安'},
              ],
            },
            {
              value: 21,
              label: '新疆维吾尔族自治区',
              children: [
                {value: 22, label: '乌鲁木齐'},
                {value: 23, label: '克拉玛依'},
              ],
            },
          ],
        },
      ],
      linkRule: {
        name: [{required: true, message: '请填写联系人', trigger: 'blur'}],
        telephone: [
          {required: true, message: '请填写手机号', trigger: 'blur'},
          {
            pattern:
              /^(?:(?:\+|00)86)?1(?:3[\d]|4[5-79]|5[0-35-9]|6[5-7]|7[0-8]|8[\d]|9[189])\d{8}$/,
            message: '请填写正确的手机号码',
            trigger: 'blur',
          },
        ],
        // position: [
        //   {
        //     required: true,
        //     message: '请选择职位',
        //     trigger: ['blur', 'change'],
        //   },
        // ],

        sex: [
          {
            required: true,
            message: "'请选择性别",
            trigger: ['blur', 'change'],
          },
        ],
        // remark: [
        //   {
        //     required: true,
        //     message: "'请填写联系人备注",
        //     trigger: ['blur', 'change'],
        //   },
        // ],
      },
      options: [],
      companyForm: {
        id: null,
        code: '',
        type: null,
        belongSale: null,
        belongSaleDate: '',
        name: '',
        fullName: '',
        location: '',
        locationProvinceCode: '',
        locationCityCode: '',
        locationDetail: '',
        channelTypeIds: '',
        remark: '',
        signIds: '',
        contactInfo: '',
        customerContactEmail: '',
        customerContactName: '',

      },
      channelTypeIdsArr: [],
      location: [],
      tags: [],
      companyRule: {
        code: [{required: true, message: '请填写客户编码', trigger: 'blur'}],
        type: [
          {required: true, message: '请选择客户分类', trigger: 'change'},
        ],
        belongSale: [
          {required: true, message: '请选择归属销售', trigger: 'change'},
        ],
        belongSaleDate: [
          {required: true, message: '请选择指派时间', trigger: 'blur'},
        ],
        name: [{required: true, message: '请填写客户名称', trigger: 'blur'}],
        // location: [
        //   { required: true, message: '请选择所在区域', trigger: 'change' },
        // ],
        locationDetail: [
          {required: true, message: '请填写详细地址', trigger: 'blur'},
        ],
        // contactInfo: [
        //   { required: true, message: '请填写联系方式', trigger: 'blur' },
        // ],
        // channelTypeIds: [
        //   { required: true, message: '请选择渠道分类', trigger: 'change' },
        // ],
      },
      belongOptions: [],
      /*      channelTree: [],
            channelOptions: [],
            clientAreaOptions: [
              {
                label: '宏发一区',
                value: '宏发一区',
              },
              {
                label: '宏发二区',
                value: '宏发二区',
              },
              {
                label: '宏发三区',
                value: '宏发三区',
              },
            ],*/
      customerContactList: [],
      sexDictDatas: getDictDatas(DICT_TYPE.SYSTEM_USER_SEX),
      clientTypes: getDictDatas(DICT_TYPE.CLIENT_TYPE),
    };
  },

  computed: {
    displayDeptName() {
      return (
        this.belongOptions.find(
          (item) => item.userCode === this.companyForm.belongSale
        )?.deptName ?? ''
      );
    },
  },

  created() {
    this.linkForm.customerId = this.$route.params.clientId;
    this.queryParams.customerId = this.$route.params.clientId;
    this.getList();
    getAreaTree().then((res) => {
      this.cityOption = res.data;
      this.cityOption.forEach((item) => {
        item.label = item.name;
        item.value = item.id;
        item.children.forEach((i) => {
          i.label = i.name;
          i.value = i.id;
          delete i.children;
        });
      });
    });
    this.getClient();
    this.getBelong();
    this.getClientTags();
  },

  methods: {
    bindRowKeys(row) {
      return row.id;
    },
    addNewLink() {
      this.addVisible = true;
    },
    async getList() {
      this.loading = true;
      console.log('queryParams', this.queryParams);
      const queryParams = {
        ...this.queryParams,
      };
      const res = await listData(queryParams);
      this.tableData = res.data.list;
      this.total = res.data.total;
      this.loading = false;
    },
    hiddenDialog() {
      this.linkForm.name = '';
      this.linkForm.telephone = '';
      this.linkForm.position = '';
      this.linkForm.sex = '';
      this.linkForm.remark = '';
      this.addVisible = false;
    },
    submitConfirmLink() {
      this.$refs['linkForm'].validate((valid) => {
        if (valid) {
          this.submitLink();
        } else {
          console.log('error submit!!');
          return false;
        }
      });
      console.log(this.linkForm);
    },
    async submitLink() {
      this.submitLoading = true;
      const res = await addClient(this.linkForm);
      this.$confirm('联系人信息提交成功', '提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
        })
        .catch(() => {
        });
      this.submitLoading = false;
      this.getList();
      this.hiddenDialog();
    },
    delAll() {
      if (this.linkManSelect.length <= 0) {
        this.$message.error('请选择需要删除的客户');
        return false;
      }
      this.$confirm('是否确认删除所选联系人', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.calcDeleteIds();
        })
        .catch(() => {
        });
    },
    handleDelete(row) {
      this.$confirm('是否确认删除该联系人', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.linkDelete(row.id);
        })
        .catch(() => {
        });
    },
    calcDeleteIds() {
      let ids = this.linkManSelect.map((item) => item.id);
      console.log(ids);
      this.linkDelete(ids.join(','));
    },
    async linkDelete(ids) {
      const res = await delClient({ids});
      this.$message({
        message: '删除成功',
        type: 'success',
      });
      this.$refs['multipleTable'].clearSelection()
      this.getList();
    },
    handleFollow(row) {
      this.$confirm('是否设置该联系人为默认', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.linkSet(row);
        })
        .catch(() => {
        });
    },
    async linkSet(row) {
      const res = await setClient({id: row.id});
      this.$message({
        message: '设置成功',
        type: 'success',
      });
      this.getList();
    },
    handleSelectionChangePush(selection) {
      console.log(selection);
      this.linkManSelect = selection;
    },
    addClass({row, column, rowIndex, columnIndex}) {
      if (row[column.property] == null || row[column.property] == '') {
        row[column.property] = '-';
      }
    },
    handleDelete(row) {
      this.$confirm('是否确认删除该联系人', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.linkDelete(row.id);
        })
        .catch(() => {
        });
    },
    async getClient() {
      const res = await getClient({id: this.$route.params.clientId});
      //   console.log(res);
      this.clientInfo = res.data;
      if (this.clientInfo.signNames) {
        this.signNames = this.clientInfo.signNames.split(',');
      }

      //   console.log(this.signNames);
    },
    submitForm() {
      this.$refs['companyForm'].validate((valid) => {
        if (valid) {
          if (this.$refs.linkRef) {
            this.submitLink();
          } else {
            this.updateClient();
          }
        } else {
          // console.log('error submit!!');
          // console.log(this.location);
          return false;
        }
      });
    },
    // submitLink() {
    //   this.$refs['linkRef'].map((ref) => {
    //     ref.validate((valid) => {
    //       if (valid) {
    //         this.updateClient();
    //       }
    //     });
    //   });
    // },
    async updateClient() {
      // console.log(this.companyForm);
      this.companyForm.signIds = this.tags.join(',');
      this.companyForm.customerContactList = this.customerContactList;
      // console.log(this.customerContactList);
      // return;
      const res = await updateClient(this.companyForm);
      this.$confirm('客户信息保存成功', '提示', {
        confirmButtonText: '返回列表',
        cancelButtonText: '重新修改',
        type: 'warning',
      })
        .then(() => {
          this.$router.push({
            path: '/client/client-control',
          });
          this.$EventBus.$emit('refreshClientList');
        })
        .catch(() => {
        });
    },
    cityChange(e) {
      // console.log(e);
      if (e.length > 0) {
        const checkedNodes = this.$refs['cityRef'].getCheckedNodes(); // 获取当前点击的节点
        // console.log(checkedNodes);
        // console.log(checkedNodes[0].pathLabels); // 获取由 label 组成的数组checkedNodes[0].pathLabels
        const pathLabels = checkedNodes[0].pathLabels;
        this.companyForm.locationProvinceCode = e[0];
        this.companyForm.locationCityCode = e[1];
        this.companyForm.locationProvince = pathLabels[0];
        this.companyForm.locationCity = pathLabels[1];
        this.companyForm.location = `${pathLabels[0]}`;
      } else {
        this.companyForm.locationProvinceCode = '';
        this.companyForm.locationCityCode = '';
        this.companyForm.locationProvince = '';
        this.companyForm.locationCity = '';
        this.companyForm.location = '';
      }
    },
    handleCheckChange() {
      this.channelTypeIdsArr = this.calcChannelTypeIds();
    },
    handleRemoveTag(tag) {
      // 移除
      this.$refs.tree.setChecked(tag, false);
      this.calcChannelTypeIds();
    },
    calcChannelTypeIds() {
      // console.log('看看都选中什么', list);
      const list = this.$refs.tree.getCheckedKeys(true);
      this.companyForm.channelTypeIds = list.join(',');
      return list;
    },
    addTag(item) {
      this.tags.push(item.id);
      // console.log(this.tags);
      // console.log(this.tags.includes(item.id));
    },
    addNew() {
      // 添加联系人
      // console.log('添加联系人');
      this.customerContactList.push({
        name: '',
        telephone: '',
        position: '',
        sex: '',
        remark: '',
      });
    },
    // deleteLink(idx) {
    //   this.customerContactList.splice(idx, 1);
    // },
    changeTags(e) {
      // console.log(e);
    },
    resetQuery() {
    },
    handleSend() {
    },
    handleOut() {
    },
    handleQuery() {
    },
    handleClick(tab, event) {
      // console.log(tab, event);
    },

    async getClient() {
      const res = await getClient({id: this.$route.params.clientId});
      // console.log(res);
      this.companyForm = {
        id: res.data.id,
        code: res.data.code,
        type: res.data.type,
        belongSale: res.data.belongSale,
        belongSaleName: res.data.belongSaleName,
        name: res.data.name,
        fullName: res.data.fullName,
        location: res.data.location,
        locationProvinceCode: res.data.locationProvinceCode,
        locationProvince: res.data.locationProvince,
        locationCityCode: res.data.locationCityCode,
        locationCity: res.data.locationCity,
        locationDetail: res.data.locationDetail,
        channelTypeIds: res.data.channelTypeIds,
        remark: res.data.remark,
        contactInfo: res.data.contactInfo,
        customerContactEmail: res.data.customerContactEmail,
        customerContactName: res.data.customerContactName,
        belongSaleDate: res.data.belongSaleDate,
      };
      if ('' !== res.data.locationProvinceCode) {
        if ('' !== res.data.locationCityCode && undefined !== res.data.locationCityCode
          && null !== res.data.locationCityCode) {
          this.location[0] = res.data.locationProvinceCode * 1;
          this.location[1] = res.data.locationCityCode * 1;

        } else {
          this.location = res.data.locationProvinceCode * 1
        }
      }
      // console.log(this.location);
      // console.log(this.channelTypeIdsArr);
      this.channelTypeIdsArr = res.data.channelTypeIds
        ? res.data.channelTypeIds.split(',')
        : [];
      // console.log(this.channelTypeIdsArr);
      this.$nextTick(() => {
        this.$refs.tree?.setCheckedKeys(this.channelTypeIdsArr, true);
      });
      if (res.data.signIds) {
        this.tags = res.data.signIds.split(',') || [];
      }
    },

    async getBelong() {
      const res = await getBelong({isSale: true});
      this.belongOptions = res.data;
    },

    async getClientTags() {
      const res = await getClientTags();
      this.options = res.data.map((item) => {
        item.id = item.id.toString();
        return item;
      });
    },
    arrayToTree(items, rootId = 0) {
      const tree = [];
      const nodeMap = {};

      // 首先创建一个映射表，键是节点id，值是节点对象
      items.forEach((item) => {
        nodeMap[item.id] = {...item, children: []};
      });

      // 然后遍历数组，根据parentId找到对应的父节点并添加子节点
      items.forEach((item) => {
        const parentId = item.parentId;
        const node = nodeMap[item.id];
        const parent = nodeMap[parentId];

        if (parent) {
          parent.children.push(node);
        } else {
          tree.push(node);
        }
      });

      // 返回以rootId为根的树
      return tree.find((node) => node.id === rootId) || tree;
    },
    treeToArrayWithParents(tree, parentPath = '') {
      let result = [];

      function traverse(node, path = parentPath) {
        const newNode = {...node, name: `${path} ${node.name}`};
        result.push(newNode);

        if (node.children && node.children.length > 0) {
          node.children.forEach((child) => {
            traverse(child, `${newNode.name}/`);
          });
        }
      }

      tree.forEach((rootNode) => {
        traverse(rootNode);
      });

      return result;
    },
  },
};
</script>
<style lang="scss" scoped>
// @import url(); 引入公共css类
.component_class {
  background-color: #fff;
  padding: 10px;
  border-radius: 8px;
  margin-bottom: 20px;
}

.footer_btn {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 36px;
}

.delete_btn {
  position: absolute;
  top: 10px;
  right: 10px;
  z-index: 1;
}

::v-deep .el-date-editor.el-input,
::v-deep .el-date-editor.el-input__inner {
  width: 100%;
}
</style>
