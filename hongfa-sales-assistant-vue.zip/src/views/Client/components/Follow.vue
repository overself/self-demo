<!-- 价格库存看板 -->
<template>
  <div class="">
    <div class="component_title">跟进记录
      <div class="title_right_btns">
        <el-radio-group
          v-model="orderDateStr"
          @input="radioChange"
          size="small"
        >
          <el-radio-button
            v-for="(item, index) in options"
            :key="index"
            :label="item.value"
          >{{item.label}}</el-radio-button>
        </el-radio-group>
        <el-date-picker
          v-model="orderDate"
          @change="datePickerChange"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          size="small"
          :format="'yyyy-MM-dd'"
          :valueFormat="'yyyy-MM-dd'"
          :style="{width: '240px'}"
          clearable
        ></el-date-picker>
      </div>
    </div>
    <div class="component_class timeline">

      <el-timeline v-if="tableData.length>0">
        <el-timeline-item
          :timestamp="follow.followTimeStr"
          placement="top"
          v-for="(follow, index) in tableData"
          :key="index"
        >
          <el-card
            style="margin-bottom:16px"
            v-for="item in follow.items"
            :key="item.id"
          >
            <div class="timeline_header">
              <div class="header_title">{{item.contactName}} 跟进({{item.followType}})</div>
              <div class="header_time">{{parseTime(item.createTime)}}</div>
            </div>
            <div class="timeline_content">
              {{item.content}}
            </div>
            <div class="timeline_footer">
              <div>
                <!-- 来自客户： 北票宏发食品有限公司 -->
              </div>
              <div class="footer_control">
                <el-button
                  size="small"
                  @click="showDetail(item.id)"
                >详情</el-button>
                <el-button
                  size="small"
                  @click="handleDelete(item)"
                >删除</el-button>
              </div>
            </div>
          </el-card>
        </el-timeline-item>
      </el-timeline>
      <el-empty
        description="暂无数据"
        v-else
      ></el-empty>
    </div>

    <el-dialog
      title="跟进详情"
      :visible.sync="showFollowDialog"
      width="500px"
    >
      <div class="flex_center">
        <el-descriptions
          class="margin-top"
          title=""
          :column="1"
          border
        >
          <template slot="extra">
            <el-button
              size="small"
              @click="updateFollow"
            >编辑跟进</el-button>
          </template>
          <el-descriptions-item>
            <template slot="label">
              创建时间
            </template>
            {{parseTime(followDetail.createTime)}}
          </el-descriptions-item>

          <el-descriptions-item>
            <template slot="label">
              归属销售
            </template>
            <el-tag
              size="small"
              v-if="clientData.belongSaleName"
            > {{clientData.belongSaleName}}
            </el-tag>
          </el-descriptions-item>

          <el-descriptions-item>
            <template slot="label">
              客户名称
            </template>
            <div
              @click="clickClient"
              class="can_click"
            >
              {{clientData.name}}
            </div>
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              联系人
            </template>
            <el-tag size="small"> {{followDetail.contactName}}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              内容描述
            </template>
            {{followDetail.content}}
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              附件
            </template>
            <el-button
              type="text"
              @click="download(file)"
              v-for="file in followDetail.files"
              :key="file.id"
            >{{file.name}}</el-button>
          </el-descriptions-item>
        </el-descriptions>

      </div>
      <span
        slot="footer"
        class="dialog-footer"
      >
        <el-button
          type="info"
          @click="showFollowDialog = false"
        >取 消</el-button>
      </span>
      <el-image
        style="width: 0;height: 0;"
        v-if="showImage"
        class="hideImgDiv"
        ref="preview"
        :src="imgList[0]"
        :preview-src-list="imgList"
      >
      </el-image>
    </el-dialog>
  </div>
</template>

<script>
import { listData, getFollow, delFollow } from '@/api/Client/follow';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: {},
  props: {
    clientData: {
      type: Object,
      default: () => {
        return {};
      },
    },
  },
  data() {
    // 这里存放数据
    return {
      showImage: false,
      imgList: [],
      followDetail: {
        // createTime: '2024-03-20 12:00',
        // company: '北票宏发食品有限公司',
        // saleMan: '赵小刚',
        // linkMan: '李小红',
        // disc: '这是一个描述描述比较长这是一个描述描述比较长这是一个描述描述比较长这是一个描述描述比较长',
      },
      showFollowDialog: false,
      dateValue: 0,
      options: [],
      total: 0,
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        customerId: undefined,
        fromDate: undefined,
        toDate: undefined,
      },
      tableData: [
        // {
        //   id: 1,
        //   clientName: '客户名称',
        //   linkName: '联系人',
        //   linkNumber: '联系方式',
        //   area: '所在地区',
        //   clientCat: '客户分类',
        //   pathCat: '渠道分类',
        //   belong: '归属大区',
        //   belongSaler: '归属销售',
        //   state: '客户状态',
        //   time: '最近成交时间',
        // },
        // {
        //   id: 2,
        //   clientName: '客户名称',
        //   linkName: '联系人',
        //   linkNumber: '联系方式',
        //   area: '所在地区',
        //   clientCat: '客户分类',
        //   pathCat: '渠道分类',
        //   belong: '归属大区',
        //   belongSaler: '归属销售',
        //   state: '客户状态',
        //   time: '最近成交时间',
        // },
        // {
        //   id: 3,
        //   clientName: '客户名称',
        //   linkName: '联系人',
        //   linkNumber: '联系方式',
        //   area: '所在地区',
        //   clientCat: '客户分类',
        //   pathCat: '渠道分类',
        //   belong: '归属大区',
        //   belongSaler: '归属销售',
        //   state: '客户状态',
        //   time: '最近成交时间',
        // },
        // {
        //   id: 4,
        //   clientName: '客户名称',
        //   linkName: '联系人',
        //   linkNumber: '联系方式',
        //   area: '所在地区',
        //   clientCat: '客户分类',
        //   pathCat: '渠道分类',
        //   belong: '归属大区',
        //   belongSaler: '归属销售',
        //   state: '客户状态',
        //   time: '最近成交时间',
        // },
      ],
      stockData: {
        xData: [
          '2024-5-1',
          '2024-5-2',
          '2024-5-3',
          '2024-5-4',
          '2024-5-5',
          '2024-5-6',
          '2024-5-7',
        ],
        yData: [0, 100, 200, 300, 400, 500, 600],
        max: 200,
        min: 20,
      },
      menuData: [],
      calcListData: [],
      orderDate: [],
      orderDateStr: '',
      followId: null,
    };
  },
  // 监听属性 类似于data概念
  computed: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
  },
  // 监控data中的数据变化
  watch: {
    orderDate(newVal, oldVal) {
      console.log(newVal, oldVal);
      this.$nextTick(() => {
        this.getList();
      });
    },
  },
  // 方法集合
  methods: {
    download(file) {
      if (
        file.type == 'image/png' ||
        file.type == 'image/jpg' ||
        file.type == 'image/jpeg'
      ) {
        // console.log('图片');
        this.imgList.push(file.url);
        this.showImage = true;
        this.$nextTick(() => {
          this.$refs.preview.clickHandler();
        });
      } else {
        var element = document.createElement('a');
        element.setAttribute('href', file.url);
        element.setAttribute('download', file.name);
        // 触发点击
        document.body.appendChild(element);
        element.click();

        // 然后移除
        document.body.removeChild(element);
      }
    },
    async getList() {
      this.loading = true;
      console.log('queryParams', this.queryParams);
      const queryParams = {
        ...this.queryParams,
      };
      const res = await listData(queryParams);
      const tempTableData = res.data.list.map((item) => {
        item.followTimeStr = this.$dayjs(item.followTime).format('YYYY-MM-DD');
        return item;
      });

      this.tableData = tempTableData.reduce((accumulator, currentItem) => {
        // 如果accumulator中还没有这个followTimeStr，创建一个新的条目
        if (
          !accumulator.some(
            (item) => item.followTimeStr === currentItem.followTimeStr
          )
        ) {
          accumulator.push({
            followTimeStr: currentItem.followTimeStr,
            items: [],
          });
        }
        // 找到对应的followTimeStr条目，并将当前item添加到其items数组中
        const group = accumulator.find(
          (item) => item.followTimeStr === currentItem.followTimeStr
        );
        group.items.push(currentItem);
        return accumulator;
      }, []);
      console.log('处理后的', this.tableData);
      this.total = res.data.total;
      this.loading = false;
    },
    updateFollow() {
      this.$EventBus.$emit('addNewFollow', this.followDetail);
    },
    clickClient() {
      this.showFollowDialog = false;
      this.$emit('toClientInfo');
    },
    showDetail(id) {
      this.followId = id;
      this.getFollow();
      // 展示跟进详情
      this.showFollowDialog = true;
    },
    async getFollow() {
      const res = await getFollow({
        id: this.followId,
      });
      this.followDetail = res.data;
    },
    handleFollow() {},
    handleInfo() {
      this.$router.push({
        path: '/client/info',
      });
      console.log('详情按钮');
    },
    handleSelectionChangePush(selection) {
      this.multiple = selection;
    },
    bindRowKeys(row) {
      return row.id;
    },
    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      }
    },
    setDateOptions() {
      this.options = [
        { label: '本周', value: this.getRangeDate('week') },
        { label: '本月', value: this.getRangeDate('month') },
        { label: '季度', value: this.getRangeDate('quarter') },
        { label: '全年', value: this.getRangeDate('year') },
      ];
      this.radioChange(this.options[0].value);
      console.log(this.options);
      this.getList();
    },
    radioChange(value) {
      this.orderDateStr = value;
      this.queryParams.fromDate = value.split(',')[0];
      this.queryParams.toDate = value.split(',')[1];
      this.orderDate = value.split(',');
    },
    datePickerChange(value) {
      console.log(value);
      if (!value) {
        this.queryParams.fromDate = '';
        this.queryParams.toDate = '';
      } else {
        this.queryParams.fromDate = value[0];
        this.queryParams.toDate = value[1];
      }
    },
    handleDelete(row) {
      this.$confirm('是否确认删除该跟进记录', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.followDelete(row.id);
        })
        .catch(() => {});
    },
    async followDelete(id) {
      const res = await delFollow({ id });
      this.$message({
        message: '删除成功',
        type: 'success',
      });
      this.getList();
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {
    this.queryParams.customerId = this.$route.params.clientId;
    this.setDateOptions();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.$EventBus.$on('getFollowList', this.getList);
    this.$EventBus.$on('getFollow', this.getFollow);
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {
    this.$EventBus.$off('getFollowList', this.getList);
    this.$EventBus.$off('getFollow', this.getFollow);
  }, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}
// @import url(); 引入公共css类
.component_class {
  background-color: #fff;
  padding: 30px 10px 10px;
  border-radius: 8px;
  margin-bottom: 20px;
}
.timeline {
  .timeline_header {
    display: flex;
    justify-content: space-between;
    .header_title {
      font-size: 18px;
    }
  }
  .timeline_content {
    margin: 20px 0;
    // min-height: 100px;
  }
  .timeline_footer {
    display: flex;
    justify-content: space-between;
    .footer_control {
    }
  }
}

::v-deep {
  .is-bordered-label {
    width: 100px;
  }
}

::v-deep .el-timeline-item__timestamp.is-top {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  width: 111px;
  height: 39px;
  line-height: 30px;
  font-size: 16px;
  color: #fff;
  /* background-color: #409eff; */
  background-image: url('~@/assets/images/tag.png');
  background-size: 100% 100%;
  position: absolute;
  top: -11px;
}
::v-deep .el-timeline-item__wrapper {
  padding-top: 50px;
}
</style>
