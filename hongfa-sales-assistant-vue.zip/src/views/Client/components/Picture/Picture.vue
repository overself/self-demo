<!-- 数据统计 -->
<template>
  <div class=''>
    <div
      class="control_bar"
      v-loading='loading'
    >
      <!-- <el-radio-group v-model="dayValue">
        <el-radio-button
          v-for="(item, index) in options"
          :key="index"
          :label="item.value"
        >{{item.label}}</el-radio-button>
      </el-radio-group> -->
      <div>
        <el-date-picker
          v-model="year"
          type="year"
          size="small"
          :format="'yyyy'"
          :valueFormat="'yyyy'"
          :style="{width: '240px'}"
          @change='handleYearChange'
          :picker-options="pickerOptions"
          :clearable="false"
        ></el-date-picker>
        <el-button
          size="small"
          @click="handleQuery"
          style='margin-left: 12px;'
        >查询</el-button>

      </div>
    </div>
    <el-row
      :gutter="20"
      style='margin-top: 12px;'
    >
      <el-col :span="6">
        <div>总销售量<span>
            {{info?.allSales?.sum || '-'}}吨</span></div>
        <PictureData
          :chartData='chartData1'
          :timeArr='timeData1'
        ></PictureData>
        <div class="text-wrapper">
          <span class="text-label">月均 {{info?.allSales?.avg || '-'}}吨 </span>
          <span class="text-label">最高 {{info?.allSales?.max || '-'}}吨</span>
          <span class="text-label">最低 {{info?.allSales?.min  || '-'}}吨</span>
        </div>

      </el-col>
      <el-col :span="6">
        <div>总出库额<span>
            ¥ {{(Number(info?.allAmount?.sum)).toLocaleString()|| '-'}}</span></div>
        <StockData
          :chartData='chartData2'
          :timeArr='timeData2'
        ></StockData>
        <div class="text-wrapper">
          <span class="text-label">月均 {{info?.allAmount?.avg || '-'}} </span>
          <span class="text-label">最高 {{info?.allAmount?.max || '-'}}</span>
          <span class="text-label">最低 {{info?.allAmount?.min || '-'}}</span>
        </div>
      </el-col>
      <el-col :span="6">
        <div>总出库单数<span>
            {{info?.allNumber?.sum || '-'}}</span></div>
        <PictureData
          :chartData='chartData3'
          :timeArr='timeData3'
        ></PictureData>
        <div class="text-wrapper">
          <span class="text-label">月均 {{info?.allNumber?.avg || '-'}} </span>
          <span class="text-label">最高 {{info?.allNumber?.max || '-'}}</span>
          <span class="text-label">最低 {{info?.allNumber?.min || '-'}}</span>
        </div>
      </el-col>
      <el-col :span="6">
        <div>单笔出库单</div>
        <div class="OutStock">
          <div class="left-wrapper">
            <div>销售量 /吨</div>
            <div class="divider-wrapper">
              <div>最高 {{info.maxSales || '-'}}</div>
              <div class="up-arrow">▲</div>
              <div class="divider-1"> 均单量:{{info.avgSales || '-'}}</div>
              <div class="down-arrow">▼</div>
            </div>
            <div>最低 {{info.minSales || '-'}}</div>
          </div>
          <div class="right-wrapper">
            <div>出库额 /元</div>

            <div class="divider-wrapper">
              <div>最高 {{info.maxAmount || '-'}}</div>
              <div class="up-arrow">▲</div>
              <div class="divider-1"> 均单价:{{info.avgAmount|| '-'}}</div>
              <div class="down-arrow">▼</div>
            </div>
            <div>最低 {{info.minAmount || '-'}}</div>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import PictureData from './PictureData';
import StockData from './StockData';
import { first } from '@/api/Client/picture';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: { PictureData, StockData },
  //  props: {
  //   pickerOptions: {
  //     type: Object,
  //     default: () => {
  //       return {
  //         productId: '',
  //         productType: '',
  //         priceType: '',
  //         priceDate: '',
  //       };
  //     },
  //   },
  props: ['clientCode'],
  data() {
    // 这里存放数据
    return {
      daterange: '',
      dayValue: '',
      options: [
        { label: '最近7天', value: '' },
        { label: '15天', value: '1' },
        { label: '30天', value: '2' },
        { label: '60天', value: '3' },
        { label: '90天', value: '4' },
      ],
      firstLoading: true,
      allSales: [],
      year: '2024',
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        },
      },
      loading: true,
      chartData1: [],
      timeData1: [],
      chartData2: [],
      timeData2: [],
      chartData3: [],
      timeData3: [],
      info: {},
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    init() {
      this.firstLoading = true;
      // first().then((res) => {});
    },
    handleYearChange() {},
    handleQuery() {
      this.loading = true;
      first({
        customerCode: this.clientCode,
        startDate: this.year + '-01-01',
        endDate: this.year + '-12-31',
      }).then((res) => {
        // console.log(res);
        if (res.code == 0) {
          this.chartData1 = res.data.allSales.monthGroupList.map(
            (item) => item.amount
          );
          this.timeData1 = res.data.allSales.monthGroupList.map(
            (item) => item.monthStr
          );
          this.chartData2 = res.data.allAmount.monthGroupList.map(
            (item) => item.amount
          );
          this.timeData2 = res.data.allAmount.monthGroupList.map(
            (item) => item.monthStr
          );
          this.chartData3 = res.data.allNumber.monthGroupList.map(
            (item) => item.amount
          );
          this.timeData3 = res.data.allNumber.monthGroupList.map(
            (item) => item.monthStr
          );
          this.info = res.data;
        }
        this.loading = false;
      });
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.year = new Date().getFullYear() + '';
    this.handleQuery();
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang='scss' scoped>
// @import url(); 引入公共css类
.OutStock {
  display: flex;
  margin-top: 20px;
  height: 200px;
  .left-wrapper {
    width: 46%;
    border-right: 1px solid #eee;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding-right: 10px;
  }
  .right-wrapper {
    padding-left: 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    flex-grow: 1;
  }
  .divider-wrapper {
    position: relative;
    top: -20px;
    .divider-1 {
      position: absolute;
      top: 60px;
      // width: 100px;
      height: 24px;
      line-height: 24px;
      //
    }
    .up-arrow {
      color: #0d9e31;
      position: absolute;
      right: 10px;
      top: 0px;
    }
    .down-arrow {
      color: #ce5709;
      position: absolute;
      right: 10px;
      top: 110px;
    }
  }
}
.control_bar {
  display: flex;
  justify-content: flex-end;
  align-items: center;
}
.text-wrapper {
  display: flex;
  justify-content: space-around;
}
.text-label {
  //   margin-right: 12px;
}
</style>
