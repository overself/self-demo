<!-- 客户画像-数据统计 -->

<template>
  <div
    :class="className"
    :style="{ height: height, width: width }"
  />
</template>

<script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '100%',
    },
    height: {
      type: String,
      default: '400px',
    },
    autoResize: {
      type: Boolean,
      default: true,
    },
    chartData: {
      type: Object,
      required: () => {},
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val);
      },
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el);
      this.setOptions(this.chartData);
    },
    getColor(value, max, min) {
      let rang = max / 3;
      if (value <= rang) {
        // 绿色
        return '#7CFFB2';
      } else if (value <= rang * 2) {
        // 黄色
        return '#58D9F9';
      } else {
        // 红色
        return '#FF6E76';
      }
    },
    setOptions({ value, max, min } = {}) {
      let color = '#ffffff';

      this.chart.setOption({
        legend: {},
        tooltip: {},
        dataset: {
          dimensions: ['product', '计划', '实际', '剩余'],
          source: [
            { product: '第一周', 计划: 43.3, 实际: 85.8, 剩余: 93.7 },
            { product: '第二周', 计划: 83.1, 实际: 73.4, 剩余: 55.1 },
            { product: '第三周', 计划: 86.4, 实际: 65.2, 剩余: 82.5 },
          ],
        },
        xAxis: { type: 'category' },
        yAxis: {},
        // Declare several bar series, each will be mapped
        // to a column of dataset.source by default.
        series: [{ type: 'bar' }, { type: 'bar' }, { type: 'bar' }],
      });
    },
  },
};
</script>
