<!-- 客户画像-数据统计 -->

<template>
  <div
    :class="className"
    :style="{ height: height, width: width }"
  />
</template>

<script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '100%',
    },
    height: {
      type: String,
      default: '400px',
    },
    autoResize: {
      type: Boolean,
      default: true,
    },
    chartData: {
      type: Object,
      required: () => {},
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val);
      },
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el);
      this.setOptions(this.chartData);
    },
    getColor(value, max, min) {
      let rang = max / 3;
      if (value <= rang) {
        // 绿色
        return '#7CFFB2';
      } else if (value <= rang * 2) {
        // 黄色
        return '#58D9F9';
      } else {
        // 红色
        return '#FF6E76';
      }
    },
    setOptions({ value, max, min } = {}) {
      let color = '#ffffff';

      this.chart.setOption({
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999',
            },
          },
        },
        // legend: {
        //   data: ['销售量', '销售量曲线'],
        // },
        xAxis: [
          {
            type: 'category',
            data: [
              '1月',
              '2月',
              '3月',
              '4月',
              '5月',
              '6月',
              '7月',
              '8月',
              '9月',
              '10月',
              '11月',
              '12月',
            ],
            axisPointer: {
              type: 'shadow',
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '销售量',
            min: 0,
            max: 250,
            interval: 50,
            axisLabel: {
              formatter: '{value} 吨',
            },
          },
          {
            type: 'value',
            name: '销售量曲线',
            min: 0,
            max: 25,
            interval: 5,
            // axisLabel: {
            //   formatter: '{value} °C',
            // },
          },
        ],
        series: [
          {
            name: '销售量',
            type: 'bar',
            tooltip: {
              // valueFormatter: function (value) {
              //   return value + ' ml';
              // },
            },
            data: [
              2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0,
              2.3,
            ],
          },
          {
            name: '销售量曲线',
            type: 'line',
            // yAxisIndex: 1,
            tooltip: {
              show: false,
              // valueFormatter: function (value) {
              //   return value + ' °C';
              // },
            },
            data: [
              2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0,
              2.3,
            ],
          },
        ],
      });
    },
  },
};
</script>
