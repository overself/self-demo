<!-- 客户画像-数据统计 -->

<template>
  <div
    :class="className"
    :style="{ height: height, width: width }"
  />
</template>

<script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '100%',
    },
    height: {
      type: String,
      default: '400px',
    },
    autoResize: {
      type: Boolean,
      default: true,
    },
    chartData: {
      type: Array,
      default: [],
    },
    sales: {
      type: [Number, String],
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val);
      },
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el);
      this.setOptions(this.chartData);
      let that = this;
      setTimeout(() => {
        this.chart.on('mouseout', function (params) {
          that.setOptions();
        });
        this.chart.on('mouseover', function (params) {
          if (params.componentType === 'series') {
            that.setOptions(1);
          }
        });
      }, 2000);
    },

    getColor(value, max, min) {
      let rang = max / 3;
      if (value <= rang) {
        // 绿色
        return '#7CFFB2';
      } else if (value <= rang * 2) {
        // 黄色
        return '#58D9F9';
      } else {
        // 红色
        return '#FF6E76';
      }
    },
    setOptions(type) {
      this.chart.setOption({
        // tooltip: {
        //   trigger: 'item',
        // },
        // legend: {
        //   top: '5%',
        //   left: 'center',
        // },
        title: {
          text: type == 1 ? '' : '销售量\n' + this.sales + '吨', // 显示总量
          left: 'center',
          top: 'center',
          textStyle: {
            fontSize: 24,
            fontWeight: 'bold',
            align: 'center',
            color: '#40ff95',
          },
        },
        series: [
          {
            name: '销售量',
            type: 'pie',
            radius: ['40%', '70%'],
            avoidLabelOverlap: false,
            label: {
              show: false,
              position: 'center',
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 20,
                fontWeight: 'bold',
                formatter: '{b}\n {c}吨',
              },
            },
            labelLine: {
              show: false,
            },
            data: this.chartData,
          },
        ],
      });
    },
  },
};
</script>
