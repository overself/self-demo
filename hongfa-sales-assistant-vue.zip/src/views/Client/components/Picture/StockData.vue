<!-- 客户画像-数据统计 -->

<template>
  <div
    :class="className"
    :style="{ height: height, width: width }"
  />
</template>

<script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '100%',
    },
    height: {
      type: String,
      default: '200px',
    },
    autoResize: {
      type: Boolean,
      default: true,
    },
    chartData: {
      type: Array,
    },
    timeArr: {
      type: Array,
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val);
      },
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el);
      this.setOptions(this.chartData);
    },
    getColor(value, max, min) {
      let rang = max / 3;
      if (value <= rang) {
        // 绿色
        return '#7CFFB2';
      } else if (value <= rang * 2) {
        // 黄色
        return '#58D9F9';
      } else {
        // 红色
        return '#FF6E76';
      }
    },
    setOptions({ value, max, min } = {}) {
      let color = '#ffffff';
      this.chart.setOption({
        grid: {
          bottom: 20,
          containLabel: true,
        },
        tooltip: {
          trigger: 'axis',
        },
        xAxis: {
          type: 'category',
          data: this.timeArr,
        },
        yAxis: {
          type: 'value',
        },
        series: [
          {
            data: this.chartData,
            type: 'bar',
          },
        ],
      });
    },
  },
};
</script>
