<!-- 销售分析 -->
<template>
  <div
    class=''
    id='customer-portrait'
  >
    <div class="control_bar">
      <div>
        <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" label-width="100px">
        <el-form-item label="品类" prop="productType">
          <el-select v-model="queryParams.productType" placeholder="请选择品类" clearable filterable style="width: 240px;"
            >
            <el-option v-for="item in productCategoryList" :key="item.value" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-form-item>
        <el-date-picker
          v-model="daterange"
          type="monthrange"
          :start-placeholder="'开始月份'"
          :end-placeholder="'结束月份'"
          size="small"
          :format="'yyyy-MM'"
          :valueFormat="'yyyy-MM'"
          :picker-options="pickerOptions"
          :style="{width: '240px'}"
          :clearable="false"
        ></el-date-picker>
        <el-button
          size="small"
          @click="handleQuery"
          style='margin-left: 12px;'
        >查询</el-button>
        <el-button
          size="small"
          @click="handleExport"
        >导出</el-button>
        </el-form>

      </div>
    </div>
    <div class="sale_bar_wrap">
      <div class="chart_bar">
        <ProductData
          :chartData='chartData'
          :sales='sales'
        ></ProductData>
      </div>
      <div class="list_bar">
        <el-table
          :data="tableData"
          height="394"
          style="width: 100%"
          class='selected-table'
          v-loading='tableLoading'
        >
          <el-table-column
            prop="no"
            label="排名"
            width="60"
          >
          </el-table-column>
          <el-table-column
            prop="productTypeName"
            label="品类"
            width="80"
          >
          </el-table-column>
          <el-table-column
            prop="name"
            label="产品名称"
            show-overflow-tooltip
            min-width="120"
            align="center"
          >
            <template slot-scope="scope">
              <span>{{scope.row.name}}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="name"
            label="产品规格"
            show-overflow-tooltip
            min-width="120"
          >
            <template slot-scope="scope">
              <span>{{scope.row.spec}}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="amount"
            label="总出库量（吨）"
            min-width="90"
            show-overflow-tooltip
          >
            <template slot-scope="scope">
              <span>{{scope.row.amount}}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="avgAmount"
            label="均单量"
            min-width="90（吨）"
            show-overflow-tooltip
          >
            <template slot-scope="scope">
              <span>{{scope.row.avgAmount}}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="minPrice"
            label="售价区间"
            show-overflow-tooltip
            min-width="106"
          >
            <template slot-scope="scope">
              <span>{{scope.row.minPrice}}~{{ scope.row.maxPrice}}元/kg</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="price"
            label="均单价"
            show-overflow-tooltip
          >
            <template slot-scope="scope">
              <span>{{scope.row.price}}元/kg</span>
            </template>
          </el-table-column>
        </el-table>

      </div>

    </div>

  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import ProductData from './components/ProductData';
import PriceChart from '@/views/Board/components/PriceChart';
import { ProductType, ProductList,exportList1 } from '@/api/Client/picture';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: { ProductData, PriceChart },
  props: ['monthRangeArr'],
  data() {
    // 这里存放数据
    return {
      productCategoryList: this.getDictDatas('category_classify'), //品项
      activeName: 'first',
      daterange: '',
      dayValue: '',
      options: [
        { label: '最近7天', value: '' },
        { label: '15天', value: '1' },
        { label: '30天', value: '2' },
        { label: '60天', value: '3' },
        { label: '90天', value: '4' },
      ],
      tableData: [],
      typeData: [],
      queryParams: {
        productType: '',
        customerId: '',
        fromSaleYear: '',
        fromSaleMonth: '',
        toSaleYear: '',
        toSaleMonth: '',
        productCode: '',
      },
      params: {
        pageNo: 1,
        pageSize: 100,
      },
      total: 0,
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        },
      },
      chartData: [],
      tableLoading: true,
      exportLoading:false,
      typeDataLoaing: true,
      sales: 0,
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    //导出列表数据
    handleExport() {
      this.exportLoading = true;
      this.$modal
        .confirm('是否确认导出数据项?')
        .then(() => {
          return exportList1(this.queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '产品分析.xls');
          this.exportLoading = false;
        })
        .catch(() => {
          this.exportLoading = false;
        });
    },
    handleQuery() {
      this.queryParams.fromSaleYear = this.daterange[0].split('-')[0];
      this.queryParams.fromSaleMonth =
        this.daterange[0].split('-')[1][0] == 0
          ? this.daterange[0].split('-')[1][1]
          : this.daterange[0].split('-')[1];
      this.queryParams.toSaleYear = this.daterange[1].split('-')[0];
      this.queryParams.toSaleMonth =
        this.daterange[1].split('-')[1][0] == 0
          ? this.daterange[1].split('-')[1][1]
          : this.daterange[1].split('-')[1];
      this.typeData = [];
      this.typeDataLoaing = true;
      ProductType(this.queryParams).then((res) => {
        if (res.code == 0) {
          this.typeData = res.data.productTypeList || [];
          let arr = [];
          arr = JSON.parse(JSON.stringify(res.data.productTypeList));
          arr.sort((a, b) => {
            b.amount - a.amount;
          });
          let arr1 = arr.slice(0, 10);
          let arr2 = arr.slice(10);
          let sum = 0;
          arr2.forEach((item) => {
            sum += item.amount;
          });
          arr1.push({ typeName: '其他', amount: sum });
          arr1.forEach((item, index) => {
            if (index == 0) item.selected = true;
            item.value = this.removeTrailingZeros(
              (Number(item.amount) / 1000).toFixed(3)
            );
            item.name = item.typeName;
          });
          this.sales = this.removeTrailingZeros(
            (Number(res.data.sales) / 1000).toFixed(3)
          );
          this.chartData = arr1;
        }
        this.typeDataLoaing = false;
        this.getProductList();
      });
    },
    getProductList() {
      let params = Object.assign(
        this.queryParams,
        this.params
      );
      this.tableLoading = true;
      this.tableData = [];
      ProductList(params).then((res) => {
        this.tableData = res.data || [];
        this.tableLoading = false;
      });
    },
    removeTrailingZeros(number) {
      if (number == '-') return '-';
      let numberString = number.toString();
      numberString = numberString.replace(/(?:\.0*|(\.\d+?)0+)$/, '$1');
      let num = String(parseFloat(numberString));
      let arr = num.split('.');
      if (arr.length > 1 && arr[1].length > 3) {
        // console.log(arr[1].length,parseFloat(numberString));
        return parseFloat(numberString).toFixed(3);
      } else {
        return parseFloat(numberString);
      }
    },
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    setTimeout(() => {
      this.daterange = this.monthRangeArr;
      this.queryParams.customerId = this.$route.params.clientId;
      this.handleQuery();
    }, 500);
  },
};
</script>
<style lang='scss' scoped>
// @import url(); 引入公共css类
.OutStock {
  display: flex;
}
.control_bar {
  display: flex;
  justify-content: flex-end;
  align-items: center;
}
.sale_bar_wrap {
  display: flex;
  justify-content: space-between;
  .sale_bar {
    width: 500px;
    display: flex;
    flex-wrap: wrap;
    padding: 10px;
    background-color: #fff;
    border-radius: 8px 8px 8px 8px;
    .sale_item {
      width: 190px;
      height: 50%;
    }
  }
  .chart_bar {
    width: 400px;
  }
  .list_bar {
    flex: 1;
    padding: 10px;
  }
}

::v-deep .el-table .el-table__body-wrapper tr.highlight-row {
  background-color: rgba(91, 211, 225, 0.1) !important;
}

::v-deep.el-table--enable-row-hover
  .el-table__body
  tr.highlight-row:hover
  > td.el-table__cell {
  background-color: rgba(91, 211, 225, 0.1) !important;
}
::v-deep .selected-table.el-table .el-table__body-wrapper tr {
  background-color: rgba(91, 211, 225, 0.1) !important;
}
</style>
