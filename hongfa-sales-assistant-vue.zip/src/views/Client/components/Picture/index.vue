<!-- 价格库存看板 -->
<template>
  <div class="coming-soon">
    <div class="component_title">数据统计
    </div>
    <div class="component_class">
      <Picture :clientCode='clientCode'></Picture>
    </div>
    <div class="component_title">销售分析
    </div>
    <div class="component_class">
      <Sale
        :monthRangeArr='monthRangeArr12'
        :clientCode='clientCode'
      ></Sale>
    </div>
    <div class="component_title">产品分析
    </div>
    <div class="component_class">
      <Product :monthRangeArr='monthRangeArr6'></Product>
    </div>

    <div class="component_title">计划/完成量分析
    </div>
    <div class="component_class">
      <Plant :monthRangeArr='monthRangeArr'></Plant>
    </div>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import Sale from './Sale';
import Picture from './Picture';
import Plant from './Plant';
import Product from './Product';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: { Picture, Plant, Sale, Product },
  props: {
    clientCode: {
      type: String,
      default: '',
    },
  },
  data() {
    // 这里存放数据
    return {
      monthRangeArr: [],
      monthRangeArr6: [],
      monthRangeArr12:[],
      total: 0,
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        username: undefined,
        mobile: undefined,
        status: undefined,
        deptId: undefined,
        createTime: [],
      },
      options: [
        {
          value: '重点关注',
          label: '重点关注',
        },
        {
          value: '核心客户',
          label: '核心客户',
        },
        {
          value: '老客户',
          label: '老客户',
        },
      ],
      accountForm: {
        accountName: '',
        openBank: '',
        bankNumber: '',
      },
      accountDialogVisible: false,
      tableData: [
        {
          id: 1,
          clientName: '客户名称',
          linkName: '联系人',
          linkNumber: '联系方式',
          area: '所在地区',
          clientCat: '客户分类',
          pathCat: '渠道分类',
          belong: '归属大区',
          belongSaler: '归属销售',
          state: '客户状态',
          time: '最近成交时间',
        },
        {
          id: 2,
          clientName: '客户名称',
          linkName: '联系人',
          linkNumber: '联系方式',
          area: '所在地区',
          clientCat: '客户分类',
          pathCat: '渠道分类',
          belong: '归属大区',
          belongSaler: '归属销售',
          state: '客户状态',
          time: '最近成交时间',
        },
        {
          id: 3,
          clientName: '客户名称',
          linkName: '联系人',
          linkNumber: '联系方式',
          area: '所在地区',
          clientCat: '客户分类',
          pathCat: '渠道分类',
          belong: '归属大区',
          belongSaler: '归属销售',
          state: '客户状态',
          time: '最近成交时间',
        },
        {
          id: 4,
          clientName: '客户名称',
          linkName: '联系人',
          linkNumber: '联系方式',
          area: '所在地区',
          clientCat: '客户分类',
          pathCat: '渠道分类',
          belong: '归属大区',
          belongSaler: '归属销售',
          state: '客户状态',
          time: '最近成交时间',
        },
      ],
      stockData: {
        xData: [
          '2024-5-1',
          '2024-5-2',
          '2024-5-3',
          '2024-5-4',
          '2024-5-5',
          '2024-5-6',
          '2024-5-7',
        ],
        yData: [0, 100, 200, 300, 400, 500, 600],
        max: 200,
        min: 20,
      },
      menuData: [],
      calcListData: [],
      code: '',
    };
  },
  // 监听属性 类似于data概念
  computed: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
  },
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    getMonth() {
      const now = new Date();
      const year = new Date().getFullYear();
      const currentMonth = now.getMonth() + 1; // JavaScript 中月份是从0开始的
      const lastMonth = currentMonth - 1 || 12; // 防止月份为0的情况，即上一个月是12月
      const currentMonthStr =
        currentMonth > 9 ? currentMonth : '0' + currentMonth;
      const lastMonthStr = lastMonth > 9 ? lastMonth : '0' + lastMonth;
      this.monthRangeArr = [
        year + '-' + currentMonthStr,
        year + '-' + currentMonthStr,
      ];
      const sixMonthsAgo = new Date(now.setMonth(now.getMonth() - 5));
      const month6 =
        sixMonthsAgo.getMonth() > 9
          ? sixMonthsAgo.getMonth()
          : '0' + sixMonthsAgo.getMonth();
      const year6 = sixMonthsAgo.getFullYear();
      this.monthRangeArr6 = [
        year6 + '-' + month6,
        year + '-' + currentMonthStr,
      ];
      const yearMonthsAgo = new Date(now.setMonth(now.getMonth() - 5));
      const month12 =
        yearMonthsAgo.getMonth() > 9
          ? yearMonthsAgo.getMonth()
          : '0' + yearMonthsAgo.getMonth();
      const year12 = yearMonthsAgo.getFullYear();
      this.monthRangeArr12 = [
        year12 + '-' + month12,
        year + '-' + currentMonthStr,
      ];
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.getMonth();
    this.code = this.clientCode;
    // this.calcCatData();
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}
// @import url(); 引入公共css类
.component_class {
  background-color: #fff;
  padding: 10px;
  border-radius: 8px;
  margin-bottom: 20px;
}
</style>
