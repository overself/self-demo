<!-- 数据统计 -->
<template>
  <div class=''>
    <div class="control_bar">
      <div style="margin-bottom:8px">
        <el-date-picker
          v-model="daterange"
          type="monthrange"
          :start-placeholder="'开始月份'"
          :end-placeholder="'结束月份'"
          size="small"
          :format="'yyyy-MM'"
          :valueFormat="'yyyy-MM'"
          :picker-options="pickerOptions"
          :style="{width: '240px'}"
          :clearable="false"
        ></el-date-picker>
        <el-button
          style='margin-left:12px'
          size="small"
          @click="handleQuery"
        >查询</el-button>
      </div>
    </div>
    <el-table
      :data="tableData"
      style="width: 100%"
      v-loading='tableLoading'
      :show-summary='true'
    >
      <el-table-column
        prop='month'
        label="月度"
        align="center"
      ></el-table-column>
      <el-table-column
        label="工厂"
        align="center"
        prop='factory'
      >
        <template slot-scope="scope">
          <span>{{objFactory[scope.row.factory]}}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="业务员"
        align="center"
        prop='salespersons'
      ></el-table-column>
      <el-table-column
        label="本月"
        align="center"
      >
        <el-table-column
          prop="monthTargetSales"
          label="目标"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="monthCompleteSales"
          label="完成量"
          align="center"
        >
        </el-table-column>

      </el-table-column>
      <el-table-column
        label="第一周"
        align="center"
      >
        <el-table-column
          prop="week1TargetSales"
          label="目标"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="week1CompleteSales"
          label="完成量"
          align="center"
        >
        </el-table-column>

      </el-table-column>
      <el-table-column
        label="第二周"
        align="center"
      >
        <el-table-column
          prop="week2TargetSales"
          label="目标"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="week2CompleteSales"
          label="完成量"
          align="center"
        >
        </el-table-column>

      </el-table-column>
      <el-table-column
        label="第三周"
        align="center"
      >
        <el-table-column
          prop="week3TargetSales"
          label="目标"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="week3CompleteSales"
          label="完成量"
          align="center"
        >
        </el-table-column>

      </el-table-column>
      <el-table-column
        label="第四周"
        align="center"
      >
        <el-table-column
          prop="week4TargetSales"
          label="目标"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="week4CompleteSales"
          label="完成量"
          align="center"
        >
        </el-table-column>
      </el-table-column>

    </el-table>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import WeekData from './components/WeekData';
import MounthData from './components/MounthData';
import StockData from './StockData';
import { four } from '@/api/Client/picture';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: { MounthData, WeekData, StockData },
  props: ['monthRangeArr'],
  data() {
    // 这里存放数据
    return {
      activeName: 'first',
      daterange: '',
      dayValue: '',
      options: [
        { label: '最近7天', value: '' },
        { label: '15天', value: '1' },
        { label: '30天', value: '2' },
        { label: '60天', value: '3' },
        { label: '90天', value: '4' },
      ],
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        },
      },
      queryParams: {
        customerId: '',
        fromSaleYear: '',
        fromSaleMonth: '',
        toSaleYear: '',
        toSaleMonth: '',
      },
      tableData: [],
      tableLoading: true,
      objFactory: {
        bp_1_factory: '北票一厂',
        bp_2_factory: '北票二厂',
        cy_factory: '朝阳工厂',
        kz_ln_factory: '喀左工厂(龙鸟)',
        kz_yy_factory: '喀左工厂(远赢)',
        kz_factory: '喀左工厂',
        '-': '-',
      },
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    handleClick() {},
    handleQuery() {
      this.queryParams.fromSaleYear = this.daterange[0].split('-')[0];
      this.queryParams.fromSaleMonth =
        this.daterange[0].split('-')[1][0] == 0
          ? this.daterange[0].split('-')[1][1]
          : this.daterange[0].split('-')[1];
      this.queryParams.toSaleYear = this.daterange[1].split('-')[0];
      this.queryParams.toSaleMonth =
        this.daterange[1].split('-')[1][0] == 0
          ? this.daterange[1].split('-')[1][1]
          : this.daterange[1].split('-')[1];
      this.tableData = [];
      this.tableLoading = true;
      four(this.queryParams).then((res) => {
        if (res.code == 0) {
          this.tableData = res.data || [];
        }
        this.tableLoading = false;
      });
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    setTimeout(() => {
      this.daterange = this.monthRangeArr;
      this.queryParams.customerId = this.$route.params.clientId;
      // console.log(this.$route.params.clientId, 'this.$route.params.clientId');

      this.handleQuery();
    }, 500);
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang='scss' scoped>
// @import url(); 引入公共css类
.OutStock {
  display: flex;
}
.control_bar {
  display: flex;
  justify-content: flex-end;
  align-items: center;
}
</style>
