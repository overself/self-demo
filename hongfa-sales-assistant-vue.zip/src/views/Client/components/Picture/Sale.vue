<!-- 销售分析 -->
<template>
  <div class=''>
    <div class="control_bar">
      <!-- <el-radio-group v-model="dayValue">
        <el-radio-button
          v-for="(item, index) in options"
          :key="index"
          :label="item.value"
        >{{item.label}}</el-radio-button>
      </el-radio-group> -->
      <div style='margin-bottom: 8px;'>
        <el-date-picker
          v-model="daterange"
          type="monthrange"
          :start-placeholder="'开始月份'"
          :end-placeholder="'结束月份'"
          size="small"
          :format="'yyyy-MM'"
          :valueFormat="'yyyy-MM'"
          :picker-options="pickerOptions"
          @change="changeDate"
          :style="{width: '240px'}"
          :clearable="false"
        ></el-date-picker>
        <el-button
          size="small"
          @click="handleQuery"
          style='margin-left: 12px;'
        >查询</el-button>
        <el-button
          size="small"
          @click="handleExport"
        >导出</el-button>
      </div>
    </div>
    <el-table
      :data="tableData"
      style="width: 100%"
      v-loading='loading'
    >

      <el-table-column
        label="销售量"
        align="center"
      >
        <el-table-column
          prop="monthStr"
          label="月度"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="allSales"
          label="销售量"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="beforeYearAllSales"
          label="去年销售量"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="allSalesYoY"
          label="同比"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="allSalesMoM"
          label="环比"
          align="center"
        >
        </el-table-column>
      </el-table-column>
      <el-table-column
        label="销售额"
        align="center"
      >
        <el-table-column
          prop="allAmount"
          label="销售额"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="beforeYearAllAmount"
          label="去年销售额"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="allAmountYoY"
          label="同比"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="allAmountMoM"
          label="环比"
          align="center"
        >
        </el-table-column>
      </el-table-column>
      <el-table-column
        label="月均价"
        align="center"
      >
        <el-table-column
          prop="avgPrice"
          label="月均价"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="beforeYearAvgPrice"
          label="去年月均价"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="avgPriceYoY"
          label="同比"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="avgPriceMoM"
          label="环比"
          align="center"
        >
        </el-table-column>
      </el-table-column>
    </el-table>
    <!-- <div class="sale_bar_wrap">
      <div class="sale_bar">
        <div class="sale_item">
          <img
            src=""
            alt=""
          >
          <div>上月销售量</div>
          <div>286吨</div>
        </div>
        <div class="sale_item">
          <img
            src=""
            alt=""
          >
          <div>上月出库额</div>
          <div>¥289,000</div>
        </div>
        <div class="sale_item">
          <img
            src=""
            alt=""
          >
          <div>本月销售量</div>
          <div>286吨</div>
        </div>
        <div class="sale_item">
          <img
            src=""
            alt=""
          >
          <div>上月出库额</div>
          <div>¥289,000</div>
        </div>
      </div>
      <div class="chart_bar">

        <el-tabs
          v-model="activeName"
          @tab-click="handleClick"
        >
          <el-tab-pane
            label="出库额趋势图"
            name="first"
          >
            <div
              class="list_wrap"
              v-if="activeName === 'first'"
            >
              <Out></Out>
            </div>
          </el-tab-pane>
          <el-tab-pane
            label="销售量趋势图"
            name="second"
          >
            <div
              class="list_wrap"
              v-if="activeName === 'second'"
            >
              <Sold></Sold>

            </div>
          </el-tab-pane>
        </el-tabs>
      </div>

    </div> -->

  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
  import {
    getTimeConfig
  } from '@/api/Analyse/SaleAnalyse';
import Sold from './components/Sold';
import Out from './components/Out';
import { Second,exportList, } from '@/api/Client/picture';
// import StockData from './StockData';

export default {
  // import引入的组件需要注入到对象中才能使用
  components: { Out, Sold },
  props: ['monthRangeArr', 'clientCode'],
  // ,
  data() {
    // 这里存放数据
    return {
      activeName: 'first',
      daterange: [],
      dayValue: '',
      options: [
        { label: '最近7天', value: '' },
        { label: '15天', value: '1' },
        { label: '30天', value: '2' },
        { label: '60天', value: '3' },
        { label: '90天', value: '4' },
      ],
      queryParams: {
            customerCode: '',
            startDate: '',
            endDate: '',
      },
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        },
      },
      tableData: [],
      loading: true,
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
  //配置月份
      changeDate() {
        let startDate = this.daterange[0];
        let endDate = this.daterange[1];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams.startDate = ''
              }
            } else {
              this.queryParams.startDate = ''
            }
          })
        getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.endDate = ''
            }
          })
      },
      //导出列表数据
      handleExport() {
        const queryParams = {
            customerCode: this.clientCode,
            startDate: this.queryParams.startDate,
            endDate: this.queryParams.endDate,
        };
        this.exportLoading = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList(queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '销售分析.xls');
            this.exportLoading = false;
          })
          .catch(() => {
            this.exportLoading = false;
          });
      },
    handleClick() {},
    handleQuery() {
      this.tableData = [];
      this.loading = true;
      Second({
        customerCode: this.clientCode,
        startDate: this.queryParams.startDate,
        endDate: this.queryParams.endDate,
      }).then((res) => {
        this.tableData = res.data || [];
        this.loading = false;
      }).catch(() => {
            this.loading = false;
          });
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    setTimeout(async () => {
      this.daterange = this.monthRangeArr;
        let startDate = this.daterange[0];
        let endDate = this.daterange[1];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
      await  getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams.startDate = ''
              }
            } else {
              this.queryParams.startDate = ''
            }
          })
       await getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.endDate = ''
            }
          })
      this.handleQuery();
    }, 500);
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang='scss' scoped>
// @import url(); 引入公共css类
.OutStock {
  display: flex;
}
.control_bar {
  display: flex;
  justify-content: flex-end;
  align-items: center;
}
.sale_bar_wrap {
  display: flex;
  justify-content: space-between;
  .sale_bar {
    width: 400px;
    display: flex;
    flex-wrap: wrap;
    padding: 10px;
    background-color: #fff;
    border-radius: 8px 8px 8px 8px;
    .sale_item {
      width: 190px;
      height: 50%;
    }
  }
  .chart_bar {
    flex: 1;
  }
}
</style>
