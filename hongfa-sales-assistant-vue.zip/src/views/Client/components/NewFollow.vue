<!-- 新跟进 -->
<template>
  <el-dialog
    title="新建跟进"
    :visible.sync="visible"
    width="500px"
  >
    <div class="flex_center">
      <el-form
        :model="clientForm"
        ref="clientForm"
        :rules="rules"
        @submit.native.prevent
      >
        <el-row :gutter="20">
          <el-col :span="24">
            <div class="flex_row">
              <div class="form_label">
                <span style="color: #D30607">*</span>客户名称
              </div>
              <el-form-item
                prop="usci"
                class="register_item"
              >
                <el-input
                  clearable
                  v-model="clientForm.name"
                  placeholder="请输入客户名称"
                  readonly
                ></el-input>
              </el-form-item>
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="24">
            <div class="flex_row">
              <div class="form_label">
                <!-- <span style="color: #D30607">*</span> -->联系人
              </div>
              <el-form-item
                class="register_item"
                prop="contactId"
                v-if="linkManList.length>0"
              >
                <el-select
                  v-model="clientForm.contactId"
                  placeholder="请选择联系人"
                  style="width:100%"
                >
                  <el-option
                    v-for="linkMan in linkManList"
                    :key="linkMan.id"
                    :label="linkMan.name"
                    :value="linkMan.id"
                  />
                </el-select>
              </el-form-item>
              <el-form-item
                class="register_item"
                prop="contactName"
                v-if="linkManList.length==0"
              >
                <el-input
                  clearable
                  v-model="clientForm.contactName"
                  placeholder="请填写联系人"
                ></el-input>

              </el-form-item>
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <div class="flex_row">
              <div class="form_label">
                <span style="color: #D30607">*</span>跟进方式
              </div>
              <el-form-item
                class="register_item"
                prop="followType"
              >
                <el-select
                  v-model="clientForm.followType"
                  placeholder="请选择跟进方式"
                  clearable
                  filterable
                  style="width:100%"
                >
                  <el-option
                    v-for="item in followTypeList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </div>
          </el-col>

          <el-col :span="12">
            <div class="flex_row">
              <div class="form_label">
                <span style="color: #D30607">*</span>跟进时间
              </div>
              <el-form-item
                class="register_item"
                prop="followTime"
              >
                <!-- style="width: 240px" -->
                <el-date-picker
                  v-model="clientForm.followTime"
                  format="yyyy-MM-dd HH:mm"
                  value-format="yyyy-MM-dd HH:mm"
                  type="datetime"
                  placeholder="请选择跟进时间"
                />
              </el-form-item>
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="24">
            <div class="flex_row">
              <div class="form_label">
                <span style="color: #D30607">*</span>内容描述
              </div>
              <el-form-item
                class="register_item"
                prop="content"
              >
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 2, maxRows: 4}"
                  maxlength="1000"
                  show-word-limit
                  clearable
                  v-model="clientForm.content"
                  placeholder="请输入跟进内容
勤跟进，多签单"
                  style
                ></el-input>
              </el-form-item>
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="24">
            <div class="flex_row">
              <div class="form_label">
                <!-- <span style="color: #D30607">*</span> -->附件上传
              </div>
              <FileUpload
                v-model="fileData"
                :fileType="fileType"
                :limit="5"
                :fileSize="100"
              />
            </div>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <span
      slot="footer"
      class="dialog-footer"
    >
      <el-button
        type="info"
        @click="hiddenDialog"
      >取 消</el-button>
      <el-button
        type="primary"
        @click="submitConfirmFollow"
      >确 认</el-button>
    </span>
  </el-dialog>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import FileUpload from '@/components/FileUpload';
import { getLinksByClient } from '@/api/Client/link';
import { updateFollow, addFollow } from '@/api/Client/follow';

export default {
  // import引入的组件需要注入到对象中才能使用
  components: { FileUpload },
  props: {
    visible: {
      type: Boolean,
      default: false,
    },
    clientData: {
      type: Object,
      default: () => {},
    },
  },
  // watch: {
  //   clientData: {
  //     deep: true,
  //     handler(newVal, oldVal) {
  //       //newVal和oldVal会包含formData里面的每一个属性值
  //       console.log(newVal, oldVal);
  //       this.clientForm.customerId = newVal.id;
  //       this.clientForm.name = newVal.name;
  //     },
  //   },
  // },
  data() {
    // 这里存放数据
    return {
      fileType: ['doc', 'xls', 'ppt', 'txt', 'pdf', 'jpg', 'png', 'jpeg'],
      fileData: '',
      linkManList: [],
      clientForm: {
        name: '',
        customerId: '',
        contactId: '',
        followType: '',
        followTime: '',
        content: '',
        fileUrls: '',
      },
      rules: {
        name: [{ required: true, message: '请填写客户名称', trigger: 'blur' }],
        contactId: [
          { required: true, message: '请选择联系人', trigger: 'change' },
        ],
        // contactName: [
        //   { required: true, message: '请填写联系人', trigger: 'blur' },
        // ],

        followType: [
          { required: true, message: '请填写跟进方式', trigger: 'blur' },
        ],
        followTime: [
          { required: true, message: '请选择跟进时间', trigger: 'change' },
        ],
        content: [
          { required: true, message: '请输入跟进内容', trigger: 'blur' },
        ],
      },
      followTypeList: this.getDictDatas('follow_up'),
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    hiddenDialog() {
      this.$emit('update:visible', false);
    },
    async getLinks() {
      const res = await getLinksByClient({
        customerId: this.clientData.customerId,
      });
      // this.linkManList = res.data;
      if (res.data.length > 0 && this.clientForm.contactId === '') {
        this.clientForm.contactId = res.data[0].id;
      }
    },
    submitConfirmFollow() {
      if (this.fileData.length > 0) {
        this.clientForm.fileUrls = this.fileData
          .map((item) => item.url)
          .join(',');
      }
      this.$refs['clientForm'].validate((valid) => {
        if (valid) {
          this.addFollow();
        } else {
          console.log('error submit!!');
          console.log(this.location);
          return false;
        }
      });
      // if (this.clientForm.contactId === '') {
      //   this.$message({
      //     message: '请选择联系人',
      //     type: 'error',
      //   });
      //   return;
      // }
      // if (this.clientForm.followType === '') {
      //   this.$message({
      //     message: '请填写跟进方式',
      //     type: 'error',
      //   });
      //   return;
      // }
      // if (this.clientForm.followTime === '') {
      //   this.$message({
      //     message: '请选择跟进时间',
      //     type: 'error',
      //   });
      //   return;
      // }
      // if (this.clientForm.content === '') {
      //   this.$message({
      //     message: '请填写跟进内容',
      //     type: 'error',
      //   });
      //   return;
      // }
    },
    async addFollow() {
      let res = null;
      if (this.clientForm.id) {
        res = await updateFollow(this.clientForm);
        // 更新成功后,调取重新获取跟进内容
        this.$EventBus.$emit('getFollow');
      } else {
        res = await addFollow(this.clientForm);
      }
      this.$message({
        message: '添加成功',
        type: 'success',
      });
      this.$EventBus.$emit('getFollowList');
      this.hiddenDialog();
    },

    initEdit() {
      if (this.clientData.id) {
        this.clientForm.id = this.clientData.id;
      }
      if (this.clientData.contactId) {
        this.clientForm.contactId = this.clientData.contactId;
      }
      if (this.clientData.followType) {
        this.clientForm.followType = this.clientData.followType;
      }
      if (this.clientData.followTime) {
        this.clientForm.followTime = this.$dayjs(
          this.clientData.followTime
        ).format('YYYY-MM-DD HH:mm');
      }
      if (this.clientData.content) {
        this.clientForm.content = this.clientData.content;
      }
      if (this.clientData.files.length > 0) {
        this.fileData = this.clientData.files;
        this.clientForm.fileUrls = this.clientData.files
          .map((item) => {
            return item.url;
          })
          .join(',');
      }
      console.log(this.clientForm);
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {
    console.log(this.clientData);
    this.clientForm.customerId = this.clientData.customerId;
    this.clientForm.name = this.clientData.name;
    this.getLinks();
    if (this.clientData.id) {
      this.initEdit();
    }
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang='scss' scoped>
// @import url(); 引入公共css类
</style>
