<!--  -->
<template>
  <div class="search_wrap">
    <div
      class="component_title"
      style="margin-bottom: 0px;"
    >
      {{clientData.clientData}} 客户归属：{{clientData.belongSaleName}}
      <div class="title_right_btns">
        <el-button
          v-if="showUpdateBtn"
          size="small"
          @click="updateClient"
        >编辑客户</el-button>
        <el-button
          size="small"
          @click="addNewFollow"
        >写新跟进</el-button>
        <el-button
          size="small"
          @click="$router.go(-1);"
        >返回</el-button>
      </div>
    </div>
    <NewFollow
      ref="NewFollow"
      v-if="followDialogVisible"
      :visible.sync="followDialogVisible"
      :clientData="clientFollowData"
    ></NewFollow>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';

import NewFollow from '../components/NewFollow';

export default {
  // import引入的组件需要注入到对象中才能使用
  components: { NewFollow },
  props: {
    showUpdateBtn: {
      type: Boolean,
      default: false,
    },
    clientData: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    // 这里存放数据
    return {
      theId: 1,
      fileData: '',
      followDialogVisible: false,
      linkManList: [
        {
          id: 1,
          linkName: '张三',
          linkPhone: '12345678901',
          linkTitle: '销售',
          sex: '男',
          disc: '备注',
        },
        {
          id: 2,
          linkName: '李四',
          linkPhone: '12345678901',
          linkTitle: '销售',
          sex: '男',
          disc: '备注',
        },
      ],
      clientFollowData: {},
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    submitConfirmFollow() {},
    updateClient() {
      this.$router.push({
        path: '/client-control/update/' + this.$route.params.clientId,
      });
    },
    addNewFollow() {
      console.log('从ContorHeader添加NewFollow');
      console.log(this.clientData);
      this.clientFollowData = {
        customerId: this.clientData.id,
        name: this.clientData.name,
      };
      this.followDialogVisible = true;
    },
    addNewFollow2(item) {
      console.log('从list添加NewFollow', item);
      this.clientFollowData = {
        ...item,
        name: this.clientData.name,
      };
      this.followDialogVisible = true;
    },
  },

  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.$EventBus.$on('addNewFollow', this.addNewFollow2);
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {
    this.$EventBus.$off('addNewFollow', this.addNewFollow2);
  }, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang='scss' scoped>
// @import url(); 引入公共css类
</style>
