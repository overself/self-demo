<!-- 价格库存看板 -->
<template>
  <div class="">
    <div
      class="component_title"
      style="margin-bottom:0"
    >客户列表
      <div class="title_right_btns">
        <!-- <el-button
          size="small"
          @click="delAll"
        >删除</el-button>
        <el-button
          size="small"
          @click="addNewLink"
        >添加</el-button> -->
      </div>
    </div>
    <div class="content_wrap">
      <div class="list_wrap">
        <el-table
          v-loading="loading"
          :data="tableData"
          border
          @selection-change="handleSelectionChangePush"
          ref="multipleTable"
          :row-key="bindRowKeys"
          :cell-style="addClass"
        >
          <!-- <el-table-column
            type="selection"
            width="55"
            align="center"
            :reserve-selection="true"
          /> -->
          <el-table-column
            label="序号"
            type="index"
            align="center"
            header-align="center"
            width="100"
          ></el-table-column>

          <el-table-column
            label="客户编码"
            align="center"
            prop="code"
          />
          <el-table-column
            label="客户名称"
            align="center"
            prop="name"
          />
          <el-table-column
            label="出库量（吨）"
            align="center"
            prop="output"
          >
            <template v-slot="scope">
              <div>{{scope.row.output | removeTrailingZeros}}</div>
            </template>
          </el-table-column>

          <!-- <el-table-column
            label="操作"
            align="center"
            width="260"
            class-name="small-padding fixed-width"
          >
            <template v-slot="scope">
              <el-button
                size="mini"
                type="text"
                icon="el-icon-edit"
                @click="handleFollow(scope.row)"
              >设为默认联系人</el-button>
              <el-button
                size="mini"
                type="text"
                icon="el-icon-edit"
                @click="handleDelete(scope.row)"
              >删除</el-button>
            </template>
          </el-table-column> -->
        </el-table>
        <!-- <el-row>
          <el-col>
            <pagination
              :total="total"
              :page.sync="queryParams.pageNo"
              :limit.sync="queryParams.pageSize"
              @pagination="getList"
            />
          </el-col>
        </el-row> -->
      </div>
    </div>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
// import { DICT_TYPE, getDictDatas } from '@/utils/dict';
import { listData } from '@/api/Client/send';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    // 这里存放数据
    return {
      addVisible: false,
      total: 0,
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        customerId: '',
      },
      options: [
        {
          value: '重点关注',
          label: '重点关注',
        },
        {
          value: '核心客户',
          label: '核心客户',
        },
        {
          value: '老客户',
          label: '老客户',
        },
      ],
      tableData: [],
      menuData: [],
      calcListData: [],
      loading: false,
      submitLoading: false,
      linkForm: {
        customerId: null,
        name: '',
        telephone: '',
        position: '',
        sex: null,
        remark: '',
      },
      linkRule: {
        name: [{ required: true, message: '请填写联系人', trigger: 'blur' }],
        telephone: [
          { required: true, message: '请填写手机号', trigger: 'blur' },
          {
            pattern:
              /^(?:(?:\+|00)86)?1(?:3[\d]|4[5-79]|5[0-35-9]|6[5-7]|7[0-8]|8[\d]|9[189])\d{8}$/,
            message: '请填写正确的手机号码',
            trigger: 'blur',
          },
        ],
        // position: [
        //   {
        //     required: true,
        //     message: '请选择职位',
        //     trigger: ['blur', 'change'],
        //   },
        // ],

        sex: [
          {
            required: true,
            message: '请选择性别',
            trigger: ['blur', 'change'],
          },
        ],
        // remark: [
        //   {
        //     required: true,
        //     message: "'请填写联系人备注",
        //     trigger: ['blur', 'change'],
        //   },
        // ],
      },
      // sexDictDatas: getDictDatas(DICT_TYPE.SYSTEM_USER_SEX),
      linkManSelect: [],
    };
  },
  // 监听属性 类似于data概念
  computed: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
  },
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    addNewLink() {
      this.addVisible = true;
    },
    async getList() {
      this.loading = true;
      // console.log('queryParams', this.queryParams);
      const queryParams = {
        ...this.queryParams,
      };
      const res = await listData(queryParams);
      this.tableData = res.data;
      console.log(this.tableData, res.data);
      //   this.total = res.data.total;
      this.loading = false;
    },
    hiddenDialog() {
      this.linkForm.name = '';
      this.linkForm.telephone = '';
      this.linkForm.position = '';
      this.linkForm.sex = '';
      this.linkForm.remark = '';
      this.addVisible = false;
    },
    submitConfirmLink() {
      this.$refs['linkForm'].validate((valid) => {
        if (valid) {
          this.submitLink();
        } else {
          console.log('error submit!!');
          return false;
        }
      });
      console.log(this.linkForm);
    },
    async submitLink() {
      this.submitLoading = true;
      const res = await addClient(this.linkForm);
      this.$confirm('联系人信息提交成功', '提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {})
        .catch(() => {});
      this.submitLoading = false;
      this.getList();
      this.hiddenDialog();
    },
    handleFollow(row) {
      this.$confirm('是否设置该联系人为默认', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.linkSet(row);
        })
        .catch(() => {});
    },
    async linkSet(row) {
      const res = await setClient({ id: row.id });
      this.$message({
        message: '设置成功',
        type: 'success',
      });
      this.getList();
    },
    delAll() {
      if (this.linkManSelect.length <= 0) {
        this.$message.error('请选择需要删除的客户');
        return false;
      }
      this.$confirm('是否确认删除所选联系人', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.calcDeleteIds();
        })
        .catch(() => {});
    },
    handleDelete(row) {
      this.$confirm('是否确认删除该联系人', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.linkDelete(row.id);
        })
        .catch(() => {});
    },
    calcDeleteIds() {
      let ids = this.linkManSelect.map((item) => item.id);
      console.log(ids);
      this.linkDelete(ids.join(','));
    },
    async linkDelete(ids) {
      const res = await delClient({ ids });
      this.$message({
        message: '删除成功',
        type: 'success',
      });
      this.getList();
    },
    handleInfo() {
      this.$router.push({
        path: '/client/info',
      });
      console.log('详情按钮');
    },
    handleSelectionChangePush(selection) {
      // console.log(selection);
      this.linkManSelect = selection;
    },
    bindRowKeys(row) {
      return row.id;
    },
    // 处理分类相关数据
    calcCatData() {
      this.calcListData = [];
      let calcListDataIdx = 0;
      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];
        // console.log(item);
        if (index === 0) {
          item.domId = item.catName;
          item.domIdx = calcListDataIdx;
          this.calcListData.push(1);
          this.menuData.push({ label: item.catName });
        } else {
          if (item.catName !== this.tableData[index - 1].catName) {
            item.domId = item.catName;
            calcListDataIdx++;
            item.domIdx = calcListDataIdx;
            this.calcListData.push(1);
            this.menuData.push({ label: item.catName });
          } else {
            item.domId = item.catName + index;
            this.calcListData[calcListDataIdx]++;
          }
        }
      }
      // console.log(this.tableData);
      // console.log(this.calcListData);
      // console.log(this.menuData);
    },
    addClass({ row, column, rowIndex, columnIndex }) {
      if (
        columnIndex != 3 &&
        (row[column.property] == null || row[column.property] == '')
      ) {
        row[column.property] = '-';
      }
    },

    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        // console.log(row, column, rowIndex, columnIndex);
        if (row.catName === row.domId) {
          return {
            rowspan: this.calcListData[row.domIdx],
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {
    this.linkForm.customerId = this.$route.params.clientId;
    this.queryParams.customerId = this.$route.params.clientId;
    this.getList();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    // this.calcCatData();
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}
// @import url(); 引入公共css类
</style>
