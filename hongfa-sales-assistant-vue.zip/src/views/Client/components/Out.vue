<!-- 价格库存看板 -->
<template>
  <div class="">
    <div class="component_title">出库单列表
      <div class="title_right_btns">
        <el-radio-group
          v-model="queryParams.orderDate"
          @input="radioChange"
          size="small"
        >
          <el-radio-button
            v-for="(item, index) in options"
            :key="index"
            :label="item.value"
          >{{item.label}}</el-radio-button>
        </el-radio-group>
        <el-date-picker
          v-model="orderDate"
          @change="datePickerChange"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          size="small"
          :format="'yyyy-MM-dd'"
          :valueFormat="'yyyy-MM-dd'"
          :style="{width: '240px'}"
          clearable
        ></el-date-picker>
      </div>
    </div>
    <div class="component_class outbound">
      <el-table
        :data="tableData"
        border
        style="width: 100%;"
        :cell-style="addClass"
        v-loading="loading"
      >
        <el-table-column
          prop="orderNo"
          label="单据编号"
          header-align="center"
          align="center"
        ></el-table-column>
        <!--
        <el-table-column
          prop="customerName"
          label="客户简称"
          header-align="center"
          align="center"
        > </el-table-column> -->

        <!-- <el-table-column
          prop="customerFullName"
          label="客户名称"
          header-align="center"
          align="center"
        > </el-table-column> -->

        <el-table-column
          prop="customerTypeName"
          label="客户分类"
          header-align="center"
          align="center"
        > </el-table-column>

        <el-table-column
          prop="sendCustomerName"
          label="送货客户名称"
          header-align="center"
          align="center"
        > </el-table-column>

        <!-- 要处理成吨 返的是kg -->
        <el-table-column
          prop="allAmount"
          label="出库量（吨）"
          header-align="center"
          align="center"
        >
          <template slot-scope="scope">
            <span>{{scope.row.allAmount   | weightFormat() | removeTrailingZeros}}</span>
          </template>
        </el-table-column>

        <el-table-column
          prop="salePerson"
          label="归属销售"
          header-align="center"
          align="center"
        > </el-table-column>

        <el-table-column
          prop="area"
          label="归属大区"
          header-align="center"
          align="center"
        >
          <template slot-scope="scope">
            <span>{{areaObj[scope.row.area]}}</span>
          </template>
        </el-table-column>

        <el-table-column
          prop="orderDate"
          label="业务日期"
          header-align="center"
          align="center"
        > </el-table-column>

        <el-table-column
          label="操作"
          header-align="center"
          align="center"
          class-name="small-padding fixed-width"
        >
          <template v-slot="scope">
            <el-button
              size="mini"
              type="text"
              @click="toDetail(scope.row.id)"
            >详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="queryParams.pageNo"
        :limit.sync="queryParams.pageSize"
        @pagination="getList"
      />
    </div>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
// import { list } from '@/api/delivery/salesDelivery/index';
import { list } from '@/api/Client/index';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: {},
  props: {
    clientCode: {
      type: String,
      default: '',
    },
  },
  data() {
    // 这里存放数据
    return {
      orderDate: [],
      options: [],
      total: 0,
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        customerCode: undefined, //客户编码,必传
        orderDate: undefined,
      },
      tableData: [],
      areaObj: {
        101: '宏发一区',
        102: '宏发二区',
        103: '宏发三区',
        '-': '-',
      },
    };
  },
  // 监听属性 类似于data概念
  computed: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
  },
  // 监控data中的数据变化
  watch: {
    orderDate(newVal, oldVal) {
      console.log(newVal, oldVal);
      this.$nextTick(() => {
        this.getList();
      });
    },
  },
  // 方法集合
  methods: {
    radioChange(value) {
      this.queryParams.orderDate = value;
      this.orderDate = value.split(',');
    },
    datePickerChange(value) {
      console.log(value);
      if (!value) {
        this.queryParams.orderDate = '';
      } else {
        this.queryParams.orderDate = value.join(',');
      }
    },
    setDateOptions() {
      this.options = [
        { label: '本周', value: this.getRangeDate('week') },
        { label: '本月', value: this.getRangeDate('month') },
        { label: '季度', value: this.getRangeDate('quarter') },
        { label: '全年', value: this.getRangeDate('year') },
      ];
      this.radioChange(this.options[0].value);
      console.log(this.options);
    },
    toDetail(id) {
      this.$router.push({
        path: `/sales-delivery/info/${id}`,
      });
    },
    handleFollow() {},

    handleInfo() {
      this.$router.push({
        path: '/client/info',
      });
      console.log('详情按钮');
    },
    handleSelectionChangePush(selection) {
      this.multiple = selection;
    },
    bindRowKeys(row) {
      return row.id;
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      }

      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },

    getList() {
      this.loading = true;
      let params = this.queryParams;

      list(params)
        .then((res) => {
          this.loading = false;
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.total;
        })
        .catch(() => {
          this.loading = false;
        });
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {
    this.queryParams.customerCode = this.clientCode;
    this.setDateOptions();
    this.getList();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}
// @import url(); 引入公共css类
.component_class {
  background-color: #fff;
  padding: 10px;
  border-radius: 8px;
  margin-bottom: 20px;
}
.outbound {
  .timeline_header {
    display: flex;
    justify-content: space-between;
    .header_title {
      font-size: 18px;
    }
  }
  .timeline_content {
    margin: 20px 0;
    min-height: 100px;
  }
  .timeline_footer {
    display: flex;
    justify-content: space-between;
    .footer_control {
    }
  }
}
</style>
