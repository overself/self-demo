<!-- 预警进度 -->
<template>
  <div class='progress_box'>
    <el-progress
      class=""
      type="circle"
      :stroke-width="10"
      :show-text="false"
      :percentage="percentage"
      :color="colors"
    ></el-progress>

    <div class="textCenter">
      <div class="title">{{title}}</div>
      <div class="time"> >{{days}}天</div>
      <div
        class="time"
        v-if="showAccount"
      >
        < {{acount}}吨</div>
      </div>
    </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';

export default {
  // import引入的组件需要注入到对象中才能使用
  components: {},
  props: {
    percentage: {
      type: Number,
      default: 10,
    },
    title: {
      type: String,
      default: '',
    },
    days: {
      type: Number,
      default: 0,
    },
    acount: {
      type: Number,
      default: 0,
    },
    showAccount: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    // 这里存放数据
    return {
      colors: [
        { color: '#5cb87a', percentage: 33 },
        { color: '#e6a23c', percentage: 66 },
        { color: '#f56c6c', percentage: 100 },
      ],
    };
  },
  // 监听属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {},
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>

<style lang='scss' scoped>
.progress_box {
  position: relative;
  left: 44px;
  width: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  /* height: 400px; */

  .el-progress {
    width: 80%;
    ::v-deep {
      .el-progress-circle {
        width: 100% !important;
        height: 100% !important;
      }
      .el-progress__text {
        white-space: pre;
      }
    }
  }

  .textCenter {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    .title {
      font-size: 1vw;
      color: #303133;
      font-weight: 600;
      margin-bottom: 5px;
    }
    .time {
      text-align: center;
      color: #f56c6c;
      font-size: 1.2vw;
    }
  }
}
// @import url(); 引入公共css类
</style>
