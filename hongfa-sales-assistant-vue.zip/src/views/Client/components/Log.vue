<!-- 价格库存看板 -->
<template>
  <div class="">
    <div class="component_title">客户日志
    </div>
    <div class="component_class outbound">
      <el-table
        :data="tableData"
        border
        style="width: 100%;"
        max-height="500px"
        :cell-style="addClass"
        v-loading="loading"
      >
        <el-table-column
          prop="createTime"
          label="时间"
          header-align="center"
          align="center"
          show-overflow-tooltip
        >
          <template v-slot="scope">
            <span>{{ parseTime(scope.row.createTime) }}</span>
          </template>
        </el-table-column>

        <el-table-column
          prop="subType"
          label="操作"
          header-align="center"
          align="center"
          show-overflow-tooltip
        > </el-table-column>

        <el-table-column
          prop="action"
          label="操作描述"
          header-align="center"
          align="center"
          show-overflow-tooltip
        > </el-table-column>

        <el-table-column
          prop="userName"
          label="操作人"
          header-align="center"
          align="center"
          show-overflow-tooltip
        > </el-table-column>
      </el-table>
      <pagination
        :total="total"
        :page.sync="queryParams.pageNo"
        :limit.sync="queryParams.pageSize"
        @pagination="getList"
      />
    </div>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
// import { list } from '@/api/delivery/salesDelivery/index';
import { logList } from '@/api/Client/index';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: {},
  props: {
    clientId: {
      type: String,
      default: '',
    },
  },
  data() {
    // 这里存放数据
    return {
      total: 0,
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        bizId: '', //客户编码,必传
      },
      tableData: [],
    };
  },
  // 监听属性 类似于data概念
  computed: {
    handleClick(tab, event) {
      // console.log(tab, event);
    },
  },
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    addClass({ row, column, rowIndex, columnIndex }) {
      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },

    getList() {
      this.loading = true;
      let params = this.queryParams;
      params.bizId = this.clientId;
      logList(params)
        .then((res) => {
          this.loading = false;
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.total;
        })
        .catch(() => {
          this.loading = false;
        });
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {
    this.getList();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {}, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}
// @import url(); 引入公共css类
.component_class {
  background-color: #fff;
  padding: 10px;
  border-radius: 8px;
  margin-bottom: 20px;
}
.outbound {
  .timeline_header {
    display: flex;
    justify-content: space-between;
    .header_title {
      font-size: 18px;
    }
  }
  .timeline_content {
    margin: 20px 0;
    min-height: 100px;
  }
  .timeline_footer {
    display: flex;
    justify-content: space-between;
    .footer_control {
    }
  }
}
</style>
