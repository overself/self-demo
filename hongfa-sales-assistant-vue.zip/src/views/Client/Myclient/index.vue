<!-- 我的客户管理 -->
<template>
  <div class="app-container Board">
    <!-- 搜索工作栏 -->
    <el-row :gutter="20">
      <!--部门数据-->
      <!--用户数据-->
      <el-col
        :span="24"
        :xs="24"
      >
        <el-collapse
          accordion
          v-model="activeTabName"
          @change="handleCollapseChange"
        >
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">我的客户管理
                <div
                  class="title_right_btns"
                  @click.stop="handleScreen"
                >
                  <screenfull
                    id="screenfull"
                    class="right-menu-item hover-effect"
                    ref="screenIcon"
                    @screenToggle="handleScreenToggle"
                  />{{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">

              <el-form
                :model="queryParams"
                ref="queryForm"
                size="small"
                :inline="true"
                label-width="100px"
              >
                <el-form-item
                  label="客户分类"
                  prop="type"
                >
                  <el-select
                    clearable
                    v-model="queryParams.type"
                    placeholder="请选择客户分类"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="item in clientTypes"
                      :key="item.value"
                      :value="item.value"
                      :label="item.label"
                    ></el-option>
                  </el-select>
                </el-form-item>

                <el-form-item
                  label="客户简称"
                  prop="name"
                >
                  <el-input
                    v-model="queryParams.name"
                    placeholder="请输入客户简称"
                    clearable
                    style="width: 240px"
                  />
                </el-form-item>

                <el-form-item
                  label="送货客户名称"
                  prop="name"
                >
                  <el-input
                    v-model="queryParams.sendCustomerName"
                    placeholder="请输入送货客户名称"
                    clearable
                    style="width: 240px"
                  />
                </el-form-item>

                <!-- <el-form-item
                  label="客户状态"
                  prop="type"
                >
                  <el-select
                    clearable
                    v-model="queryParams.customerStatus"
                    placeholder="请选择客户状态"
                    style="width: 240px"
                  >
                    <el-option
                      v-for="item in customerStatusOp"
                      :key="item.value"
                      :value="item.value"
                      :label="item.label"
                    ></el-option>
                  </el-select>
                </el-form-item> -->

                <!-- <el-form-item
                  label="业务部门"
                  prop="deptId"
                >
                  <el-select
                    v-model="queryParams.deptId"
                    placeholder="请选择业务部门"
                    style="width: 240px"
                    :disabled="activeName == 2"
                    filterable
                    clearable
                  >
                    <el-option
                      v-for="item in clientAreaOptions"
                      :key="item.value"
                      :value="item.value"
                      :label="item.label"
                    ></el-option>
                  </el-select>
                </el-form-item> -->

                <!-- <el-form-item
                  label="归属销售"
                  prop="belongSale"
                >
                  <el-select
                    v-model="queryParams.belongSale"
                    placeholder="请选择归属销售"
                    style="width: 240px"
                    :disabled="activeName == 2"
                    filterable
                    clearable
                  >
                    <el-option
                      v-for="item in belongListOp"
                      :key="item.id"
                      :value="item.id"
                      :label="item.nickname"
                    ></el-option>
                  </el-select>
                </el-form-item> -->

                <el-form-item
                  label="所在地区"
                  prop="location"
                >
                  <el-cascader
                    clearable
                    filterable
                    style="width: 240px"
                    :placeholder="`请选择所在地区`"
                    v-model="queryParams.location"
                    :options="cityOption"
                    @change="cityChange"
                  >
                  </el-cascader>
                </el-form-item>
                <!-- <el-form-item
                  label="客户标签"
                  prop="type"
                >
                  <el-select
                    clearable
                    v-model="signIds"
                    placeholder="客户标签"
                    style="width: 240px"
                    multiple
                  >
                    <el-option
                      v-for="item in customerTagOp"
                      :key="item.id"
                      :value="item.id"
                      :label="item.name"
                    ></el-option>
                  </el-select>
                </el-form-item> -->
                <!-- <el-form-item
              label="联系人"
              prop="customerContactName"
            >
              <el-input
                v-model="queryParams.customerContactName"
                placeholder="请输入联系人"
                clearable
                style="width: 240px"
              />
            </el-form-item> -->

                <el-form-item
                  label="最近出库日期"
                  prop="createTime"
                >
                  <el-date-picker
                    v-model="queryParams.createTime"
                    @change="dateChange"
                    style="width: 240px"
                    value-format="yyyy-MM-dd"
                    type="daterange"
                    range-separator="-"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    :default-time="['00:00:00', '23:59:59']"
                  />
                </el-form-item>
                <el-form-item
                  label="客户编码"
                  prop="name"
                >
                  <el-input
                    v-model="queryParams.code"
                    placeholder="请输入客户编码"
                    clearable
                    style="width: 240px"
                  />
                </el-form-item>
                <!-- <el-form-item style="margin-left: 30px;">
                  <el-radio
                    v-model="queryParams.businessStatus"
                    label=""
                  >全部客户</el-radio>
                  <el-radio
                    v-model="queryParams.businessStatus"
                    :label="0"
                  >历史客户</el-radio>
                  <el-radio
                    v-model="queryParams.businessStatus"
                    :label="1"
                  >常用客户</el-radio>
                </el-form-item> -->
                <el-form-item>
                  <el-button
                    icon="el-icon-search"
                    @click="handleQuery"
                  >查询</el-button>
                  <el-button
                    icon="el-icon-refresh"
                    @click="resetQuery"
                  >重置</el-button>
                </el-form-item>
              </el-form>
            </div>
          </el-collapse-item>
        </el-collapse>
        <div class="content_wrap">
          <!-- <el-tabs
            v-model="activeName"
            @tab-click="handleClick"
          >
            <el-tab-pane
              :label="item.label"
              :name="item.value"
              v-for="(item,index) in tabList"
              :key="index"
            ></el-tab-pane>
          </el-tabs> -->
          <div class="tabs_right_btns">

            <!-- <el-button
              size="small"
              @click="handleSend"
            >指派客户</el-button> -->
            <!-- <el-button
              size="small"
              :loading="exportLoading"
              @click="handleExport"
            >导出</el-button> -->
          </div>
        </div>

      </el-col>

    </el-row>
    <div
      class="content_wrap"
      style="padding-top:0"
    >
      <div class="list_wrap">
        <List
          ref="clientList"
          @changeShowStatus="changeShowStatus"
          :queryParams="queryParams"
          :activeName="activeName"
        ></List>
      </div>
    </div>
    <el-row>
      <el-col>

      </el-col>
    </el-row>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
import { getAreaTree } from '@/api/system/area';
import { getUserProfile } from '@/api/system/user';
import Screenfull from '@/components/Screenfull';
import List from './list';
import { getDictDatas, DICT_TYPE } from '@/utils/dict';
import { exportExcel, getBelong } from '@/api/Client/index';
import { deepClone } from '@/utils';
import { listData } from '@/api/system/tag';
export default {
  name: 'Client',
  // import引入的组件需要注入到对象中才能使用
  components: { List, Screenfull },
  data() {
    // 这里存放数据
    return {
      exportLoading: false,
      tabList: [],
      hiddenInfo: true,
      total: 0,
      customerStatusOp: [
        {
          label: '全部',
          value: '',
        },
        {
          label: '正常',
          value: 'NORMAL',
        },
        {
          label: '流失预警',
          value: 'WARNING_LOSS',
        },
        {
          label: '出库预警',
          value: 'WARNING_OUT',
        },
        {
          label: '计划预警',
          value: 'WARNING_PLAN',
        },
        {
          label: '跟进预警',
          value: 'WARNING_FOLLOW',
        },
        {
          label: '关闭',
          value: 'CLOSE',
        },
      ],
      queryParams: {
        pageNo: 1,
        pageSize: 20,
        businessStatus: 1,
        name: '',
        customerContactName: '',
        fromLastSale: '',
        toLastSale: '',
        // area: '',
        deptId: '',
        type: null,
        location: '',
        locationProvinceCode: '',
        locationCityCode: '',
        createTime: [],
        customerStatus: null,
        belongSale: '',
        signIds: '',
      },
      cityOption: [],
      clientAreaOptions: this.getDictDatas('hfywbm'),
      allClientAreaOptions: this.getDictDatas('hfywbm'),
      activeName: '2',
      // tabsAllOP: [
      //   // { label: '全部客户', value: '1', mapValue: 'all' },
      //   { label: '我的客户', value: '2', mapValue: 'self' },
      //   // { label: '宏发一区', value: '101', mapValue: 'zone1' },
      //   // { label: '宏发二区', value: '102', mapValue: 'zone2' },
      //   // { label: '宏发三区', value: '103', mapValue: 'zone3' },
      // ],
      clientAreaDatas: getDictDatas(DICT_TYPE.CLIENT_AREA),
      clientTypes: [],
      belongListAll: [],
      belongListOp: [],
      customerTagOp: [],
      isFullScreen: true,
      activeTabName: '1',
      signIds: [],
    };
  },

  watch: {
    'queryParams.deptId'(newVal, oldVal) {
      //   console.log('参数发生变化', newVal);
      this.belongListOp = [];
      this.queryParams.belongSale = '';
      //   this.belongListOp = this.belongListAll.map((i) => {
      //     i.deptId == newVal;
      //   });
      this.belongListAll.forEach((res) => {
        if (res.deptId == newVal) {
          this.belongListOp.push(res);
        }
      });
      //   console.log('获取到的新数组', this.belongListOp);
    },
    activeTabName: {
      handler(newVal, oldVal) {
        if (newVal != '1' && this.queryParams.pageSize < 20) {
          this.queryParams.pageNo = 1;
          this.queryParams.pageSize = 20;
          this.getList();
        }
      },
      deep: true,
      immediate: true,
    },
    signIds: {
      handler(newVal, oldVal) {
        if (newVal.length > 0) {
          this.queryParams.signIds = newVal.join(',');
        } else {
          this.queryParams.signIds = '';
        }
      },
      deep: true,
      immediate: true,
    },
  },

  // 方法集合
  methods: {
    handleExport() {
      const queryParams = {
        name: this.queryParams.name,
        customerContactName: this.queryParams.customerContactName,
        fromLastSale: this.queryParams.fromLastSale,
        toLastSale: this.queryParams.toLastSale,
        // area: this.queryParams.area,
        deptId: this.queryParams.deptId,
        type: this.queryParams.type,
        locationProvinceCode: this.queryParams.locationProvinceCode,
        locationCityCode: this.queryParams.locationCityCode,
        dataType: this.activeName,
      };
      console.log(queryParams);
      this.$modal
        .confirm('是否确认导出?')
        .then(() => {
          this.exportLoading = true;
          return exportExcel(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '客户导出.xls');
          this.exportLoading = false;
        })
        .catch(() => {});
    },
    dateChange(e) {
      this.queryParams.fromLastSale = e[0];
      this.queryParams.toLastSale = e[1];
    },
    cityChange(e) {
      this.queryParams.locationProvinceCode = e[0];
      this.queryParams.locationCityCode = e[1];
    },
    getList() {
      this.$nextTick(() => {
        this.$refs.clientList.getList();
      });
    },
    handleSend() {
      this.$nextTick(() => {
        this.$refs.clientList.handleEdit();
      });
    },
    resetQuery() {
      this.queryParams = {
        pageNo: 1,
        pageSize: 20,
        name: '',
        customerContactName: '',
        fromLastSale: '',
        toLastSale: '',
        // area: '',
        deptId: '',
        type: null,
        locationProvinceCode: '',
        locationCityCode: '',
        createTime: [],
        customerStatus: null,
        businessStatus: 1,
        belongSale: '',
        signIds: '',
      };
      this.signIds = [];
      this.getList();
    },
    async getUserProfile() {
      this.tabList = [];
      const res = await getUserProfile();
      console.log('clientAreaDatas', this.clientAreaDatas);
      // this.tabsAllOP.map((item) => {
      //   if (res.data.permissionTabs.includes(item.mapValue)) {
      //     this.tabList.push(item);
      //   }
      // });
      // console.log('tabList', this.tabList);
      // this.activeName = this.tabList[0].value;
      if (this.activeName == 1) {
        this.clientAreaOptions = this.getDictDatas('hfywbm');
        // this.queryParams.area = '';
        this.queryParams.deptId = '';
      } else if (this.activeName == 2) {
        // this.queryParams.area = '';
        this.queryParams.deptId = '';
      } else {
        this.clientAreaOptions = [];
        this.allClientAreaOptions.forEach((it) => {
          if (it.value == this.activeName) {
            this.clientAreaOptions.push(it);
          }
        });
        // this.queryParams.area = this.activeName;
        this.queryParams.deptId = this.activeName;
      }
      console.log(this.activeName);
      this.$nextTick(() => {
        this.getList();
      });
    },
    changeShowStatus() {
      this.hiddenInfo = false;
    },
    handleQuery() {
      this.getList();
    },
    // handleClick(tab, event) {
    //   console.log('activeName', this.activeName);
    //   if (this.activeName == 1) {
    //     this.clientAreaOptions = this.getDictDatas('hfywbm');
    //     // this.queryParams.area = '';
    //     this.queryParams.deptId = '';
    //   } else if (this.activeName == 2) {
    //     // this.queryParams.area = '';
    //     this.queryParams.deptId = '';
    //   } else {
    //     this.clientAreaOptions = [];
    //     this.allClientAreaOptions.forEach((it) => {
    //       if (it.value == this.activeName) {
    //         this.clientAreaOptions.push(it);
    //       }
    //     });
    //     // this.queryParams.area = this.activeName;
    //     this.queryParams.deptId = this.activeName;
    //   }
    //   this.$nextTick(() => {
    //     this.getList();
    //   });
    // },
    async getBelong() {
      const res = await getBelong({ isSale: true });
      this.belongListAll = res.data;
    },
    handleScreen() {
      this.$refs.screenIcon.click();
    },
    handleScreenToggle(val) {
      this.isFullScreen = val;
      // console.log(val, 123);
    },
    handleCollapseChange(val) {
      console.log(val, 'handleCollapseChange');
      // this.$refs['market_price_type'].calTableHeight()
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {
    this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
    this.clientTypes.unshift({ label: '全部', value: '' });
    getAreaTree().then((res) => {
      this.cityOption = res.data;

      this.cityOption.forEach((item) => {
        item.label = item.name;
        item.value = item.id;

        item.children.forEach((i) => {
          i.label = i.name;
          i.value = i.id;

          delete i.children;
        });
      });
    });
    this.getBelong();
    this.getUserProfile();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    listData({ pageNo: 1, pageSize: 100 }).then((res) => {
      this.customerTagOp = res.data.list;
    });
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {
    console.log('被销毁');
  }, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
// @import url(); 引入公共css类
.component_title {
  padding: 10px 30px 0 20px;
}
::v-deep .el-collapse-item__content {
  padding-bottom: 0 !important;
}
</style>
