<!-- 客户管理列表 -->
<template>
  <div class="">
    <el-table
      v-loading="loading"
      :data="tableData"
      border
      @selection-change="handleSelectionChangePush"
      ref="multipleTable"
      :row-key="bindRowKeys"
      :cell-style="addClass"
    >
      <el-table-column
        type="selection"
        width="55"
        align="center"
        :reserve-selection="true"
      />
      <!-- <el-table-column
        label="序号"
        type="index"
        align="center"
        header-align="center"
        width="100"
      ></el-table-column> -->
      <el-table-column
        label="客户编码"
        align="center"
        prop="code"
        width="170"
      >
        <template slot-scope="scope">
          <router-link
            :to="'/client-control/info/' + scope.row.id"
            class="router_btn"
          >
            <span class="cursor-p">{{scope.row.code}}</span>

          </router-link>

        </template>
      </el-table-column>
      <el-table-column
        label="客户简称"
        align="center"
        prop="name"
        show-overflow-tooltip
        width="250"
      >
        <template slot-scope="scope">
          <router-link
            :to="'/client-control/info/' + scope.row.id"
            class="router_btn"
          >
            <span class="cursor-p">{{scope.row.name}}</span>

          </router-link>

        </template>
      </el-table-column>
      <!-- <el-table-column
        label="客户名称"
        align="center"
        prop="fullName"
        show-overflow-tooltip
        width="252"
      > -->
       <!-- <template slot-scope="scope">
          <router-link
            :to="'/client-control/info/' + scope.row.id"
            class="router_btn"
          >
            <span class="cursor-p">{{scope.row.fullName}}</span>

          </router-link>

        </template>
      </el-table-column> -->
      <!-- <el-table-column
        label="联系人"
        align="center"
        prop="customerContactName"
      />
      <el-table-column
        label="联系方式"
        align="center"
        prop="customerContactTelephone"
      /> -->
      <el-table-column
        label="客户分类"
        align="center"
        prop="typeName"
      />
      <el-table-column
        label="所在区域"
        align="center"
        prop="location"
      />

      <!-- <el-table-column
        label="渠道分类"
        align="center"
        prop="channelTypeNames"
      /> -->
      <el-table-column
        label="业务部门"
        align="center"
        prop="departmentName"
      ></el-table-column>

      <el-table-column
        label="归属销售"
        align="center"
        prop="belongSaleName"
      />
      <!-- <el-table-column
        label="客户状态"
        align="center"
        prop="status"
      >
        <template v-slot="scope">
          <div
            v-for="state in scope.row.status.split(' ')"
            :key="state"
            class="status_box"
            :class="{'normal':state==='正常','lost':state==='流失预警','out':state==='出库量预警','follow':state==='跟进预警'}"
          >
            {{ state }}
          </div>
        </template>
      </el-table-column> -->
      <el-table-column
        label="客户标签"
        align="center"
        prop="signNames"
      />
      <el-table-column
        label="送货客户数量"
        align="center"
        prop="sendCustomerName"
      >
        <template v-slot="scope">
          <span v-if="scope.row.sendCustomers !== null">
            <span
              class="show-send-customers"
              @click="showSendCustomers(scope.row)"
              v-if="scope.row.sendCustomers && scope.row.sendCustomers.length && scope.row.sendCustomers.length > 0"
            >{{scope.row.sendCustomers.length}}</span>
            <span v-else>0</span>
          </span>
          <span v-else>-</span>
        </template>
      </el-table-column>

      <el-table-column
        label="最近出库时间"
        align="center"
        prop="lastSale"
      ></el-table-column>
      <el-table-column
        label="操作"
        align="center"
        width="160"
        class-name="small-padding fixed-width"
      >
        <template v-slot="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleFollow(scope.row)"
          >跟进</el-button>
          <router-link
            :to="'/client-control/update/' + scope.row.id"
            class="router_btn"
          >
            <el-button
              size="mini"
              type="text"
              icon="el-icon-edit"
            >编辑</el-button>
          </router-link>
          <router-link
            :to="'/client-control/info/' + scope.row.id"
            class="router_btn"
          >
            <el-button
              size="mini"
              type="text"
              icon="el-icon-edit"
            >详情
            </el-button>
          </router-link>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      :total="total"
      :page.sync="queryParams.pageNo"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <el-dialog
      title="重新指派客户"
      :visible.sync="accountDialogVisible"
      width="500px"
    >
      <div class="flex_center">
        <el-form
          :model="accountForm"
          ref="accountForm"
          @submit.native.prevent
        >
          <el-row :gutter="20">
            <el-col :span="24">
              <div class="flex_row">
                <div class="form_label">
                  客户信息
                </div>
                <el-form-item
                  prop="usci"
                  class="register_item"
                >
                  <el-table
                    :data="clientData"
                    max-height="300"
                  >
                    <el-table-column
                      label="客户名称"
                      align="center"
                      prop="name"
                    />
                    <el-table-column
                      label="客户归属"
                      align="center"
                      prop="belongSaleName"
                    />
                  </el-table>
                </el-form-item>
              </div>
            </el-col>
            <el-col :span="24">
              <div class="flex_row">
                <div class="form_label">
                  指派时间
                </div>
                <el-form-item class="register_item">
                  <el-date-picker
                  :picker-options="pickerOptions"
                    v-model="accountForm.belongSaleDate"
                    type="date"
                    placeholder="选择日期"
                    format="yyyy-MM-dd"
                    value-format="yyyy-MM-dd"
                  >
                  </el-date-picker>
                </el-form-item>
              </div>
            </el-col>
            <el-col :span="24">
              <div class="flex_row">
                <div class="form_label">
                  接收对象
                </div>
                <el-form-item class="register_item">
                  <el-select
                    v-model="accountForm.belongSale"
                    placeholder="请选择接收对象"
                    style="width:100%"
                    filterable
                  >
                    <el-option
                      v-for="dict in belongOptions"
                      :key="dict.id"
                      :label="dict.nickname"
                      :value="dict.id"
                    />
                  </el-select>
                </el-form-item>
              </div>
            </el-col>

          </el-row>
          <el-row :gutter="20">
            <el-col :span="24">
              <div class="flex_row">
                <div class="form_label">
                  备注信息
                </div>
                <el-form-item
                  prop="usci"
                  class="register_item"
                >
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 2, maxRows: 4}"
                    maxlength="300"
                    show-word-limit
                    clearable
                    v-model="accountForm.remark"
                    placeholder="请填写备注"
                    style
                  ></el-input>
                </el-form-item>
              </div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <div class="little_tip">*
                如需变更客户相关记录归属人员请勾选相关选项
              </div>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <span
        slot="footer"
        class="dialog-footer"
      >
        <el-button
          type="info"
          @click="accountDialogVisible = false"
        >取 消</el-button>
        <el-button
          type="primary"
          @click="submitConfirmAccount"
        >确 认</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="送货客户"
      :visible.sync="sendCustomerDialogVisible"
      width="700px"
    >
      <el-table
        v-loading="sendCustomerLoading"
        :data="sendCustomerTableData"
        border
      >
        <el-table-column
          type="index"
          width="50"
        ></el-table-column>

        <el-table-column
          label="送货客户编码"
          align="center"
          prop="code"
          width="150"
        ></el-table-column>

        <el-table-column
          label="送货客户名称"
          align="center"
          prop="name"
        ></el-table-column>
      </el-table>

      <span
        slot="footer"
        class="dialog-footer"
      >
        <el-button
          type="info"
          @click="sendCustomerDialogVisible = false"
        >取 消</el-button>
      </span>
    </el-dialog>

    <!-- <el-dialog
      title="客户详情"
      :visible.sync="updateDialogVisible"
      width="900px"
      fullscreen
      center
    >
      <div class="flex_center">
        <ClientInfo></ClientInfo>
      </div>
      <span
        slot="footer"
        class="dialog-footer"
      >
        <el-button
          type="info"
          @click="updateDialogVisible = false"
        >取 消</el-button>
        <el-button
          type="primary"
          @click="submitConfirmAccount"
        >确 认</el-button>
      </span>
    </el-dialog> -->
    <NewFollow
      ref="NewFollow"
      v-if="followDialogVisible"
      :visible.sync="followDialogVisible"
      :clientData="clientFollowData"
    ></NewFollow>
  </div>
</template>

<script>
// 这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
// 例如：import 《组件名称》 from '《组件路径》';
// import ClientInfo from './info';
import { listData, getBelong, assignClient } from '@/api/Client/index';
import NewFollow from '../components/NewFollow';
export default {
  // import引入的组件需要注入到对象中才能使用
  components: {
    NewFollow,
  },
  props: {
    queryParams: {
      type: Object,
      default: () => {},
    },
    activeName: {
      type: String,
      default: '',
    },
  },

  data() {
    // 这里存放数据
    return {
      pickerOptions: {
                disabledDate(time) {
                  const currentDate = new Date();
                  const currentYear = currentDate.getFullYear();
                  const currentMonth = currentDate.getMonth() + 1; // 月份是从0开始的，所以需要+1
                  // 获取传入日期的年份和月份
                  const year = time.getFullYear();
                  const month = time.getMonth() + 1;
                  // 判断年份和月份是否相同，不同则禁用
                  return year !== currentYear || month !== currentMonth;
                },
              },
      areaObj: {
        101: '宏发一区',
        102: '宏发二区',
        103: '宏发三区',
        '-': '-',
      },
      listIds: [],
      loading: false,
      sendCustomerLoading: false,
      value: '',
      total: 0,
      options: [
        {
          value: '重点关注',
          label: '重点关注',
        },
        {
          value: '核心客户',
          label: '核心客户',
        },
        {
          value: '老客户',
          label: '老客户',
        },
      ],
      accountForm: {
        ids: '',
        belongSale: '',
        remark: '',
        belongSaleDate: '',
      },
      accountDialogVisible: false,
      updateDialogVisible: false,
      sendCustomerDialogVisible: false,
      tableData: [],
      stockData: {
        xData: [
          '2024-5-1',
          '2024-5-2',
          '2024-5-3',
          '2024-5-4',
          '2024-5-5',
          '2024-5-6',
          '2024-5-7',
        ],
        yData: [0, 100, 200, 300, 400, 500, 600],
        max: 200,
        min: 20,
      },
      menuData: [],
      calcListData: [],
      clientData: [],
      belongOptions: [],
      clientFollowData: {},
      followDialogVisible: false,
      seletIds: [],
      sendCustomerTableData: [],
    };
  },
  // 监听属性 类似于data概念
  computed: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
  },
  // 监控data中的数据变化

  // 方法集合

  methods: {
    showSendCustomers(row) {
      this.sendCustomerTableData = row.sendCustomers;
      this.sendCustomerDialogVisible = true;
    },

    async getList() {
      this.loading = true;
      // console.log('queryParams', this.queryParams);
      // console.log('activeName', this.activeName);
      const queryParams = {
        ...this.queryParams,
        dataType: this.activeName,
      };
      const res = await listData(queryParams);
      this.tableData = res.data.list;
      this.total = res.data.total;
      this.loading = false;
    },
    async submitConfirmAccount() {
      // console.log(this.accountForm);
      if (
        this.accountForm.belongSale == '' ||
        this.accountForm.belongSaleDate == ''
      ) {
        this.$message.error('请选择接收对象和指派时间');
        return false;
      }
      const res = await assignClient(this.accountForm);
      this.$message.success('指派成功');
      this.accountDialogVisible = false;
      this.getList();
      this.$refs.multipleTable.clearSelection();
    },
    handleFollow(row) {
      this.clientFollowData = { customerId: row.id, name: row.name };
      //  {
      //   customerId: row.id,
      //     name: row.name,
      //     contact: 1,
      //     contactName: row.customerContactName,

      //     followType: 1,
      //     followTime: '',
      //     content: '',
      //     fileUrls:''
      // };
      console.log('row', row);
      this.followDialogVisible = true;
    },
    handleEdit() {
      //
      if (this.clientData.length <= 0) {
        this.$message.error('请选择需要指派的客户');
        return false;
      }
      let flag = false
      for(let i = 0;i<this.clientData.length;i++){
        if (this.clientData[i].typeName=='-') {
          flag=true
          this.$message.error('指派的客户必须有客户分类');
          return;
        }
        if (this.clientData[i].location=='-') {
          flag=true
          this.$message.error('指派的客户必须有所在地区');
          return;
        }
      }
      if(flag){
        return false;
      }
      // console.log('this.clientData', this.clientData);
      this.accountForm.ids = this.clientData.map((item) => item.id).join(',');
      this.accountForm.belongSale = '';
      this.accountForm.remark = '';
      this.accountForm.belongSaleDate = '';
      this.accountDialogVisible = true;
      // console.log('编辑按钮');
    },
    handleInfo() {
      // this.updateDialogVisible = true;
      // this.$emit('changeShowStatus');
      // console.log('详情按钮', this.$route);
      // console.log('详情按钮', this.$router);
      // this.$router.getRoutes();
      // let childrenRoute = {
      //   path: 'info',
      //   name: 'ClientInfo',
      //   component: () => import('@/views/Client/Client/info.vue'),
      //   meta: {
      //     title: '查看详情',
      //   },
      // };
      // this.$router.addRoute('Client', childrenRoute);
      // console.log(this.$router);
      // this.$router.push({
      //   path: '/client/client/info',
      // });
      // console.log('详情按钮');
    },
    handleSelectionChangePush(selection) {
      console.log(selection);
      // 记录seletIds
      this.seletIds = selection.map((item) => item.id);
      this.clientData = selection;
    },

    bindRowKeys(row) {
      return row.id;
    },
    // 处理分类相关数据
    calcCatData() {
      this.calcListData = [];
      let calcListDataIdx = 0;
      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];
        // console.log(item);
        if (index === 0) {
          item.domId = item.catName;
          item.domIdx = calcListDataIdx;
          this.calcListData.push(1);
          this.menuData.push({ label: item.catName });
        } else {
          if (item.catName !== this.tableData[index - 1].catName) {
            item.domId = item.catName;
            calcListDataIdx++;
            item.domIdx = calcListDataIdx;
            this.calcListData.push(1);
            this.menuData.push({ label: item.catName });
          } else {
            item.domId = item.catName + index;
            this.calcListData[calcListDataIdx]++;
          }
        }
      }
      // console.log(this.tableData);
      // console.log(this.calcListData);
      // console.log(this.menuData);
    },
    addClass({ row, column, rowIndex, columnIndex }) {
      if (row[column.property] == null || row[column.property] == '') {
        row[column.property] = '-';
      }
    },
    toTop() {
      // console.log(this.$refs);
      // this.$scrollTo(this.$refs[0]);
      this.calcCatData();
    },

    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        // console.log(row, column, rowIndex, columnIndex);
        if (row.catName === row.domId) {
          return {
            rowspan: this.calcListData[row.domIdx],
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }
    },
    async getBelong() {
      const res = await getBelong({ isSale: true });
      this.belongOptions = res.data;
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {
    // this.getList()
    this.getBelong();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.$EventBus.$on('refreshClientList', this.getList);
    this.calcCatData();
  },
  beforeCreate() {}, // 生命周期 - 创建之前
  beforeMount() {}, // 生命周期 - 挂载之前
  beforeUpdate() {}, // 生命周期 - 更新之前
  updated() {}, // 生命周期 - 更新之后
  beforeDestroy() {
    this.$EventBus.$off('refreshClientList', this.getList);
  }, // 生命周期 - 销毁之前
  destroyed() {}, // 生命周期 - 销毁完成
  activated() {}, // 如果页面有keep-alive缓存功能，这个函数会触发
};
</script>

<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}
.router_btn {
  margin-left: 10px;
}
.little_tip {
  color: #e6a23c;
}
.cursor-p {
  color: #1890ff;
  cursor: pointer;
}
.status_box {
  &.normal {
    color: #1890ff;
  }
  &.lost {
    color: #ff0000;
  }
  &.out {
    color: #ff9900;
  }
  &.follow {
    color: #d23f57;
  }
}

.show-send-customers {
  color: #0000ff;
  cursor: pointer;
}
::v-deep .el-date-editor.el-input,
::v-deep .el-date-editor.el-input__inner {
  width: 100%;
}
</style>
