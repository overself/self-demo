<template>
  <div class="dashboard-editor-container">
    <!-- 快速入口 -->
    <el-row class="row-btm">
      <EntranceCard />
    </el-row>

    <div class="coming-soon-home">
      <!-- 系统简报/库存趋势 -->
      <el-row :gutter="8" class="row-btm">
        <el-col :span="12">
          <SysRecordCard />
        </el-col>

        <el-col :span="12">
          <!--<StockCard />-->
          <!-- <ClientCard /> -->
        </el-col>
      </el-row>

      <!-- 出库量目标/销售趋势 -->
      <!--<el-row
        :gutter="8"
        class="row-btm"
      >
        <el-col :span="12">
          <DeliveryCard />
        </el-col>

        <el-col :span="12">
          <CompareCard />
        </el-col>
      </el-row>
      <el-row class="row-btm">
        <SaleCard />
      </el-row>-->
      <!-- 渠道/客户分布 -->
      <!--<el-row
        :gutter="8"
        class="row-btm"
      >
        <el-col :span="12">
          <ChanelCard />
        </el-col>

        <el-col :span="12">
          <PerformanceCard />
          <ClientCard />
        </el-col>
      </el-row>-->
    </div>
  </div>
</template>

<script>
import EntranceCard from './dashboard/card/entranceCard/index';
import SysRecordCard from './dashboard/card/sysRecordCard/index';
import StockCard from './dashboard/card/stockCard/index';
import DeliveryCard from './dashboard/card/deliveryCard/index';
import SaleCard from './dashboard/card/saleCard/index';
import CompareCard from './dashboard/card/compareCard/index';
import ClientCard from './dashboard/card/clientCard/index';
import PerformanceCard from './dashboard/card/performanceCard/index';
import ChanelCard from './dashboard/card/chanelCard/index.vue';
// import PanelGroup from './dashboard/PanelGroup';
// import LineChart from './dashboard/LineChart';
// import RaddarChart from './dashboard/RaddarChart';
// import PieChart from './dashboard/PieChart';
// import BarChart from './dashboard/BarChart';

export default {
  name: 'Index',
  components: {
    EntranceCard,
    SysRecordCard,
    StockCard,
    DeliveryCard,
    SaleCard,
    ClientCard,
    PerformanceCard,
    CompareCard,
    ChanelCard,
    // PanelGroup,
    // LineChart,
    // RaddarChart,
    // PieChart,
    // BarChart,
  },
  data() {
    return {
      // lineChartData: lineChartData.newVisitis,
    };
  },
  methods: {
    handleSetLineChartData(type) {
      // this.lineChartData = lineChartData[type];
    },
  },
};
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;

  .row-btm {
    margin-bottom: 8px;
  }

  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
}

@media (max-width: 1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}
</style>
