<!-- 客户预警 -->
<template>
  <div class="app-container Board">

    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <el-collapse
          accordion
          v-model="activeTabName"
          @change="handleCollapseChange"
        >
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">预警查询
                <div
                  class="title_right_btns"
                  @click.stop="handleScreen"
                >
                  <screenfull
                    id="screenfull"
                    class="right-menu-item hover-effect"
                    ref="screenIcon"
                    @screenToggle="handleScreenToggle"
                  />{{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">

              <!-- 搜索工作栏 -->
              <BaseSearchContainer
                :column="searchColumn"
                :params="queryParams"
                :isAll="false"
                @datePickerChange="onDatePickerChange"
                @onSearch="handleQuery"
                @onReset="handleReset"
              ></BaseSearchContainer>
            </div>
          </el-collapse-item>
        </el-collapse>
        <CrudHeader>
          <template slot="left">
            <el-tabs
              v-model="activeName"
              @tab-click="handleClick"
            >
              <el-tab-pane
                v-for="(item, index) in tabList"
                :key="index"
                :label="item.label"
                :name="item.value"
              ></el-tab-pane>
            </el-tabs>
          </template>

          <template slot="rightBtns">
            <el-button
              v-hasPermi="['hf:customer:export']"
              size="small"
              @click="handleExport"
              :loading="exportLoading"
            >导出</el-button>
          </template>

          <template slot="list">
            <div class="">
              <el-table
                :data="tableData"
                border
                style="width: 100%;"
                v-loading="loading"
                :cell-style="addClass"
              >
                <el-table-column
                  label="客户简称"
                  align="center"
                  prop="name"
                  show-overflow-tooltip
                  width="252"
                />
                <el-table-column
                  label="客户名称"
                  align="center"
                  prop="fullName"
                  show-overflow-tooltip
                  width="252"
                />
                <el-table-column
                  label="客户分类"
                  align="center"
                  prop="typeName"
                />
                <el-table-column
                  label="所在区域"
                  align="center"
                  prop="locationDetail"
                >
                </el-table-column>
                <el-table-column
                  label="归属销售"
                  align="center"
                  prop="belongSaleName"
                />
                <el-table-column
                  label="客户预警"
                  align="center"
                  prop="belongSaleName"
                > <template v-slot="scope">
                    <div
                      v-for="state in scope.row.status.split(' ')"
                      :key="state"
                      class="status_box"
                      :class="{'normal':state==='正常','lost':state==='流失预警','out':state==='出库量预警','follow':state==='跟进预警'}"
                    >
                      {{ state }}
                    </div>
                  </template>
                </el-table-column>
                <el-table-column
                  label="客户标签"
                  align="center"
                  prop="signNames"
                />
                <!-- <el-table-column
                  label="送货客户编码"
                  align="center"
                  prop="sendCustomerCode"
                />
                <el-table-column
                  label="送货名称"
                  align="center"
                  prop="sendCustomerName"
                /> -->
                <el-table-column
                  label="最近出库日期"
                  align="center"
                  prop="lastSale"
                />
                <el-table-column
                  label="最近跟进时间"
                  align="center"
                  prop="followTime"
                  width='130'
                />
                <!-- <el-table-column
                  label="联系人"
                  align="center"
                  prop="customerContactName"
                />
                <el-table-column
                  label="联系方式"
                  align="center"
                  prop="customerContactTelephone"
                />

                <el-table-column
                  label="归属大区"
                  align="center"
                  prop="area"
                />

                <el-table-column
                  label="客户状态"
                  align="center"
                  prop="status"
                >
                  <template v-slot="scope">
                    <div
                      v-for="state in scope.row.status.split(' ')"
                      :key="state"
                      class="status_box"
                      :class="{'normal':state==='正常','lost':state==='流失预警','out':state==='出库量预警','follow':state==='跟进预警'}"
                    >
                      {{ state }}
                    </div>
                  </template>
                </el-table-column>
                <el-table-column
                  label="最近成交时间"
                  align="center"
                  prop="lastSale"
                ></el-table-column> -->

                <el-table-column
                  label="操作"
                  header-align="center"
                  align="center"
                  class-name="small-padding fixed-width"
                  width="200"
                >
                  <template v-slot="scope">
                    <el-button
                      size="mini"
                      type="text"
                      icon="el-icon-edit"
                      @click="handleFollow(scope.row)"
                    >跟进</el-button>
                    <router-link
                      :to="'/client-control/update/' + scope.row.id"
                      class="router_btn"
                    >

                      <el-button
                        size="mini"
                        type="text"
                        icon="el-icon-edit"
                        style="margin-left: 10px;"
                      >编辑</el-button>
                    </router-link>
                    <el-button
                      size="mini"
                      type="text"
                      icon="el-icon-edit"
                      style="margin-left: 10px;"
                      @click="toDetail(scope.row.id)"
                    >详情</el-button>

                  </template>
                </el-table-column>
              </el-table>

              <pagination
                v-show="total > 0"
                :total="total"
                :page.sync="queryParams.pageNo"
                :limit.sync="queryParams.pageSize"
                @pagination="getList"
              />
            </div>
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
    <NewFollow
      ref="NewFollow"
      v-if="followDialogVisible"
      :visible.sync="followDialogVisible"
      :clientData="clientFollowData"
    ></NewFollow>
  </div>
</template>

<script>
import Screenfull from '@/components/Screenfull';
import { listData } from '@/api/system/addCustomer/index';
import { exportExcel } from '@/api/monitoring/customer/index';
import { deepClone } from '@/utils';
import NewFollow from '../../Client/components/NewFollow.vue';
import { getUserProfile } from '@/api/system/user';

const queryParamsCommon = {
  pageNo: 1,
  pageSize: 10,
  deptId: null,
  warningType: '',
  fromLastSale: '',
  toLastSale: '',
  // myCustomer: 0,
  warnTabType: '',
  _orderDate: '',
};

export default {
  name: 'SalesDelivery',
  components: {
    Screenfull,
    NewFollow,
  },

  data() {
    return {
      userInfo: {},
      clientFollowData: {},
      followDialogVisible: false,
      loading: false,
      exportLoading: false,
      // 时间选择默认1个月
      queryParams: deepClone(queryParamsCommon),
      activeName: '',
      tabs: [
        { label: '流失预警', value: '3', mapValue: 'ls' },
        { label: '计划预警', value: '4', mapValue: 'jh' },
        { label: '出库量预警', value: '5', mapValue: 'ck' },
        // { label: '全部预警', value: '1', mapValue: 'all' },
        // { label: '我的预警', value: '2', mapValue: 'self' },
        // { label: '宏发一区', value: '101', mapValue: 'zone1' },
        // { label: '宏发二区', value: '102', mapValue: 'zone2' },
        // { label: '宏发三区', value: '103', mapValue: 'zone3' },
      ],
      areaObjMap: {
        ls:'流失预警',
        jh:'',
        ck:null,
        // all: null,
        // self: '',
        // zone1: '宏发一区',
        // zone2: '宏发二区',
        // zone3: '宏发三区',
      },
      tableData: [],
      total: 0,
      productCodeList: [],
      searchColumn: (this.searchColumn = [
        {
          label: '业务部门',
          prop: 'deptId',
          type: 'select',
          search: true,
          disabled: false,
          dicData: [
            { label: '宏发一区', value: '101' },
            { label: '宏发二区', value: '102' },
            { label: '宏发三区', value: '103' },
          ],
        },
        // {
        //   label: '预警分类',
        //   prop: 'warningType',
        //   type: 'select',
        //   key: 'warningType',
        //   search: true,
        //   dicData: [
        //     { label: '流失预警', value: 'WARNING_LOSS' },
        //     { label: '跟进预警', value: 'WARNING_FOLLOW' },
        //     { label: '计划预警', value: 'WARNING_PLAN' },
        //     { label: '出库量预警', value: 'WARNING_OUT' },
        //   ],
        // },
        {
          label: '客户标签',
          prop: 'ids',
          key: 'CUSTOMER_TAG',
          type: 'select',
          search: true,
          quick: true,
          multiple: true,
          unshiftAll: true,
          dicUrl: '/system/sign/simple-list',
          dicData: [],
        },
      ]),
      tabList: [],
      isFullScreen: true,
      activeTabName: '1',
      tempId: '',
    };
  },

  created() {
    // 默认二个月
    // this.setDefaultMonth();
    // this.queryParams.dataType = '全部客户';
    this.getUserProfile();
    // this.getList();
  },
  mounted() {
    let that = this;
    this.$EventBus.$on('getFollowList', that.getFollowList);
  },
  watch: {},
  methods: {
    async getUserProfile() {
      this.tabList = [];
      const res = await getUserProfile();
      this.userInfo = res.data;

      // if (res.data.posts?.findIndex((item) => item.id == 2) !== -1) {
      //   // 经理
      //   this.searchColumn[0].disabled = true;
      //   this.searchColumn = deepClone(this.searchColumn);
      // }

      this.tabs.map((item) => {
          this.tabList.push(item);
        // if (res.data.permissionTabs.includes(item.mapValue)) {
        //   this.tabList.push(item);
        // }
      });
      this.activeName = this.tabList[0].value;
      this.queryParams.warnTabType = this.activeName;

      this.$nextTick(() => {
        this.getList();
      });
    },

    handleFollow(row) {
      this.clientFollowData = { customerId: row.id, name: row.name };
      //  {
      //   customerId: row.id,
      //     name: row.name,
      //     contact: 1,
      //     contactName: row.customerContactName,

      //     followType: 1,
      //     followTime: '',
      //     content: '',
      //     fileUrls:''
      // };
      console.log('row', row);
      this.followDialogVisible = true;
    },
    handleExport() {
      const queryParams = this.formatQueryParams(this.queryParams);
      this.$modal
        .confirm('是否确认导出数据项?')
        .then(() => {
          return exportExcel(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '客户预警.xls');
        })
        .catch(() => {});
    },

    onDatePickerChange(e) {
      if (e) {
        this.queryParams.fromLastSale = e[0];
        this.queryParams.toLastSale = e[1];
      } else {
        this.queryParams.fromLastSale = '';
        this.queryParams.toLastSale = '';
      }
    },

    handleQuery() {
      // console.log(this.queryParams);

      this.queryParams.pageNo = 1;
      this.getList();
    },

    handleReset() {
      // this.queryParams = deepClone(queryParamsCommon);
      // this.setDefaultMonth();
      this.queryParams.pageNo = 1;
      this.getList();
    },
    getFollowList() {
      console.log('get');

      this.queryParams.pageNo = 1;
      this.getList();
    },
    handleClick(tab, event) {
      this.queryParams.pageNo = 1;
      this.queryParams.warnTabType = this.activeName;

      // if (this.activeName != '1') {
      //   this.queryParams.deptId = undefined;
      // } else {
      //   this.queryParams.deptId = this.tempId;
      // }
      if (this.activeName != '1') {
        for (let i = 0; i < this.searchColumn.length; i++) {
          if (this.searchColumn[i].label == '业务部门') {
            this.queryParams.deptId = undefined;
            // this.searchColumn[i].disabled = true;
            break;
          }
        }
      } else {
        for (let i = 0; i < this.searchColumn.length; i++) {
          if (this.searchColumn[i].label == '业务部门') {
            this.searchColumn[i].disabled = false;
            break;
          }
        }
      }

      this.searchColumn = deepClone(this.searchColumn);
      this.getList();
    },

    formatQueryParamsAndTabs() {
      switch (this.activeName) {
        case '3':
          this.queryParams.warningType = this.activeName;
          break;

        case '4':
          this.queryParams.warningType = this.activeName;
          break;

        case '5':
          this.queryParams.warningType = this.activeName;
          break;

        case 'WARNING_ALL':
          this.queryParams.warningType = this.activeName;
          break;

        case '我的客户':
          this.queryParams.myCustomer = 1;

          break;

        case '101':
        case '102':
        case '103':
          this.queryParams.area = this.activeName;
          break;

        default:
          break;
      }
    },

    formatQueryParams(queryParams) {
      let params = deepClone(queryParams);

      delete params._orderDate;

      if (params._warningType) {
        params.warningType = params._warningType;
      }

      return params;
    },

    toDetail(id) {
      this.$router.push(`/client-control/info/${id}`);
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      if (row[column.property] == null || row[column.property] == '') {
        row[column.property] = '-';
      }
    },

    getList(type) {
      this.loading = true;
      //   let params = {
      //     warningType: 'WARNING_ALL',
      //     pageNo: 1,
      //     pageSize: 10,
      //   };
      let params = this.formatQueryParams(this.queryParams);
      delete params.ids;
      params.signIds = this.queryParams.ids
        ? this.queryParams.ids.join(',')
        : '';
      // if (this.activeName == 1) {
        this.tempId = this.queryParams.deptId;
      // }
      // if()
      listData(params)
        .then((res) => {
          this.loading = false;
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.total;
        })
        .catch(() => {
          this.loading = false;
        });
    },

    setDefaultMonth() {
      const today = this.$dayjs().startOf('day').format('YYYY-MM-DD');
      const oneMonthBefore = this.$dayjs()
        .subtract(2, 'month')
        .startOf('day')
        .format('YYYY-MM-DD');

      this.queryParams._orderDate = [oneMonthBefore, today];
      this.queryParams.fromLastSale = oneMonthBefore;
      this.queryParams.toLastSale = today;
    },
    handleScreen() {
      this.$refs.screenIcon.click();
    },
    handleScreenToggle(val) {
      this.isFullScreen = val;
      // console.log(val, 123);
    },
    handleCollapseChange() {
      // this.$refs['market_price_type'].calTableHeight()
    },
    handleGoClientInfo(id) {
      this.$router.push('/client-control/info/' + id);
    },
  },
};
</script>

<style lang="scss" scoped>
::v-deep .list_wrap {
  margin-top: 0 !important;
}

.status_box {
  &.normal {
    color: #1890ff;
  }
  &.lost {
    color: #ff0000;
  }
  &.out {
    color: #ff9900;
  }
  &.follow {
    color: #d23f57;
  }
}
.component_title {
  padding: 10px 30px 0 20px;
}
::v-deep .el-collapse-item__content {
  padding-bottom: 0 !important;
}
</style>
