<template>
  <div class="list_wrap">
    <el-table
      :data="tableData"
      :span-method="objectSpanMethod"
      border
      style="width: 100%;"
      :cell-style="addClass"
    >
      <el-table-column
        prop="productTypeName"
        label="类名"
        header-align="center"
        align="center"
        width="62"
      >
        <template slot-scope="scope">
          <div
            :id="scope.row.domId"
            class="cat_mao"
            :ref="scope.$index"
          ></div>
          <div class="cat_text">
            {{ scope.row.productTypeName||'-' }}
          </div>
        </template>
      </el-table-column>

      <el-table-column
        prop="productTopTypeName"
        label="品项大类"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="productName"
        label="品项名称"
        header-align="center"
        align="center"
        width="230"
      ></el-table-column>

      <el-table-column
        prop="productSpec"
        label="详细规格"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input
              v-model="scope.row.newRow.productSpec"
              placeholder="请填写"
            ></el-input>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.productSpec}}</div>
        </template>
      </el-table-column>

      <el-table-column
        prop="amount"
        label="库存（吨）"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input-number
              style="width:100%"
              :controls="false"
              :step="0.001"
              :precision="3"
              v-model="scope.row.newRow.amount"
              @input.native="changeInputPt2($event,3)"
              placeholder="请填写"
            ></el-input-number>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.amount|weightFormat}}</div>
        </template>
      </el-table-column>

      <!-- <el-table-column
        prop="remark"
        label="库存备注"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input
              v-model="scope.row.newRow.remark"
              placeholder="请填写"
            ></el-input>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.remark}}</div>
        </template>
      </el-table-column> -->

      <el-table-column
        prop="upperLimit"
        label="库存上限"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input-number
              style="width:100%"
              :controls="false"
              :step="0.001"
              :precision="3"
              v-model="scope.row.newRow.upperLimit"
              @input.native="changeInputPt2($event,3)"
              placeholder="请填写"
            ></el-input-number>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.upperLimit|weightFormat}}</div>
        </template>
      </el-table-column>

      <el-table-column
        prop="lowerLimit"
        label="库存下限"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div
            class="is_edit"
            v-if="scope.row.isEdit"
          >
            <el-input-number
              style="width:100%"
              :controls="false"
              :step="0.001"
              :precision="3"
              v-model="scope.row.newRow.lowerLimit"
              @input.native="changeInputPt2($event,3)"
              placeholder="请填写"
            ></el-input-number>
          </div>
          <div
            class=""
            v-else
          >{{scope.row.lowerLimit|weightFormat}}</div>
        </template>
      </el-table-column>

      <el-table-column
        prop="stockStatus"
        label="库存预警"
        header-align="center"
        align="center"
      >
        <template slot-scope="scope">
          <div style="color: red;">{{displayLimit(scope.row)}}</div>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { updateData } from '@/api/Board/StockBoard';
import { listData } from '@/api/monitoring/stock/index.js';

export default {
  props: {
    queryParams: {
      type: Object,
      default: () => {
        return {
          productId: '',
          productType: '',
          factoryType: '',
          // priceDate: '',
        };
      },
    },
  },
  data() {
    return {
      tableData: [],
      stockData: {
        xData: [
          '2024-5-1',
          '2024-5-2',
          '2024-5-3',
          '2024-5-4',
          '2024-5-5',
          '2024-5-6',
          '2024-5-7',
        ],
        yData: [0, 100, 200, 300, 400, 500, 600],
        max: 200,
        min: 20,
      },
      menuData: [],
      calcListData: [],
    };
  },

  methods: {
    displayLimit(item) {
      if (Number(item.amount) > Number(item.upperLimit)) {
        return '超过上限';
      } else if (Number(item.amount) < Number(item.lowerLimit)) {
        return '低于下限';
      }

      return '-';
    },

    handleEdit(row, rowIdx) {
      // 编辑
      if (row.isEdit) {
        // 保存
        console.log(row.newRow);
        // this.$set(this.tableData, rowIdx, { ...row, ...row.newRow });
        // this.tableData[rowIdx] = row.newRow;

        const newDate = { id: row.id, ...row.newRow };
        this.updateDataFunc(newDate).then(() => {
          row.isEdit = false;
          this.$message({
            type: 'success',
            message: '保存成功',
          });
        });
        row.productName = row.newRow.productName;
        row.productSpec = row.newRow.productSpec;
        row.amount = row.newRow.amount;
        row.lowerLimit = row.newRow.lowerLimit;
        row.remark = row.newRow.remark;
        row.upperLimit = row.newRow.upperLimit;
        console.log(this.tableData);
      } else {
        // 编辑
        row.isEdit = true;
      }
    },
    async updateDataFunc(data) {
      await updateData(data);
    },
    async getList() {
      console.log(this.queryParams);
      const res = await listData(this.queryParams);
      res.data.map((item) => {
        item.isEdit = false;
        item.newRow = {
          productName: item.productName,
          productSpec: item.productSpec,
          amount: item.amount,
          lowerLimit: item.lowerLimit,
          remark: item.remark,
          upperLimit: item.upperLimit,
        };
      });
      this.tableData = res.data;
      this.calcCatData();
    },
    // 处理分类相关数据
    calcCatData() {
      this.calcListData = [];
      this.menuData = [];
      let calcListDataIdx = 0;
      for (let index = 0; index < this.tableData.length; index++) {
        const item = this.tableData[index];
        // console.log(item);
        if (index === 0) {
          item.domId = item.productTypeName;
          item.domIdx = calcListDataIdx;
          this.calcListData.push(1);
          this.menuData.push({ label: item.productTypeName });
        } else {
          if (
            item.productTypeName !== this.tableData[index - 1].productTypeName
          ) {
            item.domId = item.productTypeName;
            calcListDataIdx++;
            item.domIdx = calcListDataIdx;
            this.calcListData.push(1);
            this.menuData.push({ label: item.productTypeName });
          } else {
            item.domId = item.productTypeName + index;
            this.calcListData[calcListDataIdx]++;
          }
        }
      }
      // console.log(this.tableData);
      // console.log(this.calcListData);
      // console.log(this.menuData);
    },
    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0 || columnIndex === 3) {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      }
      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },
    toTop() {
      // console.log(this.$refs);
      // this.$scrollTo(this.$refs[0]);
      this.calcCatData();
    },

    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        // console.log(row, column, rowIndex, columnIndex);
        if (row.productTypeName === row.domId) {
          return {
            rowspan: this.calcListData[row.domIdx],
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }
    },
  },
  created() {
    this.getList();
  },
  mounted() {
    this.calcCatData();
  },
};
</script>

<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}
.cat_text {
  margin: auto;
  width: 14px;
}
.pop_text {
  color: #2d7ae6;
}
</style>
