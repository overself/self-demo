<!-- 库存预警 -->
<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <div class="search_wrap">
          <div class="component_title">库存预警

            <div class="title_right_btns">
              <screenfull
                id="screenfull"
                class="right-menu-item hover-effect"
              />全屏
            </div>
          </div>
        </div>

        <div class="content_wrap">
          <el-tabs
            v-model="activeName"
            @tab-click="handleClick"
          >
            <el-tab-pane
              v-for="tab in factoryOption"
              :key="tab.value"
              :label="tab.label"
              :name="tab.value"
            >
              <List
                v-if="activeName==tab.value"
                :ref="tab.value"
                :queryParams="{...queryParams,factoryType:tab.value}"
              ></List>
            </el-tab-pane>
          </el-tabs>

         <!-- <div class="tabs-right-search__wrapper">
            <div class="tabs-right-search__inner">
              <el-form
                :model="queryParams"
                size="small"
                :inline="true"
                label-width="90px"
              >
                <el-form-item label="">
                  <el-date-picker
                    v-model="queryParams.date"
                    type="date"
                    placeholder="选择日期"
                    size="small"
                    :format="'yyyy-MM-dd'"
                    :valueFormat="'yyyy-MM-dd'"
                    :style="{width: '240px'}"
                    :picker-options="datePickerOptions"
                    @change='onDatePickerChange'
                    :clearable="false"
                  ></el-date-picker>
                </el-form-item>
              </el-form>
            </div>
          </div> -->

          <div class="tabs_right_btns">
            <!-- <div class="right_text">
              <CurrentTime></CurrentTime>
            </div>
            <div class="right_text">
              单位：元/公斤
            </div> -->

            <el-button
              v-hasPermi="['system:board-inventory:warnexport']"
              style="margin-left:10px"
              size="small"
              :loading="exportLoading"
              @click="handleExport('')"
            >导出</el-button>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getDictDatas, DICT_TYPE } from '@/utils/dict';
import Screenfull from '@/components/Screenfull';
import { getToday } from '@/api/Board/StockBoard';
import { exportExcel } from '@/api/monitoring/stock/index';
import { productData } from '@/api/Board/common';
import { getBaseHeader } from '@/utils/request';

import List from './list';
export default {
  components: { List, Screenfull },

  data () {
    return {
      exportLoading: false,
      queryParams: {
        productId: '',
        productType: '',
        date: this.$dayjs().format('YYYY-MM-DD'),
        // priceDate: this.$dayjs().format('YYYY-MM-DD'),
      },
      datePickerOptions: {
        disabledDate (time) {
          // 获取今天的日期
          const today = new Date();
          // 如果选择的日期在今天之后，则禁用
          return time.getTime() > today.getTime();
        },
      },
      productNameDatas: [],
      statusDictDatas: getDictDatas(DICT_TYPE.CATEGORY_CLASSIFY),
      upload: {
        // 是否禁用上传
        isUploading: false,
        // 是否更新已经存在的用户数据
        updateSupport: 0,
        // 设置上传的请求头部
        headers: getBaseHeader(),
        // 上传的地址
        url:
          process.env.VUE_APP_BASE_API +
          '/admin-api/system/board/inventory/import',
      },
      // factoryOption: getDictDatas(DICT_TYPE.SYSTEM_FACTORY),
      factoryOption: getDictDatas('factory_product'),
      activeName: getDictDatas('factory_product')[0].value,
    };
  },
  computed: {},
  watch: {
    'queryParams.productType' (newVal, oldVal) {
      console.log(newVal, oldVal);
      if (newVal === '') {
        this.productNameDatas = [];
      } else {
        this.queryParams.productId = '';
        this.getProductData();
      }
    },
    activeTabName: {
      handler (newVal, oldVal) {
        if (newVal != '1' && this.queryParams.pageSize < 20) {
          this.queryParams.pageNo = 1
          this.queryParams.pageSize = 20
          this.$nextTick(() => {
            this.$refs.hookList.getList();
          })

        }
      },
      deep: true,
      // immediate: true,
    }
  },
  methods: {
    onDatePickerChange () {
      this.$refs[this.activeName].getList();
    },
    handleFileSuccess (response, file, fileList) {
      console.log(response, file, fileList);
      if (response.code === 0) {
        this.$message({
          type: 'success',
          message: '导入成功',
        });
        this.$nextTick(() => {
          this.$refs[this.activeName].getList();
        });
      } else {
        this.$notify.error({
          title: response.msg,
        });
      }
      this.$refs.upload.clearFiles();
      this.upload.isUploading = false;
    },
    handleFileUploadProgress (event, file, fileList) {
      this.upload.isUploading = true;
    },
    async getToday () {
      const res = await getToday();
    },

    handleExport (type) {
      const queryParams = {
        ...this.queryParams,
        factoryType: this.activeName,
      };
      this.$modal
        .confirm('是否确认导出?')
        .then(() => {
          this.exportLoading = true;
          return exportExcel(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '库存预警.xls');
          this.exportLoading = false;
        })
        .catch(() => { });
    },

    handleQuery () {
      // console.log(this.queryParams);
      // console.log(this.$refs.list);
      this.$nextTick(() => {
        this.$refs[this.activeName][0].getList();
      });
    },
    resetQuery () {
      this.queryParams.productId = '';
      this.queryParams.productType = '';
      // this.queryParams.priceDate = this.$dayjs().format('YYYY-MM-DD');
      console.log('点击了重置', this.queryParams);
      this.$nextTick(() => {
        this.$refs[this.activeName][0].getList();
      });
    },
    handleClick (tab, event) {
      console.log(tab, event);
      // this.$refs[this.activeName].$ready = true;
      // this.$refs.test_list.getList();
      this.queryParams.factoryType = this.activeName;
    },
    async getProductData () {
      const query = {
        type: this.queryParams.productType,
      };
      const res = await productData(query);
      this.productNameDatas = res.data;
    },
  },
};
</script>

<style lang="scss" scoped>
.tabs-right-search__wrapper {
  position: absolute;
  top: 15px;
  left: 560px;
  display: inline-block;
  width: 10px;
  height: 10px;
}
</style>
