<!-- 预警说明 -->
<template>
  <div class="app-container Board">

    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <div class="search_wrap">
          <div class="component_title">预警列表

            <div class="title_right_btns">
              <screenfull
                id="screenfull"
                class="right-menu-item hover-effect"
              />全屏
            </div>
          </div>
        </div>

        <CrudHeader>
          <template slot="list">
            <div class="">
              <el-table
                :data="tableData"
                border
                style="width: 100%;"
              >
                <el-table-column
                  label="序号"
                  type="index"
                >
                </el-table-column>
                <el-table-column
                  label="预警分类"
                  align="center"
                  prop="category"
                  width="80px"
                />
                <el-table-column
                  label="预警名称"
                  align="center"
                  prop="name"
                  width="150px"
                />
                <el-table-column
                  label="适配范围"
                  align="center"
                  prop="range"
                  width="200px"
                />
                <el-table-column
                  label="阈值"
                  align="center"
                  prop="threshold"
                  width="80px"
                />
                <el-table-column
                  label="预警规则说明"
                  align="center"
                  prop="rules"
                />
              </el-table>
            </div>
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import Screenfull from '@/components/Screenfull';

export default {
  name: 'SalesDelivery',
  components: {
    Screenfull,
  },

  data () {
    return {
      loading: false,
      exportLoading: false,
      queryParams: {},
      activeName: '全部客户',
      tableData: [
        {
          category: '客户类',
          name: '跟进预警',
          range: '一区 二区 三区',
          threshold: '7天',
          rules: '超过7天，没有《客户跟进》记录的客户，进行预警',
        },
        {
          category: '客户类',
          name: '流失预警',
          range: '一区 二区 三区',
          threshold: '30天',
          rules: '超过30天，没有《出库单》记录的客户，进行预警',
        },
        {
          category: '客户类',
          name: '出库量预警',
          range: '一区 二区 三区',
          threshold: '30天',
          rules: '超过30天，且出库量少于30吨的客户，进行预警',
        },
        {
          category: '客户类',
          name: '计划预警',
          range: '一区 二区 三区',
          threshold: '30天',
          rules: '超过30天，没有《计划预警》记录的，客户进行，预警',
        },
      ],
      total: 0,
    };
  },

  methods: {},
};
</script>

<style lang="scss" scoped>
::v-deep .list_wrap {
  margin-top: 0 !important;
}

.status_box {
  &.normal {
    color: #1890ff;
  }
  &.lost {
    color: #ff0000;
  }
  &.out {
    color: #ff9900;
  }
  &.follow {
    color: #d23f57;
  }
}
</style>
