<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col :span="24" :xs="24">
        <el-collapse accordion v-model="activeTabName">
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">产品销售排名
                <div class="title_right_btns" @click.stop="handleScreen">
                  <screenfull id="screenfull" class="right-menu-item hover-effect" ref="screenIcon" @screenToggle="handleScreenToggle" />
                  {{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">
              <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" label-width="100px">
                <el-form-item label="品项大类" prop="productBigType">
                  <el-select filterable clearable v-model="queryParams.productBigType" placeholder="请选择品项大类" style="width: 240px">
                    <el-option v-for="dict in searchProductTopTypeList" :key="dict.value" :label="dict.label" :value="dict.value" />
                  </el-select>
                </el-form-item>
                <el-form-item label="品类" prop="productType">
                  <el-select v-model="queryParams.productType" placeholder="请选择品类" clearable filterable style="width: 240px;"
                    @change="onProductCategoryChange">
                    <el-option v-for="item in productCategoryList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="品项名称" prop="productName">
                  <el-input v-model="queryParams.productName" placeholder="请输入品项名称" style="width: 240px"></el-input>
                </el-form-item>
                <!-- <el-form-item label="品项" prop="productName">
                  <el-select v-model="queryParams.productName" placeholder="请选择品项" clearable filterable style="width: 240px;">
                    <el-option v-for="item in productCodeList" :key="item.id" :label="item.name" :value="item.id">
                      <span class="st-name-spec">{{item.name}} / {{item.spec}}</span>
                    </el-option>
                  </el-select>
                </el-form-item> -->
                <el-form-item label="业务部门" prop="departmentName">
                  <el-select v-model="queryParams.departmentName" placeholder="请选择业务部门" style="width: 240px" filterable clearable>
                    <el-option v-for="item in clientAreaOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="业务员" prop="saleUserId">
                  <el-select v-model="queryParams.saleUserId" placeholder="请选择业务员" style="width: 240px" filterable clearable>
                    <el-option v-for="item in belongList" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="工厂" prop="factory">
                  <el-select v-model="queryParams.factory" placeholder="请选择工厂" style="width: 240px" filterable clearable>
                    <el-option v-for="item in factoriesOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="所在地区" prop="location">
                  <el-cascader clearable filterable style="width: 240px" :placeholder="`请选择所在地区`" v-model="queryParams.location"
                    :options="cityOption" @change="onCityChange">
                  </el-cascader>
                </el-form-item>
                <el-form-item label="客户分类" prop="customerType">
                  <el-select @change="onCustomerTypeChange" clearable v-model="queryParams.customerType" placeholder="请选择客户分类"
                    style="width: 240px">
                    <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="客户名称" prop="customerName">
                  <el-select v-model="queryParams.customerName" placeholder="请选择客户名称" clearable filterable allow-create
                    style="width: 240px;">
                    <el-option v-for="item in customerNameList" :key="item.id" :label="item.name" :value="item.name">
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="日期" prop="date">
                  <el-date-picker :clearable="false" value-format="yyyy-MM-dd" v-model="queryParams.dateRange" type="daterange"
                    placeholder="选择日期" style="width: 240px" @change="changeDate">
                  </el-date-picker>
                </el-form-item>
                <el-form-item style="margin-left: 100px;">
                  <el-button icon="el-icon-search" @click="handleQuery">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="handleReset">重置</el-button>
                  <el-button icon="el-icon-download" :loading="exportLoading" @click="handleExport">导出</el-button>
                </el-form-item>
              </el-form>
              <el-form size="small" :inline="true" label-width="100px">
                <el-form-item style="margin-left: 100px;">
                  <el-radio-group v-model="queryParams.type">
                    <el-radio :label="1">销售单</el-radio>
                    <el-radio :label="2">退货单</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-form>
            </div>
          </el-collapse-item>
        </el-collapse>
        <el-dialog :visible="priceVisible" width="400" @open="getPriceChart()" @close="priceVisible=false">
          <div v-loading="chartLoading">
            <div class="chart_wrap">
              <div class="chart_title">价格趋势</div>
              <div class="chart_control">
                <el-radio-group v-model="priceDateOption" size="mini" @input="dateOptionChange()">
                  <el-radio-button v-for="(item, index) in dateOptions" :key="index" :label="item.value">{{item.label}}</el-radio-button>
                </el-radio-group>
              </div>
            </div>
            <PriceChart :chart-data="priceData" :width="'720px'"></PriceChart>
          </div>
        </el-dialog>
        <CrudHeader>
          <template slot="list">
            <el-table row-key="id" :data="tableData" border v-loading="tableLoading">
              <el-table-column type="index" width="50" label="排名" align="center"></el-table-column>
              <el-table-column label="品项编码" min-width="130" align="center">
                <template v-slot="{row}">
                  <router-link :to="{path: '/delivery/summary', query: {productName:row.productName}}">
                    <span class="cursor-p">{{row.productCode}}</span>
                  </router-link>
                </template>
              </el-table-column>
              <el-table-column prop="productName" label="品项名称" min-width="200" align="center"></el-table-column>
              <el-table-column prop="productTypeName" label="分类" min-width="80" align="center"></el-table-column>
              <el-table-column prop="spec" label="详细规格" min-width="100" align="center"></el-table-column>
              <el-table-column prop="saleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="saleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="orderNo" label="订单量" min-width="100" align="center"></el-table-column>
              <el-table-column prop="avgPrice" label="均价(元/kg)" min-width="100" align="center">
                <template slot-scope="scope">
                  <a style="color: #2d7ae6;" @click="showPop(scope.row)">{{ scope.row.avgPrice}}</a>
                </template>
              </el-table-column>
              <el-table-column label="价格区间" min-width="100" align="center">
                <template v-slot="{row}">
                  {{row.minPrice+'-'+row.maxPrice}}
                </template>
              </el-table-column>
              <el-table-column prop="minPriceConunt" label="低价单" min-width="90" align="center"></el-table-column>
              <el-table-column prop="maxPriceConunt" label="高价单" min-width="90" align="center"></el-table-column>
            </el-table>
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import {
    getBelong
  } from '@/api/Client/index';
  import {
    getPriceChart
  } from '@/api/Board/PriceBoard';
  import {
    productTopType,
    producTtype
  } from '@/api/Board/StockBoard';
  import {
    getTimeConfig,
    getProductAnalysis,
    exportList,
  } from '@/api/Analyse/GoodsSale';
  import {
    getAreaTree
  } from '@/api/system/area';
  import Screenfull from '@/components/Screenfull';
  import {
    getProductOptions,
    getCustomerOptions
  } from '@/api/delivery/salesDelivery/index';
  import {
    deepClone
  } from '@/utils';
  import PriceChart from '../../Board/components/PriceChart';
  const queryParamsCommon = {
    startDate: '',
    endDate: '',
    customerType: '',
    factory: '',
    location: '',
    pageNo: 1,
    pageSize: 20,
    departmentName: '',
    customerName: '',
    productCode: '',
    productName: '',
    locationProvinceCode: null,
    locationCityCode: null,
    productBigType: '',
    productType: '',
    type: 1,
    dateRange: [],
    orderMonth: [],
    saleUserId: ''
  };

  export default {
    name: 'GoodsSale',
    components: {
      Screenfull,
      PriceChart
    },

    data() {
      return {
        belongListOp: [], //归属销售下拉框
        belongList: [], //归属销售下拉框
        customerNameList: [],
        priceData: {
          days: [],
          outBounds: [],
          prices: [],
        },
        priceDateOption: 'seven_day',
        dateOptions: [{
            value: 'seven_day',
            label: '7天',
          },
          {
            value: 'fifteen_day',
            label: '15天',
          },
          {
            value: 'thirty_day',
            label: '30天',
          },
        ],
        activeRow: {},
        chartLoading: false,
        priceVisible: false,
        searchProductTopTypeList: [], //品项大类
        exportLoading: false,
        queryParams: deepClone(queryParamsCommon),
        productCategoryList: this.getDictDatas('category_classify'), //品项
        productCodeList: [], //品类
        clientAreaOptions: this.getDictDatas('hfywbm'), //业务部门
        factoriesOptions: this.getDictDatas('factory'), //归属工厂
        tableData: [],
        tableLoading: false,
        isFullScreen: true, //全屏
        activeTabName: "1",
        clientTypes: [], //客户分类
        cityOption: [], //所在地区
      };
    },

    watch: {
      'queryParams.departmentName': {
        handler(newVal, oldVal) {
          this.belongList = [];
          this.queryParams.saleUserId = '';
          if (newVal) {
            this.belongListOp.forEach((res) => {
              if (res.deptId == newVal) {
                this.belongList.push(res);
              }
            });
          } else {
            this.belongList = this.belongListOp;
          }
        },
      },
      activeTabName: {
        handler(newVal, oldVal) {
          if (newVal != '1' && this.queryParams.pageSize < 20) {
            this.queryParams.pageNo = 1
            this.queryParams.pageSize = 20
            this.$nextTick(() => {
              this.handleQuery()
            })

          }
        },
        deep: true,
      },
      'queryParams.productBigType'(newVal, oldVal) {
        if (newVal === '') {
          this.productCategoryList = [];
        } else {
          this.queryParams.productType = '';
          this.getSearchProducTtype();
        }
      },
      '$route': { // $route可以用引号，也可以不用引号
        async handler(to, from) {
          if (to.query && to.query.productType) {
            this.queryParams.productType = to.query.productType
          }
          this.queryParams.startDate = this.getBeforeDate(30);
          this.queryParams.endDate = this.getBeforeDate(0);
          this.queryParams.dateRange = [this.queryParams.startDate, this.queryParams.endDate];
          this.handleQuery()
        },
        deep: true, // 深度观察监听
        immediate: true, // 第一次初始化渲染就可以监听到
      },
    },
    created() {
      this.getBelong();
      //获取商品大类
      this.getProductTopType();
      //客户分类
      this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
      //所在地区
      getAreaTree().then((res) => {
        this.cityOption = res.data;
        this.cityOption.forEach((item) => {
          item.label = item.name;
          item.value = item.id;
          item.children.forEach((i) => {
            i.label = i.name;
            i.value = i.id;
            delete i.children;
          });
        });
      });
    },
    methods: {
      //获取时间
      getBeforeDate(n) {
        var n = n;
        var d = new Date();
        var year = d.getFullYear();
        var mon = d.getMonth() + 1;
        var day = d.getDate();
        if (day <= n) {
          if (mon > 1) {
            mon = mon - 1;
          } else {
            year = year - 1;
            mon = 12;
          }
        }
        d.setDate(d.getDate() - n);
        year = d.getFullYear();
        mon = d.getMonth() + 1;
        day = d.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //获取所有业务员
      async getBelong() {
        const res = await getBelong({
          isSale: true
        });
        this.belongListOp = res.data;
        if (this.queryParams.departmentName) {
          this.belongListOp.forEach((res) => {
            if (res.deptId == this.queryParams.departmentName) {
              this.belongList.push(res);
            }
          });
        } else {
          this.belongList = this.belongListOp;
        }
      },
      onCustomerTypeChange(e) {
        this.queryParams.customerName = '';
        getCustomerOptions({
          type: e,
        }).then((res) => {
          this.customerNameList = res.data;
        });
      },
      dateOptionChange() {
        this.getPriceChart();
      },
      calLatelyDate(type) {
        let today = this.$dayjs();
        switch (type) {
          case 'seven_day':
            let sevenDaysAgo = today.subtract(6, 'day'); // 因为包含今天，所以是减去6天
            let sevenDaysStart = sevenDaysAgo.startOf('day').format('YYYY-MM-DD');
            let sevenDaysEnd = today.endOf('day').format('YYYY-MM-DD');
            return {
              fromDate: sevenDaysStart,
                toDate: sevenDaysEnd,
            };
          case 'fifteen_day':
            let fifteenDaysAgo = today.subtract(14, 'day');
            let fifteenDaysStart = fifteenDaysAgo
              .startOf('day')
              .format('YYYY-MM-DD');
            let fifteenDaysEnd = today.endOf('day').format('YYYY-MM-DD');
            return {
              fromDate: fifteenDaysStart,
                toDate: fifteenDaysEnd,
            };
          case 'thirty_day':
            let thirtyDaysAgo = today.subtract(29, 'day');
            let thirtyDaysStart = thirtyDaysAgo
              .startOf('day')
              .format('YYYY-MM-DD');
            let thirtyDaysEnd = today.endOf('day').format('YYYY-MM-DD');
            return {
              fromDate: thirtyDaysStart,
                toDate: thirtyDaysEnd,
            };
        }
      },
      //获取价格数据
      async getPriceChart() {
        this.chartLoading = true;
        const {
          fromDate,
          toDate
        } = this.calLatelyDate(this.priceDateOption);
        let data = {
          dateSpan: this.priceDateOption,
          priceType: 'market_price_type',
          productId: this.activeRow.productId,
          fromDate,
          toDate,
        };
        const res = await getPriceChart(data);
        this.priceData = res.data;
        this.chartLoading = false;
      },
      //展示趋势图
      showPop(row) {
        this.activeRow = row;
        this.priceVisible = true
      },
      // 获取搜索品项分类
      getSearchProducTtype() {
        producTtype({
          value: this.queryParams.productBigType
        }).then(
          (res) => {
            this.productCategoryList = res.data;
          }
        );
      },
      //获取商品大类
      getProductTopType() {
        productTopType().then((res) => {
          this.searchProductTopTypeList = res.data;
        });
      },
      //导出列表数据
      handleExport() {
        this.exportLoading = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '产品销售排名.xls');
            this.exportLoading = false;
          })
          .catch(() => {
            this.exportLoading = false;
          });
      },
      //选择订单日期
      changeDate() {
        this.queryParams.startDate = this.queryParams.dateRange[0];
        this.queryParams.endDate = this.queryParams.dateRange[1];
      },
      //选择所在地区
      onCityChange(e) {
        this.queryParams.locationProvinceCode = e[0];
        this.queryParams.locationCityCode = e[1];
      },
      //选择品项
      onProductCategoryChange(e) {
        // this.queryParams.productCode = '';
        // getProductOptions({
        //   type: e,
        // }).then((res) => {
        //   this.productCodeList = res.data;
        // });
      },
      //查询列表数据
      handleQuery() {
        this.queryParams.pageNo = 1;
        this.tableLoading = true
        getProductAnalysis(
          this.queryParams
        ).then((res) => {
          this.tableLoading = false
          this.tableData = res.data;
          // this.queryParams.total = res.data.total;
        });
      },
      //重置
      async handleReset() {
        this.queryParams = deepClone(queryParamsCommon);
        this.queryParams.pageNo = 1;
        this.queryParams.startDate = this.getBeforeDate(30);
        this.queryParams.endDate = this.getBeforeDate(0);
        this.queryParams.dateRange = [this.queryParams.startDate, this.queryParams.endDate];
        this.handleQuery();
      },
      //全屏
      handleScreen() {
        this.$refs.screenIcon.click()
      },
      handleScreenToggle(val) {
        this.isFullScreen = val
        // console.log(val, 123);
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .list_wrap {
    margin-top: 0 !important;
  }

  .component_title {
    padding: 10px 30px 0 20px;
  }

  ::v-deep .el-collapse-item__content {
    padding-bottom: 0 !important;
  }

  .cursor-p {
    color: #1890ff;
    cursor: pointer;
  }
</style>
