<template>
  <div class="dashboard-editor-container">
    <!-- 销售统计-->
    <el-row class="row-btm">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <!-- <span>销售统计</span> -->
          <div>
            <el-form ref="weekInQuery" size="small" :inline="true" label-width="60px">
              <el-form-item label="部门" prop="area">
                <el-select v-model="queryParams.area" placeholder="请选择部门" style="width: 140px" filterable clearable>
                  <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item>
                <el-date-picker :clearable="false" v-model="queryParams.dateRange" type="monthrange" range-separator="至"
                  start-placeholder="开始月份" end-placeholder="结束月份" @change="changeDate" value-format="yyyy-MM">
                </el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button icon="el-icon-search" @click="getList()">查询</el-button>
                <el-button icon="el-icon-download" :loading="exportLoading" @click="handleExport">导出</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
        <!-- 销售统计饼图-->
        <el-row :gutter="8" class="row-btm">
          <el-col :span="8">
            <div id="factoryOut" style="height:250px;width:100%;" />
          </el-col>
          <el-col :span="8">
            <div id="sectorOut" style="height:250px;width:100%;" />
          </el-col>
          <el-col :span="8">
            <div id="salesOut" style="height:250px;width:100%;" />
          </el-col>
        </el-row>
        <!-- 销售统计表格-->
        <div>
          <el-table row-key="id" :data="tableData" border max-height="350" v-loading="tableLoading" show-summary>
            <el-table-column prop="orderMonth" label="月份" min-width="100" align="center" fixed></el-table-column>
            <el-table-column prop="deptName" label="部门" min-width="100" align="center" fixed></el-table-column>
            <el-table-column label="汇总" align="center">
              <el-table-column prop="saleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="saleSum" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column label="同比(%)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.yoy }}
                </template>
              </el-table-column>
              <el-table-column label="环比(%)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.mom }}
                </template>
              </el-table-column>
              <el-table-column prop="orderNo" label="订单量" min-width="100" align="center"></el-table-column>
              <el-table-column prop="customerCode" label="成交客户" min-width="100" align="center"></el-table-column>
              <el-table-column prop="newOrder" label="新客单量" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="refundOrder" label="退货单" min-width="100" align="center"></el-table-column>
              <el-table-column prop="refundOrderSum" label="退货金额(万元)" min-width="100" align="center"></el-table-column> -->
              <el-table-column label="均单量(吨/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgSum }}
                </template>
              </el-table-column>
              <el-table-column label="均单价(元/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgPrice }}
                </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="朝阳" align="center">
              <el-table-column prop="cySaleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="cySaleSum" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="cyRefundOrder" label="退货单" min-width="100" align="center"></el-table-column> -->
            </el-table-column>
            <el-table-column label="喀左" align="center">
              <el-table-column prop="kzSaleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="kzSaleSum" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="kzRefundOrder" label="退货单" min-width="100" align="center"></el-table-column> -->
            </el-table-column>
            <el-table-column label="一厂" align="center">
              <el-table-column prop="ycSaleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="ycSaleSum" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="ycRefundOrder" label="退货单" min-width="100" align="center"></el-table-column> -->
            </el-table-column>
            <el-table-column label="二厂" align="center">
              <el-table-column prop="ecSaleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="ecSaleSum" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="ecRefundOrder" label="退货单" min-width="100" align="center"></el-table-column> -->
            </el-table-column>
          </el-table>
        </div>
      </el-card>
    </el-row>
    <!-- 销售出库趋势-->
    <el-row class="row-btm">
      <StockCard />
    </el-row>
  </div>
</template>

<script>
  import * as echarts from 'echarts';
  require('echarts/theme/macarons'); // echarts theme
  import resize from '@/views/dashboard/mixins/resize';
  import {
    getTimeConfig,
    getSalAnalysis,
    getSaleTotal,
    exportList1,
  } from '@/api/Analyse/SaleAnalyse';
  import StockCard from '../card/stockCard/index';
  export default {
    name: 'SaleAnalyse',
    mixins: [resize],
    components: {
      StockCard,
    },
    data() {
      return {
        tableData: [],
        tableLoading: false,
        exportLoading: false, //导出
        queryParams: {
          area: '',
          startDate: '',
          endDate: '',
          dateRange: [],
        },
        factoryData: {},
        sectorData: {},
        salesData: {},
        factoryChart: null,
        sectorChart: null,
        salesChart: null,
        options: this.getDictDatas('hfywbm'), //业务部门
      };
    },
    async mounted() {
      let startDate = this.getBeforeMonth(0);
      let endDate = this.getBeforeMonth(0);
      this.queryParams.dateRange = [startDate, endDate];
      let startYear = startDate.slice(0, 4);
      let startMonth = startDate.slice(5, 7);
      let endYear = endDate.slice(0, 4);
      let endMonth = endDate.slice(5, 7);
      await getTimeConfig({
          year: startYear,
          month: startMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.oneWeek) {
              this.queryParams.startDate = resData.oneWeek.slice(0, 10)
            } else {
              this.queryParams.startDate = ''
            }
          } else {
            this.queryParams.startDate = ''
          }
        })
      await getTimeConfig({
          year: endYear,
          month: endMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.fourWeek) {
              this.queryParams.endDate = resData.fourWeek.slice(11, 21)
            } else {
              this.queryParams.endDate = ''
            }
          } else {
            this.queryParams.endDate = ''
          }
        })
      this.getList()
    },
    beforeDestroy() {
      if (this.factoryChart) {
        this.factoryChart.dispose();
        this.factoryChart = null;
      }
      if (this.sectorChart) {
        this.sectorChart.dispose();
        this.sectorChart = null;
      }
      if (this.salesChart) {
        this.salesChart.dispose();
        this.salesChart = null;
      }
    },
    methods: {
      //配置月份
      changeDate() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams.startDate = ''
              }
            } else {
              this.queryParams.startDate = ''
            }
          })
        getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.endDate = ''
            }
          })
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //获取列表接口
      getList(flag) {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法统计数据`
          });
          return;
        }
        this.tableLoading = true
        getSalAnalysis(
          this.queryParams
        ).then((res) => {
          this.tableLoading = false
          this.tableData = res.data;
        });
        if (!flag) {
          getSaleTotal(
            this.queryParams
          ).then((res) => {
            this.factoryData = res.data.list1;
            this.sectorData = res.data.list2;
            this.salesData = res.data.list3;
            this.$nextTick(() => {
              this.factoryInitChart();
              this.sectorInitChart();
              this.salesInitChart();
            });
          });
        }
      },
      //导出接口
      handleExport() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList1(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '销售分析总览.xls');
            this.exportLoading = false;
          })
          .catch(() => {
            this.exportLoading = false;
          });
      },
      //工厂出库占比
      factoryInitChart() {
        this.factoryChart = echarts.init(document.getElementById('factoryOut'), 'macarons');
        this.factoryChart.setOption({
          title: {
            text: '工厂出库占比',
            left: 'center',
            bottom: 0,
            textStyle: {
              color: '#000',
              fontSize: 15
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)',
          },
          legend: {
            orient: 'vertical',
            right: 0,
            top: 'center',
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75'],
          series: [{
            name: '工厂出库占比',
            type: 'pie',
            radius: ['25%', '55%'],
            center: ['40%', '50%'],
            label: {
              //文字部分 显示内容为{b}：{c}可以换自己像显示的
              formatter: '{b}\n{c}',
              //折线图文字颜色
              color: "#000000",
            },
            // 折线图长度
            labelLine: { // 指示线的配置
              show: true, // 显示指示线
              length: 10, // 指示线的长度
              length2: 10, // 指示线的第二段长度
              smooth: 0.2, // 指示线平滑度
            },
            data: this.factoryData,
          }, ],
        });
      },
      //部门销量占比
      sectorInitChart() {
        this.sectorChart = echarts.init(document.getElementById('sectorOut'), 'macarons');
        this.sectorChart.setOption({
          title: {
            text: '部门销量占比',
            left: 'center',
            bottom: 0,
            textStyle: {
              color: '#000',
              fontSize: 15
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)',
          },
          legend: {
            orient: 'vertical',
            right: 0,
            top: 'center',
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75', '#fc8452'],
          series: [{
            name: '部门销量占比',
            type: 'pie',
            radius: ['25%', '55%'],
            center: ['40%', '50%'],
            label: {
              //文字部分 显示内容为{b}：{c}可以换自己像显示的
              formatter: '{b}\n{c}',
              //折线图文字颜色
              color: "#000000",
            },
            // 折线图长度
            labelLine: { // 指示线的配置
              show: true, // 显示指示线
              length: 10, // 指示线的长度
              length2: 10, // 指示线的第二段长度
              smooth: 0.2, // 指示线平滑度
            },
            data: this.sectorData,
          }, ],
        });
      },
      //部门销售额占比
      salesInitChart() {
        this.salesChart = echarts.init(document.getElementById('salesOut'), 'macarons');
        this.salesChart.setOption({
          title: {
            text: '部门销售额占比',
            left: 'center',
            bottom: 0,
            textStyle: {
              color: '#000',
              fontSize: 15
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)',
          },
          legend: {
            orient: 'vertical',
            right: 0,
            top: 'center',
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75', '#fc8452'],
          series: [{
            name: '部门销售额占比',
            type: 'pie',
            radius: ['25%', '55%'],
            center: ['40%', '50%'],
            label: {
              //文字部分 显示内容为{b}：{c}可以换自己像显示的
              formatter: '{b}\n{c}',
              //折线图文字颜色
              color: "#000000",
            },
            // 折线图长度
            labelLine: { // 指示线的配置
              show: true, // 显示指示线
              length: 10, // 指示线的长度
              length2: 10, // 指示线的第二段长度
              smooth: 0.2, // 指示线平滑度
            },
            data: this.salesData,
          }, ],
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .el-table--medium .el-table__cell {
    padding: 0 !important;
  }

  .dashboard-editor-container {
    padding: 32px;
    background-color: rgb(240, 242, 245);
    position: relative;

    .row-btm {
      margin-bottom: 8px;
    }
  }
</style>
