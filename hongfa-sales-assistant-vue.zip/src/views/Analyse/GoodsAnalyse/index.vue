<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col :span="24" :xs="24">
        <el-collapse accordion v-model="activeTabName">
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">产品分析总览
                <div class="title_right_btns" @click.stop="handleScreen">
                  <screenfull id="screenfull" class="right-menu-item hover-effect" ref="screenIcon" @screenToggle="handleScreenToggle" />
                  {{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">
              <!-- 搜索工作栏 -->
              <BaseSearchContainer :column="searchColumn" :params="queryParams" @elDatePickerChange="onDatePickerChange"
                @onSearch="handleQuery" @onReset="handleReset">
                <template #productType>
                  <el-select filterable clearable v-model="queryParams.productType" placeholder="请选择品项大类" style="width: 240px">
                    <el-option v-for="dict in searchProductTopTypeList" :key="dict.value" :label="dict.label" :value="dict.value" />
                  </el-select>
                </template>
                <template #area>
                  <el-select clearable v-model="queryParams.area" placeholder="请选择业务部门" style="width: 240px">
                    <el-option v-for="item in clientAreaOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </template>
                <template #btnsRight>
                  <el-button icon="el-icon-download" :loading="exportLoading" @click="handleExport">导出</el-button>
                </template>
              </BaseSearchContainer>
            </div>
          </el-collapse-item>
        </el-collapse>
        <CrudHeader>
          <template slot="list">
            <el-table row-key="id" :data="tableData" border v-loading="tableLoading" show-summary>
              <el-table-column label="分类" min-width="100" align="center">
                <template v-slot="{row}">
                  <router-link :to="{path: '/analyse/goods-sale', query: {productType:row.productType}}">
                    <span class=" cursor-p">{{row.productTypeName}}</span>
                  </router-link>
                </template>
              </el-table-column>
              <el-table-column label="总计" align="center">
                <el-table-column prop="saleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="数量占比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.saleAmountAccount }}
                  </template>
                </el-table-column>
                <el-table-column label="金额占比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.saleSumAccount }}
                  </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="一厂" align="center">
                <el-table-column prop="saleAmountYc" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSumYc" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="销量占比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.accountYc }}
                  </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="二厂" align="center">
                <el-table-column prop="saleAmountEc" label="销量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSumEc" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="销量占比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.accountEc }}
                  </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="朝阳" align="center">
                <el-table-column prop="saleAmountCy" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSumCy" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="销量占比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.accountCy }}
                  </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="喀左" align="center">
                <el-table-column prop="saleAmountKz" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSumKz" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="销量占比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.accountKz }}
                  </template>
                </el-table-column>
              </el-table-column>
            </el-table>
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import {
    productTopType
  } from '@/api/Board/StockBoard'; //获取商品大类
  import BaseSearchContainer from '@/components/BaseSearchContainer/index'; //搜索工作栏
  import Screenfull from '@/components/Screenfull'; //全屏
  import {
    getTimeConfig,
    getProductAnalysis,
    exportList,
  } from '@/api/Analyse/GoodsAnalyse';
  import {
    deepClone
  } from '@/utils';
  const queryParamsCommon = {
    startDate: '',
    endDate: '',
    productType: '',
    area: '',
    dateRange: [],
  };
  export default {
    name: 'GoodsAnalyse',
    components: {
      Screenfull,
      BaseSearchContainer,
    },
    data() {
      return {
        tableData: [],
        tableLoading: false,
        searchProductTopTypeList: [], //品项大类
        exportLoading: false, //导出
        queryParams: deepClone(queryParamsCommon),
        searchColumn: [{
            label: '品项大类',
            prop: 'productType',
            type: 'select',
            search: true,
          },
          {
            label: '业务部门',
            prop: 'area',
            type: 'select',
            search: true,
            disabled: false,
            dicData: [],
          },
          {
            label: '月份',
            prop: 'dateRange',
            startPlaceholder: '开始月份',
            endPlaceholder: '结束月份',
            format: 'yyyy-MM',
            valueFormat: 'yyyy-MM',
            type: 'monthrange',
            clearable: false,
            search: true,
          },
        ],
        clientAreaOptions: this.getDictDatas('hfywbm'), //业务部门
        exportMaxMonth: 6, //导出月份限制
        isFullScreen: true, //全屏
        activeTabName: "1" //默认展开
      };
    },

    watch: {
      activeTabName: {
        handler(newVal, oldVal) {
          if (newVal != '1' && this.queryParams.pageSize < 20) {
            this.queryParams.pageNo = 1
            this.queryParams.pageSize = 20
            this.$nextTick(() => {
              this.handleQuery();
            })
          }
        },
        deep: true,
      }
    },
    async created() {
      //获取商品大类
      this.getProductTopType();
      let startDate = this.getBeforeMonth(0);
      let endDate = this.getBeforeMonth(0);
      this.queryParams.dateRange = [startDate, endDate];
      let startYear = startDate.slice(0, 4);
      let startMonth = startDate.slice(5, 7);
      let endYear = endDate.slice(0, 4);
      let endMonth = endDate.slice(5, 7);
      await getTimeConfig({
          year: startYear,
          month: startMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.oneWeek) {
              this.queryParams.startDate = resData.oneWeek.slice(0, 10)
            } else {
              this.queryParams.startDate = ''
            }
          } else {
            this.queryParams.startDate = ''
          }
        })
      await getTimeConfig({
          year: endYear,
          month: endMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.fourWeek) {
              this.queryParams.endDate = resData.fourWeek.slice(11, 21)
            } else {
              this.queryParams.endDate = ''
            }
          } else {
            this.queryParams.endDate = ''
          }
        })
      this.handleQuery();
    },
    methods: {
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //获取商品大类
      getProductTopType() {
        productTopType().then((res) => {
          this.searchProductTopTypeList = res.data;
        });
      },
      //导出列表数据
      handleExport() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '产品分析总览.xls');
            this.exportLoading = false;
          })
          .catch(() => {
            this.exportLoading = false;
          });
      },
      onDatePickerChange(e) {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams.startDate = ''
              }
            } else {
              this.queryParams.startDate = ''
            }
          })
        getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.endDate = ''
            }
          })
      },
      handleQuery() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法统计数据`
          });
          return;
        }
        this.queryParams.pageNo = 1;
        this.tableLoading = true
        getProductAnalysis(
          this.queryParams
        ).then((res) => {
          this.tableLoading = false
          this.tableData = res.data;
          // this.queryParams.total = res.data.total;
        });
      },
      //重置
      async handleReset() {
        this.queryParams = deepClone(queryParamsCommon);
        this.queryParams.pageNo = 1;
        let startDate = this.getBeforeMonth(0);
        let endDate = this.getBeforeMonth(0);
        this.queryParams.dateRange = [startDate, endDate];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        await getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams.startDate = ''
              }
            } else {
              this.queryParams.startDate = ''
            }
          })
        await getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.endDate = ''
            }
          })
        this.handleQuery();
      },
      //初始化导出数据
      formatQueryParams(queryParams) {
        let params = deepClone(queryParams);
        if (params._allAmount1 != '' && params._allAmount2 != '') {
          // params.allAmount = `${params._allAmount1},${params._allAmount2}`;
          params.allAmount = `${(params._allAmount1 * 1000).toFixed(3)},${(
          params._allAmount2 * 1000
        ).toFixed(3)}`;
        }
        if (params._allSum1 != '' && params._allSum2 != '') {
          params.allSum = `${params._allSum1},${params._allSum2}`;
        }
        delete params._orderDate;
        delete params._locationCity;
        return params;
      },
      //切换全屏
      handleScreen() {
        this.$refs.screenIcon.click()
      },
      //切换全屏
      handleScreenToggle(val) {
        this.isFullScreen = val
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .list_wrap {
    margin-top: 0 !important;
  }

  .cursor-p {
    color: #1890ff;
  }

  .component_title {
    padding: 10px 30px 0 20px;
  }

  ::v-deep .el-collapse-item__content {
    padding-bottom: 0 !important;
  }
</style>
