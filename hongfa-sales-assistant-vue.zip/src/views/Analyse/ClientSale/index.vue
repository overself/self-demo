<template>
  <div class="app-container Board">
    <el-row :gutter="20">
      <el-col :span="24" :xs="24">
        <el-collapse accordion v-model="activeTabName">
          <el-collapse-item name="1">
            <template slot="title">
              <div class="component_title">客户销售排名
                <div class="title_right_btns" @click.stop="handleScreen">
                  <screenfull id="screenfull" class="right-menu-item hover-effect" ref="screenIcon" @screenToggle="handleScreenToggle" />
                  {{isFullScreen?'全屏':'退出全屏'}}
                </div>
              </div>
            </template>
            <div class="search_wrap">
              <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" label-width="100px">
                <el-form-item label="客户分类" prop="type">
                  <el-select clearable v-model="queryParams.type" placeholder="请选择客户分类" style="width: 240px">
                    <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="业务部门" prop="deptId">
                  <el-select v-model="queryParams.deptId" placeholder="请选择业务部门" style="width: 240px" filterable clearable>
                    <el-option v-for="item in clientAreaOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="归属销售" prop="saleUserId">
                  <el-select v-model="queryParams.saleUserId" placeholder="请选择归属销售" style="width: 240px" filterable clearable>
                    <el-option v-for="item in belongListOp" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="客户名称" prop="customerName">
                  <el-input v-model="queryParams.customerName" placeholder="请输入客户名称" style="width: 240px"></el-input>
                </el-form-item>
                <el-form-item label="品类" prop="productType">
                  <el-select v-model="queryParams.productType" placeholder="请选择品类" clearable filterable style="width: 240px;"
                    @change="onProductCategoryChange">
                    <el-option v-for="item in productCategoryList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                  </el-select>
                </el-form-item>
                <!-- <el-form-item label="品项" prop="productCode">
                  <el-select v-model="queryParams.productCode" placeholder="请选择品项" clearable filterable style="width: 240px;">
                    <el-option v-for="item in productCodeList" :key="item.code" :label="item.name" :value="item.code">
                      <span class="st-name-spec">{{item.name}} / {{item.spec}}</span>
                    </el-option>
                  </el-select>
                </el-form-item> -->
                <el-form-item label="品项名称" prop="productName">
                  <el-input v-model="queryParams.productName" placeholder="请输入品项名称" style="width: 240px"></el-input>
                </el-form-item>
                <el-form-item label="所在地区" prop="location">
                  <el-cascader clearable filterable style="width: 240px" :placeholder="`请选择所在地区`" v-model="queryParams.location"
                    :options="cityOption" @change="onCityChange">
                  </el-cascader>
                </el-form-item>
                <el-form-item label="日期" prop="date">
                  <el-date-picker :clearable="false" value-format="yyyy-MM-dd" v-model="queryParams.dateRange" type="daterange"
                    placeholder="选择日期" style="width: 240px" @change="changeDate">
                  </el-date-picker>
                </el-form-item>
                <el-form-item style="margin-left: 100px;">
                  <el-button icon="el-icon-search" @click="handleQuery()">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="handleReset">重置</el-button>
                  <el-button icon="el-icon-download" :loading="exportLoading" @click="handleExport">导出</el-button>
                </el-form-item>
              </el-form>
              <el-form size="small" :inline="true" label-width="100px">
                <el-form-item style="margin-left: 100px;">
                  <el-radio-group v-model="queryParams.orderType">
                    <el-radio :label="1">按销量</el-radio>
                    <el-radio :label="2">按销售额</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-form>
            </div>
          </el-collapse-item>
        </el-collapse>
        <CrudHeader>
          <template slot="list">
            <el-table row-key="id" :data="tableData" border max-height="500" v-loading="tableLoading">
              <el-table-column type="index" width="50" label="排名" align="center" fixed></el-table-column>
              <el-table-column prop="customerCode" label="客户编码" min-width="120" align="center"></el-table-column>
              <el-table-column prop="customerName" label="客户名称" min-width="100" align="center">
                <!-- <template v-slot="{row}">
                  <router-link :to="{path: '/delivery/summary', query: {customerName:row.customerName}}">
                    <span class=" cursor-p">{{row.customerName}}</span>
                  </router-link>
                </template> -->
                <template v-slot="{row}">
                  <router-link :to="'/client-control/info/' + row.customerId">
                    <span class=" cursor-p">{{row.customerName}}</span>
                  </router-link>
                </template>
                <!-- <template slot-scope="scope">
                  <router-link
                    :to="'/client-control/info/' + scope.row.id"
                    class="router_btn"
                  >
                    <span class="cursor-p">{{scope.row.customerName}}</span>

                  </router-link>

                </template> -->
              </el-table-column>
              <el-table-column prop="salePerson" label="归属销售" min-width="100" align="center"></el-table-column>
              <el-table-column prop="saleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="saleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="orderNo" label="订单量" min-width="100" align="center"></el-table-column>
              <el-table-column prop="avgPrice" label="均价(元/kg)" min-width="100" align="center"></el-table-column>
              <el-table-column label="价格区间" min-width="100" align="center">
                <template v-slot="{row}">
                  {{(row.minPrice?row.minPrice:'')+'-'+(row.maxPrice?row.maxPrice:'')}}
                </template>
              </el-table-column>
              <el-table-column prop="maxPriceConunt" label="高价单" min-width="100" align="center"></el-table-column>
              <el-table-column prop="minPriceConunt" label="低价单" min-width="100" align="center"></el-table-column>
              <el-table-column prop="typeName" label="客户分类" min-width="100" align="center"></el-table-column>
              <el-table-column prop="location" label="区域" min-width="160" align="center"></el-table-column>
              <el-table-column prop="deptName" label="业务部门" min-width="100" align="center"></el-table-column>
              <el-table-column prop="sendNum" label="送货客户数" min-width="100" align="center"></el-table-column>
              <el-table-column prop="lastSale" label="最近交易时间" min-width="100" align="center"></el-table-column>
              <el-table-column prop="beforeSale" label="上次交易时间" min-width="100" align="center"></el-table-column>
            </el-table>
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="queryParams.current"
              :page-sizes="[10, 20, 50, 100]" :page-size="queryParams.size" layout="total, sizes, prev, pager, next, jumper"
              :total="queryParams.total">
            </el-pagination>
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import {
    getAreaTree
  } from '@/api/system/area';
  import Screenfull from '@/components/Screenfull';
  import {
    getTimeConfig,
    getCustomerAnalysis,
    exportList,
  } from '@/api/Analyse/ClientSale';
  import {
    getProductOptions,
  } from '@/api/delivery/salesDelivery/index';
  import {
    deepClone
  } from '@/utils';
  import {
    getBelong
  } from '@/api/Client/index';
  const queryParamsCommon = {
    customerName: '',
    productCode: '',
    productName: '',
    startDate: '',
    endDate: '',
    productType: '',
    deptId: '',
    location: '',
    type: '',
    area: '',
    orderMonth: [],
    dateRange: [],
    saleUserId: '',
    orderType: 1,
    current: 1,
    size: 10,
    total: 0,
  };

  export default {
    name: 'ClientSale',
    components: {
      Screenfull,
    },
    data() {
      return {
        exportLoading: false,
        queryParams: deepClone(queryParamsCommon),
        productCategoryList: this.getDictDatas('category_classify'), //品项
        productCodeList: [], //品类
        belongListAll: [],
        belongListOp: [], //归属销售
        clientAreaOptions: this.getDictDatas('hfywbm'), //业务部门
        tableData: [],
        tableLoading: false,
        isFullScreen: true, //全屏
        activeTabName: "1",
        clientTypes: [], //客户分类
        cityOption: [], //所在地区
      };
    },

    watch: {
      'queryParams.deptId'(newVal, oldVal) {
        this.belongListOp = [];
        this.queryParams.saleUserId = '';
        if (newVal) {
          this.belongListAll.forEach((res) => {
            if (res.deptId == newVal) {
              this.belongListOp.push(res);
            }
          });
        } else {
          this.belongListOp = this.belongListAll
        }
      },
      activeTabName: {
        handler(newVal, oldVal) {
          if (newVal != '1' && this.queryParams.pageSize < 20) {
            this.queryParams.pageNo = 1
            this.queryParams.pageSize = 20
            this.$nextTick(() => {
              this.handleQuery()
            })
          }
        },
        deep: true,
      }
    },
    async created() {
      //客户分类
      this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
      //归属销售
      this.getBelong();
      //所在地区
      getAreaTree().then((res) => {
        this.cityOption = res.data;
        this.cityOption.forEach((item) => {
          item.label = item.name;
          item.value = item.id;
          item.children.forEach((i) => {
            i.label = i.name;
            i.value = i.id;
            delete i.children;
          });
        });
      });
      this.queryParams.startDate = this.getBeforeDate(30);
      this.queryParams.endDate = this.getBeforeDate(0);
      this.queryParams.dateRange = [this.queryParams.startDate, this.queryParams.endDate];
      this.handleQuery()
    },
    methods: {
      //获取时间
      getBeforeDate(n) {
        var n = n;
        var d = new Date();
        var year = d.getFullYear();
        var mon = d.getMonth() + 1;
        var day = d.getDate();
        if (day <= n) {
          if (mon > 1) {
            mon = mon - 1;
          } else {
            year = year - 1;
            mon = 12;
          }
        }
        d.setDate(d.getDate() - n);
        year = d.getFullYear();
        mon = d.getMonth() + 1;
        day = d.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //切换分页和页码
      handleSizeChange(val) {
        this.queryParams.size = val
        this.handleQuery();
      },
      handleCurrentChange(val) {
        this.queryParams.current = val
        this.handleQuery(true);
      },
      //导出列表数据
      handleExport() {
        this.exportLoading = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '客户销售排名.xls');
            this.exportLoading = false;
          })
          .catch(() => {
            this.exportLoading = false;
          });
      },
      //选择订单日期
      changeDate() {
        this.queryParams.startDate = this.queryParams.dateRange[0];
        this.queryParams.endDate = this.queryParams.dateRange[1];
      },
      //选择所在地区
      onCityChange(e) {
        this.queryParams.locationProvinceCode = e[0];
        this.queryParams.locationCityCode = e[1];
      },
      //选择品项
      onProductCategoryChange(e) {
        this.queryParams.productCode = '';
        getProductOptions({
          type: e,
        }).then((res) => {
          this.productCodeList = res.data;
        });
      },
      //查询列表数据
      handleQuery(flag) {
        if (!flag) {
          this.queryParams.current = 1
        }
        this.tableLoading = true
        getCustomerAnalysis(
          this.queryParams
        ).then((res) => {
          this.tableLoading = false
          this.tableData = res.data.records;
          this.queryParams.total = res.data.total;
        });
      },
      //重置
      async handleReset() {
        this.queryParams = deepClone(queryParamsCommon);
        this.queryParams.pageNo = 1;
        this.queryParams.startDate = this.getBeforeDate(30);
        this.queryParams.endDate = this.getBeforeDate(0);
        this.queryParams.dateRange = [this.queryParams.startDate, this.queryParams.endDate];
        this.handleQuery();
      },
      //归属销售
      async getBelong() {
        const res = await getBelong({
          isSale: true
        });
        this.belongListAll = res.data;
      },
      //全屏
      handleScreen() {
        this.$refs.screenIcon.click()
      },
      handleScreenToggle(val) {
        this.isFullScreen = val
        // console.log(val, 123);
      },
    },
  };
</script>

<style lang="scss" scoped>
  .cursor-p {
    color: #1890ff;
    cursor: pointer;
  }

  ::v-deep .list_wrap {
    margin-top: 0 !important;
  }

  .component_title {
    padding: 10px 30px 0 20px;
  }

  ::v-deep .el-collapse-item__content {
    padding-bottom: 0 !important;
  }
</style>
