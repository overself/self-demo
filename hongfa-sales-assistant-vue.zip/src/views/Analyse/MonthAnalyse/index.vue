<template>
  <div class="dashboard-editor-container">
    <!-- 销售汇总-->
    <el-row class="row-btm">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>销售汇总</span>
          <div>
            <el-form size="small" :inline="true" label-width="100px">
              <el-form-item>
                <el-date-picker @change="changeDate" value-format="yyyy-MM" v-model="allValue" type="month" placeholder="选择月"
                  :clearable="false"></el-date-picker>
                </el-date-picker>
              </el-form-item>
            </el-form>
          </div>
        </div>
        <!-- 销售统计表格-->
        <div>
          <el-table row-key="id" :data="allTableData" border v-loading="allTableLoading" show-summary>
            <el-table-column prop="deptName" label="部门" fixed min-width="100" align="center"></el-table-column>
            <el-table-column label="汇总" align="center">
              <el-table-column prop="saleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column label="同比(%)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.yoy }}
                </template>
              </el-table-column>
              <el-table-column label="环比(%)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.mom }}
                </template>
              </el-table-column>
              <el-table-column prop="saleSum" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="orderNo" label="订单量" min-width="100" align="center"></el-table-column>
              <el-table-column prop="customerCode" label="成交客户" min-width="100" align="center"></el-table-column>
              <el-table-column prop="newOrder" label="新客单" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="refundOrder" label="退货单" min-width="100" align="center"></el-table-column>
              <el-table-column prop="refundSum" label="退货金额(万元)" min-width="100" align="center"></el-table-column> -->
              <el-table-column label="均单量(吨/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgSum }}
                </template>
              </el-table-column>
              <el-table-column label="均单价(元/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgPrice }}
                </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="朝阳" align="center">
              <el-table-column prop="saleVolumeCy" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="totalAmountCy" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="returnOrderCy" label="退货单" min-width="100" align="center"></el-table-column> -->
            </el-table-column>
            <el-table-column label="喀左" align="center">
              <el-table-column prop="saleVolumKz" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="totalAmountKz" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="returnOrderKz" label="退货单" min-width="100" align="center"></el-table-column> -->
            </el-table-column>
            <el-table-column label="一厂" align="center">
              <el-table-column prop="saleVolumeYc" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="totalAmountYc" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="returnOrderYc" label="退货单" min-width="100" align="center"></el-table-column> -->
            </el-table-column>
            <el-table-column label="二厂" align="center">
              <el-table-column prop="saleVolumeEc" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="totalAmountEc" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <!-- <el-table-column prop="returnOrderEc" label="退货单" min-width="100" align="center"></el-table-column> -->
            </el-table-column>
          </el-table>
        </div>
        <!-- 销售统计饼图-->
        <el-row :gutter="8" class="row-btm">
          <el-col :span="8">
            <div id="factoryOut" style="height:250px;width:100%;" />
          </el-col>
          <el-col :span="8">
            <div id="sectorOut" style="height:250px;width:100%;" />
          </el-col>
          <el-col :span="8">
            <div id="salesOut" style="height:250px;width:100%;" />
          </el-col>
        </el-row>
      </el-card>
    </el-row>
    <el-row class="row-btm">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane label="业务员销售情况" name="1">
          <div class="clearfix">
            <div>
              <el-form ref="weekInQuery1" size="small" :inline="true" label-width="60px">
                <el-form-item label="部门" prop="area">
                  <el-select v-model="queryParams1.area" placeholder="请选择部门" style="width: 140px" filterable clearable>
                    <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="品类" prop="productType">
                  <el-select v-model="queryParams1.productType" placeholder="请选择品类" clearable filterable style="width: 140px;">
                    <el-option v-for="item in productCategoryList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="品项" prop="productCode">
                  <el-select filterable clearable allow-create v-model="queryParams1.productCode" placeholder="请选择品项" style="width: 240px">
                    <el-option v-for="item in searchproductCodeList1" :key="item.code" :label="item.name" :value="item.code">
                      <span class="st-name-spec">{{item.name}} / {{item.spec}}</span>
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="月份" prop="date">
                  <el-date-picker @change="changeDate1" value-format="yyyy-MM" v-model="queryParams1.date" type="month" placeholder="选择月"
                    :clearable="false" style="width: 140px"></el-date-picker>
                  </el-date-picker>
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="getList1()">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="resetQuery1">重置</el-button>
                  <el-button icon="el-icon-download" :loading="exportLoading1" @click="handleExport1">导出</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
          <!-- 销售统计表格-->
          <div>
            <el-table row-key="id" :data="tableData1" border max-height="330" v-loading="tableLoading1" show-summary>
              <el-table-column type="index" width="50" label="排序" fixed align="center"></el-table-column>
              <el-table-column label="姓名" fixed min-width="100" align="center">
                <template v-slot="{row}">
                  <router-link :to="{path: '/delivery/summary', query: {salePerson:row.nickName}}">
                    <span class=" cursor-p">{{row.nickName}}</span>
                  </router-link>
                </template>
              </el-table-column>
              <el-table-column label="汇总" align="center">
                <el-table-column prop="saleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column label="同比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.yoy }}
                  </template>
                </el-table-column>
                <el-table-column label="环比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.mom }}
                  </template>
                </el-table-column>
                <el-table-column prop="saleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="orderNo" label="订单量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="customerCode" label="成交客户" min-width="100" align="center"></el-table-column>
                <el-table-column prop="newOrder" label="新客单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="maxPriceConunt" label="高价单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="minPriceConunt" label="低价单" min-width="100" align="center"></el-table-column>
                <!-- <el-table-column prop="refundOrder" label="退货单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="refundAmount" label="退货金额" min-width="100" align="center"></el-table-column> -->
                <el-table-column label="均单量(吨/单)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.avgSum }}
                  </template>
                </el-table-column>
                <el-table-column label="均单价(元/单)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.avgPrice }}
                  </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="朝阳" align="center">
                <el-table-column prop="cySaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="cySaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <!--   <el-table-column prop="cyRefundOrder" label="退货单" min-width="100" align="center"></el-table-column> -->
              </el-table-column>
              <el-table-column label="喀左" align="center">
                <el-table-column prop="kzSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="kzSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <!-- <el-table-column prop="kzRefundOrder" label="退货单" min-width="100" align="center"></el-table-column> -->
              </el-table-column>
              <el-table-column label="一厂" align="center">
                <el-table-column prop="ycSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="ycSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <!-- <el-table-column prop="ycRefundOrder" label="退货单" min-width="100" align="center"></el-table-column> -->
              </el-table-column>
              <el-table-column label="二厂" align="center">
                <el-table-column prop="ecSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="ecSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <!-- <el-table-column prop="ecRefundOrder" label="退货单" min-width="100" align="center"></el-table-column> -->
              </el-table-column>
            </el-table>
          </div>
        </el-tab-pane>
        <el-tab-pane label="产品销售情况" name="2">
          <div class="clearfix">
            <div>
              <el-form ref="weekInQuery2" size="small" :inline="true" label-width="60px">
                <el-form-item label="部门" prop="area">
                  <el-select v-model="queryParams2.area" placeholder="请选择部门" style="width: 120px" filterable clearable>
                    <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="业务员" prop="saleUserId">
                  <el-select v-model="queryParams2.saleUserId" placeholder="请选择业务员" style="width: 120px" filterable clearable>
                    <el-option v-for="item in belongList" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="客户" prop="customerCode">
                  <el-select v-model="queryParams2.customerCode" placeholder="请选择客户" style="width: 140px" filterable clearable>
                    <el-option v-for="item in customerListOp" :key="item.code" :value="item.code" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
                <!-- <el-form-item label="工厂" prop="factory">
                  <el-select v-model="queryParams2.factory" placeholder="请选择工厂" clearable filterable style="width: 140px;">
                    <el-option v-for="item in options1" :key="item.value" :label="item.label" :value="item.value"></el-option>
                  </el-select>
                </el-form-item> -->
                <el-form-item label="品类" prop="productType">
                  <el-select v-model="queryParams2.productType" placeholder="请选择品类" clearable filterable style="width: 120px;">
                    <el-option v-for="item in productCategoryList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="月份" prop="date">
                  <el-date-picker @change="changeDate2" value-format="yyyy-MM" v-model="queryParams2.date" type="month" placeholder="选择月"
                    :clearable="false" style="width: 140px"></el-date-picker>
                  </el-date-picker>
                </el-form-item>
                <el-form-item>
                  <el-radio-group v-model="queryParams2.isSaleOrder">
                    <el-radio :label="1">销售单</el-radio>
                    <el-radio :label="2">退货单</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="getList2()">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="resetQuery2">重置</el-button>
                  <el-button icon="el-icon-download" :loading="exportLoading2" @click="handleExport2">导出</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
          <!-- 销售统计表格-->
          <div>
            <el-table row-key="id" :data="tableData2" border max-height="330" v-loading="tableLoading2" show-summary>
              <el-table-column type="index" width="50" label="排序" fixed align="center"></el-table-column>
              <el-table-column label="产品" fixed min-width="200" align="center">
                <template v-slot="{row}">
                  <router-link :to="{path: '/delivery/summary', query: {productName:row.productName}}">
                    <span class=" cursor-p">{{row.productName}}</span>
                  </router-link>
                </template>
              </el-table-column>
              <el-table-column prop="productTypeName" label="品类" min-width="100" align="center"></el-table-column>
              <el-table-column prop="saleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column label="同比(%)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.yoy }}
                </template>
              </el-table-column>
              <el-table-column label="环比(%)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.mom }}
                </template>
              </el-table-column>
              <el-table-column prop="saleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column label="均价(元/kg)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgPrice }}
                </template>
              </el-table-column>
              <el-table-column label="售价区间" min-width="100" align="center">
                <template v-slot="{row}">
                  {{(row.minPriceTax?row.minPriceTax:'')+'-'+(row.maxPriceTax?row.maxPriceTax:'')}}
                </template>
              </el-table-column>
              <el-table-column label="朝阳" align="center">
                <el-table-column prop="yqSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="yqSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="均价(元/kg)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.yqAvgPrice }}
                  </template>
                </el-table-column>
                <el-table-column label="售价区间" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{(row.yqMinPriceTax?row.yqMinPriceTax:'')+'-'+(row.yqMaxPriceTax?row.yqMaxPriceTax:'')}}
                  </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="喀左" align="center">
                <el-table-column prop="eqSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="eqSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="均价(元/kg)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.eqAvgPrice }}
                  </template>
                </el-table-column>
                <el-table-column label="售价区间" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{(row.eqMinPriceTax?row.eqMinPriceTax:'')+'-'+(row.eqMaxPriceTax?row.eqMaxPriceTax:'')}}
                  </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="一厂" align="center">
                <el-table-column prop="sqSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="sqSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="均价(元/kg)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.sqAvgPrice }}
                  </template>
                </el-table-column>
                <el-table-column label="售价区间" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{(row.sqMinPriceTax?row.sqMinPriceTax:'')+'-'+(row.sqMaxPriceTax?row.sqMaxPriceTax:'')}}
                  </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="二厂" align="center">
                <el-table-column prop="jtSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="jtSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="均价(元/kg)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.jtAvgPrice }}
                  </template>
                </el-table-column>
                <el-table-column label="售价区间" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{(row.jtMinPriceTax?row.jtMinPriceTax:'')+'-'+(row.jtMaxPriceTax?row.jtMaxPriceTax:'')}}
                  </template>
                </el-table-column>
              </el-table-column>
              <!-- <el-table-column label="其他" align="center">
                <el-table-column prop="qtSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="qtSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="均价" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.qtAvgPrice }}
                  </template>
                </el-table-column>
                <el-table-column label="售价区间" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{(row.qtMinPriceTax?row.qtMinPriceTax:'')+'-'+(row.qtMaxPriceTax?row.qtMaxPriceTax:'')}}
                  </template>
                </el-table-column>
              </el-table-column> -->
            </el-table>
          </div>
        </el-tab-pane>
        <el-tab-pane label="客户销售情况" name="3">
          <div class="clearfix">
            <div>
              <el-form ref="weekInQuery3" size="small" :inline="true" label-width="60px">
                <el-form-item label="部门" prop="area">
                  <el-select v-model="queryParams3.area" placeholder="请选择部门" style="width: 140px" filterable clearable>
                    <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="品类" prop="productType">
                  <el-select v-model="queryParams3.productType" placeholder="请选择品类" clearable filterable style="width: 140px;">
                    <el-option v-for="item in productCategoryList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="品项" prop="productCode">
                  <el-select filterable clearable allow-create v-model="queryParams3.productCode" placeholder="请选择" style="width: 240px">
                    <el-option v-for="item in searchproductCodeList3" :key="item.code" :label="item.name" :value="item.code">
                      <span class="st-name-spec">{{item.name}} / {{item.spec}}</span>
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="月份" prop="date">
                  <el-date-picker @change="changeDate3" value-format="yyyy-MM" v-model="queryParams3.date" type="month" placeholder="选择月"
                    :clearable="false" style="width: 140px"></el-date-picker>
                  </el-date-picker>
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="getList3()">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="resetQuery3">重置</el-button>
                  <el-button icon="el-icon-download" :loading="exportLoading3" @click="handleExport3">导出</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
          <!-- 销售统计表格-->
          <div>
            <el-table row-key="id" :data="tableData3" border max-height="330" v-loading="tableLoading3" show-summary>
              <el-table-column type="index" width="50" label="排序" fixed align="center"></el-table-column>
              <el-table-column label="客户" min-width="100" align="center">
                <template v-slot="{row}">
                  <router-link :to="{path: '/delivery/summary', query: {customerName:row.customerName}}">
                    <span class=" cursor-p">{{row.customerName}}</span>
                  </router-link>
                </template>
              </el-table-column>
              <el-table-column prop="saleUserName" label="归属销售" min-width="100" align="center"></el-table-column>
              <el-table-column prop="saleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column label="同比(%)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.yoy }}
                </template>
              </el-table-column>
              <el-table-column label="环比(%)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.mom }}
                </template>
              </el-table-column>
              <el-table-column prop="saleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="deptName" label="业务部门" min-width="100" align="center"></el-table-column>
              <el-table-column label="客户分类" min-width="100" align="center">
                <template v-slot="{row}">
                  {{row.typeName}}
                </template>
              </el-table-column>
              <el-table-column label="区域" min-width="150" align="center">
                <template v-slot="{row}">
                  {{ (row.locationProvince?row.locationProvince:'')+' '+(row.locationCity?row.locationCity:'') }}
                </template>
              </el-table-column>
              <el-table-column prop="isNewOrder" label="新客" min-width="100" align="center"></el-table-column>
              <el-table-column label="均价" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgPrice }}
                </template>
              </el-table-column>
              <el-table-column label="售价区间" min-width="100" align="center">
                <template v-slot="{row}">
                  {{(row.minPrice?row.minPrice:'')+'-'+(row.maxPrice?row.maxPrice:'')}}
                </template>
              </el-table-column>
              <el-table-column prop="maxPriceConunt" label="高价单" min-width="100" align="center"></el-table-column>
              <el-table-column prop="minPriceConunt" label="低价单" min-width="100" align="center"></el-table-column>
              <el-table-column prop="sendNum" label="送货客户数" min-width="100" align="center"></el-table-column>
              <el-table-column label="上次交易时间" min-width="100" align="center">
                <template v-slot="{row}">
                  {{row.lastSale}}
                </template>
              </el-table-column>
            </el-table>
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-row>
  </div>
</template>

<script>
  import * as echarts from 'echarts';
  require('echarts/theme/macarons'); // echarts theme
  import resize from '@/views/dashboard/mixins/resize';
  import {
    productSimple
  } from '@/api/Board/StockBoard';
  import {
    getBelong
  } from '@/api/Client/index';
  import {
    getTimeConfig
  } from '@/api/Analyse/SaleAnalyse';
  import {
    getList,
    getList1,
    getList2,
    getList3,
    getDayAnalysisFactory,
    exportList1,
    exportList2,
    exportList3,
  } from '@/api/Analyse/DailyAnalyse';
  import {
    getCustomer
  } from '@/api/teamwork/Allocate/index';
  export default {
    name: 'MonthAnalyse',
    mixins: [resize],
    data() {
      return {
        customerListOp: [], //客户下拉框
        belongListOp: [], //归属销售下拉框
        belongList: [], //归属销售下拉框
        allTableLoading: false,
        allTableData: [],
        allValue: '',
        factoryData: {},
        sectorData: [],
        salesData: [],
        factoryChart: null,
        sectorChart: null,
        salesChart: null,
        activeName: '1',
        tableLoading1: false,
        tableLoading2: false,
        tableLoading3: false,
        exportLoading1: false, //导出
        exportLoading2: false, //导出
        exportLoading3: false, //导出
        tableData1: [],
        tableData2: [],
        tableData3: [],
        queryParams: {
          year: '',
          month: '',
          orderDateStart: '',
          orderDateEnd: ''
        },
        queryParams1: {
          area: '',
          date: '',
          productType: '',
          productCode: '',
          year: '',
          month: '',
          orderDateStart: '',
          orderDateEnd: ''
        },
        queryParams2: {
          isSaleOrder: 1,
          factory: '',
          date: '',
          productType: '',
          customerCode: '',
          saleUserId: '',
          area: '',
          year: '',
          month: '',
          orderDateStart: '',
          orderDateEnd: ''
        },
        queryParams3: {
          area: '',
          date: '',
          productType: '',
          productCode: '',
          year: '',
          month: '',
          orderDateStart: '',
          orderDateEnd: ''
        },
        productCategoryList: this.getDictDatas('category_classify'), //获取品类
        searchproductCodeList1: [],
        searchproductCodeList3: [],
        options1: this.getDictDatas('factory'), //归属工厂
        options: this.getDictDatas('hfywbm'), //业务部门
      };
    },
    watch: {
      'queryParams2.saleUserId': {
        handler(newVal, oldVal) {
          this.customerListOp = [];
          this.queryParams2.customerCode = '';
          getCustomer({
            belongSale: newVal,
            isBelongSale: 1,
          }).then(
            (res) => {
              if (res.code == 0) {
                this.customerListOp = res.data;
              }
            }
          );
        },
      },
      'queryParams2.area': {
        handler(newVal, oldVal) {
          this.belongList = [];
          this.queryParams2.saleUserId = '';
          if (newVal) {
            this.belongListOp.forEach((res) => {
              if (res.deptId == newVal) {
                this.belongList.push(res);
              }
            });
          } else {
            this.belongList = this.belongListOp;
          }
        },
      },
      'queryParams1.productType'(newVal, oldVal) {
        this.queryParams1.productCode = '';
        if (newVal === '') {
          this.searchproductCodeList1 = [];
        } else {
          this.getSearchProductSimple(1);
        }
      },
      'queryParams3.productType'(newVal, oldVal) {
        this.queryParams3.productCode = '';
        if (newVal === '') {
          this.searchproductCodeList3 = [];
        } else {
          this.getSearchProductSimple(3);
        }
      },
    },
    async mounted() {
      this.getBelong();
      this.allValue = this.getBeforeMonth(0)
      this.queryParams1.date = this.getBeforeMonth(0)
      this.queryParams2.date = this.getBeforeMonth(0)
      this.queryParams3.date = this.getBeforeMonth(0)
      let year = this.allValue.slice(0, 4);
      let month = this.allValue.slice(5, 7);
      this.queryParams.year = year
      this.queryParams.month = month
      this.queryParams1.year = year
      this.queryParams1.month = month
      this.queryParams2.year = year
      this.queryParams2.month = month
      this.queryParams3.year = year
      this.queryParams3.month = month
      await getTimeConfig({
          year: year,
          month: month,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.oneWeek) {
              this.queryParams.orderDateStart = resData.oneWeek.slice(0, 10)
              this.queryParams.orderDateEnd = resData.fourWeek.slice(11, 21)
              this.queryParams1.orderDateStart = resData.oneWeek.slice(0, 10)
              this.queryParams1.orderDateEnd = resData.fourWeek.slice(11, 21)
              this.queryParams2.orderDateStart = resData.oneWeek.slice(0, 10)
              this.queryParams2.orderDateEnd = resData.fourWeek.slice(11, 21)
              this.queryParams3.orderDateStart = resData.oneWeek.slice(0, 10)
              this.queryParams3.orderDateEnd = resData.fourWeek.slice(11, 21)
              this.getList1()
              this.changeDate()
            } else {
              this.queryParams.orderDateStart = ''
              this.queryParams.orderDateEnd = ''
              this.queryParams1.orderDateStart = ''
              this.queryParams1.orderDateEnd = ''
              this.queryParams2.orderDateStart = ''
              this.queryParams2.orderDateEnd = ''
              this.queryParams3.orderDateStart = ''
              this.queryParams3.orderDateEnd = ''
              this.$notify.error({
                title: `${this.allValue}没有配置时间，无法统计数据`
              });
            }
          } else {
            this.queryParams.orderDateStart = ''
            this.queryParams.orderDateEnd = ''
            this.queryParams1.orderDateStart = ''
            this.queryParams1.orderDateEnd = ''
            this.queryParams2.orderDateStart = ''
            this.queryParams2.orderDateEnd = ''
            this.queryParams3.orderDateStart = ''
            this.queryParams3.orderDateEnd = ''
            this.$notify.error({
              title: `${this.allValue}没有配置时间，无法统计数据`
            });
          }
        })
    },
    beforeDestroy() {
      if (this.factoryChart) {
        this.factoryChart.dispose();
        this.factoryChart = null;
      }
      if (this.sectorChart) {
        this.sectorChart.dispose();
        this.sectorChart = null;
      }
      if (this.salesChart) {
        this.salesChart.dispose();
        this.salesChart = null;
      }
    },
    methods: {
      //获取所有业务员
      async getBelong() {
        const res = await getBelong({
          isSale: true
        });
        this.belongListOp = res.data;
        if (this.queryParams2.area) {
          this.belongListOp.forEach((res) => {
            if (res.deptId == this.queryParams2.area) {
              this.belongList.push(res);
            }
          });
        } else {
          this.belongList = this.belongListOp;
        }
      },
      //查询列表
      changeDate() {
        let year = this.allValue.slice(0, 4);
        let month = this.allValue.slice(5, 7);
        this.queryParams.year = year
        this.queryParams.month = month
        getTimeConfig({
            year: year,
            month: month,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.orderDateStart = resData.oneWeek.slice(0, 10)
                this.queryParams.orderDateEnd = resData.fourWeek.slice(11, 21)
                this.sectorData = []
                this.salesData = []
                this.allTableLoading = true
                getList(
                  this.queryParams
                ).then((res) => {
                  this.allTableLoading = false
                  this.allTableData = res.data;
                  this.allTableData.forEach(item => {
                    this.sectorData.push({
                      value: item.saleAmount,
                      name: item.deptName
                    })
                    this.salesData.push({
                      value: item.saleSum,
                      name: item.deptName
                    })
                  })
                  this.$nextTick(() => {
                    this.sectorInitChart();
                    this.salesInitChart();
                  });
                });
                getDayAnalysisFactory(
                  this.queryParams
                ).then((res) => {
                  this.factoryData = res.data;
                  this.$nextTick(() => {
                    this.factoryInitChart();
                  });
                });
              } else {
                this.queryParams.orderDateStart = ''
                this.queryParams.orderDateEnd = ''
                this.$notify.error({
                  title: `${this.allValue}没有配置时间，无法统计数据`
                });
              }
            } else {
              this.queryParams.orderDateStart = ''
              this.queryParams.orderDateEnd = ''
              this.$notify.error({
                title: `${this.allValue}没有配置时间，无法统计数据`
              });
            }
          })
      },
      //查询列表
      changeDate1() {
        let year = this.queryParams1.date.slice(0, 4);
        let month = this.queryParams1.date.slice(5, 7);
        this.queryParams1.year = year
        this.queryParams1.month = month
        getTimeConfig({
            year: year,
            month: month,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams1.orderDateStart = resData.oneWeek.slice(0, 10)
                this.queryParams1.orderDateEnd = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams1.orderDateStart = ''
                this.queryParams1.orderDateEnd = ''
              }
            } else {
              this.queryParams1.orderDateStart = ''
              this.queryParams1.orderDateEnd = ''
            }
          })
      },
      //查询列表
      changeDate2() {
        let year = this.queryParams2.date.slice(0, 4);
        let month = this.queryParams2.date.slice(5, 7);
        this.queryParams2.year = year
        this.queryParams2.month = month
        getTimeConfig({
            year: year,
            month: month,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams2.orderDateStart = resData.oneWeek.slice(0, 10)
                this.queryParams2.orderDateEnd = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams2.orderDateStart = ''
                this.queryParams2.orderDateEnd = ''
              }
            } else {
              this.queryParams2.orderDateStart = ''
              this.queryParams2.orderDateEnd = ''
            }
          })
      },
      //查询列表
      changeDate3() {
        let year = this.queryParams3.date.slice(0, 4);
        let month = this.queryParams3.date.slice(5, 7);
        this.queryParams3.year = year
        this.queryParams3.month = month
        getTimeConfig({
            year: year,
            month: month,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams3.orderDateStart = resData.oneWeek.slice(0, 10)
                this.queryParams3.orderDateEnd = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams3.orderDateStart = ''
                this.queryParams3.orderDateEnd = ''
              }
            } else {
              this.queryParams3.orderDateStart = ''
              this.queryParams3.orderDateEnd = ''
            }
          })
      },
      //查询列表
      getList1(flag) {
        if (!this.queryParams1.orderDateStart) {
          this.$notify.error({
            title: `${this.queryParams1.date}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams1.orderDateEnd) {
          this.$notify.error({
            title: `${this.queryParams1.date}没有配置时间，无法统计数据`
          });
          return;
        }
        this.tableLoading1 = true
        getList1(
          this.queryParams1
        ).then((res) => {
          this.tableLoading1 = false
          this.tableData1 = res.data;
        });
      },
      getList2(flag) {
        if (!this.queryParams2.orderDateStart) {
          this.$notify.error({
            title: `${this.queryParams2.date}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams2.orderDateEnd) {
          this.$notify.error({
            title: `${this.queryParams2.date}没有配置时间，无法统计数据`
          });
          return;
        }
        this.tableLoading2 = true
        getList2(
          this.queryParams2
        ).then((res) => {
          this.tableLoading2 = false
          this.tableData2 = res.data;
        });
      },
      getList3(flag) {
        if (!this.queryParams3.orderDateStart) {
          this.$notify.error({
            title: `${this.queryParams3.date}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams3.orderDateEnd) {
          this.$notify.error({
            title: `${this.queryParams3.date}没有配置时间，无法统计数据`
          });
          return;
        }
        this.tableLoading3 = true
        getList3(
          this.queryParams3
        ).then((res) => {
          this.tableLoading3 = false
          this.tableData3 = res.data;
        });
      },
      //重置列表
      resetQuery1() {
        this.queryParams1.date = this.getBeforeMonth(0)
        let year = this.queryParams1.date.slice(0, 4);
        let month = this.queryParams1.date.slice(5, 7);
        this.queryParams1.year = year
        this.queryParams1.month = month
        getTimeConfig({
            year: year,
            month: month,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams1.orderDateStart = resData.oneWeek.slice(0, 10)
                this.queryParams1.orderDateEnd = resData.fourWeek.slice(11, 21)
                this.getList1()
              } else {
                this.queryParams1.orderDateStart = ''
                this.queryParams1.orderDateEnd = ''
              }
            } else {
              this.queryParams1.orderDateStart = ''
              this.queryParams1.orderDateEnd = ''
            }
          })
      },
      resetQuery2() {
        this.queryParams2.date = this.getBeforeMonth(0)
        let year = this.queryParams2.date.slice(0, 4);
        let month = this.queryParams2.date.slice(5, 7);
        this.queryParams2.year = year
        this.queryParams2.month = month
        getTimeConfig({
            year: year,
            month: month,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams2.orderDateStart = resData.oneWeek.slice(0, 10)
                this.queryParams2.orderDateEnd = resData.fourWeek.slice(11, 21)
                this.getList2()
              } else {
                this.queryParams2.orderDateStart = ''
                this.queryParams2.orderDateEnd = ''
              }
            } else {
              this.queryParams2.orderDateStart = ''
              this.queryParams2.orderDateEnd = ''
            }
          })
      },
      resetQuery3() {
        this.queryParams3.date = this.getBeforeMonth(0)
        let year = this.queryParams3.date.slice(0, 4);
        let month = this.queryParams3.date.slice(5, 7);
        this.queryParams3.year = year
        this.queryParams3.month = month
        getTimeConfig({
            year: year,
            month: month,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams3.orderDateStart = resData.oneWeek.slice(0, 10)
                this.queryParams3.orderDateEnd = resData.fourWeek.slice(11, 21)
                this.getList3()
              } else {
                this.queryParams3.orderDateStart = ''
                this.queryParams3.orderDateEnd = ''
              }
            } else {
              this.queryParams3.orderDateStart = ''
              this.queryParams3.orderDateEnd = ''
            }
          })
      },
      //导出
      handleExport1() {
        if (!this.queryParams1.orderDateStart) {
          this.$notify.error({
            title: `${this.queryParams1.date}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams1.orderDateEnd) {
          this.$notify.error({
            title: `${this.queryParams1.date}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading1 = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList1(this.queryParams1);
          })
          .then((response) => {
            this.$download.excel(response, '业务员销售情况.xls');
            this.exportLoading1 = false;
          })
          .catch(() => {
            this.exportLoading1 = false;
          });
      },
      handleExport2() {
        if (!this.queryParams2.orderDateStart) {
          this.$notify.error({
            title: `${this.queryParams2.date}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams2.orderDateEnd) {
          this.$notify.error({
            title: `${this.queryParams2.date}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading2 = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList2(this.queryParams2);
          })
          .then((response) => {
            this.$download.excel(response, '产品销售情况.xls');
            this.exportLoading2 = false;
          })
          .catch(() => {
            this.exportLoading2 = false;
          });
      },
      handleExport3() {
        if (!this.queryParams3.orderDateStart) {
          this.$notify.error({
            title: `${this.queryParams3.date}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams3.orderDateEnd) {
          this.$notify.error({
            title: `${this.queryParams3.date}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading3 = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList3(this.queryParams3);
          })
          .then((response) => {
            this.$download.excel(response, '客户销售情况.xls');
            this.exportLoading3 = false;
          })
          .catch(() => {
            this.exportLoading3 = false;
          });
      },
      //获取品项
      getSearchProductSimple(type) {
        if (type == 1) {
          productSimple({
            type: this.queryParams1.productType
          }).then((res) => {
            this.searchproductCodeList1 = res.data;
          });
        } else if (type == 3) {
          productSimple({
            type: this.queryParams3.productType
          }).then((res) => {
            this.searchproductCodeList3 = res.data;
          });
        }
      },
      //切换tab
      handleClick() {
        if (this.activeName == 1) {
          this.getList1()
        } else if (this.activeName == 2) {
          this.getList2()
        } else if (this.activeName == 3) {
          this.getList3()
        }
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //工厂出库占比
      async factoryInitChart() {
        this.factoryChart = echarts.init(document.getElementById('factoryOut'), 'macarons');
        this.factoryChart.setOption({
          title: {
            text: '工厂出库占比',
            left: 'center',
            bottom: 0,
            textStyle: {
              color: '#000',
              fontSize: 14
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)',
          },
          legend: {
            orient: 'vertical',
            right: 0,
            top: 'center',
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75'],
          series: [{
            name: '工厂出库占比',
            type: 'pie',
            radius: ['25%', '55%'],
            center: ['40%', '50%'],
            label: {
              //文字部分 显示内容为{b}：{c}可以换自己像显示的
              formatter: '{b}\n{c}',
              //折线图文字颜色
              color: "#000000",
            },
            // 折线图长度
            labelLine: { // 指示线的配置
              show: true, // 显示指示线
              length: 10, // 指示线的长度
              length2: 10, // 指示线的第二段长度
              smooth: 0.2, // 指示线平滑度
            },
            data: this.factoryData,
          }]
        });
      },
      //部门销量占比
      async sectorInitChart() {
        this.sectorChart = echarts.init(document.getElementById('sectorOut'), 'macarons');
        this.sectorChart.setOption({
          title: {
            text: '部门销量占比',
            left: 'center',
            bottom: 0,
            textStyle: {
              color: '#000',
              fontSize: 14
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)',
          },
          legend: {
            orient: 'vertical',
            right: 0,
            top: 'center',
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75', '#fc8452'],
          series: [{
            name: '部门销量占比',
            type: 'pie',
            radius: ['25%', '55%'],
            center: ['40%', '50%'],
            label: {
              //文字部分 显示内容为{b}：{c}可以换自己像显示的
              formatter: '{b}\n{c}',
              //折线图文字颜色
              color: "#000000",
            },
            // 折线图长度
            labelLine: { // 指示线的配置
              show: true, // 显示指示线
              length: 10, // 指示线的长度
              length2: 10, // 指示线的第二段长度
              smooth: 0.2, // 指示线平滑度
            },
            data: this.sectorData,
          }, ],
        });
      },
      //部门销售额占比
      async salesInitChart() {
        this.salesChart = echarts.init(document.getElementById('salesOut'), 'macarons');
        this.salesChart.setOption({
          title: {
            text: '部门销售额占比',
            left: 'center',
            bottom: 0,
            textStyle: {
              color: '#000',
              fontSize: 14
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)',
          },
          legend: {
            orient: 'vertical',
            right: 0,
            top: 'center',
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75', '#fc8452'],
          series: [{
            name: '部门销售额占比',
            type: 'pie',
            radius: ['25%', '55%'],
            center: ['40%', '50%'],
            // center: ['40%', '50%'],
            label: {
              //文字部分 显示内容为{b}：{c}可以换自己像显示的
              formatter: '{b}\n{c}',
              //折线图文字颜色
              color: "#000000",
            },
            // 折线图长度
            labelLine: { // 指示线的配置
              show: true, // 显示指示线
              length: 10, // 指示线的长度
              length2: 10, // 指示线的第二段长度
              smooth: 0.2, // 指示线平滑度
            },
            data: this.salesData,
          }, ],
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  .cursor-p {
    color: #1890ff;
  }

  ::v-deep .el-table--medium .el-table__cell {
    padding: 0 !important;
  }

  ::v-deep .el-tabs__item {
    background-color: #FFF !important;
  }

  ::v-deep .is-active {
    color: #FFF !important;
    background-color: #0092ff !important;
  }

  .dashboard-editor-container {
    padding: 32px;
    background-color: rgb(240, 242, 245);
    position: relative;

    .row-btm {
      margin-bottom: 8px;
    }

    .el-form-item {
      margin-bottom: 10px !important;
    }
  }
</style>
