<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>销售出库趋势</span>
      <div>
        <el-form ref="weekInQuery" size="small" :inline="true" label-width="60px">
          <el-form-item label="工厂" prop="factory">
            <el-select v-model="queryParams.factory" placeholder="请选择工厂" clearable filterable style="width: 140px;">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-radio-group v-model="queryParams.isDay">
              <el-radio :label="1">按天</el-radio>
              <el-radio :label="2">按月</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item>
            <el-date-picker @change="changeDate" value-format="yyyy-MM" v-if="queryParams.isDay==1" v-model="queryParams.date" type="month"
              placeholder="选择月"></el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-date-picker @change="changeDate" value-format="yyyy-MM" v-if="queryParams.isDay==2" v-model="queryParams.dateRange"
              type="monthrange" range-separator="至" start-placeholder="开始月份" end-placeholder="结束月份">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button icon="el-icon-search" @click="getList()">查询</el-button>
            <el-button icon="el-icon-download" :loading="exportLoading" @click="handleExport">导出</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div>
      <div id="echarts" style="height:250px;width:100%;" />
      <el-table row-key="id" :data="tableData" border max-height="350" v-loading="tableLoading" show-summary>
        <el-table-column prop="orderMonth" label="日期" min-width="100" align="center"></el-table-column>
        <el-table-column prop="saleAmount" label="销售量(吨)" min-width="100" align="center"> </el-table-column>
        <el-table-column prop="saleSum" label="总金额(万元)" min-width="100" align="center"></el-table-column>
        <el-table-column prop="orderNo" label="订单量" min-width="100" align="center"></el-table-column>
        <el-table-column label="均单价(元/单)" min-width="100" align="center">
          <template v-slot="{row}">
            {{ row.avgPrice }}
          </template>
        </el-table-column>
        <el-table-column label="均单量(吨/单)" min-width="100" align="center">
          <template v-slot="{row}">
            {{ row.avgSum }}
          </template>
        </el-table-column>
        <el-table-column prop="minPriceConunt" label="低价单" min-width="100" align="center"> </el-table-column>
        <el-table-column prop="maxPriceConunt" label="高价单" min-width="100" align="center"> </el-table-column>
        <!-- <el-table-column prop="refundOrderAmount" label="退货单" min-width="100" align="center"> </el-table-column> -->
      </el-table>
    </div>
  </el-card>
</template>

<script>
  import * as echarts from 'echarts';
  require('echarts/theme/macarons'); // echarts theme
  import resize from '@/views/dashboard/mixins/resize';
  import {
    getTimeConfig,
    getSalTrendTotal,
    getSalTrend,
    exportList2,
  } from '@/api/Analyse/SaleAnalyse';
  export default {
    mixins: [resize],
    data() {
      return {
        queryParams: {
          factory: '',
          startDate: '',
          endDate: '',
          date: '',
          dateRange: [],
          isDay: 1,
        },
        chartData: {},
        chart: null,
        options: this.getDictDatas('factory'), //归属工厂
        exportLoading: false, //导出
        tableLoading: false,
        tableData: [],
      };
    },
    async mounted() {
      this.queryParams.date = this.getBeforeMonth(0);
      let queryYear = this.queryParams.date.slice(0, 4);
      let queryMonth = this.queryParams.date.slice(5, 7);
      await getTimeConfig({
          year: queryYear,
          month: queryMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.oneWeek) {
              this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              this.queryParams.endDate = resData.fourWeek.slice(11, 21)
            } else {
              this.queryParams.startDate = ''
              this.queryParams.endDate = ''
            }
          } else {
            this.queryParams.startDate = ''
            this.queryParams.endDate = ''
          }
        })
      this.getList()
    },
    beforeDestroy() {
      if (!this.chart) {
        return;
      }
      this.chart.dispose();
      this.chart = null;
    },
    methods: {
      //初始化柱状图
      initChart() {
        let data = this.chartData
        let xArr = data.x
        let min = data.min
        let max = data.max
        let norm = data.norm
        let orderNoList = data.orderNoList
        this.chart = echarts.init(document.getElementById('echarts'), 'macarons');
        this.chart.setOption({
          legend: {
            right: 30,
          },
          tooltip: {
            trigger: 'axis',
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75'],
          xAxis: {
            type: 'category',
            data: xArr,
          },
          yAxis: {
            type: 'value'
          },
          series: [{
              name: '单量',
              data: orderNoList,
              type: 'bar',
              barWidth: '20%',
              emphasis: {
                focus: 'series'
              },
            }, {
              name: '低价',
              data: min,
              type: 'bar',
              stack: 'Ad',
              barWidth: '20%',
              emphasis: {
                focus: 'series'
              },
            },
            {
              name: '高价',
              data: max,
              type: 'bar',
              stack: 'Ad',
              barWidth: '20%',
              emphasis: {
                focus: 'series'
              },
            },
            // {
            //   name: '标价',
            //   data: norm,
            //   stack: 'Ad',
            //   type: 'bar',
            //   barWidth: '20%',
            //   emphasis: {
            //     focus: 'series'
            //   },
            // },
          ],
        });
      },
      //更改时间
      changeDate() {
        if (this.queryParams.isDay == 1) {
          let queryYear = this.queryParams.date.slice(0, 4);
          let queryMonth = this.queryParams.date.slice(5, 7);
          getTimeConfig({
              year: queryYear,
              month: queryMonth,
            })
            .then((res) => {
              if (res.data.length > 0) {
                let resData = res.data[0]
                if (resData.oneWeek) {
                  this.queryParams.startDate = resData.oneWeek.slice(0, 10)
                  this.queryParams.endDate = resData.fourWeek.slice(11, 21)
                } else {
                  this.queryParams.startDate = ''
                  this.queryParams.endDate = ''
                }
              } else {
                this.queryParams.startDate = ''
                this.queryParams.endDate = ''
              }
            })
        } else if (this.queryParams.isDay == 2) {
          let startDate = this.queryParams.dateRange[0];
          let endDate = this.queryParams.dateRange[1];
          let startYear = startDate.slice(0, 4);
          let startMonth = startDate.slice(5, 7);
          let endYear = endDate.slice(0, 4);
          let endMonth = endDate.slice(5, 7);
          getTimeConfig({
              year: startYear,
              month: startMonth,
            })
            .then((res) => {
              if (res.data.length > 0) {
                let resData = res.data[0]
                if (resData.oneWeek) {
                  this.queryParams.startDate = resData.oneWeek.slice(0, 10)
                } else {
                  this.queryParams.startDate = ''
                }
              } else {
                this.queryParams.startDate = ''
              }
            })
          getTimeConfig({
              year: endYear,
              month: endMonth,
            })
            .then((res) => {
              if (res.data.length > 0) {
                let resData = res.data[0]
                if (resData.fourWeek) {
                  this.queryParams.endDate = resData.fourWeek.slice(11, 21)
                } else {
                  this.queryParams.endDate = ''
                }
              } else {
                this.queryParams.endDate = ''
              }
            })
        }
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //获取列表接口
      getList(flag) {
        if (this.queryParams.isDay == 1) {
          if (!this.queryParams.startDate) {
            this.$notify.error({
              title: `${this.queryParams.date}没有配置时间，无法统计数据`
            });
            return;
          }
        } else if (this.queryParams.isDay == 2) {
          let startDate = this.queryParams.dateRange[0];
          let endDate = this.queryParams.dateRange[1];
          if (!this.queryParams.startDate) {
            this.$notify.error({
              title: `${startDate}没有配置时间，无法统计数据`
            });
            return;
          }
          if (!this.queryParams.endDate) {
            this.$notify.error({
              title: `${endDate}没有配置时间，无法统计数据`
            });
            return;
          }
        }
        this.tableLoading = true
        getSalTrend(
          this.queryParams
        ).then((res) => {
          this.tableLoading = false
          this.tableData = res.data;
        });
        if (!flag) {
          getSalTrendTotal(
            this.queryParams
          ).then((res) => {
            this.chartData = res.data;
            this.$nextTick(() => {
              this.initChart();
            });
          });
        }
      },
      //导出接口
      handleExport() {
        if (this.queryParams.isDay == 1) {
          if (!this.queryParams.startDate) {
            this.$notify.error({
              title: `${this.queryParams.date}没有配置时间，无法导出数据`
            });
            return;
          }
        } else if (this.queryParams.isDay == 2) {
          let startDate = this.queryParams.dateRange[0];
          let endDate = this.queryParams.dateRange[1];
          if (!this.queryParams.startDate) {
            this.$notify.error({
              title: `${startDate}没有配置时间，无法导出数据`
            });
            return;
          }
          if (!this.queryParams.endDate) {
            this.$notify.error({
              title: `${endDate}没有配置时间，无法导出数据`
            });
            return;
          }
        }
        this.exportLoading = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList2(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '销售出库趋势.xls');
            this.exportLoading = false;
          })
          .catch(() => {
            this.exportLoading = false;
          });
      },
    }
  };
</script>
<style lang="scss" scoped>
  ::v-deep .el-table--medium .el-table__cell {
    padding: 0 !important;
  }
</style>
