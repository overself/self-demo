<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>销售区域</span>
      <div>
        <el-form ref="weekInQuery" size="small" :inline="true" label-width="60px">
          <el-form-item>
            <el-radio-group v-model="queryParams.isProvince" @input="changeType">
              <el-radio :label="1">按省</el-radio>
              <el-radio :label="2">按城市</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="渠道" prop="customerType">
            <el-select clearable v-model="queryParams.customerType" placeholder="请选择渠道" style="width: 140px">
              <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-date-picker :clearable="false" v-model="queryParams.dateRange" type="monthrange" range-separator="至"
              start-placeholder="开始月份" end-placeholder="结束月份" @change="changeDate" value-format="yyyy-MM">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button icon="el-icon-search" @click="getList()">查询</el-button>
            <el-button icon="el-icon-download" :loading="exportLoading" @click="handleExport">导出</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-radio-group v-model="factoryValue" @input="changeRadio">
      <el-radio-button v-for="(item, index) in options" :key="index" :label="item.value">{{item.label}}</el-radio-button>
    </el-radio-group>
    <el-row :gutter="8" class="row-btm">
      <el-col :span="6">
        <div id="main" style="height:300px;width:300px;" />
      </el-col>
      <el-col :span="18">
        <div>
          <el-table row-key="id" :data="tableData" border max-height="350" v-loading="tableLoading" show-summary>
            <el-table-column prop="locationName" label="地区" min-width="100" align="center" fixed></el-table-column>
            <el-table-column prop="saleAmount" label="销售量(吨)" min-width="100" align="center"> </el-table-column>
            <el-table-column prop="saleSum" label="总金额(万元)" min-width="100" align="center"> </el-table-column>
            <el-table-column prop="orderNo" label="订单数" min-width="100" align="center"> </el-table-column>
            <el-table-column prop="customerCode" label="客户数" min-width="100" align="center"> </el-table-column>
            <el-table-column prop="newOrder" label="新客数" min-width="100" align="center"> </el-table-column>
            <el-table-column prop="maxPriceConunt" label="高价单" min-width="100" align="center"> </el-table-column>
            <el-table-column prop="minPriceConunt" label="低价单" min-width="100" align="center"> </el-table-column>
            <<!-- el-table-column prop="refundOrder" label="退货单" min-width="100" align="center"> </el-table-column>
              <el-table-column prop="refundSum" label="退货金额(万元)" min-width="100" align="center"> </el-table-column> -->
              <el-table-column label="均单量(吨/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgSum }}
                </template>
              </el-table-column>
              <el-table-column label="均单价(元/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgPrice }}
                </template>
              </el-table-column>
          </el-table>
        </div>
      </el-col>
    </el-row>
  </el-card>
</template>

<script>
  import * as echarts from 'echarts';
  require('echarts/theme/macarons'); // echarts theme
  import resize from '@/views/dashboard/mixins/resize';
  import GeoJson from '@/utils/geoJson.json';
  import {
    getTimeConfig,
    getCustomerAnalysisProvince,
    exportList,
  } from '@/api/Analyse/ClientAnalyse';
  import {
    deepClone
  } from '@/utils';
  import {
    getDictDatas,
    DICT_TYPE
  } from '@/utils/dict';
  export default {
    mixins: [resize],
    data() {
      return {
        clientTypes: [],
        queryParams: {
          isProvince: 1,
          dateRange: '',
          startDate: '',
          endDate: '',
          customerType: '',
        },
        factoryValue: '1',
        options: [{
            label: '按销量',
            value: '1'
          },
          {
            label: '按客户数',
            value: '2'
          }
        ],
        tableData: [],
        tableLoading: false,
        exportLoading: false, //导出
        chart: null,
        mapData: [],
        seriesData: [],
      };
    },
    async mounted() {
      this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
      let startDate = this.getBeforeMonth(0);
      let endDate = this.getBeforeMonth(0);
      this.queryParams.dateRange = [startDate, endDate];
      let startYear = startDate.slice(0, 4);
      let startMonth = startDate.slice(5, 7);
      let endYear = endDate.slice(0, 4);
      let endMonth = endDate.slice(5, 7);
      await getTimeConfig({
          year: startYear,
          month: startMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.oneWeek) {
              this.queryParams.startDate = resData.oneWeek.slice(0, 10)
            } else {
              this.queryParams.startDate = ''
            }
          } else {
            this.queryParams.startDate = ''
          }
        })
      await getTimeConfig({
          year: endYear,
          month: endMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.fourWeek) {
              this.queryParams.endDate = resData.fourWeek.slice(11, 21)
            } else {
              this.queryParams.endDate = ''
            }
          } else {
            this.queryParams.endDate = ''
          }
        })
      this.getList()
    },
    beforeDestroy() {
      if (!this.chart) {
        return;
      }
      this.chart.dispose();
      this.chart = null;
    },
    methods: {
      //配置月份
      changeDate() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams.startDate = ''
              }
            } else {
              this.queryParams.startDate = ''
            }
          })
        getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.endDate = ''
            }
          })
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //切换查询地区
      changeType() {},
      // 更改地图排序
      changeRadio() {
        this.$nextTick(() => {
          this.initChart();
        });
      },
      //查询列表数据
      getList() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法统计数据`
          });
          return;
        }
        this.tableLoading = true
        getCustomerAnalysisProvince(this.queryParams).then((res) => {
          this.tableLoading = false
          this.tableData = res.data;
          if (this.queryParams.isProvince == 1) {
            this.mapData = res.data;
            this.$nextTick(() => {
              this.initChart();
            });
          }
        });
      },
      //导出列表数据
      handleExport() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '销售区域情况.xls');
            this.exportLoading = false;
          })
          .catch(() => {
            this.exportLoading = false;
          });
      },
      //初始化地图
      initChart() {
        this.mapData.forEach((item, index) => {
          this.seriesData[index] = {
            name: '',
            value: '',
          };
          switch (item.locationName) {
            case '北京':
              this.seriesData[index].name = '北京市';
              break;
            case '上海':
              this.seriesData[index].name = '上海市';
              break;
            case '重庆':
              this.seriesData[index].name = '重庆市';
              break;
            case '天津':
              this.seriesData[index].name = '天津市';
              break;
            default:
              this.seriesData[index].name = item.locationName;
              break;
          }
          if (this.factoryValue == 1) {
            this.seriesData[index].value = item.saleAmount;
          } else if (this.factoryValue == 2) {
            this.seriesData[index].value = item.customerCode;
          }
        });
        let mapName = ''
        let mapMin = 0
        let mapMax = 0
        if (this.factoryValue == 1) {
          mapName = '销量分布'
          mapMin = 1000
          mapMax = 50000
        } else if (this.factoryValue == 2) {
          mapName = '客户分布'
          mapMin = 50
          mapMax = 200
        }
        echarts.registerMap('china', {
          geoJSON: GeoJson
        });
        this.chart = echarts.init(document.getElementById('main'), 'macarons');
        let option = {
          visualMap: {
            min: mapMin, //数据的最小值，用于确定颜色映射的最小值
            max: mapMax, //数据的最大值，用于确定颜色映射的最大值
            left: 'left',
            top: 'bottom',
            text: ['高', '低'],
            calculable: false,
            orient: 'horizontal',
            inRange: {
              color: ['#ffffff', '#2f7ecd'],
              symbolSize: [30, 100],
            },
          },
          tooltip: {
            padding: 8,
            enterable: true,
            transitionDuration: 1,
            textStyle: {
              color: '#FFF',
              decoration: 'none',
            },
          },
          series: [{
            name: mapName,
            type: 'map',
            mapType: 'china',
            left: 0,
            right: 0,
            itemStyle: {
              normal: {
                label: {
                  show: false,
                },
              },
              emphasis: {
                areaColor: '#0971db',
                label: {
                  show: true,
                },
              },
            },
            label: {
              normal: {
                //静态的时候展示样式
                show: false, //是否显示地图省份得名称
                textStyle: {
                  color: '#FFF',
                  fontSize: 12,
                },
              },
              emphasis: {
                //动态展示的样式
                color: '#FFF',
              },
            },
            data: this.seriesData,
          }, ],
        };
        this.chart.setOption(option);
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .el-table--medium .el-table__cell {
    padding: 0 !important;
  }
</style>
