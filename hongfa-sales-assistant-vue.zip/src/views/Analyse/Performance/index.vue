<template>
  <div class="dashboard-editor-container">
    <el-row class="row-btm">
      <el-tabs v-model="activeName" type="border-card" @tab-click="handleClick">
        <el-tab-pane label="业务员业绩" name="1">
          <div class="clearfix">
            <div>
              <el-form ref="weekInQuery1" size="small" :inline="true" label-width="70px">
                <el-form-item label="部门" prop="area">
                  <el-select v-model="queryParams1.area" placeholder="请选择部门" style="width: 140px" filterable clearable>
                    <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="业务员" prop="saleUserId">
                  <el-select v-model="queryParams1.saleUserId" placeholder="请选择业务员" style="width: 140px" filterable clearable>
                    <el-option v-for="item in belongList" :key="item.id" :value="item.id" :label="item.nickname"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="客户分类" prop="customerType">
                  <el-select v-model="queryParams1.customerType" placeholder="请选择客户分类" style="width: 140px" filterable clearable>
                    <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item>
                  <el-date-picker :clearable="false" v-model="queryParams1.dateRange" type="monthrange" range-separator="至"
                    start-placeholder="开始月份" end-placeholder="结束月份" @change="changeDate1" value-format="yyyy-MM">
                  </el-date-picker>
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="getList1()">查询</el-button>
                  <el-button icon="el-icon-refresh" @click="resetQuery">重置</el-button>
                  <el-button icon="el-icon-download" :loading="exportLoading1" @click="handleExport1">导出</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
          <!-- 销售统计饼图-->
          <el-row :gutter="8" class="row-btm">
            <div v-if="activeName=='1'" id="clientOut1" style="height:250px;width:100%;" />
          </el-row>
          <!-- 销售统计表格-->
          <div>
            <el-table row-key="id" :data="tableData1" border max-height="500" v-loading="tableLoading1" show-summary>
              <el-table-column prop="orderMonth" label="月份" min-width="100" align="center" fixed></el-table-column>
              <el-table-column prop="rank" width="50" label="排名" align="center" fixed></el-table-column>
              <el-table-column prop="nickName" label="业务员" min-width="100" align="center" fixed></el-table-column>
              <el-table-column label="汇总" align="center">
                <el-table-column prop="saleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column label="同比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.yoy }}
                  </template>
                </el-table-column>
                <el-table-column label="环比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.mom }}
                  </template>
                </el-table-column>
                <el-table-column label="计划量" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.monthSales }}
                  </template>
                </el-table-column>
                <el-table-column label="完成量" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.monthCompleteSales }}
                  </template>
                </el-table-column>
                <el-table-column label="达成率(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.completeRation }}
                  </template>
                </el-table-column>
                <el-table-column prop="orderNo" label="订单量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="allCustomerCode" label="总客户" min-width="100" align="center"></el-table-column>
                <el-table-column prop="planCustomerCode" label="计划客户" min-width="100" align="center"></el-table-column>
                <el-table-column prop="customerCode" label="成交客户" min-width="100" align="center"></el-table-column>
                <el-table-column prop="newOrder" label="新客单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="maxPriceConunt" label="高价单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="minPriceConunt" label="低价单" min-width="100" align="center"></el-table-column>
                <el-table-column label="均单量(吨/单)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.avgAmount }}
                  </template>
                </el-table-column>
                <el-table-column label="均单价(元/单)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.avgSum }}
                  </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="朝阳" align="center">
                <el-table-column prop="saleAmountCy" label="销售量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="cySales" label="计划量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="cyCompleteSales" label="完成量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="cyCompleteRation" label="达成率(%)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSumCy" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              </el-table-column>
              <el-table-column label="喀左" align="center">
                <el-table-column prop="saleAmountKz" label="销售量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="kzSales" label="计划量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="kzCompleteSales" label="完成量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="kzCompleteRation" label="达成率(%)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSumKz" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              </el-table-column>
              <el-table-column label="一厂" align="center">
                <el-table-column prop="saleAmountYc" label="销售量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="ycSales" label="计划量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="ycCompleteSales" label="完成量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="ycCompleteRation" label="达成率(%)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSumYc" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              </el-table-column>
              <el-table-column label="二厂" min-width="100" align="center">
                <el-table-column prop="saleAmountEc" label="销售量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="ecSales" label="计划量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="ecCompleteSales" label="完成量" min-width="100" align="center"></el-table-column>
                <el-table-column prop="ecCompleteRation" label="达成率(%)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSumEc" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              </el-table-column>
            </el-table>
          </div>
        </el-tab-pane>
        <el-tab-pane label="大区业绩" name="2">
          <div class="clearfix">
            <div>
              <el-form ref="weekInQuery2" size="small" :inline="true" label-width="100px">
                <el-form-item>
                  <el-date-picker :clearable="false" v-model="queryParams2.dateRange" type="monthrange" range-separator="至"
                    start-placeholder="开始月份" end-placeholder="结束月份" @change="changeDate2" value-format="yyyy-MM">
                  </el-date-picker>
                </el-form-item>
                <el-form-item>
                  <el-button icon="el-icon-search" @click="getList2()">查询</el-button>
                  <el-button icon="el-icon-download" :loading="exportLoading2" @click="handleExport2">导出</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
          <!-- 销售统计饼图-->
          <el-row :gutter="8" class="row-btm">
            <div v-if="activeName=='2'" id="clientOut2" style="height:250px;width:100%;" />
          </el-row>
          <!-- 销售统计表格-->
          <div>
            <el-table row-key="id" :data="tableData2" border max-height="500" v-loading="tableLoading2" show-summary>
              <el-table-column prop="orderMonth" label="月份" min-width="100" align="center" fixed></el-table-column>
              <el-table-column label="总计" align="center">
                <el-table-column prop="saleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="saleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column label="同比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.yoy }}
                  </template>
                </el-table-column>
                <el-table-column label="环比(%)" min-width="100" align="center">
                  <template v-slot="{row}">
                    {{ row.mom }}
                  </template>
                </el-table-column>
                <el-table-column prop="newOrder" label="新客单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="highPrice" label="高价单" min-width="100" align="center"></el-table-column>
              </el-table-column>
              <el-table-column label="一区" align="center">
                <el-table-column prop="yqSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="yqSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="yqNewOrder" label="新客单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="yqHighPrice" label="高价单" min-width="100" align="center"></el-table-column>
              </el-table-column>
              <el-table-column label="二区" align="center">
                <el-table-column prop="eqSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="eqSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="eqNewOrder" label="新客单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="eqHighPrice" label="高价单" min-width="100" align="center"></el-table-column>
              </el-table-column>
              <el-table-column label="三区" align="center">
                <el-table-column prop="sqSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="sqSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="sqNewOrder" label="新客单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="sqHighPrice" label="高价单" min-width="100" align="center"></el-table-column>
              </el-table-column>
              <el-table-column label="集团" align="center">
                <el-table-column prop="jtSaleAmount" label="销量(吨)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="jtSaleSum" label="销售额(万元)" min-width="100" align="center"></el-table-column>
                <el-table-column prop="jtNewOrder" label="新客单" min-width="100" align="center"></el-table-column>
                <el-table-column prop="jtHighPrice" label="高价单" min-width="100" align="center"></el-table-column>
              </el-table-column>
            </el-table>
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-row>
  </div>
</template>

<script>
  import * as echarts from 'echarts';
  require('echarts/theme/macarons'); // echarts theme
  import resize from '@/views/dashboard/mixins/resize';
  import {
    deepClone
  } from '@/utils';
  import {
    getTimeConfig,
    getSalPersonAnalysis,
    getSalPersonAreaAnalysis,
    exportList1,
    exportList2,
    getSalPersonTotal,
    getSalPersonAreaTotal,
  } from '@/api/Analyse/Performance';
  import {
    getBelong
  } from '@/api/Client/index';
  export default {
    name: 'Performance',
    mixins: [resize],
    data() {
      return {
        clientTypes: [], //客户分类下拉框
        belongListOp: [], //归属销售下拉框
        belongList: [], //归属销售下拉框
        queryParams1: {
          area: '',
          dateRange: [],
          saleUserId: '',
          startDate: '',
          endDate: '',
        },
        queryParams2: {
          dateRange: [],
          startDate: '',
          endDate: '',
        },
        activeName: '1',
        tableData1: [],
        tableData2: [],
        exportLoading1: false, //导出
        exportLoading2: false, //导出
        tableLoading1: false,
        tableLoading2: false,
        clientChart1: null,
        clientChart2: null,
        clientData1: {},
        clientData2: {},
        options: this.getDictDatas('hfywbm'), //业务部门
      };
    },
    watch: {
      'queryParams1.area': {
        handler(newVal, oldVal) {
          this.belongList = [];
          this.queryParams1.saleUserId = '';
          if (newVal) {
            this.belongListOp.forEach((res) => {
              if (res.deptId == newVal) {
                this.belongList.push(res);
              }
            });
          } else {
            this.belongList = this.belongListOp;
          }
        },
      },
    },
    async mounted() {
      this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
      this.getBelong();
      let startDate = this.getBeforeMonth(0);
      let endDate = this.getBeforeMonth(0);
      this.queryParams1.dateRange = [startDate, endDate];
      let startYear = startDate.slice(0, 4);
      let startMonth = startDate.slice(5, 7);
      let endYear = endDate.slice(0, 4);
      let endMonth = endDate.slice(5, 7);
      await getTimeConfig({
          year: startYear,
          month: startMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.oneWeek) {
              this.queryParams1.startDate = resData.oneWeek.slice(0, 10)
            } else {
              this.queryParams1.startDate = ''
            }
          } else {
            this.queryParams1.startDate = ''
          }
        })
      await getTimeConfig({
          year: endYear,
          month: endMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.fourWeek) {
              this.queryParams1.endDate = resData.fourWeek.slice(11, 21)
            } else {
              this.queryParams1.endDate = ''
            }
          } else {
            this.queryParams1.endDate = ''
          }
        })
      this.getList1()
    },
    beforeDestroy() {
      if (this.clientChart1) {
        this.clientChart1.dispose();
        this.clientChart1 = null;
      }
      if (this.clientChart2) {
        this.clientChart2.dispose();
        this.clientChart2 = null;
      }
    },
    methods: {
      //配置月份
      changeDate1() {
        let startDate = this.queryParams1.dateRange[0];
        let endDate = this.queryParams1.dateRange[1];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams1.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams1.startDate = ''
              }
            } else {
              this.queryParams1.startDate = ''
            }
          })
        getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams1.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams1.endDate = ''
              }
            } else {
              this.queryParams1.endDate = ''
            }
          })
      },
      //配置月份
      changeDate2() {
        let startDate = this.queryParams2.dateRange[0];
        let endDate = this.queryParams2.dateRange[1];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams2.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams2.startDate = ''
              }
            } else {
              this.queryParams2.startDate = ''
            }
          })
        getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams2.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams2.endDate = ''
              }
            } else {
              this.queryParams2.endDate = ''
            }
          })
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //获取所有业务员
      async getBelong() {
        const res = await getBelong({
          isSale: true
        });
        this.belongListOp = res.data;
        if (this.queryParams1.area) {
          this.belongListOp.forEach((res) => {
            if (res.deptId == this.queryParams1.area) {
              this.belongList.push(res);
            }
          });
        } else {
          this.belongList = this.belongListOp;
        }
      },
      //切换tab
      async handleClick() {
        if (this.activeName == '2' && !this.queryParams2.startDate && !this.queryParams2.endDate) {
          let startDate = this.getBeforeMonth(0);
          let endDate = this.getBeforeMonth(0);
          this.queryParams2.dateRange = [startDate, endDate];
          let startYear = startDate.slice(0, 4);
          let startMonth = startDate.slice(5, 7);
          let endYear = endDate.slice(0, 4);
          let endMonth = endDate.slice(5, 7);
          await getTimeConfig({
              year: startYear,
              month: startMonth,
            })
            .then((res) => {
              if (res.data.length > 0) {
                let resData = res.data[0]
                if (resData.oneWeek) {
                  this.queryParams2.startDate = resData.oneWeek.slice(0, 10)
                } else {
                  this.queryParams2.startDate = ''
                }
              } else {
                this.queryParams2.startDate = ''
              }
            })
          await getTimeConfig({
              year: endYear,
              month: endMonth,
            })
            .then((res) => {
              if (res.data.length > 0) {
                let resData = res.data[0]
                if (resData.fourWeek) {
                  this.queryParams2.endDate = resData.fourWeek.slice(11, 21)
                } else {
                  this.queryParams2.endDate = ''
                }
              } else {
                this.queryParams2.endDate = ''
              }
            })
          this.getList2()
        }
      },
      //查询列表
      getList1(flag) {
        let startDate = this.queryParams1.dateRange[0];
        let endDate = this.queryParams1.dateRange[1];
        if (!this.queryParams1.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams1.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法统计数据`
          });
          return;
        }
        this.tableLoading1 = true
        getSalPersonAnalysis(
          this.queryParams1
        ).then((res) => {
          this.tableLoading1 = false
          this.tableData1 = res.data;
        });
        if (!flag) {
          getSalPersonTotal(
            this.queryParams1
          ).then((res) => {
            this.clientData1 = res.data;
            this.$nextTick(() => {
              this.clientInitChart1();
            });
          });
        }
      },
      getList2(flag) {
        let startDate = this.queryParams2.dateRange[0];
        let endDate = this.queryParams2.dateRange[1];
        if (!this.queryParams2.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams2.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法统计数据`
          });
          return;
        }
        this.tableLoading2 = true
        getSalPersonAreaAnalysis(
          this.queryParams2
        ).then((res) => {
          this.tableLoading2 = false
          this.tableData2 = res.data;
        });
        if (!flag) {
          getSalPersonAreaTotal(
            this.queryParams2
          ).then((res) => {
            this.clientData2 = res.data;
            this.$nextTick(() => {
              this.clientInitChart2();
            });
          });
        }
      },
      //重置列表
      async resetQuery() {
        let startDate = this.getBeforeMonth(0);
        let endDate = this.getBeforeMonth(0);
        this.queryParams1.dateRange = [startDate, endDate];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        await getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams1.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams1.startDate = ''
              }
            } else {
              this.queryParams1.startDate = ''
            }
          })
        await getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams1.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams1.endDate = ''
              }
            } else {
              this.queryParams1.endDate = ''
            }
          })
        this.getList1()
      },
      //导出
      handleExport1() {
        let startDate = this.queryParams1.dateRange[0];
        let endDate = this.queryParams1.dateRange[1];
        if (!this.queryParams1.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams1.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading1 = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList1(this.queryParams1);
          })
          .then((response) => {
            this.$download.excel(response, '业务员业绩.xls');
            this.exportLoading1 = false;
          })
          .catch(() => {
            this.exportLoading1 = false;
          });
      },
      handleExport2() {
        let startDate = this.queryParams2.dateRange[0];
        let endDate = this.queryParams2.dateRange[1];
        if (!this.queryParams2.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams2.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading2 = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList2(this.queryParams2);
          })
          .then((response) => {
            this.$download.excel(response, '大区业绩.xls');
            this.exportLoading2 = false;
          })
          .catch(() => {
            this.exportLoading2 = false;
          });
      },
      //初始化柱状图
      async clientInitChart1() {
        let data = this.clientData1;
        let highPrice = data.highPrice;
        let newOrder = data.newOrder;
        let saleAmount = data.saleAmount;
        let ywy = data.ywy;
        this.clientChart1 = echarts.init(document.getElementById('clientOut1'), 'macarons');
        this.clientChart1.setOption({
          legend: {
            right: 30,
          },
          tooltip: {
            trigger: 'axis',
          },
          color: ['#0092ff', '#ee6666', '#fac858'],
          xAxis: {
            type: 'category',
            data: ywy,
          },
          yAxis: {
            type: 'value'
          },
          series: [{
              name: '销售量',
              data: saleAmount,
              type: 'bar',
              barWidth: '20%',
            },
            {
              name: '新客单',
              data: newOrder,
              type: 'bar',
              barWidth: '20%',
            },
            {
              name: '高价单',
              data: highPrice,
              type: 'bar',
              barWidth: '20%',
            },
          ],
        });
      },
      async clientInitChart2() {
        let data = this.clientData2;
        let areas = data.areas;
        let highPrice = data.highPrice;
        let newOrder = data.newOrder;
        let saleAmount = data.saleAmount;
        let saleSum = data.saleSum;
        this.clientChart2 = echarts.init(document.getElementById('clientOut2'), 'macarons');
        this.clientChart2.setOption({
          legend: {
            right: 30,
          },
          tooltip: {
            trigger: 'axis',
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75'],
          xAxis: {
            type: 'category',
            data: areas,
          },
          yAxis: {
            type: 'value'
          },
          series: [{
              name: '销售量',
              data: saleSum,
              type: 'bar',
              barWidth: '10%',
            },
            {
              name: '新客单',
              data: newOrder,
              type: 'bar',
              barWidth: '10%',
            },
            {
              name: '高价单',
              data: highPrice,
              type: 'bar',
              barWidth: '10%',
            },
            {
              name: '销售额',
              data: saleSum,
              type: 'bar',
              barWidth: '10%',
            },
          ],
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  .dashboard-editor-container {
    padding: 32px;
    background-color: rgb(240, 242, 245);
    position: relative;

    .row-btm {
      margin-bottom: 8px;
    }
  }
</style>
