<template>
  <div class="dashboard-editor-container">
    <!-- 客户数统计 -->
    <el-row class="row-btm">
      <el-card class="box-card">
        <div class="home-sys-record_wrapper">
          <div class="record-item">
            <span class="item-label">总客户数</span>
            <countTo class="item-value" :end="systemBriefInfo?.customerCount?systemBriefInfo.customerCount : 0" />
          </div>
          <div class="record-item">
            <span class="item-label">加工厂</span>
            <countTo class="item-value" :end="systemBriefInfo?.jgc?systemBriefInfo.jgc : 0" />
          </div>
          <div class="record-item">
            <span class="item-label">贸易</span>
            <countTo class="item-value" :end="systemBriefInfo?.my?systemBriefInfo.my : 0" />
          </div>
          <div class="record-item">
            <span class="item-label">出口</span>
            <countTo class="item-value" :end="systemBriefInfo?.ck?systemBriefInfo.ck : 0" />
          </div>
          <div class="record-item">
            <span class="item-label">快餐</span>
            <countTo class="item-value" :end="systemBriefInfo?.kc?systemBriefInfo.kc : 0" />
          </div>
          <div class="record-item">
            <span class="item-label">商超</span>
            <countTo class="item-value" :end="systemBriefInfo?.sc?systemBriefInfo.sc : 0" />
          </div>
          <div class="record-item">
            <span class="item-label">经批</span>
            <countTo class="item-value" :end="systemBriefInfo?.jp?systemBriefInfo.jp : 0" />
          </div>
        </div>
      </el-card>
    </el-row>
    <!-- 销售渠道-->
    <el-row class="row-btm">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>销售渠道</span>
          <div>
            <el-form ref="weekInQuery" size="small" :inline="true" label-width="60px">
              <el-form-item label="部门" prop="area">
                <el-select v-model="queryParams.area" placeholder="请选择部门" style="width: 140px" filterable clearable>
                  <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item>
                <el-date-picker :clearable="false" v-model="queryParams.dateRange" type="monthrange" range-separator="至"
                  start-placeholder="开始月份" end-placeholder="结束月份" @change="changeDate" value-format="yyyy-MM">
                </el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button icon="el-icon-search" @click="getList()">查询</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
        <div>
          <el-table row-key="id" :data="tableData" border v-loading="tableLoading" show-summary>
            <el-table-column prop="customerTypeName" label="渠道" min-width="100" align="center" fixed></el-table-column>
            <el-table-column label="总计" align="center">
              <el-table-column prop="saleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="saleSum" label="总金额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column label="均单价(元/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgNum }}
                </template>
              </el-table-column>
              <el-table-column label="均单量(吨/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.avgAmount }}
                </template>
              </el-table-column>
              <el-table-column prop="minPriceConunt" label="低价单" min-width="100" align="center"></el-table-column>
              <el-table-column prop="maxPriceConunt" label="高价单" min-width="100" align="center"></el-table-column>
              <el-table-column prop="orderNo" label="订单量" min-width="100" align="center"></el-table-column>
              <el-table-column prop="customerCode" label="成交客户数" min-width="100" align="center"></el-table-column>
              <el-table-column prop="newOrder" label="新客单" min-width="100" align="center"></el-table-column>
            </el-table-column>
            <el-table-column label="一厂" align="center">
              <el-table-column prop="ycSaleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="ycSaleSum" label="总库额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column label="均单价(元/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.ycAvgNum }}
                </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="二厂" align="center">
              <el-table-column prop="ecSaleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="ecSaleSum" label="总库额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column label="均单价(元/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.ecAvgNum }}
                </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="朝阳" align="center">
              <el-table-column prop="cySaleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="cySaleSum" label="总库额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column label="均单价(元/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.cyAvgNum }}
                </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="喀左" align="center">
              <el-table-column prop="kzSaleAmount" label="销售量(吨)" min-width="100" align="center"></el-table-column>
              <el-table-column prop="kzSaleSum" label="总库额(万元)" min-width="100" align="center"></el-table-column>
              <el-table-column label="均单价(元/单)" min-width="100" align="center">
                <template v-slot="{row}">
                  {{ row.kzAvgNum }}
                </template>
              </el-table-column>
            </el-table-column>
          </el-table>
        </div>
        <!-- 销售统计饼图-->
        <el-row :gutter="8" class="row-btm">
          <el-col :span="7">
            <div id="salesOut" style="height:260px;width:100%;" />
          </el-col>
          <el-col :span="7">
            <div id="turnoverOut" style="height:260px;width:100%;" />
          </el-col>
          <el-col :span="10">
            <div id="clientOut" style="height:260px;width:100%;" />
          </el-col>
        </el-row>
      </el-card>
    </el-row>
    <!-- 销售区域 -->
    <el-row class="row-btm">
      <ClientCard />
    </el-row>
  </div>
</template>

<script>
  import * as echarts from 'echarts';
  require('echarts/theme/macarons'); // echarts theme
  import resize from '@/views/dashboard/mixins/resize';
  import {
    getTimeConfig,
    getCustomerTotal,
    getCustomerAnalysis,
    getQdCustomerTotal,
  } from '@/api/Analyse/ClientAnalyse';
  import ClientCard from '../card/clientCard/index';
  import CountTo from "@/components/count-to";
  export default {
    name: 'ClientAnalyse',
    mixins: [resize],
    components: {
      ClientCard,
      CountTo,
    },
    data() {
      return {
        queryParams: {
          area: '',
          dateRange: [],
          startDate: '',
          endDate: '',
        },
        tableData: [],
        tableLoading: false,
        timeArr: [],
        salesData: [],
        turnoverData: [],
        clientData: {},
        salesChart: null,
        turnoverChart: null,
        clientChart: null,
        systemBriefInfo: {}, //客户统计数
        options: this.getDictDatas('hfywbm'), //业务部门
      };
    },
    async mounted() {
      let startDate = this.getBeforeMonth(0);
      let endDate = this.getBeforeMonth(0);
      this.queryParams.dateRange = [startDate, endDate];
      let startYear = startDate.slice(0, 4);
      let startMonth = startDate.slice(5, 7);
      let endYear = endDate.slice(0, 4);
      let endMonth = endDate.slice(5, 7);
      this.getCustomerTotal()
      await getTimeConfig({
          year: startYear,
          month: startMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.oneWeek) {
              this.queryParams.startDate = resData.oneWeek.slice(0, 10)
            } else {
              this.queryParams.startDate = ''
            }
          } else {
            this.queryParams.startDate = ''
          }
        })
      await getTimeConfig({
          year: endYear,
          month: endMonth,
        })
        .then((res) => {
          if (res.data.length > 0) {
            let resData = res.data[0]
            if (resData.fourWeek) {
              this.queryParams.endDate = resData.fourWeek.slice(11, 21)
            } else {
              this.queryParams.endDate = ''
            }
          } else {
            this.queryParams.endDate = ''
          }
        })
      this.getList()
    },
    beforeDestroy() {
      if (this.salesChart) {
        this.salesChart.dispose();
        this.salesChart = null;
      }
      if (this.turnoverChart) {
        this.turnoverChart.dispose();
        this.turnoverChart = null;
      }
      if (this.clientChart) {
        this.clientChart.dispose();
        this.clientChart = null;
      }
    },
    methods: {
      //获取客户数接口
      getCustomerTotal(flag) {
        getCustomerTotal().then((res) => {
          this.systemBriefInfo = res.data;
        });
      },
      //配置月份
      changeDate() {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        let startYear = startDate.slice(0, 4);
        let startMonth = startDate.slice(5, 7);
        let endYear = endDate.slice(0, 4);
        let endMonth = endDate.slice(5, 7);
        getTimeConfig({
            year: startYear,
            month: startMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
              } else {
                this.queryParams.startDate = ''
              }
            } else {
              this.queryParams.startDate = ''
            }
          })
        getTimeConfig({
            year: endYear,
            month: endMonth,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.fourWeek) {
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.endDate = ''
            }
          })
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
      //获取列表接口
      getList(flag) {
        let startDate = this.queryParams.dateRange[0];
        let endDate = this.queryParams.dateRange[1];
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法统计数据`
          });
          return;
        }
        this.tableLoading = true
        getCustomerAnalysis(
          this.queryParams
        ).then((res) => {
          this.tableLoading = false
          this.tableData = res.data;
          this.salesData = []
          this.turnoverData = []
          this.tableData.forEach(item => {
            this.salesData.push({
              value: item.saleAmount,
              name: item.customerTypeName
            })
            this.turnoverData.push({
              value: item.saleSum,
              name: item.customerTypeName
            })
          })
          this.$nextTick(() => {
            this.salesInitChart();
            this.turnoverInitChart();
          });
        });
        if (!flag) {
          getQdCustomerTotal(
            this.queryParams
          ).then((res) => {
            this.clientData = res.data;
            this.$nextTick(() => {
              this.clientInitChart();
            });
          });
        }
      },
      getData() {
        return new Promise((resolve, reject) => {
          inventoryTrend(this.queryParams).then((res) => {
            if (res.code == 0) {
              resolve(res.data);
            }
          });
        });
      },
      //渠道销量占比
      salesInitChart() {
        this.salesChart = echarts.init(document.getElementById('salesOut'), 'macarons');
        this.salesChart.setOption({
          title: {
            text: '渠道销量占比',
            left: 'center',
            bottom: 0,
            textStyle: {
              color: '#000',
              fontSize: 14
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)',
          },
          legend: {
            orient: 'vertical',
            top: 'center',
            right: 0,
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75', '#fc8452', '#9a60b4'],
          series: [{
            name: '渠道销量占比',
            type: 'pie',
            radius: ['20%', '40%'],
            center: ['40%', '50%'],
            label: {
              //文字部分 显示内容为{b}：{c}可以换自己像显示的
              formatter: '{b}\n{c}',
              //折线图文字颜色
              color: "#000000",
            },
            // 折线图长度
            labelLine: { // 指示线的配置
              show: true, // 显示指示线
              length: 10, // 指示线的长度
              length2: 10, // 指示线的第二段长度
              smooth: 0.2, // 指示线平滑度
            },
            data: this.salesData,
          }, ],
        });
      },
      //渠道销售额占比
      turnoverInitChart() {
        this.turnoverChart = echarts.init(document.getElementById('turnoverOut'), 'macarons');
        this.turnoverChart.setOption({
          title: {
            text: '渠道销售额占比',
            left: 'center',
            bottom: 0,
            textStyle: {
              color: '#000',
              fontSize: 14
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)',
          },
          legend: {
            orient: 'vertical',
            top: 'center',
            right: 0,
          },
          color: ['#0092ff', '#ee6666', '#fac858', '#91cc75', '#fc8452', '#9a60b4'],
          series: [{
            name: '渠道销售额占比',
            type: 'pie',
            radius: ['20%', '40%'],
            center: ['40%', '50%'],
            label: {
              //文字部分 显示内容为{b}：{c}可以换自己像显示的
              formatter: '{b}\n{c}',
              //折线图文字颜色
              color: "#000000",
            },
            // 折线图长度
            labelLine: { // 指示线的配置
              show: true, // 显示指示线
              length: 10, // 指示线的长度
              length2: 10, // 指示线的第二段长度
              smooth: 0.2, // 指示线平滑度
            },
            data: this.turnoverData,
          }, ],
        });
      },
      //客户柱形图
      async clientInitChart() {
        let data = this.clientData;
        let qd = data.qd;
        let khs = data.khs;
        let zkhs = data.zkhs;
        this.clientChart = echarts.init(document.getElementById('clientOut'), 'macarons');
        this.clientChart.setOption({
          title: {
            text: '渠道客户数',
            left: 'center',
            bottom: 0,
            textStyle: {
              color: '#000',
              fontSize: 14
            }
          },
          legend: {
            right: 30,
          },
          tooltip: {
            trigger: 'axis',
          },
          color: ['#0092ff', '#ee6666'],
          xAxis: {
            type: 'category',
            data: qd,
          },
          yAxis: {
            type: 'value'
          },
          series: [{
              name: '总客户数',
              data: zkhs,
              // data: this.clientData,
              type: 'bar',
              barWidth: '20%',
            },
            {
              name: '成交客户数',
              data: khs,
              // data: this.clientData,
              type: 'bar',
              barWidth: '20%',
            },
          ],
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .el-table--medium .el-table__cell {
    padding: 0 !important;
  }

  .dashboard-editor-container {
    padding: 32px;
    background-color: rgb(240, 242, 245);
    position: relative;

    .row-btm {
      margin-bottom: 8px;
    }
  }

  .home-sys-record_wrapper {
    display: flex;
    justify-content: space-around;

    .record-item {
      background: linear-gradient(to bottom right, rgb(217 236 245), rgb(255 255 255));
      width: calc(14% - 28px);
      height: 80px;
      display: flex;
      flex-direction: column;
      align-items: center;
      border: 1px solid #eaebed;
      border-radius: 6px;
      padding: 4px;

      .item-label {
        font-size: 16px;
      }

      .item-value {
        font-weight: bold;
        font-size: 18px;
      }
    }
  }
</style>
