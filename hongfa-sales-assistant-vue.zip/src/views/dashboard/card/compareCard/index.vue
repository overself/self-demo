<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix" >
      <span>业绩对比</span>
      <div v-if="false" style="display: flex; float: right; padding: 3px 0">
        <ChartFactorySelect @radioChange="handleChange" />
      </div>
    </div>

    <div style="display: flex; height: 355px">
      <span>迭代中：预计二期上线</span>
      <compareChart v-if="false" width="50%" :chartsData="chartsData" />
      <div v-if="false" class="info-wrapper">
        <div class="item">
          <div>部门</div>
          <div>总量</div>
          <div>占比</div>
        </div>
        <div class="item">
          <div>一区</div>
          <div>{{chartsData?.oneSaleNum?chartsData.oneSaleNum : 0}}</div>
          <div>{{chartsData?.oneSaleNumScale?chartsData.oneSaleNumScale : 0}}%</div>
        </div>
        <div class="item">
          <div>二区</div>
          <div>{{chartsData?.twoSaleNum?chartsData.twoSaleNum : 0}}</div>
          <div>{{chartsData?.twoSaleNumScale?chartsData.twoSaleNumScale : 0}}%</div>
        </div>
        <div class="item">
          <div>三区</div>
          <div>{{chartsData?.threeSaleNum?chartsData.threeSaleNum : 0}}</div>
          <div>{{chartsData?.threeSaleNumScale?chartsData.threeSaleNumScale : 0}}%</div>
        </div>
        <div class="item">
          <div>集团</div>
          <div>{{chartsData?.groupSaleNum?chartsData.groupSaleNum : 0}}</div>
          <div>{{chartsData?.groupSaleNumScale?chartsData.groupSaleNumScale : 0}}%</div>
        </div>
        <div class="item">
          <div>其他</div>
          <div>{{chartsData?.otherSaleNum?chartsData.otherSaleNum : 0}}</div>
          <div>{{chartsData?.otherSaleNumScale?chartsData.otherSaleNumScale : 0}}%</div>
        </div>
      </div>
    </div>
  </el-card>
</template>

  <script>
import compareChart from './compareChart';
import ChartFactorySelect from '@/components/ChartFactorySelect/index2';
import ChartFactorySelect3 from '@/components/ChartFactorySelect/index3';
import { copmpareAcheieve } from '@/api/Home/index';
export default {
  components: {
    ChartFactorySelect,
    compareChart,
    ChartFactorySelect3,
  },
  created() {
    this.initDate();
  },
  data() {
    return {
      queryParams: {
        // fromDate: '',
        // toDate: '',
        paramKey: '1',
      },
      chartsData: {},
    };
  },
  methods: {
    initDate() {
      //   this.queryParams.fromDate = this.getMonth()[0];
      //   this.queryParams.toDate = this.getMonth()[1];
      this.getList();
    },

    getMonth() {
      const now = new Date();
      const year = new Date().getFullYear();
      const currentMonth = now.getMonth() + 1;
      const lastDay = new Date(year, currentMonth, 0).getDate();
      const currentMonthStr =
        currentMonth > 9 ? currentMonth : '0' + currentMonth;
      return [
        year + '-' + currentMonthStr + '-01',
        year + '-' + currentMonthStr + '-' + lastDay,
      ];
    },
    handleChange(val) {
      //   this.queryParams.fromDate = val[0];
      //   this.queryParams.toDate = val[1];
      this.queryParams.paramKey = val;
      this.getList();
    },
    handleTimeTChange() {},
    getList() {
      copmpareAcheieve(this.queryParams).then((res) => {
        this.chartsData = res.data;
      });
    },
  },
};
</script>

  <style lang="scss" scoped>
.info-wrapper {
  display: flex;
  flex-direction: column;
  width: 50%;
  justify-content: space-around;

  .plan-info-wrapper {
    display: flex;
    justify-content: space-around;

    .plan-info-item {
      display: flex;
      flex-direction: column;

      .label {
        margin-bottom: 20px;
      }

      .value {
        font-weight: 700;
      }
    }
  }

  .factory-info-wrapper {
    display: flex;
    justify-content: space-around;

    .factory-info-item {
      display: flex;
      flex-direction: column;

      .label {
        margin-bottom: 20px;
      }

      .value {
        margin-bottom: 20px;
        font-weight: 700;
      }
    }
  }

  .plan {
    color: #3399ff;
  }

  .complete {
    color: #2fc25b;
  }
}
.info-wrapper {
  .item {
    display: flex;
    justify-content: space-around;
  }
}
</style>
