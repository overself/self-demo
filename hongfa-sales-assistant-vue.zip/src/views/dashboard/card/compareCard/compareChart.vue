<template>
  <div
    :class="className"
    :style="{height:height,width:width}"
  />
</template>

  <script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '100%',
    },
    height: {
      type: String,
      default: '336px',
    },
    chartsData: {
      type: Object,
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  watch: {
    chartsData: {
      handler(val) {
        this.initChart();
      },
      deep: true,
    },
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el);

      this.chart.setOption({
        tooltip: {
          trigger: 'item',
        },
        legend: {
          top: '5%',
          left: 'center',
        },
color: ['#0092ff', '#ee6666', '#fac858', '#91cc75', '#fc8452'],
        series: [
          {
            name: '业绩对比',
            type: 'pie',
            radius: ['25%', '55%'],
            // avoidLabelOverlap: false,
            label: {
              show: false,
              position: 'center',
            },
            // emphasis: {
            //   label: {
            //     show: true,
            //     fontSize: 40,
            //     fontWeight: 'bold',
            //   },
            // },
            labelLine: {
              normal: {
                show: false, // 不显示标签指引线
              },
            },
            data: [
              { value: this.chartsData.oneSaleNum, name: '一区' },
              { value: this.chartsData.twoSaleNum, name: '二区' },
              { value: this.chartsData.threeSaleNum, name: '三区' },
              { value: this.chartsData.groupSaleNum, name: '集团' },
              { value: this.chartsData.otherSaleNum, name: '其他' },
            ],
          },
        ],
      });
    },
  },
};
</script>
