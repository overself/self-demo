<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>快速入口</span>
    </div>
    <div>
      <el-row :gutter="8">
        <div class="entrance-item" v-for="(item, index) in entranceList" :key='index'>
          <el-col :span="4">
            <a href="javascript:void(0)" @click="toNext(item)">
              <img class="entrance-icon" :src="item.icon" alt="" srcset="">
              <span class="entrance-label">{{ item.label }}</span>
            </a>
          </el-col>
        </div>
      </el-row>
    </div>
  </el-card>
</template>

<script>
import { getUserProfile } from '@/api/system/user';

export default {
  data() {
    return {
      user: {
        posts: [],
      },
      entranceList: [
        {
          icon: require('@/assets/images/index_icon1.png'),
          path: '/board/PriceBorad',
          label: '价格库存看板',
        },
        {
          icon: require('@/assets/images/index_icon2.png'),
          path: '/client/client-control',
          label: '新增跟进',
        },
        {
          icon: require('@/assets/images/index_icon3.png'),
          path: '/client/client-control',
          label: '客户管理',
        },
        /* TODO:HWJ 出库单查询入口暂时去掉
        {
          icon: require('@/assets/images/index_icon4.png'),
          path: '/delivery/sales-delivery',
          label: '出库单查询',
        },*/
        {
          icon: require('@/assets/images/index_icon5.png'),
          path: '/client/client-control',
          label: '编辑客户',
        },
        // {
        //   icon: require('@/assets/images/index_icon6.png'),
        //   path: '/personal/salesman',
        //   label: '个人中心',
        // },
      ],
    };
  },

  created() {
    this.getUser();
  },

  methods: {
    toNext(item) {
      if (item.label == '个人中心') {
        if (this.user.posts.length) {
          if (this.user.posts.findIndex((item) => item.id == 2) !== -1) {
            // 经理
            this.$router.push({
              // path: '/personal/manager',
              path: '/personal/salesman',
            });
            return;
          } else if (this.user.posts.findIndex((item) => item.id == 3) !== -1) {
            // 销售
            this.$router.push({
              path: '/personal/salesman',
            });
            return;
          }
        }

        this.$notify.error({ title: '暂无权限' });
      } else {
        this.$router.push({
          path: item.path,
        });
      }
    },

    getUser() {
      getUserProfile().then((res) => {
        // console.log(res.data);
        this.user = res.data;
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.entrance-item {
  a {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .entrance-icon {
    width: 85px;
    height: 85px;
    margin-bottom: 20px;
  }

  .entrance-label {
    font-family: PingFang SC, PingFang SC;
    font-weight: 400;
    font-size: 16px;
    color: #000;
    line-height: 19px;
  }
}
</style>
