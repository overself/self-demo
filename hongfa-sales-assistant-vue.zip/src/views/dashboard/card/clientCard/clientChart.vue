<template>
  <div>
    <div
      :class="className"
      :style="{height:height,width:width}"
      id="main"
    ></div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';
import GeoJson from '@/utils/geoJson.json';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '300px',
    },
    height: {
      type: String,
      default: '400px',
    },
    chartsData: {
      type: Array,
    },
  },
  data() {
    return {
      chart: null,
      seriesData: [],
    };
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
    console.log(GeoJson, 'GeoJson');
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },

  watch: {
    chartsData: {
      handler(val) {
        if (val.length) {
          val.forEach((item, index) => {
            this.seriesData[index] = {
              name: '',
              value: '',
            };
            switch (item.location) {
              case '北京':
                this.seriesData[index].name = '北京市';
                break;
              case '上海':
                this.seriesData[index].name = '上海市';
                break;
              case '重庆':
                this.seriesData[index].name = '重庆市';
                break;
              case '天津':
                this.seriesData[index].name = '天津市';
                break;

              default:
                this.seriesData[index].name = item.location;
                break;
            }

            this.seriesData[index].value = item.customerNumber;
          });
        } else {
          this.seriesData = [];
        }

        this.initChart();
      },
      deep: true,
    },
  },
  methods: {
    highlightProvince(provinceName, lastName) {
      //   var option = this.chart.getOption();
      //   option.series[0].data = option.series[0].data.map(function (item) {
      //     if (item.name === provinceName) {
      //       return { ...item, itemStyle: { areaColor: '#3399ff' } }; // 高亮颜色
      //     } else {
      //       return item;
      //     }
      //   });

      //   this.chart.setOption({
      //     series: [
      //       {
      //         data: [
      //           // {
      //           //   name: provinceName,
      //           //   value: 119,
      //           //   tipData: [
      //           //     Math.round(Math.random() * 1000),
      //           //     Math.round(Math.random() * 1000),
      //           //   ],
      //           //   itemStyle: { emphasis: { areaColor: '#ff0000' } },
      //           // },
      //           //   {
      //           //     name: '黑龙江省',
      //           //     value: 8867,
      //           //     tipData: [
      //           //       Math.round(Math.random() * 1000),
      //           //       Math.round(Math.random() * 1000),
      //           //     ],
      //           //     itemStyle: { emphasis: { areaColor: '#ff0000' } },
      //           //   },
      //         ],
      //       },
      //     ],
      //   });

      this.chart.dispatchAction({
        type: 'downplay',
        // seriesIndex: 0,
        // dataIndex: 0,
        name: lastName,
      });
      this.chart.dispatchAction({
        type: 'showTip',
        name: provinceName,
      });
      this.chart.dispatchAction({
        type: 'highlight',
        // seriesIndex: 0,
        // dataIndex: 0,
        name: provinceName,
      });
    },

    initChart() {
      echarts.registerMap('china', { geoJSON: GeoJson });
      this.chart = echarts.init(document.getElementById('main'), 'macarons');

      let option = {
        visualMap: {
          left: 'left',
          top: 'bottom',
          text: ['高', '低'],
          calculable: false,
          orient: 'horizontal',
          inRange: {
            color: ['#ffffff', '#2f7ecd'],
            symbolSize: [30, 100],
          },
        },
        tooltip: {
          padding: 8,
          enterable: true,
          transitionDuration: 1,
          textStyle: {
            color: '#121212',
            decoration: 'none',
          },
        },
        // title: {
        //   text: '广东省119', // 显示总量
        //   left: 'center',
        //   top: '200',
        //   textStyle: {
        //     fontSize: 24,
        //     fontWeight: 'bold',
        //     align: 'center',
        //     color: '#3399ff',
        //   },
        // },
        series: [
          {
            name: '客户分布',
            type: 'map',
            mapType: 'china',
            left: 0,
            right: 0,
            // emphasis: {
            //   label: {
            //     show: true,
            //     areaColor: 'green',
            //   },
            // },
            itemStyle: {
              normal: {
                label: {
                  show: false,
                },
              },
              emphasis: {
                areaColor: '#0971db',
                label: {
                  show: true,
                },
              },
            },
            label: {
              normal: {
                //静态的时候展示样式
                show: false, //是否显示地图省份得名称
                textStyle: {
                  color: '#000',
                  fontSize: 12,
                },
              },
              emphasis: {
                //动态展示的样式
                color: '#000',
              },
            },
            data: this.seriesData,
          },
        ],
      };

      this.chart.setOption(option);
    },
  },
};
</script>
