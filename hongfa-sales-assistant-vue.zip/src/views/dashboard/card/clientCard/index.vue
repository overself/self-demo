<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>客户分布</span>

      <div style="display: flex; float: right; padding: 3px 0">
        <ChartFactorySelect2 @radioChange="handleTimeChange" />
      </div>
    </div>

    <div style="display: flex;justify-content: space-around;">
      <div>
        <el-radio-group v-model="factoryValue" @input="handleInput">
          <el-radio-button v-for="(item, index) in options" :key="index" :label="item.value">{{ item.label
          }}</el-radio-button>
        </el-radio-group>
        <ClientChart :chartsData="tableData" ref="ClientChartRef" />
      </div>

      <div class="info-wrapper">
        <el-table :data="tableData" style="width: 100%;" :row-style="{ height: '60px' }" stripe
          @row-click="handleTableClick">
          <el-table-column type="index" label="排名前五" header-align="center" align="center"
            width="90px"></el-table-column>

          <el-table-column prop="location" label="所在区域" header-align="center" align="center"> </el-table-column>

          <el-table-column prop="output" label="出库数量" header-align="center" align="center"> </el-table-column>

          <el-table-column prop="newCustomerNumber" label="数量/新客" header-align="center" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.customerNumber }}/{{ scope.row.newCustomerNumber }}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </el-card>
</template>

<script>
import ClientChart from './clientChart';
import { customerDist } from '@/api/Home/index';
import ChartFactorySelect2 from '@/components/ChartFactorySelect/index2';
export default {
  components: {
    ClientChart,
    ChartFactorySelect2,
  },

  data() {
    return {
      queryParams: {
        // fromDate: '',
        // toDate: '',
        paramKey: '1',
        sortParam: 'sales',
      },
      options: [
        { label: '按销量排名', value: '1' },
        { label: '按客户数排名', value: '2' },
        { label: '按新客户排名', value: '3' },
      ],
      factoryValue: '1',
      tableData: [],
      lastName: '',
      name: '',
    };
  },
  created() {
    // this.initDate();
    this.getList();
  },
  methods: {
    initDate() {
      this.queryParams.fromDate = this.getMonth()[0];
      this.queryParams.toDate = this.getMonth()[1];
      this.getList();
    },
    getMonth() {
      const now = new Date();
      const year = new Date().getFullYear();
      const currentMonth = now.getMonth() + 1;
      const lastDay = new Date(year, currentMonth, 0).getDate();
      const currentMonthStr =
        currentMonth > 9 ? currentMonth : '0' + currentMonth;
      return [
        year + '-' + currentMonthStr + '-01',
        year + '-' + currentMonthStr + '-' + lastDay,
      ];
    },
    handleTimeChange(val) {
      //   this.queryParams.fromDate = val[0];
      //   this.queryParams.toDate = val[1];
      this.queryParams.paramKey = val;
      this.getList();
    },
    handleInput(e) {
      switch (e) {
        case '1':
          this.queryParams.sortParam = 'sales';
          break;
        case '2':
          this.queryParams.sortParam = 'customer';
          break;
        case '3':
          this.queryParams.sortParam = 'newCustomer';
          break;

        default:
          break;
      }
      this.getList();
    },
    getList() {
      customerDist(this.queryParams).then((res) => {
        this.tableData = res.data;
      });
    },
    handleTableClick(row) {
      this.lastName = this.name;
      switch (row.location) {
        case '北京':
          this.name = '北京市';
          break;
        case '上海':
          this.name = '上海市';
          break;
        case '重庆':
          this.name = '重庆市';
          break;
        case '天津':
          this.name = '天津市';
          break;

        default:
          this.name = row.location;
          break;
      }

      this.$refs.ClientChartRef.highlightProvince(this.name, this.lastName);
    },
  },
};
</script>

<style lang="scss" scoped>
.info-wrapper {
  display: flex;
  flex-direction: column;
  width: 50%;
  justify-content: space-around;
}

.el-table::before {
  height: 0;
}
</style>
