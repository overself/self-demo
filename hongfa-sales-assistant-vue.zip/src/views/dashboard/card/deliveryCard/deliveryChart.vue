<template>
  <div
    :class="className"
    :style="{height:height,width:width}"
  />
</template>

<script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '100%',
    },
    height: {
      type: String,
      default: '300px',
    },
    chartsData: {
      type: Object,
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  watch: {
    chartsData: {
      handler(val) {
        this.setOptions(val);
      },
      deep: true,
    },
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    setOptions(type) {
      this.chart.setOption({
        title: {
          text:
            type == 1
              ? ''
              : '完成度\n' +
                (this.chartsData.planOutput != 0
                  ? (
                      (this.chartsData.finishOutput /
                        this.chartsData.planOutput) *
                      100
                    ).toFixed(2)
                  : 100) +
                '%', // 显示总量
          left: 'center',
          top: 'center',
          textStyle: {
            fontSize: 24,
            fontWeight: 'bold',
            align: 'center',
            color: '#91cc75',
          },
        },
        tooltip: {
          trigger: 'item',
        },
        grid: {
          bottom: 10,
        },
        legend: {
          top: '5%',
          left: 'center',
        },
        color: ['#0092ff', '#91cc75'],
        series: [
          {
            name: '',
            type: 'pie',
            radius: ['40%', '70%'],
            avoidLabelOverlap: false,
            label: {
              show: false,
              position: 'center',
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 18,
                fontWeight: '400 ',
              },
            },
            labelLine: {
              show: false,
            },
            data: [
              { value: this.chartsData.planOutput, name: '计划出库量' },
              { value: this.chartsData.finishOutput, name: '实际出库量' },
            ],
          },
        ],
      });
    },
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons');
      this.setOptions();
      let that = this;
      setTimeout(() => {
        this.chart.on('mouseout', function (params) {
          that.setOptions();
        });
        this.chart.on('mouseover', function (params) {
          if (params.componentType === 'series') {
            that.setOptions(1);
          }
        });
      }, 1200);
    },
  },
};
</script>
