<template>
  <el-card class="box-card">
    <div
      slot="header"
      class="clearfix"
    >
      <span>销售计划</span>

      <div style="display: flex; float: right; padding: 3px 0">
        <!-- <el-select
          v-model="companyTargetValue"
          placeholder="请选择"
          style="margin-right: 20px;"
        >
          <el-option
            v-for="item in companyTargetOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select> -->

        <!-- <el-date-picker
          v-model="month"
          type="month"
          placeholder="选择日期"
          format="yyyy-MM"
          value-format="yyyy-MM"
          :clearable="false"
          @change="handleMonthChange"
        >
        </el-date-picker> -->
        <ChartFactorySelect3
          @timeChange="handleTimeChange"
          @initTime="initTime"
        />
      </div>
    </div>
    <ChartFactorySelect
      @radioChange="handleChange"
      :showOther="false"
    />
    <div style="display: flex;">
      <DeliveryChart
        width="50%"
        :chartsData="chartsData"
      />

      <div class="info-wrapper">
        <div class="plan-info-wrapper">
          <div class="plan-info-item">
            <span class="label">计划出库量</span>
            <span class="value plan">{{info?.planOutput?info.planOutput : 0}}吨</span>
          </div>

          <div class="plan-info-item">
            <span class="label">完成出库量</span>
            <span class="value complete">{{info?.finishOutput?info.finishOutput : 0}}吨</span>
          </div>
        </div>

        <div class="factory-info-wrapper">
          <div
            class="factory-info-item"
            v-for="(item,index) in 4"
            :key="item"
          >
            <div
              class="item"
              v-if="index===0"
            >
              <span class="label">北票一厂</span>
              <span class="value plan">{{info?.planBp1?info.planBp1 : 0}}吨</span>
              <span class="value complete">{{info?.finishBp1?info.finishBp1 : 0}}吨</span>
            </div>
            <div
              class="item"
              v-if="index===1"
            >
              <span class="label">北票二厂</span>
              <span class="value plan">{{info?.planBp2?info.planBp2 : 0}}吨</span>
              <span class="value complete">{{info?.finishBp2?info.finishBp2 : 0}}吨</span>
            </div>
            <div
              class="item"
              v-if="index===2"
            >
              <span class="label">朝阳</span>
              <span class="value plan">{{info?.planCy?info.planCy : 0}}吨</span>
              <span class="value complete">{{info?.finishCy?info.finishCy : 0}}吨</span>
            </div>
            <div
              class="item"
              v-if="index===3"
            >
              <span class="label">喀左</span>
              <span class="value plan">{{info?.planKz?info.planKz : 0}}吨</span>
              <span class="value complete">{{info?.finishKz?info.finishKz : 0}}吨</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </el-card>
</template>

<script>
import DeliveryChart from './deliveryChart';
import ChartFactorySelect from '@/components/ChartFactorySelect/index1';
import ChartFactorySelect3 from '@/components/ChartFactorySelect/index3';
import { outputPlan } from '@/api/Home/index';
export default {
  components: {
    DeliveryChart,
    ChartFactorySelect,
    ChartFactorySelect3,
  },
  created() {
    this.initDate();
  },
  data() {
    return {
      companyTargetValue: '',
      date: '',
      chartsData: { planOutput: 0, finishOutput: 0 },
      queryParams: {
        // fromDate: '',
        // toDate: '',
        saleYear: '',
        saleMonth: '',
        dept: undefined,
      },

      month: '',
      info: {},
      //   companyTargetOptions: [
      //     { label: '公司月度目标', value: '1' },
      //     { label: '一区月度目标', value: '2' },
      //     { label: '二区月度目标', value: '3' },
      //     { label: '三区月度目标', value: '4' },
      //   ],
    };
  },
  methods: {
    // initDate() {
    //   const now = new Date();
    //   const year = new Date().getFullYear();
    //   const currentMonth = now.getMonth() + 1;
    //   const lastDay = new Date(year, currentMonth, 0).getDate();
    //   const currentMonthStr =
    //     currentMonth > 9 ? currentMonth : '0' + currentMonth;
    //   this.month = year + '-' + String(currentMonthStr);
    //   this.queryParams.fromDate = year + '-' + currentMonthStr + '-01';
    //   this.queryParams.toDate = year + '-' + currentMonthStr + '-' + lastDay;
    //   this.getList();
    // },
    // handleMonthChange(e) {
    //   const lastDay = new Date(e.split('-')[0], e.split('-')[1], 0).getDate();
    //   this.queryParams.fromDate =
    //     e.split('-')[0] + '-' + e.split('-')[1] + '-01';
    //   this.queryParams.toDate =
    //     e.split('-')[0] + '-' + e.split('-')[1] + '-' + lastDay;
    //   this.getList();
    // },
    initTime(val) {
      let dateArr = val.split('-');
      this.queryParams.saleYear = dateArr[0];
      this.queryParams.saleMonth = dateArr[1];
      this.getList();
    },
    handleTimeChange(val) {
      let dateArr = val.split('-');
      this.queryParams.saleYear = dateArr[0];
      this.queryParams.saleMonth = dateArr[1];
      this.getList();
    },
    handleChange(e) {
      switch (e) {
        case '1':
          this.queryParams.dept = '101';
          break;
        case '2':
          this.queryParams.dept = '102';
          break;
        case '3':
          this.queryParams.dept = '103';
          break;
        case '4':
          this.queryParams.dept = '104';
          break;
        default:
          this.queryParams.dept = undefined;
          break;
      }
      this.getList();
    },
    getList() {
      outputPlan(this.queryParams).then((res) => {
        console.log(res, 'getList');
        this.chartsData.finishOutput = 0;
        this.chartsData.planOutput = 0;
        if (res.code == 0) {
          this.chartsData.finishOutput = res.data.finishOutput;
          this.chartsData.planOutput = res.data.planOutput;
          this.info = res.data;
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.info-wrapper {
  display: flex;
  flex-direction: column;
  width: 50%;
  justify-content: space-around;

  .plan-info-wrapper {
    display: flex;
    justify-content: space-around;

    .plan-info-item {
      display: flex;
      flex-direction: column;

      .label {
        margin-bottom: 20px;
      }

      .value {
        font-weight: 700;
      }
    }
  }

  .factory-info-wrapper {
    display: flex;
    justify-content: space-around;

    .factory-info-item {
      display: flex;
      flex-direction: column;

      .label {
        margin-bottom: 20px;
      }

      .value {
        margin-bottom: 20px;
        font-weight: 700;
      }
    }
  }

  .plan {
    color: #0092ff;
  }

  .complete {
    color: #91cc75;
  }
  .item {
    display: flex;
    flex-direction: column;
  }
}
</style>
