<template>
  <el-card class="box-card">
    <div
      slot="header"
      class="clearfix"
    >
      <span>销售趋势</span>

      <div style="display: flex; float: right; padding: 3px 0">
        <ChartFactorySelect3
          @timeChange="handleTimeChange"
          @initTime="initTime"
        />
      </div>

    </div>
    <ChartFactorySelect
      @radioChange="handleChange"
      style="margin-top:10px"
    />
    <div>
      <SaleChart :chartsData="chartsData" />
    </div>
  </el-card>
</template>

<script>
import SaleChart from './saleChart';
import ChartFactorySelect from '@/components/ChartFactorySelect/index1';
import ChartFactorySelect3 from '@/components/ChartFactorySelect/index3';
import { salesTrend } from '@/api/Home/index';
export default {
  components: {
    SaleChart,
    ChartFactorySelect,
    ChartFactorySelect3,
  },

  data() {
    return {
      queryParams: {
        // fromDate: '',
        // toDate: '',
        saleYear: '',
        saleMonth: '',
        dept: undefined,
      },
      chartsData: {},
    };
  },
  mounted() {
    // this.getLast30Days();
  },
  methods: {
    getLast30Days() {
      let dates = [];
      for (let i = 29; i >= 0; i--) {
        let date = new Date();
        date.setDate(date.getDate() - i);
        dates.push(date.toISOString().split('T')[0]);
      }
      this.queryParams.fromDate = dates[0];
      this.queryParams.toDate = dates[29];
      this.getList();
      //   return dates;
      //   console.log(dates, 'dates');
    },
    initTime(val) {
      let dateArr = val.split('-');
      this.queryParams.saleYear = dateArr[0];
      this.queryParams.saleMonth = dateArr[1];
      this.getList();
    },
    handleTimeChange(val) {
      let dateArr = val.split('-');
      this.queryParams.saleYear = dateArr[0];
      this.queryParams.saleMonth = dateArr[1];
      this.getList();
    },
    handleChange(e) {
      switch (e) {
        case '1':
          this.queryParams.dept = '101';
          break;
        case '2':
          this.queryParams.dept = '102';
          break;
        case '3':
          this.queryParams.dept = '103';
          break;
        case '4':
          this.queryParams.dept = '104';
          break;
        case '5':
          this.queryParams.dept = 'other';
          break;
        default:
          this.queryParams.dept = undefined;
          break;
      }
      this.getList();
    },
    getList() {
      salesTrend(this.queryParams).then((res) => {
        this.chartsData = res.data;
      });
    },
  },
};
</script>
