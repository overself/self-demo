<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>库存趋势</span>

      <div style="display: flex; float: right; padding: 3px 0">
        <!-- <ChartFactorySelect /> -->
        <ChartFactorySelect3 @timeChange="handleTimeChange" @initTime="initTime" />
        <!-- <el-button
          type="text"
          style="margin-left: 20px;"
        >查看更多</el-button> -->
      </div>
    </div>

    <div>
      <StockChart :time="time" :height="'294px'" />
    </div>
  </el-card>
</template>

<script>
  import StockChart from './stockChart';
  import ChartFactorySelect3 from '@/components/ChartFactorySelect/index3';
  export default {
    components: {
      StockChart,
      ChartFactorySelect3,
    },

    data() {
      return {
        time: '',
      };
    },
    methods: {
      initTime(val) {
        this.time = val;
      },
      handleTimeChange(val) {
        this.time = val;
      },
    },
  };
</script>
