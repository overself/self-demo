<template>
  <div :class="className">
    <ChartFactorySelect @radioChange="handleChange" />
    <div
      :style="{height:height,width:width}"
      id="echarts"
    ></div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';
import { inventoryTrend } from '@/api/Home/index';
import ChartFactorySelect from '@/components/ChartFactorySelect/index';

const animationDuration = 6000;

export default {
  mixins: [resize],
  components: {
    ChartFactorySelect,
  },
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '100%',
    },
    height: {
      type: String,
      default: '266px',
    },
    time: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      chart: null,
      queryParams: {
        saleYear: '',
        saleMonth: '',
        factoryType: undefined,
      },
      timeArr: [],
      barData: [],
      lineData: [],
    };
  },
  mounted() {
    // this.getLast30Days();
    this.$nextTick(() => {
      this.initChart();
    });
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  watch: {
    time: {
      handler(val) {
        // console.log(val, 'watch');

        let dateArr = val.split('-');
        this.queryParams.saleYear = dateArr[0];
        this.queryParams.saleMonth = dateArr[1];
        this.initChart();
      },
      deep: true,
    },
  },
  methods: {
    getLast30Days() {
      let dates = [];
      for (let i = 29; i >= 0; i--) {
        let date = new Date();
        date.setDate(date.getDate() - i);
        dates.push(date.toISOString().split('T')[0]);
      }
      this.queryParams.fromDate = dates[0];
      this.queryParams.toDate = dates[29];
      //   return dates;
      //   console.log(dates, 'dates');
    },

    handleChange(e) {
      switch (e) {
        case '1':
          this.queryParams.factoryType = 'bp_1_factory';
          break;
        case '2':
          this.queryParams.factoryType = 'bp_2_factory';
          break;
        case '3':
          this.queryParams.factoryType = 'cy_factory';
          break;
        case '4':
          this.queryParams.factoryType = 'kz_factory';
          break;
        default:
          this.queryParams.factoryType = undefined;
          break;
      }
      this.initChart();
    },
    getData() {
      return new Promise((resolve, reject) => {
        inventoryTrend(this.queryParams).then((res) => {
          if (res.code == 0) {
            resolve(res.data);
          }
        });
      });
    },
    async initChart() {
      if (this.queryParams.saleYear == '') return;
      let data = await this.getData();

      this.timeArr = data.dateList;
      this.barData = data.outputList;
      this.lineData = data.inventoryList;
      this.chart = echarts.init(document.getElementById('echarts'), 'macarons');
      this.chart.setOption({
        legend: {
          right: 30,
        },
        tooltip: {},
        color: ['#0092ff', '#91cc75'],
        // dataset: {
        //   source: [
        //     ['product', '计划', '实际'],
        //     ['Matcha Latte', 43.3, 85.8],
        //     ['Milk Tea', 83.1, 73.4],
        //     ['Cheese Cocoa', 86.4, 65.2],
        //     ['Walnut Brownie', 72.4, 53.9],
        //   ],
        // },
        xAxis: { type: 'category', data: this.timeArr },
        yAxis: { type: 'value' },
        // Declare several bar series, each will be mapped
        // to a column of dataset.source by default.
        series: [
          {
            name: '出库量',
            data: this.barData,
            type: 'bar',
          },

          {
            name: '库存量',
            data: this.lineData,
            type: 'line',
          },
        ],
      });
    },
  },
};
</script>
