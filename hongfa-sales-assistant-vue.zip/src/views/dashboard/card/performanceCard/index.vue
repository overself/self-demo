<template>
  <el-card class="box-card">
    <div
      slot="header"
      class="clearfix"
    >
      <span>业绩排行TOP10</span>

      <div style="display: flex; float: right; padding: 3px 0">
        <el-date-picker
          v-model="date"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          style="margin-right: 20px;"
        ></el-date-picker>

        <ChartFactorySelect :options="selectOptions" />
        <el-button
          type="text"
          style="margin-left: 20px;"
        >查看更多</el-button>
      </div>
    </div>

    <div>
      <PerformanceChart />
    </div>
  </el-card>
</template>

<script>
import PerformanceChart from './performanceChart';
import ChartFactorySelect from '@/components/ChartFactorySelect/index';

export default {
  components: {
    PerformanceChart,
    ChartFactorySelect,
  },

  data() {
    return {
      date: '',
      selectOptions: [
        { label: '总览', value: '1' },
        { label: '新客', value: '2' },
      ],
    };
  },
};
</script>
