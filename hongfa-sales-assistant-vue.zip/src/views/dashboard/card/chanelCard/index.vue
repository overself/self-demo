<template>
  <el-card class="box-card">
    <div
      slot="header"
      class="clearfix"
    >
      <span>渠道销量</span>

      <div style="display: flex; float: right; padding: 3px 0">
        <ChartFactorySelect2 @radioChange="handleTimeChange" />
      </div>
    </div>
    <ChartFactorySelect1 @radioChange="handleDeptChange" />
    <div style="display: flex;">
      <chanelCharts
        width="50%"
        :chartsData="chartsData"
      />
      <div class="info-bottom-wrapper">
        <div class="item">
          <div>渠道</div>
          <div>总量</div>
          <div>占比</div>
        </div>
        <div
          class="item"
          v-for="(item,index) in chartsData"
          :key="index"
        >
          <div>{{ item.channelName }}</div>
          <div>{{item.saleNum ?item.saleNum : 0}}</div>
          <div>{{item.saleNumScale ?item.saleNumScale : 0}}%</div>
        </div>

      </div>
    </div>
  </el-card>
</template>
    
    <script>
import chanelCharts from './chanelCharts';
import ChartFactorySelect1 from '@/components/ChartFactorySelect/index1';
import ChartFactorySelect2 from '@/components/ChartFactorySelect/index2';
import { channelSales } from '@/api/Home/index';
export default {
  components: {
    ChartFactorySelect1,
    ChartFactorySelect2,
    chanelCharts,
  },
  created() {
    // this.initDate();
    this.getList();
  },
  data() {
    return {
      queryParams: {
        // fromDate: '',
        // toDate: '',
        paramKey: '1',
      },
      chartsData: [],
    };
  },
  methods: {
    initDate() {
      this.queryParams.fromDate = this.getMonth()[0];
      this.queryParams.toDate = this.getMonth()[1];
      this.getList();
    },
    getMonth() {
      const now = new Date();
      const year = new Date().getFullYear();
      const currentMonth = now.getMonth() + 1;
      const lastDay = new Date(year, currentMonth, 0).getDate();
      const currentMonthStr =
        currentMonth > 9 ? currentMonth : '0' + currentMonth;
      return [
        year + '-' + currentMonthStr + '-01',
        year + '-' + currentMonthStr + '-' + lastDay,
      ];
    },
    handleTimeChange(val) {
      //   this.queryParams.fromDate = val[0];
      //   this.queryParams.toDate = val[1];
      this.queryParams.paramKey = val;
      this.getList();
    },
    handleDeptChange(e) {
      switch (e) {
        case '1':
          this.queryParams.dept = '101';
          break;
        case '2':
          this.queryParams.dept = '102';
          break;
        case '3':
          this.queryParams.dept = '103';
          break;
        case '4':
          this.queryParams.dept = '104';
          break;
        case '5':
          this.queryParams.dept = 'other';
          break;
        default:
          this.queryParams.dept = undefined;
          break;
      }
      this.getList();
    },
    getList() {
      channelSales(this.queryParams).then((res) => {
        this.chartsData = res.data;
      });
    },
  },
};
</script>
    
    <style lang="scss" scoped>
.info-wrapper {
  display: flex;
  flex-direction: column;
  width: 50%;
  justify-content: space-around;

  .plan-info-wrapper {
    display: flex;
    justify-content: space-around;

    .plan-info-item {
      display: flex;
      flex-direction: column;

      .label {
        margin-bottom: 20px;
      }

      .value {
        font-weight: 700;
      }
    }
  }

  .factory-info-wrapper {
    display: flex;
    justify-content: space-around;

    .factory-info-item {
      display: flex;
      flex-direction: column;

      .label {
        margin-bottom: 20px;
      }

      .value {
        margin-bottom: 20px;
        font-weight: 700;
      }
    }
  }

  .plan {
    color: #3399ff;
  }

  .complete {
    color: #2fc25b;
  }
}
.info-bottom-wrapper {
  display: flex;
  flex-direction: column;
  width: 50%;
  justify-content: space-around;
  height: 400px;
  overflow-y: auto;
  .item {
    display: flex;
    justify-content: space-around;
  }
}
</style>
    