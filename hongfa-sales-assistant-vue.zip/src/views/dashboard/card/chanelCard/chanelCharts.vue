<template>
  <div
    :class="className"
    :style="{height:height,width:width}"
  />
</template>

    <script>
import * as echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import resize from '@/views/dashboard/mixins/resize';

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart',
    },
    width: {
      type: String,
      default: '100%',
    },
    height: {
      type: String,
      default: '336px',
    },
    chartsData: {
      type: Array,
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  watch: {
    chartsData: {
      handler(val) {
        this.initChart();
      },
      deep: true,
    },
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el);
      let seriesData = [];
      let option;
      option = {
        tooltip: {
          trigger: 'item',
        },
        legend: {
          top: '5%',
          left: 'center',
        },
color: ['#0092ff', '#ee6666', '#fac858', '#91cc75', '#fc8452', '#9a60b4'],
        series: [
          {
            name: '渠道销量',
            type: 'pie',
            radius: ['25%', '55%'],
            // avoidLabelOverlap: false,
            label: {
              show: false,
              position: 'center',
            },
            // emphasis: {
            //   label: {
            //     show: true,
            //     fontSize: 40,
            //     fontWeight: 'bold',
            //   },
            // },
            // label: {
            //   normal: {
            //     position: 'outside', // 标签在扇形外侧
            //     // 其他标签样式设置
            //   },
            // },
            labelLine: {
              normal: {
                show: true, // 不显示标签指引线
              },
            },
            data: seriesData,
          },
        ],
      };
      for (var i = 0; i < this.chartsData.length; i++) {
        var item = this.chartsData[i];
        seriesData.push({ value: item.saleNum, name: item.channelName });
      }
      option && this.chart.setOption(option);
    },
  },
};
</script>
