<template>
  <el-card class="box-card" style="height:545px">
    <div slot="header" class="clearfix">
      <span>系统简报</span>
    </div>

    <div>
      <div class="home-sys-record_wrapper">
        <div class="itemwrapper">
          <div class="record-item">
            <span class="item-label">总库存</span>
            <countTo class="item-value" :end="systemBriefInfo.totalInventory ? systemBriefInfo.totalInventory : 0"
              :decimals="systemBriefInfo.totalInventoryDis" :key="systemBriefInfo.totalInventoryDis">
              <template v-slot:right>
                吨
              </template>
            </countTo>
          </div>
          <div class="record-item">
            <span class="item-label">一厂总库存</span>
            <countTo class="item-value"
              :end="systemBriefInfo.bp1FactoryInventory ? systemBriefInfo.bp1FactoryInventory : 0"
              :decimals="systemBriefInfo.bp1FactoryInventoryDis" :key="systemBriefInfo.bp1FactoryInventoryDis">
              <template v-slot:right>
                吨
              </template>
            </countTo>
          </div>
          <div class="record-item">
            <span class="item-label">二厂总库存</span>
            <countTo class="item-value"
              :end="systemBriefInfo.bp2FactoryInventory ? systemBriefInfo.bp2FactoryInventory : 0"
              :decimals="systemBriefInfo.bp2FactoryInventoryDis" :key="systemBriefInfo.bp2FactoryInventoryDis">
              <template v-slot:right>
                吨
              </template>
            </countTo>
          </div>
          <div class="record-item">
            <span class="item-label">朝阳总库存</span>
            <countTo class="item-value"
              :end="systemBriefInfo.cyFactoryInventory ? systemBriefInfo.cyFactoryInventory : 0"
              :decimals="systemBriefInfo.cyFactoryInventoryDis" :key="systemBriefInfo.cyFactoryInventory">
              <template v-slot:right>
                吨
              </template>
            </countTo>
          </div>
          <div class="record-item">
            <span class="item-label">喀左总库存</span>
            <countTo class="item-value"
              :end="systemBriefInfo.kzFactoryInventory ? systemBriefInfo.kzFactoryInventory : 0"
              :decimals="systemBriefInfo.kzFactoryInventoryDis" :key="systemBriefInfo.kzFactoryInventory">
              <template v-slot:right>
                吨
              </template>
            </countTo>
          </div>
        </div>
        <div class="itemwrapper" v-if="false">
          <div class="record-item record-item-110">
            <span class="item-label">总出库量</span>
            <div class="item-box">
              <span class="label-pre">本月: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.deliveryVolumeByMonth ? systemBriefInfo.deliveryVolumeByMonth : 0" :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
              <span class="label-pre">昨日: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.deliveryVolumeByYesterday ? systemBriefInfo.deliveryVolumeByYesterday : 0"
                :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
            </div>

          </div>
          <div class="record-item record-item-110">
            <span class="item-label">一厂出库量</span>
            <div class="item-box">
              <span class="label-pre">本月: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.ycdeliveryVolumeByMonth ? systemBriefInfo.ycdeliveryVolumeByMonth : 0"
                :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
              <span class="label-pre">昨日: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.ycdeliveryVolumeByYesterday ? systemBriefInfo.ycdeliveryVolumeByYesterday : 0"
                :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
            </div>
          </div>
          <div class="record-item record-item-110">
            <span class="item-label">二厂出库量</span>
            <div class="item-box">
              <span class="label-pre">本月: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.ecdeliveryVolumeByMonth ? systemBriefInfo.ecdeliveryVolumeByMonth : 0"
                :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
              <span class="label-pre">昨日: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.ecdeliveryVolumeByYesterday ? systemBriefInfo.ecdeliveryVolumeByYesterday : 0"
                :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
            </div>
          </div>
          <div class="record-item record-item-110">
            <span class="item-label">朝阳出库量</span>
            <div class="item-box">
              <span class="label-pre">本月: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.cydeliveryVolumeByMonth ? systemBriefInfo.cydeliveryVolumeByMonth : 0"
                :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
              <span class="label-pre">昨日: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.cydeliveryVolumeByYesterday ? systemBriefInfo.cydeliveryVolumeByYesterday : 0"
                :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
            </div>
          </div>
          <div class="record-item record-item-110">
            <span class="item-label">喀左出库量</span>
            <div class="item-box">
              <span class="label-pre">本月: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.kzdeliveryVolumeByMonth ? systemBriefInfo.kzdeliveryVolumeByMonth : 0"
                :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
              <span class="label-pre">昨日: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.kzdeliveryVolumeByYesterday ? systemBriefInfo.kzdeliveryVolumeByYesterday : 0"
                :decimals="0">
                <template v-slot:right>
                  吨
                </template>
              </countTo>
            </div>
          </div>
        </div>
        <div class="itemwrapper" v-if="false">
          <div class="record-item record-item-110">
            <span class="item-label">新客户成交</span>
            <div class="item-box">
              <span class="label-pre">本月: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.newCustomerCountByMonth ? systemBriefInfo.newCustomerCountByMonth : 0" />
              <span class="label-pre">昨日: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.newCustomerCountByYesterday ? systemBriefInfo.newCustomerCountByYesterday : 0" />
            </div>
          </div>
          <div class="record-item record-item-110">
            <span class="item-label">批价单数</span>
            <div class="item-box">
              <span class="label-pre">本月: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.approvePriceCountByMonth ? systemBriefInfo.approvePriceCountByMonth : 0" />
              <span class="label-pre">昨日: </span>
              <countTo class="item-value"
                :end="systemBriefInfo.approvePriceCountByYesterday ? systemBriefInfo.approvePriceCountByYesterday : 0" />
            </div>
          </div>
          <!-- 删除card：待确认客户和库存预警
          <div class="record-item" @click="goClient" style="cursor: pointer;">
            <span class="item-label">待确认客户</span>
            <countTo class="item-value" :countClass="countClass"
              :end="systemBriefInfo.unconfirmedUserCount	?systemBriefInfo.unconfirmedUserCount	 : 0" />
          </div>
          <div class="record-item" @click="goWarning" style="cursor: pointer;">
            <span class="item-label">库存预警</span>
            <countTo class="item-value" :countClass="countClass" :end="systemBriefInfo.warningKC?systemBriefInfo.warningKC : 0"
              :decimals="0">
            </countTo>
          </div>-->
          <div class="record-item record-item-none">
            <span class="item-label"></span>
            <span class="item-value"></span>
          </div>
          <div class="record-item record-item-none">
            <span class="item-label"></span>
            <span class="item-value"></span>
          </div>
          <div class="record-item record-item-none">
            <span class="item-label"></span>
            <span class="item-value"></span>
          </div>
        </div>
        <!-- <el-row style="margin-bottom: 20px">

          <el-col :span="4">

          </el-col>

          <el-col :span="4">
            <div class="record-item">
              <span class="item-label"> 昨日新客出库量</span>
              <span class="item-value">{{systemBriefInfo.newCustomerOutput?systemBriefInfo.newCustomerOutput : 0}}吨</span>
            </div>
          </el-col>

          <el-col :span="6">
            <div class="record-item">
              <span class="item-label">昨日出库均价</span>
              <span class="item-value">{{systemBriefInfo.outputAvg?systemBriefInfo.outputAvg : 0}}吨</span>
            </div>
          </el-col>

          <el-col :span="6">
            <div class="record-item">
              <span class="item-label"> 昨日新增库存</span>
              <span class="item-value">{{systemBriefInfo.newInventory?systemBriefInfo.newInventory : 0}}吨</span>
            </div>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="6">
            <div class="record-item">
              <span class="item-label"> 客户流失预警</span>
              <span class="item-value">{{systemBriefInfo.customerLossWarn?systemBriefInfo.customerLossWarn : 0}}吨</span>
            </div>
          </el-col>

          <el-col :span="6">
            <div class="record-item">
              <span class="item-label">客户出库量预警</span>
              <span class="item-value">{{systemBriefInfo.customerOutputWarn?systemBriefInfo.customerOutputWarn : 0}}吨</span>
            </div>
          </el-col>

          <el-col :span="6">
            <div class="record-item">
              <span class="item-label">客户跟进预警</span>
              <span class="item-value">{{systemBriefInfo.customerFollowWarn?systemBriefInfo.customerFollowWarn : 0}}吨</span>
            </div>
          </el-col>

          <el-col :span="6">
            <div class="record-item">
              <span class="item-label">产品库存预警</span>
              <span class="item-value">{{systemBriefInfo.productInventoryWarn?systemBriefInfo.productInventoryWarn : 0}}吨</span>
            </div>
          </el-col>
        </el-row> -->
      </div>
    </div>
  </el-card>
</template>

<script>
import {
  systemBrief
} from '@/api/Home/index';
import CountTo from "@/components/count-to";
export default {
  components: {
    CountTo,
  },
  data() {
    return {
      systemBriefInfo: {},
      countClass: 'countClass'
    };
  },
  methods: {
    getData() {
      systemBrief().then((res) => {
        this.systemBriefInfo = {
          ...res.data,
          totalInventoryDis: (`${res.data.totalInventory || ''}`).split('.')[1]?.length || 0,
          bp1FactoryInventoryDis: (`${res.data.bp1FactoryInventory || ''}`).split('.')[1]?.length || 0,
          bp2FactoryInventoryDis: (`${res.data.bp2FactoryInventory || ''}`).split('.')[1]?.length || 0,
          cyFactoryInventoryDis: (`${res.data.cyFactoryInventory || ''}`).split('.')[1]?.length || 0,
          kzFactoryInventoryDis: (`${res.data.kzFactoryInventory || ''}`).split('.')[1]?.length || 0,
        };
      });
    },
    goClient() {
      this.$router.push('/client/otherclient')
    },
    goWarning() {
      this.$router.push('/monitoring/stock')
    },
  },
  created() {
    this.getData();
  },
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    // this.getData();
    console.log(12);
  },
};
</script>

<style lang="scss" scoped>
::v-deep .countClass {
  color: red;
}

.home-sys-record_wrapper {
  // display: flex;
  // flex-direction: column;
  height: 350px; // 图表元素高
  // justify-content: space-around;

  .itemwrapper {
    display: flex;
    justify-content: space-between;
    margin-bottom: 12px;
  }

  .record-item {
    background: linear-gradient(to bottom right, rgb(217 236 245), rgb(255 255 255));
    width: 18%;
    height: 90px;
    display: flex;
    flex-direction: column;
    align-items: center;
    border: 1px solid #eaebed;
    border-radius: 8px;
    padding: 4px;

    // margin-right: ;
    .item-label {
      width: 100%;
      text-align: center;
      vertical-align: center;
      border-radius: 4px 4px 0 0;
      font-size: 13px;
      font-weight: 500;
      padding: 4px 0;
    }

    .item-box {
      width: 100%;
      display: inline-flex;
      flex-direction: column;
      height: 80px;
      padding-left: 6px;

      .label-pre {
        font-size: 12px;
        color: #928f8f;
        margin: 2px 0;
      }

      .item-value {
        font-weight: bold;
        line-height: 19px;
        font-size: 13px;
        height: 20px;
      }
    }

    .item-value {
      font-weight: bold;
      font-size: 13px;
      height: 58px;
      display: flex;
      align-items: center;
    }

    .label-pre {
      font-size: 12px;
    }
  }

  .record-item-none {
    background: none;
    border: none;

    .item-label {
      border-bottom: 0px;
      background: unset;
    }
  }

  .record-item-110 {
    height: 120px;
  }
}
</style>
