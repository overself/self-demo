<template>
  <div>
    <UserInfo
      :identity="manager"
      @userInfo="getUserInfo"
    />

    <CrudHeader>
      <template slot="left">
        <el-tabs v-model="activeName">
          <el-tab-pane
            v-for="(item, index) in tabs"
            :key="index"
            :label="item.label"
            :name="item.name"
          >
            <div class="list_wrap">
              <el-radio-group
                v-model="personIndex"
                style="margin-bottom: 20px;"
                @change="onRadioGroupChange"
              >
                <el-radio-button
                  :label="index + 1"
                  v-for="(item, index) in personList"
                  :key="index"
                >{{item.nickname}}</el-radio-button>
              </el-radio-group>

              <Table
                ref="hookTable"
                :data="tableData"
                :params="queryParams"
                :identity="manager"
                @handleQuery="handleQuery"
              />

              <pagination
                v-show="total > 0"
                :total="total"
                :page.sync="personIndex"
                :limit="1"
                @pagination="changePersonGetList"
              />
            </div>
          </el-tab-pane>
        </el-tabs>
      </template>

      <template slot="rightBtns">
        <BaseSearchContainer
          :column="searchColumn"
          :params="queryParams"
          :show-reset-btn="false"
          :show-search-btn="false"
          @elDatePickerChange="onElDatePickerChange"
        />
      </template>
    </CrudHeader>
  </div>
</template>

<script>
import UserInfo from '../components/UserInfo/index';
import Table from '../components/Table/index';
import { getSalesList } from '@/api/personal/index';
import { manager } from '../components/enum';
import { mixins } from '../components/mixins';
import { getConfigMonth } from '@/api/personal/index';

export default {
  mixins: [mixins],
  components: {
    UserInfo,
    Table,
  },

  data() {
    return {
      manager,
      activeName: '1',
      tabs: [{ label: '任务追踪', name: '1' }],
      // tableData: [],
      tableData: {
        table1: [],
        table2: [],
      },
      queryParams: {
        userId: '',
        saleYear: '',
        saleMonth: '',
        _date: '',
      },
      searchColumn: [
        {
          label: '日期选择',
          prop: '_date',
          type: 'month',
          format: 'yyyy-MM',
          valueFormat: 'yyyy-MM',
          search: true,
          clearable: false,
        },
      ],
      total: 0,
      personIndex: 0,
      personList: [],
      salesParams: {},
    };
  },

  methods: {
    handleQuery(){
      this.$_getList();
    },
    onElDatePickerChange(e) {
      // console.log(e);
      let dateArr = e.split('-');
      this.queryParams.saleYear = dateArr[0];
      this.queryParams.saleMonth = dateArr[1];

      this.$_getWeekDays(e).then(() => {
        this.$_getList();
      });
    },

    onRadioGroupChange(e) {
      this.changePersonGetList();
    },

    changePersonGetList() {
      this.queryParams.userId = this.personList[this.personIndex - 1].id;
      this.queryParams.userName =
        this.personList[this.personIndex - 1].nickname;
      this.$_getList();
    },

    getUserInfo(e) {
      // console.log(e);
      getConfigMonth().then((res) => {
        const year = res.data.year;
        const month = res.data.month;

        // this.queryParams.userId = e.id;
        // this.queryParams.userName = e.nickname;
        this.queryParams.saleYear = year;
        this.queryParams.saleMonth = month;
        this.queryParams._date = `${year}-${month}`;

        this.salesParams.builtInParentDeptId = e.builtInParentDeptId;

        if (this.salesParams.builtInParentDeptId) {
          this.getSalesList();
        } else {
          this.$notify.error({ title: '暂无权限查看列表' });
        }
      });
    },

    getSalesList() {
      getSalesList(this.salesParams).then((res) => {
        // console.log(res);
        this.personList = res.data;

        if (res.data.length) {
          this.total = res.data.length;
          this.queryParams.userId = res.data[0].id;
          this.queryParams.userName = res.data[0].nickname;
          this.queryParams.builtInParentDeptId =
            res.data[0].builtInParentDeptId;

          this.$_getList();
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
</style>
