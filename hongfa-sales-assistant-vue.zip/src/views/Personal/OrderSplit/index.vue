<template>
  <el-container class="layout-wrap">
    <!-- 左侧主表 -->
    <el-aside width="56%" class="left-panel">
      <el-card shadow="never" class = 'form-card'>
        <el-form
          :model="form"
          ref="formRef"
          label-width="100px"
          class="form-container">
          <el-row :gutter="100">
            <el-col :span="8">
              <el-form-item label="工厂：" prop="selectedFactoryCode">
                <el-select
                  v-model="form.selectedFactoryCode"
                  placeholder="请选择工厂"
                  size="mini"
                  style="width: 100%;">
                  <el-option
                    v-for="f in factoryList"
                    :key="f.code"
                    :label="f.name"
                    :value="f.code"/>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="运输方式：" prop="shipType">
                <el-select
                  v-model="form.shipType"
                  placeholder="请选择运输方式"
                  size="mini"
                  style="width: 100%;">
                  <el-option label="公司配送" value="Z1"/>
                  <el-option label="客户自提" value="Z2"/>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="是否含运费：" prop="includeFreight">
                <el-select
                  v-model="form.includeFreight"
                  placeholder="是否含运费"
                  size="mini"
                  style="width: 100%;">
                  <el-option label="是" value="Y"/>
                  <el-option label="否" value="N"/>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="100">
            <el-col :span="8">
              <el-form-item label="车牌号：" prop="plateNumber">
                <el-input
                  v-model="form.plateNumber"
                  placeholder="请输入车牌号"
                  size="mini"
                  style="width:100%"
                  maxlength="8"
                  @input="formatPlate"/>
              </el-form-item>
            </el-col>
            <!-- 司机姓名和司机电话 -->
            <el-col :span="8">
              <el-form-item label="司机姓名：" prop="driverName">
                <el-input
                  v-model="form.driverName"
                  placeholder="请输入司机姓名"
                  size="mini"
                  style="width: 100%;">
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="司机电话：" prop="driverPhone">
                <el-input
                  v-model="form.driverPhone"
                  type="tel"
                  maxlength="11"
                  placeholder="请输入手机号"
                  size="mini"
                  style="width:100%"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="12">
              <el-form-item label="一级客户：" prop="selectedLevel1Customer">
                <el-select
                  v-model="form.selectedLevel1Customer"
                  value-key="code"
                  placeholder="一级客户"
                  size="mini"
                  style="width: 100%;"
                  filterable
                  clearable
                  default-first-option
                  remote
                  :remote-method="queryLevel1Customer"
                  @change="onLevel1CustomerChange"
                  :loading="customerLoading">
                  <el-option
                    v-for="c in customerOptions"
                    :key="c.code"
                    :label="c.name"
                    :value="c"/>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="日期：" prop="selectedDate">
                <el-date-picker
                  v-model="form.selectedDate"
                  type="date"
                  placeholder="选择日期"
                  size="mini"
                  style="width: 100%;"
                  :picker-options="pickerOptions"
                  format="yyyy-MM-dd"
                  value-format="yyyy-MM-dd"/>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item style="text-align: right;">
                <el-button
                  type="primary"
                  size="mini"
                  @click="addFactoryCard">
                  添加
                </el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <!-- 客户详情条 -->
        <div v-if="form.selectedLevel1Customer" class="customer-bar">
          <span>客户编码：{{ form.selectedLevel1Customer.code }}</span>
          <span>销售工号：{{ form.selectedLevel1Customer.belongSale }}</span>
          <span>所属销售：{{ form.selectedLevel1Customer.belongSaleName }}</span>
          <span>部门：{{ form.selectedLevel1Customer.deptName }}</span>
          <span>渠道：{{ form.selectedLevel1Customer.typeName }}</span>
        </div>
      </el-card>
      <el-card
        v-for="(group, idx) in leftGroups"
        :key="group.factory"
        shadow="hover"
        class="factory-card">
        <div slot="header" class="factory-header">
          <span style="margin-left: 30px;">
            <i class="el-icon-office-building"></i> {{ group.factory || '' }}
          </span>
          <span style="margin-left: 30px;">
            <i class="el-icon-date"></i> {{ group.selectedDate || '' }}
          </span>
          <span style="margin-left: 30px;">
            <i class="el-icon-truck"></i> {{ group.plateNumber || '' }}
          </span>
          <span style="margin-left: 30px;">
            <i class="el-icon-user"></i> {{ group.driverName || '' }}
          </span>
          <span style="margin-left: 30px;">
            <i class="el-icon-mobile-phone"></i> {{ group.driverPhone || '' }}
          </span>
          <!-- 新增：card 级顺序调整 -->
          <div style="margin-left: auto; display: flex; gap: 4px;">
            <el-button
              type="text"
              icon="el-icon-top"
              :disabled="idx === 0"
              @click="moveCard(idx, -1)"/>
            <el-button
              type="text"
              icon="el-icon-bottom"
              :disabled="idx === leftGroups.length - 1"
              @click="moveCard(idx, 1)"/>
            <el-button type="text" icon="el-icon-delete" style="color: #f56c6c" @click="removeFactoryCard(group)"/>
          </div>
        </div>
        <el-table :data="group.rows" border stripe size="mini" show-summary :summary-method="getSummaries(group.rows)"
                  @cell-dblclick="enterEditMode">
          <el-table-column type="index" label="No." width="45" align="center"/>
          <el-table-column prop="name" label="产品名称" min-width="160" align="center">
            <template slot-scope="{row}">
              <el-select v-if="row.editing" v-model="row.product" filterable clearable value-key="code"
                         default-first-option
                         remote :remote-method="(keyword) => queryProduct(keyword, group)" :loading="productLoading"
                         @change="onProductChange(row)" size="mini" style="width:100%">
                <el-option v-for="p in productOptions" :key="p.code" :label="p.name" :value="p"/>
              </el-select>
              <span v-else>{{ row.name || '' }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="spec" label="规格(KG)" width="75" align="center">
            <template slot-scope="{row}">
              <el-input-number v-if="row.editing" v-model="row.spec" :precision="1" :min="0.0" :max="99.9"
                               :controls="false" size="mini" style="width:100%" @change="calcRow(row)"/>
              <span v-else>{{ row.spec|fixed1 }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="rep" label="补车" width="80" align="center">
            <template slot-scope="{row}">
              <el-select
                v-if="row.editing"
                v-model="row.rep"
                size="mini"
                style="width:100%">
                <el-option label="是" value="Y"/>
                <el-option label="否" value="N"/>
              </el-select>
              <span v-else>{{ repLabel(row.rep) }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="orderType" label="订单类型" width="95" align="center">
            <template slot-scope="{row}">
              <el-select
                v-if="row.editing"
                v-model="row.orderType"
                size="mini"
                style="width:100%">
                <el-option label="标准" value="ZOR1"/>
                <el-option label="临时" value="ZOR2"/>
              </el-select>
              <span v-else>{{ orderTypeLabel(row.orderType) }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="qty" label="件数" width="90" align="center">
            <template slot-scope="{row}">
              <el-input-number v-if="row.editing" v-model="row.qty" :precision="0" :min="0" :max="9999"
                               :controls="false" size="mini" style="width:100%" @change="calcRow(row)"/>
              <span v-else>{{ row.qty }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="totalWeight" label="数量(KG)" width="85" align="center">
            <template slot-scope="{row}">
              <span :title="`库存：${Number(row.product?.inventory||0).toFixed(1)}`" >{{ row.totalWeight|fixed1 }}</span>
              <!-- 基准线进度条 -->
              <div class="inventory-bar"
                   :style="inventoryBarStyle(row)"
              ></div>
            </template>
          </el-table-column>
          <el-table-column prop="price" label="单价(元)" width="85" align="center">
            <template slot-scope="{row}">
              <div v-if="row.editing" class="price-cell" :title="`标准价：${Number(row.product?.price||0).toFixed(1)}`">
                <el-input-number v-model="row.price" :precision="1" :min="0.0" :max="999.9"
                                 :controls="false" size="mini" style="width:100%" @change="calcRow(row)"/>
              </div>
              <span v-else :title="`标准价：${Number(row.product?.price||0).toFixed(1)}`" >{{ row.price|fixed1 }}</span>
              <!-- 基准线进度条 -->
              <div class="price-bar"
                   :style="priceBarStyle(row)"
              ></div>
            </template>
          </el-table-column>
          <el-table-column prop="totalAmount" label="金额(元)" width="100" align="center">
            <template slot-scope="{row}"><span>{{ row.totalAmount|fixed2 }}</span></template>
          </el-table-column>
          <el-table-column label="操作" width="120" align="center" fixed="right">
            <template slot-scope="{row, $index}">
              <el-button type="text" icon="el-icon-top" :disabled="$index === 0" @click="moveRow(group, $index, -1)"/>
              <el-button type="text" icon="el-icon-bottom" :disabled="$index === group.rows.length - 1"
                         @click="moveRow(group, $index,  1)"/>
              <el-button
                v-if="!row.editing"
                type="text"
                icon="el-icon-plus"
                @click="addRowToFactory(group, $index)"/>
              <el-button
                v-else
                type="text"
                icon="el-icon-check"
                @click="saveRow(row)"/>
              <el-button type="text" icon="el-icon-delete" style="color: #f56c6c"
                         @click="delRowFromFactory(group, $index)"/>
            </template>
          </el-table-column>
        </el-table>
      </el-card>
      <el-empty v-if="!leftGroups.length" description="暂无订单数据"/>
    </el-aside>

    <!-- 右侧拆单 -->
    <el-main class="right-panel">
      <div class="right-top">
        <el-input-number v-model="amount" style="width:100px" size="mini" :precision="2" :min="0" :controls="false"
                         placeholder="请输入金额"
                         class="name-input"/>
        <!-- 产品多选 -->
        <el-select
          v-model="selectedProducts"
          placeholder="产品筛选"
          size="mini"
          style="width: 200px; margin-right: 12px;"
          multiple
          filterable
          clearable>
          <el-option
            v-for="p in uniqueProductList"
            :key="p"
            :label="p"
            :value="p"/>
        </el-select>
        <!-- 二级客户 -->
        <el-select
          v-model="secondaryCustomer"
          value-key="code"
          placeholder="二级客户"
          size="mini"
          style="width: 160px; margin-right: 12px;"
          filterable
          default-first-option
          :loading="secondaryCustomerLoading">
          <el-option
            v-for="c in secondaryCustomerOptions"
            :key="c.code"
            :label="c.name"
            :value="c"/>
        </el-select>
        <el-button type="primary" size="mini" @click="addTable">拆单</el-button>
        <el-button type="success" size="mini" icon="el-icon-download" style="margin-left:auto" @click="exportSaleOrder">导出
        </el-button>
      </div>
      <div class="right-scroll">
        <el-card v-for="(t, i) in tables" :key="t.id" shadow="hover" class="factory-card">
          <div slot="header">
            <!-- 第一行：金额 + 差额 + 删除按钮 -->
            <div class="card-header-line">
              <span>{{ t.name }}</span>
              <span>开票金额：{{ t.totalSelectedAmount|fixed2 }} 元</span>
              <span>补差：{{ t.remainingAmount|fixed2 }} 元</span>
              <span>折扣：{{ t.discount|fixed2 }} 元</span>
              <el-button type="text" :disabled="i!==0" class="del-btn" @click="delTable(i)">删除</el-button>
            </div>
            <!-- 第二行：二级客户信息 -->
            <div class="sub-line">
              <span>客户编码：{{ t.secondaryCustomer.code }}</span>
              <span>客户名称：{{ t.secondaryCustomer.name }}</span>
            </div>
          </div>
          <el-table-column
            v-for="c in columns"
            :key="c.prop || c.label"
            :prop="c.prop"
            :label="c.label"
            :width="c.width"
            :min-width="c.minWidth"
            :align="c.align || 'center'"
            :formatter="c.formatter"
          />
          <el-table :data="t.rows" size="mini" border>
            <el-table-column
              v-for="c in columns"
              :key="c.prop || c.label"
              :prop="c.prop || null"
              :label="c.label"
              :width="c.width"
              :align="c.align || 'center'"
              :formatter="c.formatter || undefined"
            />
          </el-table>
        </el-card>
        <el-empty v-if="!tables.length" description="暂无拆单数据"/>
      </div>
    </el-main>
  </el-container>
</template>

<script>
import Decimal from 'decimal.js'
import dayjs from 'dayjs'
import OrderSplit from '@/utils/OrderSplit'
import {getCustomerListByName, getProductFactoryList, getSubCustomerList} from '@/api/system/orderSplit/index'
import {generateSaleOrderFile} from '@/utils/exportSaleOrderTemplate'

export default {
  name: 'OrderSplit',
  data() {
    return {
      form: {
        plateNumber: '', // 车牌号
        driverName: '', // 司机姓名
        driverPhone: '', // 司机联系方式（手机号）
        selectedFactoryCode: '1001', // 工厂代码
        selectedDate: dayjs().format('YYYY-MM-DD'), // 日期
        selectedLevel1Customer: null, // 一级客户
        shipType: 'Z2',
        includeFreight: 'Y'
      },
      customerOptions: [],
      customerLoading: false,
      factoryList: [
        {code: '1001', name: '一厂'},
        {code: '1002', name: '二厂'},
        {code: '1011', name: '朝阳'},
        {code: '1021', name: '喀左'}
      ],
      secondaryCustomer: null,
      secondaryCustomerLoading: false,
      secondaryCustomerOptions: [],
      tableData: [],
      productLoading: false,
      productOptions: [],
      amount: null,
      selectedProducts: [],
      // 左侧分组示例
      leftGroups: [],
      tables: [],
      columns: [
        {prop: 'index', label: 'No.', width: 45},
        {prop: 'name', label: '产品名称', minWidth: 160},
        {prop: 'spec', label: '规格(KG)', width: 75},
        {prop: 'rep', label: '补车', width: 50,
          formatter: (row) => this.repLabel(row.rep)
        },
        {prop: 'orderType', label: '订单类型', width: 75,
          formatter: (row) => this.orderTypeLabel(row.orderType)
        },
        {prop: 'qty', label: '件数', width: 80},
        {
          prop: "totalWeight",
          label: '数量(KG)',
          width: 85,
          formatter: (row) =>
            row?.spec != null && row?.qty != null
              ? (Number(row.spec) * Number(row.qty)).toFixed(1)
              : '0.0'
        },
        {prop: 'price', label: '单价(元)', width: 75},
        {
          prop: 'totalAmount', label: '金额(元)', width: 100,
          formatter: (row) =>
            row?.spec != null && row?.qty != null && row?.price != null
              ? (Number(row.spec) * Number(row.qty) * Number(row.price)).toFixed(2)
              : '0.00'
        }
      ],
      pickerOptions: {
        // disabledDate(time) {
        //   return time.getTime() < Date.now()  // 昨天及以前禁用
        // }
      },
      splitter: { remaining: [] }
    }
  },
  mounted() {
    this.initData()
  },
  computed: {
    uniqueProductList() {
      const set = new Set()
      this.leftGroups.forEach(g =>
        g.rows.forEach(r => {
          if (r.name) set.add(r.name)
        })
      )
      return Array.from(set).sort()
    },
    leftRemainAmount() {
      return this.splitter.remaining
        .reduce((sum, p) => sum.plus(new Decimal(p.spec).times(p.qty).times(p.price)), new Decimal(0))
        .toFixed(2)
    }
  },
  // watch: {
  //   leftRemainAmount: {
  //     immediate: true,   // 第一次也触发
  //     handler(val) {
  //       this.amount = Number(val) || 0
  //     }
  //   }
  // },
  methods: {
    initData() {
      // 把所有工厂的 rows 合并成一份库存
      const totalStock = this.leftGroups.flatMap(g =>
        g.rows.map(r => ({
          factoryCode: g.factoryCode,
          selectedLevel1Customer: g.selectedLevel1Customer,
          selectedDate: g.selectedDate,
          shipType: g.shipType,
          includeFreight: g.includeFreight,
          plateNumber: g.plateNumber,
          driverName: g.driverName,
          driverPhone: g.driverPhone,
          product: r.product,
          code: r.code,
          name: r.name,
          spec: r.spec,
          rep: r.rep,
          orderType: r.orderType,
          sortType: r.sortType,
          qty: r.qty,
          price: r.price
        }))
      )
      this.splitter = new OrderSplit(totalStock)
    },
    formatPlate(val) {
      let raw = (val || '').toUpperCase().replace(/\s+/g, '')
      // 2. 过滤汉字、字母、数字以外的字符
      raw = raw.replace(/[^[\u4e00-\u9fa5A-Z0-9]/g, '')
      // 3. 限制长度
      raw = raw.slice(0, 8)
      // 4. 写回
      this.$nextTick(() => {
        this.form.plateNumber = raw
      })
    },
    isPlateValid(str) {
      return /^[京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新军使]{1}[A-Z]{1}[A-Z0-9]{5,6}$/.test(str)
    },
    onLevel1CustomerChange(newObj) {
      this.querySecondaryCustomer(newObj.code)
    },
    onProductChange(row) {
      // const repeat = this.leftGroups
      //   .filter(g => g.factoryCode === row.product.factoryCode)
      //   .some(g => g.rows.some(r => r.code === row.product.code && r.id !== row.id))
      // if (repeat) {
      //   this.$message.warning('同一工厂内不允许重复品')
      //   return
      // }
      row.code = row.product.code
      row.name = row.product.name
      row.spec = row.product.spec
      row.price = row.product.price
      this.calcRow(row)
    },
    addFactoryCard() {
      const exist = this.leftGroups.some(g => g.factoryCode === this.form.selectedFactoryCode)
      if (exist) {
        this.$message.warning('该工厂已存在，请勿重复添加')
        return
      }
      // if (!this.form.plateNumber || !this.form.plateNumber.trim()) {
      //   this.$message.warning('请输入车牌号')
      //   return
      // }
      // if (!this.isPlateValid(this.form.plateNumber)) {
      //   this.$message.warning('车牌号格式不正确')
      //   return
      // }
      // if (!this.form.driverName || !this.form.driverName.trim()) {
      //   this.$message.warning('请输入司机姓名')
      //   return
      // }
      // if (!this.form.driverPhone || !/^1[3-9]\d{9}$/.test(this.form.driverPhone)) {
      //   this.$message.warning('请输入正确的司机手机号')
      //   return
      // }
      if (!this.form.selectedLevel1Customer) {
        this.$message.warning('请选择一级客户')
        return
      }

      const f = this.factoryList.find(f => f.code === this.form.selectedFactoryCode)
      this.leftGroups.push({
        factory: f.name,
        factoryCode: f.code,
        selectedLevel1Customer: this.form.selectedLevel1Customer,
        selectedDate: this.form.selectedDate,
        shipType: this.form.shipType,
        includeFreight: this.form.includeFreight,
        plateNumber: this.form.plateNumber,
        driverName: this.form.driverName,
        driverPhone: this.form.driverPhone,
        rows: this.createEmptyRow(true)
      })
    },
    removeFactoryCard(group) {
      const idx = this.leftGroups.findIndex(g => g.factoryCode === group.factoryCode)
      if (idx > -1) this.leftGroups.splice(idx, 1)
      this.rebuildRemaining();
    },
    // 复用已有 moveRow 逻辑，只是把 leftGroups 当成数组
    moveCard(idx, dir) {
      // 借用原 moveRow 的交换逻辑，只是把 this.leftGroups 当数组
      const tar = idx + dir
      if (tar < 0 || tar >= this.leftGroups.length) return
      const tmp = this.leftGroups[idx]
      this.$set(this.leftGroups, idx, this.leftGroups[tar])
      this.$set(this.leftGroups, tar, tmp)
      this.rebuildRemaining()   // 若顺序影响库存，保持同步
    },
    // 双击进入编辑
    enterEditMode(row, column) {
      const editableProps = ['name', 'spec', 'rep', 'orderType', 'qty', 'price']
      if (editableProps.includes(column.property)) {
        this.$set(row, 'editing', true)
      }
    },
    repLabel(code) {
      const map = {Y: '是', N: '否'}
      return map[code] ?? '否'
    },
    orderTypeLabel(code) {
      const map = {ZOR1: '标准', ZOR2: '临时'}
      return map[code] ?? '标准'
    },
    // 保存本行
    saveRow(row) {
      // const repeat = this.leftGroups
      //   .filter(g => g.factoryCode === row.product.factoryCode)
      //   .some(g => g.rows.some(r => r.code === row.product.code && r.id !== row.id))
      // if (repeat) {
      //   this.$message.warning('同一工厂内不允许重复品')
      //   return
      // }
      if (!row.product || !row.product.code) {
        this.$message.warning('请先选择产品！')
        return
      }
      if (row.rep === 'Y') {
        row.sortType = 3
      } else {
        row.sortType = row.orderType === 'ZOR1' ? 1 : 2
      }
      this.$set(row, 'editing', false)
      this.calcRow(row)
      this.rebuildRemaining();
    },
    rebuildRemaining() {
      const totalStock = this.leftGroups.flatMap(g =>
        g.rows.map(r => ({
          factoryCode: g.factoryCode,
          selectedLevel1Customer: g.selectedLevel1Customer,
          selectedDate: g.selectedDate,
          shipType: g.shipType,
          includeFreight: g.includeFreight,
          plateNumber: g.plateNumber,
          driverName: g.driverName,
          driverPhone: g.driverPhone,
          product: r.product,
          code: r.code,
          name: r.name,
          spec: r.spec,
          rep: r.rep,
          orderType: r.orderType,
          sortType: r.sortType,
          qty: r.qty,
          price: r.price
        }))
      );
      // 复用原实例，只替换剩余库存
      this.splitter.remaining = totalStock.map(p => ({
        ...p,
        _specFen: Math.round(p.spec * 100),
        _priceFen: Math.round(p.price * 100)
      }));
      this.reorderRemaining()
    },
    reorderRemaining() {
      const prio = this.selectedProducts.map(n =>
        this.splitter.remaining.find(p => p.name === n)
      ).filter(Boolean)
      const rest = this.splitter.remaining
        .filter(p => !this.selectedProducts.includes(p.name))
        .sort((a, b) => (a.sortType || 9) - (b.sortType || 9))
      this.splitter.remaining = [...prio, ...rest]
    },
    addRowToFactory(group, idx = -1) {
      const ins = this.createEmptyRow(true)[0];
      idx === -1 ? group.rows.push(ins) : group.rows.splice(idx + 1, 0, ins);
    },
    // 组内删行
    delRowFromFactory(group, idx) {
      group.rows.splice(idx, 1);
      if (!group.rows.length) group.rows.push(this.createEmptyRow(true)[0]);
      this.rebuildRemaining();
    },
// 组内上下移动
    moveRow(group, idx, dir) {
      const tar = idx + dir;
      if (tar < 0 || tar >= group.rows.length) return;
      const tmp = group.rows[idx];
      this.$set(group.rows, idx, group.rows[tar]);
      this.$set(group.rows, tar, tmp);
      this.rebuildRemaining();
    },
    createEmptyRow(editing = true) {
      return [{
        id: Date.now(),
        editing,
        product: {code: null, name: '', spec: '', price: '', inventory: '', factoryCode: null, kindCode: null},
        code: null,
        name: '',
        spec: 0.0,
        rep: 'N',
        orderType: 'ZOR1',
        sortType: 1,
        qty: 1,
        totalWeight: 0.0,
        price: 0.0,
        totalAmount: 0.00
      }]
    },
    async queryLevel1Customer(keyword) {
      if (!keyword) {
        this.customerOptions = []
        return
      }
      this.customerLoading = true;
      let query = {
        name: keyword
      };
      getCustomerListByName(query).then((res) => {
        this.customerLoading = false
        this.customerOptions = res.data;
      });
    },
    async querySecondaryCustomer(code) {
      this.secondaryCustomerOptions = []
      this.secondaryCustomer = null
      if (!code) {
        return
      }
      this.secondaryCustomerLoading = true
      let query = {
        code: code
      };
      getSubCustomerList(query).then((res) => {
        this.secondaryCustomerLoading = false
        this.secondaryCustomerOptions = res.data;
      });
    },
    async queryProduct(keyword, group) {
      if (!keyword) {
        this.productOptions = [];
        return
      }
      if (!group?.factoryCode) {
        this.$message.warning('请先选择工厂！');
        return;
      }
      if (!group?.selectedDate) {
        this.$message.warning('请先选择日期！');
        return;
      }
      this.productLoading = true
      let query = {
        name: keyword,
        factoryCode: group.factoryCode,
        date: group.selectedDate
      };
      getProductFactoryList(query).then((res) => {
        this.productLoading = false
        this.productOptions = res.data;
      });
    },
    calcRow(row) {
      // 1. 根据单价决定订单类型
      const standardPrice = Number(row.product?.price || 0)
      const inputPrice = Number(row.price || 0)
      row.orderType = inputPrice < standardPrice ? 'ZOR2' : 'ZOR1'

      row.spec = Number(row.spec) || 0.0
      row.qty = Number(row.qty) || 0
      row.price = Number(row.price) || 0.0
      row.totalWeight = new Decimal(row.spec).times(row.qty).toFixed(2)
      row.totalAmount = new Decimal(row.spec).times(row.qty).times(row.price).toFixed(2)
    },
    getSummaries(rows) {
      return function ({columns, data}) {   // ← 这里解构
        const sums = Array(columns.length).fill('');
        const wtIdx = columns.findIndex(c => c.label === '数量(KG)');
        const wtLIdx = columns.findIndex(c => c.label === '件数');
        const amtIdx = columns.findIndex(c => c.label === '金额(元)');
        const amtLIdx = columns.findIndex(c => c.label === '单价(元)');
        if (wtLIdx > -1) sums[wtLIdx] = '数量合计：';
        if (wtIdx > -1) sums[wtIdx] = rows.reduce((a, b) => a.plus(b.totalWeight), new Decimal(0)).toFixed(1);
        if (amtLIdx > -1) sums[amtLIdx] = '金额合计：';
        if (amtIdx > -1) sums[amtIdx] = rows.reduce((a, b) => a.plus(b.totalAmount), new Decimal(0)).toFixed(2);
        return sums;
      };
    },
    addTable() {
      const val = this.amount
      if (!val || !(val > 0)) return this.$message.warning('请输入金额')
      if (!this.secondaryCustomer) {
        return this.$message.warning('请选择二级客户');
      }
      // 拆单
      const priorityNames = this.selectedProducts.length ? this.selectedProducts : []
      const [result] = this.splitter.split([Number(val)], priorityNames)
      if (!result.selectedProducts.length) return this.$message.warning('无可拆商品')

      // 1. 剩余为 0 时，当场算前面所有 remainingAmount 之和
      const finalDiscount = this.splitter.remaining.every(r => Number(r.qty) === 0)
        ? this.tables.reduce((sum, t) => sum + Number(t.remainingAmount), 0)
        : 0

      // 右侧卡片 // 把二级客户写入本次拆单的每一行
      result.selectedProducts.forEach((r, i) => {
        r.index = i + 1
        r.secondaryCustomer = this.secondaryCustomer
        r.secondaryCustomer = this.secondaryCustomer
      })
      this.tables.unshift({
        id: Date.now(),
        secondaryCustomer: this.secondaryCustomer,
        name: `金额：${val.toFixed(2)} 元`,
        remainingAmount: result.remainingAmount,
        totalSelectedAmount: result.totalSelectedAmount,
        discount: finalDiscount,
        rows: result.selectedProducts,
        _raw: result.selectedProducts
      })
      console.log(this.tables)
      // 左侧同步剩余
      this.syncLeftTable()
      this.amount = null
    },
    delTable(i) {
      if (i !== 0) return
      const card = this.tables[i]
      card._raw.forEach(sr => {
        /* 1. 库存层：factoryCode + name 精准匹配 */
        const idx = this.splitter.remaining.findIndex(
          p => p.factoryCode === sr.factoryCode && p.name === sr.name
        );
        if (idx !== -1) this.splitter.remaining[idx].qty += sr.qty;
      });
      this.tables.splice(i, 1)
      this.syncLeftTable()
    },
    syncLeftTable() {
      // 遍历每个工厂
      this.leftGroups.forEach(factory => {
        // 遍历每个工厂的每行数据
        factory.rows.forEach(row => {
          // 在 remaining 中找到匹配的品
          const remainingItem = this.splitter.remaining.find(
            r => r.factoryCode === factory.factoryCode && r.name === row.name
          );
          if (remainingItem) {
            // 更新数量
            row.qty = remainingItem.qty;
            row.totalWeight = new Decimal(row.spec).times(row.qty).toFixed(2);
            row.totalAmount = new Decimal(row.spec).times(row.qty).times(row.price).toFixed(2);
          }
        });
      });
    },
    inventoryBarStyle(row) {
      const std = Number(row.product?.inventory || 0) || 1   //库存
      const cur = Number(row.totalWeight || 0)                 // 当前数量
      const percent = Math.min(150, (cur / std) * 100)   // 最大 150% 截断
      let color =
        percent < 100 ? '#67C23A' :
          percent === 100 ? '#409EFF' :
            '#F56C6C'
      return {
        background: `linear-gradient(to right, ${color} 0%, ${color} ${percent}%, transparent ${percent}%)`,
        height: '3px',
        borderRadius: '2px',
        marginTop: '1px'
      }
    },
    priceBarStyle(row) {
      const std = Number(row.product?.price || 0) || 1   // 标准价
      const cur = Number(row.price || 0)                 // 当前输入
      const percent = Math.min(150, (cur / std) * 100)   // 最大 150% 截断
      let color =
        percent < 100 ? '#F56C6C' :   // 低了-红
          percent === 100 ? '#409EFF' : // 持平-绿
            '#67C23A'   // 高了-蓝
      return {
        background: `linear-gradient(to right, ${color} 0%, ${color} ${percent}%, transparent ${percent}%)`,
        height: '3px',
        borderRadius: '2px',
        marginTop: '1px'
      }
    },
    async exportSaleOrder() {
      if (!this.tables.length) return this.$message.warning('暂无拆单数据')
      await generateSaleOrderFile(this.tables)
    }
  },
  filters: {fixed1: v => Number(v).toFixed(1), fixed2: v => Number(v).toFixed(2), fixed3: v => Number(v).toFixed(3)}
}
</script>
<style scoped>
.layout-wrap {
  height: 100vh;
  background: #f5f7fa;
}

.left-panel {
  padding: 8px 8px 16px 6px;
  background: #fafafa;
  border-right: 1px solid #c0c4cc;
}

.form-card {
  border: none;
  margin-bottom: 10px;
}

.form-card ::v-deep .el-card__body {
  padding: 5px;
}

.factory-card {
  margin-bottom: 15px;
}

/* 工厂 card 头部高度 */
.factory-card ::v-deep .el-card__header {
  padding: 4px 12px; /* 上下 4px  左右保持 12px */
  line-height: 24px; /* 让文字垂直居中 */
}

.factory-card ::v-deep .el-card__body {
  padding: 5px;
}

.factory-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.right-panel {
  display: flex;
  flex-direction: column;
  padding: 8px 5px 5px 5px;
}

.right-top {
  padding: 12px 16px;
  background: #fff;
  border-bottom: 1px solid #e6e6e6;
  display: flex;
  align-items: center;
}

.name-input {
  width: 260px;
  margin-right: 12px;
}

.right-scroll {
  flex: 1;
  overflow-y: auto;
  padding: 5px 0px;
  background: #fafafa;
}

.card-header-line {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 2px; /* 左右统一留白 */
  font-size: 16px;
}

.sub-line {
  display: flex;
  gap: 16px;
  font-size: 13px;
  color: #2d7ae6;
}

.del-btn {
  color: #f56c6c;
}

.del-btn[disabled] {
  color: #c0c4cc;
  cursor: not-allowed;
}

.customer-bar {
  display: flex;
  gap: 16px;
  font-size: 13px;
  color: #2d7ae6;
  background: #eaf2fd;
  padding: 4px 16px;
  margin: -8px 0 8px 0;
}

.form-container .el-row {
  margin-bottom: 0 !important;
}

/* 让进度条只占输入框内部，不额外撑高单元格 */
.price-cell {
  display: inline-block;
  width: 100%;
}
</style>
