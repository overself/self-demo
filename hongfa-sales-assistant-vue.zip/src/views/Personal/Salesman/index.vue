<template>
  <div>
    <UserInfo ref="hookUserInfo" :identity="salesman" @userInfo="getUserInfo" />

    <CrudHeader>
      <template slot="left">
        <el-tabs v-model="activeName">
          <el-tab-pane v-for="(item, index) in tabs" :key="index" :label="item.label" :name="item.name">
            <div class="list_wrap">
              <Table ref="hookTable" :data="tableData" :params="queryParams" :identity="salesman" @handleQuery="handleQuery"
                :weekDays="weekDays" />
            </div>
          </el-tab-pane>
        </el-tabs>
      </template>

      <template slot="rightBtns">
        <BaseSearchContainer :column="searchColumn" :params="queryParams" @elDatePickerChange="onElDatePickerChange" @onSearch="handleQuery"
          @onReset="handleReset">
          <template #factory>
            <el-select v-model="queryParams.factory" placeholder="请选择工厂" style="width: 100px" filterable clearable>
              <el-option v-for="item in factoriesOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </template>
          <template #customerTypeMore>
            <el-select multiple clearable v-model="queryParams.customerTypeMore" placeholder="请选择客户分类" style="width: 240px">
              <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </template>
        </BaseSearchContainer>
      </template>
    </CrudHeader>
  </div>
</template>

<script>
  import {
    deepClone
  } from '@/utils';
  import UserInfo from '../components/UserInfo/index';
  import Table from '../components/Table/index';
  import {
    salesman
  } from '../components/enum';
  import {
    mixins
  } from '../components/mixins';
  import {
    getConfigMonth,
  } from '@/api/personal/index';

  export default {
    mixins: [mixins],
    components: {
      UserInfo,
      Table,
    },

    data() {
      return {
        factoriesOptions: this.getDictDatas('factory'), //归属工厂
        clientTypes: [], //客户分类下拉框
        salesman,
        activeName: '1',
        tabs: [{
          label: '销售任务追踪',
          name: '1'
        }, ],
        tableData: [],
        queryParams: {
          factory: '',
          customerTypeMore: [],
          userId: '',
          saleYear: '',
          saleMonth: '',
          _date: '',
        },
        searchColumn: [{
            label: '工厂',
            prop: 'factory',
            type: 'select',
            search: true,
            disabled: false,
            dicData: [],
          },
          {
            label: '客户分类',
            prop: 'customerTypeMore',
            type: 'select',
            search: true,
            disabled: false,
            dicData: [],
          }, {
            label: '日期选择',
            prop: '_date',
            type: 'month',
            format: 'yyyy-MM',
            valueFormat: 'yyyy-MM',
            search: true,
            clearable: false,
          },
        ],
      };
    },
    created() {
      //查询客户分类下拉框数据
      this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
    },

    methods: {
      onTableSave() {
        this.$refs.hookUserInfo.refreshKanBan();
      },
      onElDatePickerChange(e) {
        let dateArr = e.split('-');
        this.queryParams.saleYear = dateArr[0];
        this.queryParams.saleMonth = dateArr[1];
        this.$_getWeekDays(e).then(() => {
          this.$_getList();
        });
      },
      handleQuery() {
        this.queryParams.customerType = this.queryParams.customerTypeMore.join(',')
        this.$_getList();
      },
      handleReset() {
        this.queryParams.factory = ''
        this.queryParams.customerType = ''
        this.queryParams.customerTypeMore = []
        this.queryParams._date = this.queryParams.saleYear + '-' + this.queryParams.saleMonth
        this.$_getList();
      },
      getUserInfo(e) {
        getConfigMonth().then((res) => {
          const year = res.data.year;
          const month = res.data.month;
          this.queryParams.userId = e.id;
          this.queryParams.userName = e.nickname;
          this.queryParams.deptId = e.builtInParentDeptId;
          this.queryParams.saleYear = year;
          this.queryParams.saleMonth = month;
          this.queryParams._date = `${year}-${month}`;
          this.$_getWeekDays(this.queryParams._date).then(() => {
            this.$_getList();
          });
        });
      },
      addClass({
        row,
        column,
        rowIndex,
        columnIndex
      }) {
        if (row[column.property] == null || row[column.property] == '') {
          row[column.property] = '-';
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .royalty-tips {
    margin: 15px 0;
    font-size: 14px;
    color: rgba(153, 153, 153, 1);
  }
</style>
