<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix box-card-header">
        <span style="flex: 1;">业务员计划（{{user.nickname}}）</span>
        <BaseSearchContainer :column="searchColumn" :params="queryParams" :show-reset-btn="false" @onSearch="onKanbanSearch">
        </BaseSearchContainer>
      </div>
      <div>
        <el-row :gutter="20">
          <el-col :span="10">
            <el-table :data="tableData" border style="width: 100%;">
              <el-table-column prop="factory" label="工厂" align="center"></el-table-column>
              <el-table-column prop="yc" label="一厂" align="center"></el-table-column>
              <el-table-column prop="ec" label="二厂" align="center"></el-table-column>
              <el-table-column prop="cy" label="朝阳" align="center"></el-table-column>
              <el-table-column prop="kz" label="喀左" align="center"></el-table-column>
              <el-table-column prop="totalAmount" label="总计" align="center"></el-table-column>
            </el-table>
          </el-col>
          <el-col :span="14">
            <el-table :data="tableData1" border style="width: 100%;">
              <el-table-column prop="totalCustomer" label="总客户数" align="center"></el-table-column>
              <el-table-column prop="factory" label="加工厂" align="center"></el-table-column>
              <el-table-column prop="trade" label="贸易" align="center"></el-table-column>
              <el-table-column prop="export" label="出口" align="center"></el-table-column>
              <el-table-column prop="fast" label="快餐" align="center"></el-table-column>
              <el-table-column prop="supermarket" label="商超" align="center"></el-table-column>
              <el-table-column prop="approvedBy" label="经批" align="center"></el-table-column>
              <el-table-column prop="planCustomer" label="计划客户数" align="center"></el-table-column>
            </el-table>
          </el-col>
        </el-row>
      </div>
    </el-card>
  </div>
</template>

<script>
  import {
    getUserProfile,
    getUser
  } from '@/api/system/user';
  import {
    getSalesKanban,
    getConfigMonth,
    newPersonUp
  } from '@/api/personal/index';
  import {
    identityEnum,
    salesman,
    manager
  } from '../enum';
  export default {
    name: 'PersonalUserInfo',
    props: {
      identity: {
        type: Number,
        default: -1,
      },
    },

    data() {
      return {
        tableData1: [],
        tableData: [],
        queryParams: {
          userId: '',
          saleYear: '',
          saleMonth: '',
          _date: '',
        },
        identityEnum,
        userId: '',
        user: {
          nickname: '',
          username: '',
          avatar: '',
          mobile: '',
          dept: {
            id: '',
            name: '',
            parentId: '',
          },
          posts: [],
        },
        searchColumn: [{
          label: '日期选择',
          prop: '_date',
          type: 'month',
          format: 'yyyy-MM',
          valueFormat: 'yyyy-MM',
          search: true,
        }, ],
      };
    },
    created() {
      if (this.$route.query.userId) {
        this.userId = this.$route.query.userId;
        this.getOtherUser();
      } else {
        this.getUser();
      }
    },

    methods: {
      onKanbanSearch(e) {
        if (e) {
          const saleArr = e._date.split('-');
          this.queryParams.saleYear = saleArr[0];
          this.queryParams.saleMonth = saleArr[1];
        } else {
          this.queryParams.saleYear = '';
          this.queryParams.saleMonth = '';
        }
        this.getSalesKanban();
      },
      getUser(isEmit = true) {
        getConfigMonth().then((res) => {
          const year = res.data.year;
          const month = res.data.month;
          this.queryParams.saleYear = year;
          this.queryParams.saleMonth = month;
          this.queryParams._date = `${year}-${month}`;
          getUserProfile().then((response) => {
            this.user = response.data;
            this.getSalesKanban();
            isEmit && this.$emit('userInfo', this.user);
          });
        });
      },
      getOtherUser(isEmit = true) {
        getConfigMonth().then((res) => {
          const year = res.data.year;
          const month = res.data.month;
          this.queryParams.saleYear = year;
          this.queryParams.saleMonth = month;
          this.queryParams._date = `${year}-${month}`;
          getUser(this.userId).then((res) => {
            this.user = res.data;
            this.getSalesKanban();
            isEmit && this.$emit('userInfo', this.user);
          });
        });
      },

      getSalesKanban() {
        let obj = {};
        if (this.identity == manager) {
          obj.deptId = this.user.builtInParentDeptId;
        } else if (this.identity == salesman) {
          obj.userId = this.user.id;
        }
        obj.saleYear = this.queryParams.saleYear;
        obj.saleMonth = this.queryParams.saleMonth;
        newPersonUp({
          isFactoryTotal: 1,
          ...obj,
        }).then((res) => {
          this.tableData = res.data.afterFactory;
          this.tableData1 = res.data.customerList;
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  .box-card-header {
    display: flex;
    justify-content: space-between;
  }

  .title {
    font-size: 16px;
    font-weight: 700;
    margin-bottom: 10px;
  }

  .user-info_wrapper {
    display: flex;
    align-items: flex-start;

    .el-avatar {
      flex: 0 0 50px;
      height: 50px;
    }

    .info {
      margin-left: 20px;
    }
  }

  .process-wrapper {
    .process-item {
      display: flex;
      margin-bottom: 45px;

      &:nth-last-child(1) {
        margin-bottom: 0;
      }

      .el-progress.el-progress--line {
        flex: 1;
      }
    }
  }

  .ratio-item {
    display: flex;
    flex-direction: column;
    align-items: center;

    &.left {
      align-items: flex-start;
      padding-bottom: 5px;

      span {
        &:nth-child(1) {
          display: flex;
          align-items: center;
        }
      }

      .ratio-item_factory__nums {
        width: 130px;
        margin-left: 20px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
  }

  .royalty-tips {
    margin: 15px 0;
    font-size: 14px;
    color: rgba(153, 153, 153, 1);
  }

  .plan-complete__wrapper {
    .title {
      margin-bottom: 7px;
      font-family: PingFang SC, PingFang SC;
      font-weight: 500;
      font-size: 16px;
      color: #000000;
      line-height: 19px;
    }

    .plan-nums__wrapper {
      display: flex;
      margin-bottom: 15px;

      .plan-nums_item {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-right: 10px;
        padding: 10px;
        border-radius: 4px;

        &:nth-last-child(1) {
          margin-right: 0;
        }

        &.blue {
          background-color: #f1f8ff;
        }

        &.green {
          background-color: #f1fff5;
        }

        .nums-item_label {
          font-family: PingFang SC, PingFang SC;
          font-weight: 400;
          font-size: 14px;
          color: #000000;
        }

        .nums-item_value {
          font-family: PingFang SC, PingFang SC;
          font-weight: 500;
          font-size: 18px;

          &.blue {
            color: #1b8fff;
          }

          &.green {
            color: #3d9a57;
          }
        }
      }
    }

    .factory-nums__wrapper {
      display: flex;

      .factory-nums_item {
        flex: 1;
        padding: 0 10px;
        border-right: 1px solid #f6f6f6;

        &:nth-child(1) {
          padding-left: 0;
        }

        &:nth-last-child(1) {
          padding-right: 0;
          border-right: none;
        }

        .item-title {
          margin-bottom: 13px;
          font-family: PingFang SC, PingFang SC;
          font-weight: 400;
          font-size: 14px;
          color: #000000;
        }

        .item-nums {

          .item-nums_plan,
          .item-nums_complete {
            display: flex;
            align-items: center;
            font-family: PingFang SC, PingFang SC;
            font-weight: 400;
            font-size: 12px;
            color: #a8a8a8;

            .r {
              flex: 1;
              text-align: right;
              font-family: PingFang SC, PingFang SC;
              font-weight: 400;
              font-size: 16px;

              .black {
                color: #1b8fff;
              }

              .green {
                color: #4fc05a;
              }

              .unit {
                margin-left: 3px;
                font-family: PingFang SC, PingFang SC;
                font-weight: 400;
                font-size: 12px;
                color: #d3d3d3;
              }
            }
          }

          .item-nums_plan {
            margin-bottom: 7px;
          }

          .item-nums_complete {}
        }
      }
    }
  }

  // .el-descriptions {
  //   ::v-deep .el-descriptions__table {
  //     tbody {
  //       &:nth-child(2) {
  //         padding-top: 20px;
  //       }
  //     }
  //   }
  // }
</style>
