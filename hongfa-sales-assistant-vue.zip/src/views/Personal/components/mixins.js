import {
  list,
  getConfigMonth
} from '@/api/personal/index';
import {
  getTimeConfig
} from '@/api/teamwork/configDate/index.js';
import {
  mapGetters
} from "vuex";
export const mixins = {
  data() {
    return {
      weekDays: {
        firstWeekStart: '',
        firstWeekEnd: '',
        secondWeekStart: '',
        secondWeekEnd: '',
        thirdWeekStart: '',
        thirdWeekEnd: '',
        fourthWeekStart: '',
        fourthWeekEnd: ''
      },
    }
  },

  created() {
    this.$_getConfigWeekDays();
  },
  mounted() {


  },
  computed: {
    ...mapGetters(['userId']),
  },

  methods: {
    formatDate(date) {
      const dateArr = date.split('-');
      const startDate = `${dateArr[0]}-${dateArr[1]}-${dateArr[2]}`;
      const endDate = `${dateArr[3]}-${dateArr[4]}-${dateArr[5]}`;
      return `${this.$dayjs(startDate).format('MM/DD')}-${this.$dayjs(endDate).format('MM/DD')}`;
    },
    $_getConfigWeekDays() {
      getConfigMonth().then(res => {
        if (res.data.oneWeek === null || res.data.twoWeek === null || res.data.threeWeek === null || res.data.fourWeek === null) {
          this.$notify.error({
            title: `请先配置时间`
          });

          return;
        }
        this.weekDays = {
          oneWeek: this.formatDate(res.data.oneWeek),
          twoWeek: this.formatDate(res.data.twoWeek),
          threeWeek: this.formatDate(res.data.threeWeek),
          fourWeek: this.formatDate(res.data.fourWeek),
        };
      }).catch((err) => {})
    },
    $_getWeekDays(date) {
      return new Promise((resolve, reject) => {
        const dateArr = date.split('-');
        getTimeConfig({
          year: dateArr[0],
          month: dateArr[1],
        }).then(res => {
          if (res.data.oneWeek === null || res.data.twoWeek === null || res.data.threeWeek === null || res.data.fourWeek ===
            null) {
            this.$notify.error({
              title: `请先配置${dateArr[0]}年${dateArr[1]}月的周配置`
            });
            reject({
              year: dateArr[0],
              month: dateArr[1],
              message: `${dateArr[0]}年${dateArr[1]}月的周未配置`
            });
            return;
          }
          this.weekDays = {
            oneWeek: this.formatDate(res.data.oneWeek),
            twoWeek: this.formatDate(res.data.twoWeek),
            threeWeek: this.formatDate(res.data.threeWeek),
            fourWeek: this.formatDate(res.data.fourWeek),
          };
          resolve(res);
        }).catch((err) => {
          reject(err);
        })
      })
    },
    $_getList() {
      this.showLoading();
      this.hideTableFun();
      Promise.all([list(this.queryParams)]).then(async (res) => {
        this.tableData = res[0].data
        this.hideLoading();
        this.showTableFun();
      }).catch(() => {
        this.showTableFun();
      });
    },
    showLoading() {
      if (this.$refs.hookTable) {
        if (Array.isArray(this.$refs.hookTable)) {
          this.$refs.hookTable[0].showLoading();
        } else {
          this.$refs.hookTable.showLoading();
        }
      }
    },
    hideLoading() {
      if (this.$refs.hookTable) {
        if (Array.isArray(this.$refs.hookTable)) {
          this.$refs.hookTable[0].hideLoading();
        } else {
          this.$refs.hookTable.hideLoading();
        }
      }
    },
    showTableFun() {
      if (this.$refs.hookTable) {
        if (Array.isArray(this.$refs.hookTable)) {
          this.$refs.hookTable[0].showTableFun();
        } else {
          this.$refs.hookTable.showTableFun();
        }
      }
    },
    hideTableFun() {
      if (this.$refs.hookTable) {
        if (Array.isArray(this.$refs.hookTable)) {
          this.$refs.hookTable[0].hideTableFun();
        } else {
          this.$refs.hookTable.hideTableFun();
        }
      }
    },
  }
};
