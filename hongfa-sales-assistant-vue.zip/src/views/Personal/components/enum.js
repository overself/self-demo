const manager = 2;
const salesman = 3;

const identityEnum = {
  [manager]: '销售经理',
  [salesman]: '业务员',
}

export {
  identityEnum,
  manager,
  salesman,
};

