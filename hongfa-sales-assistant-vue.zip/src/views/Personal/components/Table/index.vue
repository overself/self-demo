<template>
  <div v-loading="loading" style="min-height: 50px;">
    <div style="margin-bottom: 20px;">
      <div class="table-actions">
        <div></div>
        <div
          v-if="identity == salesman && params.saleYear >= Number(year) && params.saleMonth >= Number(month )&& permi.hasPermi('system:sales-task:update')">
          <el-button type="primary" icon="el-icon-plus" circle @click="clickAdd('add')"></el-button>
        </div>
      </div>
      <el-table :max-height="tableHeight" v-if="showTable" ref='hookTable' :data="data" border style="width: 100%;" show-summary
        :summary-method="getSummaries">
        <el-table-column prop="userName" label="业务员" align="center">
          <template slot-scope="scope">
            <a @click="toPersonal(scope.row)" style="color: #1890ff;">{{scope.row.userName}}</a>
          </template>
        </el-table-column>
        <!-- <el-table-column prop="area" label="大区" align="center"></el-table-column> -->
        <el-table-column prop="customerCode" label="客户编码" align="center" width="120px"></el-table-column>
        <el-table-column label="客户名称" align="center">
          <template v-slot="{row}">
            <router-link :to="'/client-control/info/' + row.customerId">
              <span style="color: #1890ff;">{{row.customerName}}</span>
            </router-link>
          </template>
        </el-table-column>
        <el-table-column prop="customerTypeName" label="客户分类" align="center"></el-table-column>
        <el-table-column prop="averageMonthSales" label="月均量" align="center" width="70px"></el-table-column>
        <el-table-column prop="lastMonthSales" label="上月完成量" align="center" width="100px"></el-table-column>
        <el-table-column prop="monthSales" label="计划量" align="center" width="70px">
          <template slot-scope="scope">
            <a @click="clickDetail(scope.row)" style="color: #1890ff;">{{scope.row.monthSales}}</a>
          </template>
        </el-table-column>
        <el-table-column prop="monthCompleteSales" label="完成量" align="center" width="70px"></el-table-column>
        <el-table-column prop="monthCompleteRate" label="达成率(%)" align="center"></el-table-column>
        <el-table-column label="第一周" align="center">
          <template #header>
            <div>第一周</div>
            <div>{{weekDays.oneWeek}}</div>
          </template>
          <el-table-column prop="oneWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="oneWeekCompleteSales" label="完成" align="center"></el-table-column>
        </el-table-column>
        <el-table-column label="第二周" align="center">
          <template #header>
            <div>第二周</div>
            <div>{{weekDays.twoWeek}}</div>
          </template>
          <el-table-column prop="twoWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="twoWeekCompleteSales" label="完成" align="center"></el-table-column>
        </el-table-column>
        <el-table-column label="第三周" align="center">
          <template #header>
            <div>第三周</div>
            <div>{{weekDays.threeWeek}}</div>
          </template>
          <el-table-column prop="threeWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="threeWeekCompleteSales" label="完成" align="center"></el-table-column>
        </el-table-column>
        <el-table-column label="第四周" align="center">
          <template #header>
            <div>第四周</div>
            <div>{{weekDays.fourWeek}}</div>
          </template>
          <el-table-column prop="fourWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="fourWeekCompleteSales" label="完成" align="center"></el-table-column>
        </el-table-column>
        <el-table-column label="操作" align="center" width="110px"
          v-if="identity == salesman && params.saleYear >= Number(year) && params.saleMonth >= Number(month )&& permi.hasPermi('system:sales-task:update')">
          <template slot-scope="scope">
            <el-button size="small" type="text" @click="clickAdd('edit',scope.row)" style="margin-right: 10px;">编辑</el-button>
            <el-popconfirm title="确定删除吗？" @confirm="clickDel(scope.row)">
              <el-button slot="reference" size="small" type="text">删除</el-button>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 新增 -->
    <el-dialog :title="planType=='add'?'新增计划':'编辑计划'" :visible.sync="openAdd" width="1000px" append-to-body>
      <div class="table-actions">
        <el-form :rules="planRules" :model="addPlan" ref="addPlan" size="small" :inline="true" label-width="100px">
          <el-form-item label="月份" prop="yearmonth">
            <el-date-picker :disabled="true" style="width: 240px" v-model="addPlan.yearmonth" type="month" value-format="yyyy-MM">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="客户" prop="customerId">
            <el-select :disabled="planType=='edit'" v-model="addPlan.customerId" placeholder="请选择客户" style="width: 240px"
              @change="changeClient" filterable>
              <el-option v-for="item in clientList" :key="item.id" :value="item.id" :label="item.name"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="客户分类" prop="customerTypeName">
            <el-input v-model="addPlan.customerTypeName" :disabled="true" style="width: 240px" />
          </el-form-item>
          <el-form-item label="总计划" prop="monthSales">
            <el-input v-model="addPlan.monthSales" :disabled="true" style="width: 240px" />
          </el-form-item>
        </el-form>
        <el-button type="primary" icon="el-icon-plus" circle @click="clickAddRow()"></el-button>
      </div>
      <el-table row-key="id" :data="planData" border style="width: 100%;">
        <!-- v-if="addPlan.customerType=='khfl6'" -->
        <el-table-column prop="factoryName" label="工厂" align="center">
          <template slot-scope="scope">
            <el-select v-model="scope.row.factory" placeholder="请选择工厂">
              <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column prop="oneWeekPlanSales" label="第一周" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.oneWeekPlanSales"
              placeholder="请输入第一周计划量" style="width: 100%;" @blur="inputBlur"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="twoWeekPlanSales" label="第二周" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.twoWeekPlanSales"
              placeholder="请输入第二周计划量" style="width: 100%;" @blur="inputBlur"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="threeWeekPlanSales" label="第三周" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.threeWeekPlanSales"
              placeholder="请输入第三周计划量" style="width: 100%;" @blur="inputBlur"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="fourWeekPlanSales" label="第四周" align="center">
          <template slot-scope="scope">
            <el-input-number :controls="false" :min="0" class="def-input-number" v-model="scope.row.fourWeekPlanSales"
              placeholder="请输入第四周计划量" style="width: 100%;" @blur="inputBlur"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" width="110px"
          v-if="identity == salesman && params.saleYear >= Number(year) && params.saleMonth >= Number(month )&& permi.hasPermi('system:sales-task:update')">
          <template slot-scope="scope">
            <el-popconfirm title="确定删除吗？" @confirm="clickDelRow(scope.$index)">
              <el-button slot="reference" size="small" type="text">删除</el-button>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitPlanForm('addPlan')">确 定</el-button>
        <el-button @click="closePlan">取 消</el-button>
      </div>
    </el-dialog>
    <!-- 新增 -->
    <el-dialog title="计划详情" :visible.sync="openDetail" width="1100px" append-to-body :close-on-click-modal="true">
      <el-form :model="detailPlan" ref="addPlan" size="small" :inline="true" label-width="100px">
        <el-form-item label="月份">
          <el-input v-model="detailPlan.yearmonth" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="客户">
          <el-input v-model="detailPlan.customerName" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="客户分类">
          <el-input v-model="detailPlan.customerTypeName" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="总计划">
          <el-input v-model="detailPlan.monthSales" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="完成量">
          <el-input v-model="detailPlan.monthCompleteSales" :disabled="true" style="width: 240px" />
        </el-form-item>
        <el-form-item label="达成率(%)">
          <el-input v-model="detailPlan.completeRation" :disabled="true" style="width: 240px" />
        </el-form-item>
      </el-form>
      <el-table row-key="id" :data="planDetail" border style="width: 100%;">
        <!-- v-if="addPlan.customerType=='khfl6'" -->
        <el-table-column prop="factoryName" label="工厂" align="center"></el-table-column>
        <el-table-column label="第一周" align="center">
          <el-table-column prop="oneWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="oneWeekCompleteSales" label="完成" align="center"></el-table-column>
          <!-- <el-table-column prop="oneWeekCompleteRation" label="达成率(%)" align="center"></el-table-column> -->
        </el-table-column>
        <el-table-column label="第二周" align="center">
          <el-table-column prop="twoWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="twoWeekCompleteSales" label="完成" align="center"></el-table-column>
          <!-- <el-table-column prop="twoWeekCompleteRation" label="达成率(%)" align="center"></el-table-column> -->
        </el-table-column>
        <el-table-column label="第三周" align="center">
          <el-table-column prop="threeWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="threeWeekCompleteSales" label="完成" align="center"></el-table-column>
          <!-- <el-table-column prop="threeWeekCompleteRation" label="达成率(%)" align="center"></el-table-column> -->
        </el-table-column>
        <el-table-column label="第四周" align="center">
          <el-table-column prop="fourWeekPlanSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="fourWeekCompleteSales" label="完成" align="center"></el-table-column>
          <!-- <el-table-column prop="fourWeekCompleteRation" label="达成率(%)" align="center"></el-table-column> -->
        </el-table-column>
        <el-table-column label="本月" align="center">
          <el-table-column prop="monthSales" label="计划" align="center"></el-table-column>
          <el-table-column prop="monthCompleteSales" label="完成" align="center"></el-table-column>
          <el-table-column prop="monthCompleteRation" label="达成率(%)" align="center"></el-table-column>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
  import {
    getCustomer
  } from '@/api/teamwork/Allocate/index';
  import {
    newUpdate,
    listDetail,
    newDel
  } from '@/api/personal/index';
  import {
    salesman
  } from '../enum';
  import permi from '@/plugins/auth.js';
  import debounce from '@/utils/debounce.js';
  import {
    mapGetters
  } from 'vuex';
  import {
    getConfigMonth
  } from '@/api/personal/index';
  export default {
    props: {
      data: {
        type: Array,
        default: [],
      },

      params: {
        type: Object,
        default: () => {},
      },
      weekDays: {
        type: Object,
        default: () => {},
      },
      identity: {
        type: Number,
        default: -1,
      },
      tableHeight: {
        type: Number,
        default: 500,
      }
    },

    data() {
      return {
        options: this.getDictDatas('factory'),
        salesman,
        permi,
        loading: false,
        showTable: true,
        year: '2024',
        month: '1',
        openAdd: false,
        openDetail: false,
        detailPlan: {},
        planDetail: [],
        addPlan: {
          yearmonth: '',
          customerId: '',
          customerType: '',
          monthSales: '',
        },
        planRules: { //品项新增编辑校验
          yearmonth: [{
            required: true,
            message: '请选择月份',
            trigger: 'change'
          }],
          customerId: [{
            required: true,
            message: '请选择客户',
            trigger: 'blur'
          }],
          type: [{
            required: true,
            message: '请输入客户分类',
            trigger: 'blur'
          }],
          monthSales: [{
            required: true,
            message: '请输入总计划',
            trigger: 'blur'
          }],
        },
        planData: [{
          oneWeekPlanSales: 0,
          twoWeekPlanSales: 0,
          threeWeekPlanSales: 0,
          fourWeekPlanSales: 0,
        }],
        clientList: [],
        planType: '',
      };
    },

    computed: {
      ...mapGetters(['userId']),
    },

    watch: {
      'params.userId': {
        handler(newV) {
          getCustomer({
            isBelongSale: 1,
            belongSale: newV,
          }).then(
            (res) => {
              if (res.code == 0) {
                this.clientList = res.data
              }
            })
        }
      },
    },

    created() {
      this.getConfigDate();
    },

    methods: {
      getSummaries(param) {
        const {
          columns,
          data
        } = param;
        const sums = [];
        let monthSales = 0;
        let monthCompleteSales = 0;
        let monthCompleteRate = 0;
        columns.forEach((column, index) => {
          if (index === 0) {
            sums[index] = '合计';
            return;
          }
          const values = data.map(item => Number(item[column.property]));
          if (!values.every(value => isNaN(value))) {
            sums[index] = values.reduce((prev, curr) => {
              const value = Number(curr);
              if (!isNaN(value)) {
                return prev + curr;
              } else {
                return prev;
              }
            }, 0);
            sums[index] = sums[index].toFixed(0)
            sums[index] += '';
            if (column.property == 'monthSales') {
              monthSales = sums[index]
            }
            if (column.property == 'monthCompleteSales') {
              monthCompleteSales = sums[index]
            }
            if (column.property == 'monthCompleteRate') {
              monthCompleteRate = index
            }
          } else {
            sums[index] = '';
          }
        });
        sums[monthCompleteRate] = (monthCompleteSales / monthSales * 100).toFixed(0);
        if (monthCompleteSales == 0 || monthSales == 0) {
          sums[monthCompleteRate] = 0
        }
        if (isNaN(sums[monthCompleteRate])) {
          sums[monthCompleteRate] = 0
        }
        return sums;
      },
      toPersonal(item) {
        this.$router.push({
          path: '/personal/salesman',
          query: {
            userId: item.userId,
          },
        });
      },
      inputBlur() {
        this.addPlan.monthSales = 0
        this.planData.forEach(item => {
          this.addPlan.monthSales = this.addPlan.monthSales + item.oneWeekPlanSales + item.twoWeekPlanSales + item
            .threeWeekPlanSales + item
            .fourWeekPlanSales;
        })
      },
      clickAddRow() {
        this.planData.push({
          oneWeekPlanSales: 0,
          twoWeekPlanSales: 0,
          threeWeekPlanSales: 0,
          fourWeekPlanSales: 0,
        })
      },
      clickDelRow(index) {
        this.planData.splice(index, 1)
        this.addPlan.monthSales = 0
        this.planData.forEach(item => {
          this.addPlan.monthSales = this.addPlan.monthSales + item.oneWeekPlanSales + item.twoWeekPlanSales + item
            .threeWeekPlanSales + item
            .fourWeekPlanSales;
        })
      },
      changeClient(e) {
        this.addPlan.userId = this.params.userId
        this.addPlan.userName = this.params.userName
        // this.addPlan.monthSales = ''
        this.clientList.forEach(item => {
          if (e == item.id) {
            this.addPlan.customerCode = item.code
            this.addPlan.customerName = item.name
            this.addPlan.customerTypeName = item.typeName
            this.addPlan.customerType = item.type
          }
        })
        // if (this.addPlan.customerType == 'khfl6') {
        // this.planData = [{
        //     factoryName: '北票一厂',
        //     factory: 'bp_1_factory',
        //     oneWeekPlanSales: 0,
        //     twoWeekPlanSales: 0,
        //     threeWeekPlanSales: 0,
        //     fourWeekPlanSales: 0,
        //   }, {
        //     factoryName: '北票二厂',
        //     factory: 'bp_2_factory',
        //     oneWeekPlanSales: 0,
        //     twoWeekPlanSales: 0,
        //     threeWeekPlanSales: 0,
        //     fourWeekPlanSales: 0,
        //   },
        //   {
        //     factoryName: '朝阳工厂',
        //     factory: 'cy_factory',
        //     oneWeekPlanSales: 0,
        //     twoWeekPlanSales: 0,
        //     threeWeekPlanSales: 0,
        //     fourWeekPlanSales: 0,
        //   },
        //   {
        //     factoryName: '喀左工厂',
        //     factory: 'kz_factory',
        //     oneWeekPlanSales: 0,
        //     twoWeekPlanSales: 0,
        //     threeWeekPlanSales: 0,
        //     fourWeekPlanSales: 0,
        //   }
        // ]
        // } else {
        //   this.planData = [{
        //     oneWeekPlanSales: 0,
        //     twoWeekPlanSales: 0,
        //     threeWeekPlanSales: 0,
        //     fourWeekPlanSales: 0,
        //   }]
        // }
      },
      submitPlanForm(formName) {
        this.addPlan.monthSales = 0
        this.planData.forEach(item => {
          this.addPlan.monthSales = this.addPlan.monthSales + item.oneWeekPlanSales + item.twoWeekPlanSales + item
            .threeWeekPlanSales + item
            .fourWeekPlanSales;
        })
        let validateData = false
        validateData = this.planData.some(function(item) {
          if (!item.factory) {
            return true; //返回false
          }
        })
        if (validateData) {
          this.$notify.warning({
            title: '必须选择工厂！'
          });
          return;
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.addPlan.builtInParentDeptId = this.params.deptId
            this.addPlan.saleYear = this.addPlan.yearmonth.slice(0, 4);
            this.addPlan.saleMonth = this.addPlan.yearmonth.slice(5, 7);
            newUpdate({
              ...this.addPlan,
              body: this.planData,
            }).then(
              (res) => {
                if (res.code == 0) {
                  this.openAdd = false
                  this.$emit('handleQuery');
                }
              }
            );
          } else {
            return false;
          }
        });
      },
      closePlan() {
        this.openAdd = false
      },
      clickDetail(row) {
        listDetail({
          isFactoryTotal: 1,
          ...row,
          ...this.params,
        }).then((res) => {
          this.detailPlan = res.data
          this.detailPlan.yearmonth = this.detailPlan.saleYear + '-' + this.detailPlan.saleMonth
          this.planDetail = res.data.body
          this.openDetail = true
        });
      },
      clickAdd(type, row) {
        this.planType = type
        if (type == 'add') {
          this.addPlan = {
            yearmonth: this.params._date,
            customerId: '',
            customerTypeName: '',
            monthSales: '',
          }
          this.planData = []
          this.openAdd = true
        } else if (type == 'edit') {
          listDetail({
            isFactoryTotal: 1,
            ...row,
            ...this.params,
          }).then((res) => {
            this.addPlan = res.data
            this.addPlan.yearmonth = this.addPlan.saleYear + '-' + this.addPlan.saleMonth
            this.planData = res.data.body
            this.openAdd = true
          });
        }
      },
      getConfigDate() {
        getConfigMonth().then((res) => {
          this.year = res.data.year;
          this.month = res.data.month;
        });
      },
      showLoading() {
        this.loading = true;
      },
      hideLoading() {
        this.loading = false;
      },
      showTableFun() {
        this.showTable = true;
      },
      hideTableFun() {
        this.showTable = false;
      },
      clickDel(row) {
        newDel({
          ...row,
          ...this.params,
        }).then((res) => {
          this.$emit('handleQuery');
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  ::v-deep .el-table--medium .el-table__cell {
    padding: 0 !important;
  }

  ::v-deep .el-input.is-disabled .el-input__inner {
    color: #000;
  }

  .table-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
  }

  //去掉number输入框的上下箭头
  ::v-deep input::-webkit-outer-spin-button,
  ::v-deep input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  ::v-deep input[type='number'] {
    -moz-appearance: textfield;
  }
</style>
