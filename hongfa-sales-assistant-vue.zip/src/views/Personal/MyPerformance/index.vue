<template>
  <div class="dashboard-editor-container">
    <el-row class="row-btm">
      <el-card class="box-card">
        <div slot="header" class="clearfix box-card-header">
          <span style="flex: 1;">我的绩效({{queryParams.nickname}})</span>
          <div class="clearfix">
            <el-form ref="queryRef" size="small" :inline="true" label-width="70px">
              <el-form-item label="客户分类" prop="customerTypeMore">
                <el-select multiple clearable v-model="queryParams.customerTypeMore" placeholder="请选择客户分类" style="width: 240px">
                  <el-option v-for="item in clientTypes" :key="item.value" :value="item.value" :label="item.label"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="月份">
                <el-date-picker :clearable="false" v-model="queryParams.yearmonth" type="month" @change="changeDate" value-format="yyyy-MM">
                </el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button icon="el-icon-search" @click="handleQuery">查询</el-button>
                <el-button icon="el-icon-refresh" @click="handleReset">重置</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
        <div class="home-sys-record_wrapper">
          <div class="record-item">
            <span class="item-label">总销量(吨)</span>
            <countTo class="item-value" :end="systemBriefInfo.saleAmount?systemBriefInfo.saleAmount : 0" :decimals="2" />
          </div>
          <div class="record-item">
            <span class="item-label">新客单量</span>
            <countTo class="item-value" :end="systemBriefInfo.newOrder?systemBriefInfo.newOrder : 0" />
          </div>
          <div class="record-item">
            <span class="item-label">高价单量</span>
            <countTo class="item-value" :end="systemBriefInfo.totalHigh?systemBriefInfo.totalHigh : 0" />
          </div>
          <div class="record-item">
            <span class="item-label">计划量(吨)</span>
            <countTo class="item-value" :end="systemBriefInfo.monthSales?systemBriefInfo.monthSales : 0" :decimals="2" />
          </div>
          <!-- <div class="record-item">
            <span class="item-label">完成量(吨)</span>
            <countTo class="item-value" :end="systemBriefInfo.monthCompleteSales?systemBriefInfo.monthCompleteSales : 0" :decimals="2" />
          </div> -->
          <div class="record-item">
            <span class="item-label">达成率（%）</span>
            <countTo class="item-value" :end="systemBriefInfo.completeRation?systemBriefInfo.completeRation : 0" :decimals="2" />
          </div>
        </div>
      </el-card>
    </el-row>
    <el-row class="row-btm">
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="客户提成" name="1">
          <el-button icon="el-icon-download" :loading="exportLoading1" @click="handleExport1" style="float: right;">导出</el-button>
          <el-table row-key="id" :data="tableData1" border v-loading="tableLoading1" show-summary>
            <el-table-column prop="customerCode" label="客户编码" align="center"></el-table-column>
            <el-table-column prop="customerName" label="客户名称" min-width="100" align="center"></el-table-column>
            <el-table-column prop="customerTypeName" label="客户分类" align="center"></el-table-column>
            <el-table-column prop="amount" label="销售量(吨)" align="center"></el-table-column>
            <el-table-column prop="totalReward" label="提成" align="center"></el-table-column>
          </el-table>
          <pagination v-show="queryParams1.total>0" :total="queryParams1.total" :page.sync="queryParams1.pageNo"
            :limit.sync="queryParams1.pageSize" @pagination="getCustomerList()" />
        </el-tab-pane>
        <el-tab-pane label="品项提成" name="2">
          <el-button icon="el-icon-download" :loading="exportLoading2" @click="handleExport2" style="float: right;">导出</el-button>
          <el-table row-key="id" :data="tableData1" border v-loading="tableLoading1" show-summary>
            <el-table-column prop="customerCode" label="客户编码" align="center"></el-table-column>
            <el-table-column prop="customerName" label="客户名称" min-width="100" align="center"></el-table-column>
            <el-table-column prop="customerTypeName" label="客户分类" align="center"></el-table-column>
            <el-table-column prop="amount" label="销售量(吨)" align="center"></el-table-column>
            <el-table-column prop="totalReward" label="提成" align="center"></el-table-column>
          </el-table>
          <el-table row-key="id" :data="tableData2" border v-loading="tableLoading2" show-summary style="margin-top: 10px;">
            <el-table-column prop="productTypeName" label="分类" align="center"></el-table-column>
            <el-table-column prop="productCode" label="品项编码" align="center"></el-table-column>
            <el-table-column prop="productName" label="品项名称" min-width="100" align="center"></el-table-column>
            <el-table-column prop="factoryName" label="工厂" min-width="100" align="center"></el-table-column>
            <el-table-column prop="amount" label="销售量(吨)" align="center"></el-table-column>
            <el-table-column prop="market" label="市场提成" align="center"></el-table-column>
            <el-table-column prop="high" label="高端提成" align="center"></el-table-column>
            <el-table-column prop="totalReward" label="总提成" align="center"></el-table-column>
          </el-table>
          <pagination v-show="queryParams2.total>0" :total="queryParams2.total" :page.sync="queryParams2.pageNo"
            :limit.sync="queryParams2.pageSize" @pagination="getProductList()" />
        </el-tab-pane>
        <el-tab-pane label="周考核提成" name="3">
          <el-button icon="el-icon-download" :loading="exportLoading3" @click="handleExport3" style="float: right;">导出</el-button>
          <el-table row-key="id" :data="tableData3" border v-loading="tableLoading3" show-summary>
            <el-table-column label="周" align="center">
              <template slot-scope="scope">
                <span v-if="scope.row.week==1">第一周</span>
                <span v-else-if="scope.row.week==2">第二周</span>
                <span v-else-if="scope.row.week==3">第三周</span>
                <span v-else-if="scope.row.week==4">第四周</span>
              </template>
            </el-table-column>
            <el-table-column prop="productName" label="品项" min-width="100" align="center"></el-table-column>
            <el-table-column prop="completeSales" label="销售量(吨)" align="center"></el-table-column>
            <el-table-column prop="factoryName" label="工厂" align="center"></el-table-column>
            <el-table-column prop="reward" label="提成" align="center"></el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </el-row>
  </div>
</template>

<script>
  import {
    deepClone
  } from '@/utils';
  import {
    getUserProfile
  } from '@/api/system/user';
  import resize from '@/views/dashboard/mixins/resize';
  import {
    getTimeConfig,
    getList,
    getCustomerList,
    getProductList,
    getWeekList,
    exportList1,
    exportList2,
    exportList3
  } from '@/api/teamwork/Performance';
  import CountTo from "@/components/count-to";
  export default {
    name: 'MyPerformance',
    mixins: [resize],
    components: {
      CountTo,
    },
    data() {
      return {
        clientTypes: [], //客户分类下拉框
        exportLoading1: false,
        exportLoading2: false,
        exportLoading3: false,
        queryParams1: { //周考核品项查询条件
          total: 0,
          pageSize: 10,
          pageNo: 1,
          type: 1,
        },
        queryParams2: { //周考核品项查询条件
          total: 0,
          pageSize: 10,
          pageNo: 1,
        },
        activeName: '1',
        queryParams: {
          yearmonth: '',
          startDate: '',
          endDate: '',
          nickname: '',
          saleUserId: '',
          area: '',
          userId: '',
          customerTypeMore: [],
        },
        tableData1: [],
        tableLoading1: false,
        tableData2: [],
        tableLoading2: false,
        tableData3: [],
        tableLoading3: false,
        systemBriefInfo: {}, //客户统计数
      };
    },
    watch: {
      '$route': { // $route可以用引号，也可以不用引号
        async handler(to, from) {
          this.clientTypes = deepClone(this.getDictDatas(this.DICT_TYPE.CLIENT_TYPE));
          if (to.query && to.query.area) {
            this.queryParams.area = to.query.area
          }
          if (to.query && to.query.nickname) {
            this.queryParams.nickname = to.query.nickname
          }
          if (to.query && to.query.customerTypeMore) {
            this.queryParams.customerTypeMore = to.query.customerTypeMore
          }
          if (to.query && to.query.orderMonth) {
            this.queryParams.yearmonth = to.query.orderMonth;
            let year = this.queryParams.yearmonth.slice(0, 4);
            let month = this.queryParams.yearmonth.slice(5, 7);
            await getTimeConfig({
                year: year,
                month: month,
              })
              .then((res) => {
                if (res.data.length > 0) {
                  let resData = res.data[0]
                  if (resData.oneWeek) {
                    this.queryParams.startDate = resData.oneWeek.slice(0, 10)
                    this.queryParams.endDate = resData.fourWeek.slice(11, 21)
                  } else {
                    this.queryParams.startDate = ''
                    this.queryParams.endDate = ''
                  }
                } else {
                  this.queryParams.startDate = ''
                  this.queryParams.endDate = ''
                }
              })
          } else {
            this.queryParams.yearmonth = this.getBeforeMonth(0).slice(0, 7)
            let year = this.queryParams.yearmonth.slice(0, 4);
            let month = this.queryParams.yearmonth.slice(5, 7);
            await getTimeConfig({
                year: year,
                month: month,
              })
              .then((res) => {
                if (res.data.length > 0) {
                  let resData = res.data[0]
                  if (resData.oneWeek) {
                    this.queryParams.startDate = resData.oneWeek.slice(0, 10)
                    this.queryParams.endDate = resData.fourWeek.slice(11, 21)
                  } else {
                    this.queryParams.startDate = ''
                    this.queryParams.endDate = ''
                  }
                } else {
                  this.queryParams.startDate = ''
                  this.queryParams.endDate = ''
                }
              })
          }
          if (to.query && to.query.saleUserId) {
            this.queryParams.saleUserId = to.query.saleUserId
            this.queryParams.userId = to.query.saleUserId
            this.handleQuery()
          } else {
            this.getUser()
          }
        },
        deep: true, // 深度观察监听
        immediate: true, // 第一次初始化渲染就可以监听到
      },
    },
    methods: {
      //重置
      handleReset() {
        this.queryParams.customerTypeMore = []
        this.handleQuery()
      },
      getUser() {
        getUserProfile().then((response) => {
          this.queryParams.area = response.data.builtInParentDeptId
          this.queryParams.nickname = response.data.nickname
          this.queryParams.saleUserId = response.data.id
          this.queryParams.userId = response.data.id
          this.handleQuery()
        });
      },
      handleQuery() {
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${this.queryParams.yearmonth}没有配置时间，无法统计数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${this.queryParams.yearmonth}没有配置时间，无法统计数据`
          });
          return;
        }
        this.queryParams.customerTypes = this.queryParams.customerTypeMore.join(',')
        getList(
          this.queryParams
        ).then((res) => {
          this.systemBriefInfo = res.data[0] ? res.data[0] : {};
        });
        this.queryParams1.type = 1;
        this.queryParams1.pageSize = 10;
        this.queryParams1.pageNo = 1;
        this.queryParams2.pageNo = 1;
        if (this.activeName == '1') {
          this.getCustomerList()
        } else if (this.activeName == '2') {
          this.queryParams1.pageSize = 10000;
          this.queryParams1.type = 2;
          this.getCustomerList()
          this.getProductList()
        } else if (this.activeName == '3') {
          this.getWeekList()
        }
      },
      //导出列表数据
      handleExport1() {
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading1 = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList1(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '客户提成.xls');
            this.exportLoading1 = false;
          })
          .catch(() => {
            this.exportLoading1 = false;
          });
      },
      //导出列表数据
      handleExport2() {
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading2 = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList2(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '品项提成.xls');
            this.exportLoading2 = false;
          })
          .catch(() => {
            this.exportLoading2 = false;
          });
      },
      //导出列表数据
      handleExport3() {
        if (!this.queryParams.startDate) {
          this.$notify.error({
            title: `${startDate}没有配置时间，无法导出数据`
          });
          return;
        }
        if (!this.queryParams.endDate) {
          this.$notify.error({
            title: `${endDate}没有配置时间，无法导出数据`
          });
          return;
        }
        this.exportLoading3 = true;
        this.$modal
          .confirm('是否确认导出数据项?')
          .then(() => {
            return exportList3(this.queryParams);
          })
          .then((response) => {
            this.$download.excel(response, '周考核提成.xls');
            this.exportLoading3 = false;
          })
          .catch(() => {
            this.exportLoading3 = false;
          });
      },
      getCustomerList() {
        this.tableLoading1 = true
        this.tableData1 = []
        getCustomerList({
          ...this.queryParams1,
          ...this.queryParams
        }).then((res) => {
          this.tableLoading1 = false
          this.tableData1 = res.data.list;
          this.queryParams1.total = res.data.total;
        });
      },
      getProductList() {
        this.tableLoading2 = true
        getProductList({
          ...this.queryParams2,
          ...this.queryParams
        }).then((res) => {
          this.tableLoading2 = false
          this.tableData2 = res.data.list;
          this.queryParams2.total = res.data.total;
        });
      },
      getWeekList() {
        this.tableLoading3 = true
        getWeekList(
          this.queryParams
        ).then((res) => {
          this.tableLoading3 = false
          this.tableData3 = res.data;
        });
      },
      handleClick() {
        this.queryParams1.type = 1;
        this.queryParams1.pageSize = 10;
        this.queryParams1.pageNo = 1;
        this.queryParams2.pageNo = 1;
        if (this.activeName == '1') {
          this.getCustomerList()
        } else if (this.activeName == '2') {
          this.queryParams1.pageSize = 10000;
          this.queryParams1.type = 2;
          this.getCustomerList()
          this.getProductList()
        } else if (this.activeName == '3') {
          this.getWeekList()
        }
      },
      //配置月份
      async changeDate() {
        this.queryParams1.pageNo = 1;
        this.queryParams2.pageNo = 1;
        let year = this.queryParams.yearmonth.slice(0, 4);
        let month = this.queryParams.yearmonth.slice(5, 7);
        await getTimeConfig({
            year: year,
            month: month,
          })
          .then((res) => {
            if (res.data.length > 0) {
              let resData = res.data[0]
              if (resData.oneWeek) {
                this.queryParams.startDate = resData.oneWeek.slice(0, 10)
                this.queryParams.endDate = resData.fourWeek.slice(11, 21)
              } else {
                this.queryParams.startDate = ''
                this.queryParams.endDate = ''
              }
            } else {
              this.queryParams.startDate = ''
              this.queryParams.endDate = ''
            }
          })
      },
      //获取月份
      getBeforeMonth(n) {
        const now = new Date();
        now.setMonth(now.getMonth() - n);
        var year = now.getFullYear();
        var mon = now.getMonth() + 1;
        var day = now.getDate();
        let s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
        return s;
      },
    },
  };
</script>

<style lang="scss" scoped>
  .dashboard-editor-container {
    padding: 32px;
    background-color: rgb(240, 242, 245);
    position: relative;

    .row-btm {
      margin-bottom: 8px;
    }
  }

  .home-sys-record_wrapper {
    display: flex;
    justify-content: space-around;

    .record-item {
      background: linear-gradient(to bottom right, rgb(217 236 245), rgb(255 255 255));
      width: calc(14% - 28px);
      height: 80px;
      display: flex;
      flex-direction: column;
      align-items: center;
      border: 1px solid #eaebed;
      border-radius: 6px;
      padding: 4px;

      .item-label {
        font-size: 16px;
      }

      .item-value {
        font-weight: bold;
        font-size: 18px;
      }
    }
  }
</style>
