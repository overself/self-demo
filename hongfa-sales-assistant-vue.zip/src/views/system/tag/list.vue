<!-- 价格库存看板 -->
<template>
  <div class="">
    <el-table
      :data="tableData"
      border
      style="width: 100%;"
      :cell-style="addClass"
      tooltip-effect="dark"
      @selection-change="handleSelectionChange"
    >
      <el-table-column
        type="selection"
        width="55"
      >
      </el-table-column>
      <el-table-column
        prop="nums"
        label="标签分类"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="name"
        label="标签名称"
        header-align="center"
        align="center"
      > </el-table-column>

      <el-table-column
        prop="userType"
        label="客户分类"
        header-align="center"
        align="center"
      > </el-table-column>

      <el-table-column
        prop="deliveryNum"
        label="关联客户数量"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="deliveryPrice"
        label="标签描述"
        header-align="center"
        align="center"
      > </el-table-column>

      <el-table-column
        prop="concatName"
        label="创建人"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="salesName"
        label="启用状态"
        header-align="center"
        align="center"
      > </el-table-column>

      <el-table-column
        prop="time"
        label="更新时间"
        header-align="center"
        align="center"
      ></el-table-column>

      <el-table-column
        prop="amount12"
        label="操作"
        header-align="center"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template>
          <el-button
            v-hasPermi="['system:sign:delete']"
            size="mini"
            type="text"
          >删除</el-button>
          <el-button
            v-hasPermi="['system:sign:update']"
            size="mini"
            type="text"
            @click="handleEdit(scope)"
          >编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  data() {
    // 这里存放数据
    return {
      tableData: [
        {
          id: '12987122',
          nums: '1111111111111111',
          name: '宏发食品有限公司',
          userType: '市场',
          deliveryNum: '200',
          deliveryPrice: '2000',
          concatName: '李晓红',
          salesName: '未启用',
          belongArea: '宏发一区',
          isWholePrice: '1',
          time: '2024-08-08 14:44:44',
        },
      ],
    };
  },

  methods: {
    handleSelectionChange(val) {
      console.log('val', val);
    },
    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.cat_mao {
  position: absolute;
  top: 0;
}

.cat_text {
  margin: auto;
  width: 14px;
}

// @import url(); 引入公共css类
</style>