<template>
  <div class="app-container Board">
    <!-- 搜索工作栏 -->
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <div class="search_wrap">
          <div class="component_title">金蝶品项校验
            <div class="title_right_btns">
              <screenfull
                id="screenfull"
                class="right-menu-item hover-effect"
              />全屏
            </div>
          </div>

          <BaseSearchContainer
            :column="searchColumn"
            :params="queryParams"
            @onSearch="handleQuery"
          />
        </div>
        <CrudHeader>
          <template slot="rightBtns">

            <el-button
              size="small"
              style="margin-left:15px;"
              @click="handleAdd()"
            >手动同步</el-button>

            <el-button
              size="small"
              style="margin-left:15px;"
            >导出</el-button>
          </template>
          <template slot="list">
            <el-table
              :data="tableData"
              border
              style="width: 100%;"
            >
              <el-table-column
                prop="nums"
                label="品项编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="name"
                label="相名称"
                header-align="center"
                align="center"
              > </el-table-column>

              <el-table-column
                prop="userType"
                label="详细规格"
                header-align="center"
                align="center"
              > </el-table-column>

              <el-table-column
                prop="deliveryNum"
                label="品项分类"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="deliveryPrice"
                label="归属工厂"
                header-align="center"
                align="center"
              > </el-table-column>
              <el-table-column
                prop="deliveryPrice"
                label="同步状态"
                header-align="center"
                align="center"
              > </el-table-column>

              <el-table-column
                prop="concatName"
                label="同步时间"
                header-align="center"
                align="center"
              ></el-table-column>

            </el-table>
          </template>
        </CrudHeader>
      </el-col>
    </el-row>
  </div>
</template>
      <script>
import Screenfull from '@/components/Screenfull';
import BaseSearchContainer from '@/components/BaseSearchContainer/index';
export default {
  components: {
    Screenfull,
    BaseSearchContainer,
  },
  data() {
    return {
      open: false,
      options: [],
      tableData: [
        {
          id: '12987122',
          nums: '1111111111111111',
          name: '宏发食品有限公司',
          userType: '市场',
          deliveryNum: '200',
          deliveryPrice: '2000',
          concatName: '李晓红',
          salesName: '未启用',
          belongArea: '宏发一区',
          isWholePrice: '1',
          time: '2024-08-08 14:44:44',
        },
      ],
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        username: undefined,
        mobile: undefined,
        status: undefined,
        deptId: undefined,
        createTime: [],
      },
      searchColumn: [
        {
          label: '品项名称',
          prop: 'name',
          type: 'input',
          search: true,
        },
        {
          label: '品类选择',
          prop: 'name',
          type: 'select',
          search: true,
          dicData: [
            { label: '全部', value: '1' },
            { label: '客户分类1 ', value: '2' },
          ],
        },
        {
          label: '同步时间',
          prop: 'time',
          type: 'daterange',
          search: true,
        },
      ],
      rules: {},
      form: {},
    };
  },
  methods: {
    handleAdd() {
      this.open = true;
    },
    handleQuery() {},
  },
};
</script>