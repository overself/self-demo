<template>
  <div>价格表关系维护</div>
</template>