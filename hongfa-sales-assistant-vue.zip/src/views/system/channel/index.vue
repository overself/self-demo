<template>
  <div class="app-container Board">
    <!-- 搜索工作栏 -->
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <div class="search_wrap">
          <div class="component_title">客户渠道管理
            <div class="title_right_btns">
              <screenfull
                id="screenfull"
                class="right-menu-item hover-effect"
              />全屏
            </div>
          </div>
        </div>
        <div class="content_wrap">
          <el-row
            :gutter="10"
            class="mb20"
          >
            <el-col :span="1.5">
              <el-button
                v-hasPermi="['system:channel:create']"
                type="primary"
                plain
                icon="el-icon-plus"
                size="mini"
                @click="handleAdd"
              >新增</el-button>
            </el-col>
            <!-- <el-col :span="1.5">
              <el-button
                type="danger"
                icon="el-icon-delete"
                size="mini"
              >删除</el-button>
            </el-col> -->
            <el-col :span="1.5">
              <el-button
                type="info"
                plain
                icon="el-icon-sort"
                size="mini"
                @click="toggleExpandAll"
              >展开/折叠</el-button>
            </el-col>
          </el-row>
          <el-table
            v-if="refreshTable"
            :data="tableData"
            border
            style="width: 100%;"
            row-key="id"
            :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
            :default-expand-all="isExpandAll"
          >
            <el-table-column
              prop="name"
              label="渠道分类"
              header-align="center"
              align="center"
            ></el-table-column>

            <!-- <el-table-column
              prop="name"
              label="渠道名称"
              header-align="center"
              align="center"
            > </el-table-column> -->

            <el-table-column
              prop="customerCount"
              label="关联客户数量"
              header-align="center"
              align="center"
            > </el-table-column>

            <el-table-column
              prop="remark"
              label="渠道描述"
              header-align="center"
              align="center"
            > </el-table-column>

            <el-table-column
              prop="status"
              label="启用状态"
              header-align="center"
              align="center"
            >
              <template slot-scope="scope">
                <el-tag :type="scope.row.status?'success':'danger'">{{scope.row.status?'启用':"停用"}}</el-tag>
              </template>
            </el-table-column>

            <el-table-column
              prop="createTime"
              label="更新时间"
              header-align="center"
              align="center"
            >
              <template v-slot="scope">
                <span>{{ parseTime(scope.row.createTime) }}</span>
              </template>
            </el-table-column>

            <el-table-column
              prop="amount12"
              label="操作"
              header-align="center"
              align="center"
              class-name="small-padding fixed-width"
            >
              <template slot-scope="scope">
                <el-button
                  v-hasPermi="['system:channel:delete']"
                  size="mini"
                  type="text"
                  @click="deleteItem(scope.row)"
                >删除</el-button>
                <el-button
                  v-hasPermi="['system:channel:update']"
                  size="mini"
                  type="text"
                  @click="handleEdit(scope.row)"
                >编辑</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!-- <pagination
            v-show="total>0"
            :total="total"
            :page.sync="queryParams.pageNo"
            :limit.sync="queryParams.pageSize"
            @pagination="getList"
          /> -->
        </div>
      </el-col>
      <!--新增&&编辑-->
      <el-dialog
        :title="title"
        :visible.sync="open"
        width="500px"
        append-to-body
      >
        <el-form
          ref="ruleForm"
          :model="form"
          :rules="rules"
          label-width="125px"
        >
          <el-form-item
            label="创建人"
            prop="name"
          >
            <el-input
              v-model="nickname"
              placeholder="请输入角色名称"
              disabled
            />
          </el-form-item>
          <el-form-item
            label="渠道分类"
            prop="type"
          >
            <div style="display: flex;align-items: center;justify-content: space-between;">
              <el-select
                placeholder="请选择"
                style="width: 48%;"
                v-model="form.type"
                @change="getChannelList()"
              >
                <el-option
                  v-for="item in tagoOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
              <el-select
                placeholder="请选择"
                style="width: 48%;"
                v-model="form.parentId"
                v-if="form.type == 2"
              >
                <el-option
                  v-for="item in firstLevelOptions"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                >
                </el-option>
              </el-select>
            </div>
          </el-form-item>
          <el-form-item
            label="渠道名称"
            prop="name"
          >
            <el-input
              v-model="form.name"
              placeholder="请输入渠道名称"
            />
          </el-form-item>
          <el-form-item label="渠道说明">
            <el-input
              v-model="form.remark"
              type="textarea"
              placeholder="请填写渠道说明，限100字以内"
              show-word-limit
              maxlength="100"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="是否作为搜索字段"
            prop="isSearch"
          >
            <el-radio-group v-model="form.isSearch">
              <el-radio :label="1">是</el-radio>
              <el-radio :label="0">否</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item
            label="启用状态"
            prop="status"
          >
            <el-switch
              v-model="form.status"
              active-color="#13ce66"
              inactive-color="#ff4949"
              :active-value="1"
              :inactive-value="0"
            >
            </el-switch>
          </el-form-item>
        </el-form>
        <div
          slot="footer"
          class="dialog-footer"
        >
          <el-button
            type="primary"
            @click="submitForm('ruleForm')"
          >确 定</el-button>
          <el-button @click="open = false">取 消</el-button>
        </div>
      </el-dialog>
    </el-row>

  </div>
</template>
  <script>
import Screenfull from '@/components/Screenfull';
import { mapGetters } from 'vuex';
import { deepClone } from '@/utils';
import {
  listData,
  channelCreate,
  channelUpdate,
  channelDelete,
  channelList,
} from '@/api/system/channel';
export default {
  components: {
    Screenfull,
  },
  data() {
    return {
      // 总条数
      total: 0,
      queryParams: {
        pageNo: 1,
        pageSize: 10,
      },
      firstLevelOptions: [],
      open: false,

      form: {
        id: undefined,
        status: 0,
        isSearch: 1,
        type: 1,
      },
      tagoOptions: [
        {
          label: '一级渠道',
          value: 1,
        },
        {
          label: '二级渠道',
          value: 2,
        },
      ],
      rules: {
        type: [{ required: true, message: '请选择渠道分类', trigger: 'blur' }],
        name: [{ required: true, message: '请输入渠道名称', trigger: 'blur' }],
        isSearch: [
          {
            required: true,
            message: '请选择是否作为搜索字段',
            trigger: 'blur',
          },
        ],
        status: [{ required: true, message: '请选择状态', trigger: 'blur' }],
      },
      title: '新增标签',
      tableData: [],
      refreshTable: true,
      isExpandAll: true,
    };
  },
  computed: {
    ...mapGetters(['nickname']),
  },
  watch: {
    open(val) {
      if (!val) {
        this.form = {
          id: undefined,
          status: 0,
          isSearch: 1,
          type: 1,
        };
        this.$refs.ruleForm.resetFields();
      }
    },
  },
  methods: {
    getChannelList() {
      channelList().then((res) => {
        this.allChannel = res.data;
        this.firstLevelOptions = res.data.filter((item) => item.parentId == 0);
        // console.log('firstLevelOptions', this.firstLevelOptions);
      });
    },
    // 创建标签
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.form.type == 1) {
            this.form.parentId = 0;
          }
          if (!this.form.id) {
            channelCreate(this.form).then((res) => {
              this.getList();
              this.open = false;
              this.$message.success('创建成功');
            });
          } else {
            channelUpdate(this.form).then((res) => {
              this.getList();
              this.open = false;
              this.$message.success('编辑成功');
            });
          }
        }
      });
    },
    /** 展开/折叠操作 */
    toggleExpandAll() {
      this.refreshTable = false;
      this.isExpandAll = !this.isExpandAll;
      this.$nextTick(() => {
        this.refreshTable = true;
      });
    },
    getList() {
      listData(this.queryParams).then((res) => {
        this.tableData = this.handleTree(res.data, 'id');
        // this.total = res.data.total;
      });
    },
    handleSelectionChange(val) {
      console.log('val', val);
    },
    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        return 'background: #FAFAFB;font-weight: 600;font-size: 14px;color: #000000;line-height: 15px;';
      }
    },
    handleAdd() {
      this.open = true;
      this.title = '新增标签';
    },
    handleEdit(row) {
      this.form = deepClone(row);
      if (this.form.parentId != 0) {
        this.form.type = 2;
      } else {
        this.form.type = 1;
      }
      this.open = true;
      this.title = '编辑标签';
    },
    deleteItem(row) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          channelDelete({ id: row.id }).then((res) => {
            this.getList();
            this.$message({
              type: 'success',
              message: '删除成功!',
            });
          });
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          });
        });
    },
  },
  created() {
    this.getList();
    this.getChannelList();
  },
};
</script>