<template>
  <div class="app-container">
    <resetPwd class="pwd-wrapper" />
    <!-- <el-card class="box-card">
      <div
        slot="header"
        class="clearfix"
      >
        <span>个人中心（销售经理）</span>
      </div>

      <div>

        <el-row :gutter="30">
          <el-col :span="8">
            <div class="title">个人信息</div>
            <div class="user-info_wrapper">
              <el-avatar
                size="large"
                :src="user.avatar"
              ></el-avatar>

              <div class="info">
                <el-descriptions
                  title=""
                  :column="1"
                >
                  <el-descriptions-item label="姓名">{{user.nickname}}</el-descriptions-item>
                  <el-descriptions-item label="手机号">{{user.mobile}}</el-descriptions-item>
                  <el-descriptions-item label="部门">{{user.dept.name}}</el-descriptions-item>
                  <el-descriptions-item label="职位">{{posts}}</el-descriptions-item>
                </el-descriptions>
              </div>
            </div>
          </el-col>

          <el-col :span="8">
            <div>
              <div class="title">计划完成进度</div>

              <div class="process-wrapper">
                <div class="process-item">
                  <span>今日：</span>
                  <el-progress
                    :stroke-width="20"
                    :percentage="70"
                    :show-text="false"
                    status="success"
                  ></el-progress>
                  <span style="margin-left: 20px;">已完成90%</span>
                </div>

                <div class="process-item">
                  <span>本周：</span>
                  <el-progress
                    :stroke-width="20"
                    :percentage="70"
                    :show-text="false"
                  ></el-progress>
                  <span style="margin-left: 20px;">已完成90%</span>
                </div>

                <div class="process-item">
                  <span>本月：</span>
                  <el-progress
                    :stroke-width="20"
                    :percentage="70"
                    :show-text="false"
                    status="warning"
                  ></el-progress>
                  <span style="margin-left: 20px;">已完成90%</span>
                </div>
              </div>
            </div>
          </el-col>

          <el-col :span="8">
            <div>
              <div class="title">上月环比</div>
              <el-row>
                <el-col :span="8">
                  <div class="ratio-item">
                    <span>上月计划量</span>
                    <span>100吨</span>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="ratio-item">
                    <span>上月计划量</span>
                    <span>100吨</span>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="ratio-item">
                    <span>上月计划量</span>
                    <span>100吨</span>
                  </div>
                </el-col>
              </el-row>
            </div>

            <el-divider />

            <div>
              <div class="title">去年同比</div>

              <el-row>
                <el-col :span="8">
                  <div class="ratio-item">
                    <span>上月计划量</span>
                    <span>100吨</span>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="ratio-item">
                    <span>上月计划量</span>
                    <span>100吨</span>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="ratio-item">
                    <span>上月计划量</span>
                    <span>100吨</span>
                  </div>
                </el-col>
              </el-row>
            </div>
          </el-col>
        </el-row>
      </div>
    </el-card>

    <CrudHeader>
      <template slot="left">
        <el-tabs
          v-model="activeName"
          @tab-click="handleTabClick"
        >
          <el-tab-pane
            v-for="(item, index) in tabs"
            :key="index"
            :label="item.label"
            :name="item.name"
          >
            <div class="list_wrap">
              <div
                v-show="activeName == '2'"
                style="padding-left: 10px;"
              >
                <div>
                  <span>本月提成合计：￥</span>
                  <span style="font-size: 18px; font-weight: 700; color: #ff0000;">6000</span>
                  <span>元</span>
                </div>

                <div class="royalty-tips">提成规则说明</div>
              </div>

              <el-table
                :data="tableData"
                border
                style="width: 100%;"
              >
                <el-table-column
                  prop="name"
                  label="品牌名称"
                  header-align="center"
                  align="center"
                ></el-table-column>

                <el-table-column
                  prop="pName"
                  label="品项名称"
                  header-align="center"
                  align="center"
                  width="230"
                ></el-table-column>

                <el-table-column
                  prop="pCode"
                  label="品项编码"
                  header-align="center"
                  align="center"
                ></el-table-column>

                <el-table-column
                  prop="pGui"
                  label="详细规格"
                  header-align="center"
                  align="center"
                >
                  <template slot-scope="scope">
                    <span>{{scope.row.price}}/箱</span>
                  </template>
                </el-table-column>

                <el-table-column
                  prop="price"
                  label="价格"
                  header-align="center"
                  align="center"
                >
                  <template slot-scope="scope">
                    <span>{{scope.row.price}}元/kg</span>
                  </template>
                </el-table-column>

                <el-table-column
                  prop="price"
                  label="审批价格"
                  header-align="center"
                  align="center"
                >
                  <template slot-scope="scope">
                    <span :style="scope.row.price ? 'color: #FF0000': ''">{{scope.row.price}}元/kg</span>
                  </template>
                </el-table-column>

                <el-table-column
                  prop="sales"
                  label="销售数量"
                  header-align="center"
                  align="center"
                >
                  <template slot-scope="scope">
                    <span>{{scope.row.sales}}kg</span>
                  </template>
                </el-table-column>

                <el-table-column
                  prop="tPrice"
                  label="小计金额(元)"
                  header-align="center"
                  align="center"
                >
                  <template slot-scope="scope">
                    <span>￥{{scope.row.tPrice}}</span>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
        </el-tabs>
      </template>

      <template slot="rightBtns">
        <BaseSearchContainer
          :column="searchColumn"
          :params="queryParams"
          @onSearch="handleQuery"
        />

        <div style="margin-bottom: 18px;">
          <el-button
            size="small"
            v-show="activeName == '1'"
            @click="dialogVisible = true;"
          >新增</el-button>
          <el-button
            size="small"
            v-show="activeName == '2'"
          >导出</el-button>
        </div>
      </template>
    </CrudHeader>


    <el-dialog
      title="计划发货计划"
      :visible.sync="dialogVisible"
      width="1200px"
      append-to-body
    >
      <div>
        <div class="st-table-wrapper">
          <div class="st-table-head">
            <div class="st-table-item flex flex-d-c">
              <div
                class="st-table-label th border"
                style="width: 100%;"
              >工厂名称</div>
              <div class="flex1 bgc border col-span-2">库存</div>
              <div
                class="b-b"
                style="display: flex;"
              >
                <div
                  class="st-table-label th b-r"
                  style="flex: 1;"
                >联系人</div>
                <div
                  class="st-table-label th b-r"
                  style="flex: 1;"
                >客户名称</div>
                <div
                  class="st-table-label th b-r"
                  style="flex: 1;"
                >渠道</div>
              </div>
            </div>

            <div
              class="st-table-item"
              v-for="(item, index) in factoryList"
              :key='index'
            >
              <div
                class="st-table-label th border"
                style="width: 100%;"
              >{{item.label}}</div>
              <div>
                <div
                  class="b-b"
                  style="display: flex;"
                >
                  <div
                    class="st-table-label th b-r"
                    style="flex: 1;"
                  >市场库存：</div>
                  <div
                    class="st-table-label th b-r"
                    style="flex: 1;"
                  >2666</div>
                </div>

                <div
                  class="b-b"
                  style="display: flex;"
                >
                  <div
                    class="st-table-label th b-r"
                    style="flex: 1;"
                  >日均发货：</div>
                  <div
                    class="st-table-label th b-r"
                    style="flex: 1;"
                  >2666</div>
                </div>
              </div>

              <div>
                <div
                  class="b-b"
                  style="display: flex;"
                >
                  <div
                    class="st-table-label th b-r"
                    style="flex: 1;"
                  >计划</div>
                  <div
                    class="st-table-label th b-r"
                    style="flex: 1;"
                  >完成</div>
                </div>
              </div>

            </div>
          </div>

          <div class="st-table-body">
            <div
              v-for="(item, index) in addTableData"
              :key="index"
              class="flex"
            >
              <div class="st-table-item">
                <div class="bgc border col-span-2">{{item.name}}</div>
              </div>

              <div class="st-table-item">
                <div class="bgc border col-span-2">{{item.name}}</div>
              </div>

              <div class="st-table-item">
                <div class="bgc border col-span-2">市场</div>
                <div class="bgc border col-span-2">其它</div>
              </div>

            </div>
          </div>
        </div>

        <el-divider />

        <el-table
          :data="addTableData"
          :span-method="arraySpanMethod"
          :header-cell-style="headerStyle"
          border
          style="width: 100%;"
        >
          <el-table-column
            prop="name"
            label="工厂名称"
            header-align="center"
            align="center"
          >
            <el-table-column
              prop="name"
              label="库存"
              header-align="center"
              align="center"
            >
              <el-table-column
                prop="name"
                label="库存"
                header-align="center"
                align="center"
              >
                <el-table-column
                  prop="name"
                  label="联系人"
                  header-align="center"
                  align="center"
                ></el-table-column>

                <el-table-column
                  prop="name"
                  label="客户名称"
                  header-align="center"
                  align="center"
                ></el-table-column>

                <el-table-column
                  prop="name"
                  label="渠道"
                  header-align="center"
                  align="center"
                ></el-table-column>
              </el-table-column>

            </el-table-column>
          </el-table-column>

          <el-table-column
            v-for="(item, index) in factoryList"
            :key="index"
            prop="name"
            :label="item.label"
            header-align="center"
            align="center"
          >
            <el-table-column
              prop="name"
              label="市场库存"
              header-align="center"
              align="center"
            >
              <el-table-column
                prop="name"
                label="市场库存1"
                header-align="center"
                align="center"
              ></el-table-column>
            </el-table-column>

            <el-table-column
              prop="name"
              label="日均发货"
              header-align="center"
              align="center"
            >
              <el-table-column
                prop="name"
                label="日均发货1"
                header-align="center"
                align="center"
              ></el-table-column>
            </el-table-column>
          </el-table-column>
        </el-table>
      </div>

      <div
        slot="footer"
        class="dialog-footer"
      >
        <div>
          <el-button type="primary">保存</el-button>
          <el-button @click="dialogVisible = false;">取 消</el-button>
        </div>
      </div>
    </el-dialog> -->
  </div>
</template>

<script>
// import userAvatar from './userAvatar';
// import userInfo from './userInfo';
import resetPwd from './resetPwd';
import { getUserProfile } from '@/api/system/user';

export default {
  name: 'Profile',
  components: { resetPwd },
  data() {
    return {
      dialogVisible: false,
      user: {
        nickname: '',
        username: '',
        avatar: '',
        mobile: '',
        dept: {
          id: '',
          name: '',
          parentId: '',
        },
        posts: [],
      },
      roleGroup: {},
      postGroup: {},
      activeTab: 'userinfo',
      activeName: '1',
      tabs: [
        { label: '销售计划', name: '1' },
        { label: '我的提成', name: '2' },
      ],
      tableData: [
        {
          name: '龙鸟',
          pName: '公斤琵琶腿120-130',
          pCode: 'No89012',
          pGui: '1kg*10',
          price: 11.3,
          sales: 1000,
          tPrice: 11000,
        },
        {
          name: '龙鸟',
          pName: '公斤琵琶腿120-130',
          pCode: 'No89012',
          pGui: '1kg*10',
          price: 11.3,
          sales: 1000,
          tPrice: 11000,
        },
      ],
      addTableData: [
        {
          name: 'xiaomi',
          cName: '',
          markerPlan: '',
          markerComp: '',
          otherPlan: '',
          otherComp: '',
        },
      ],
      queryParams: {},
      searchColumn: [
        {
          label: '时间选择',
          prop: 'time',
          type: 'daterange',
          search: true,
        },
      ],
      factoryList: this.getDictDatas('factory'),
    };
  },

  computed: {
    posts() {
      if (this.user.posts.length) {
        return this.user.posts.map((item) => item.name).join(',');
      }

      return '暂无';
    },
  },

  created() {
    this.getUser();
  },

  methods: {
    handleTabClick() {},

    handleQuery() {},

    headerStyle({ row, column, rowIndex, columnIndex }) {
      // if (rowIndex == 1 && columnIndex == 0) {
      //   console.log(row, column);
      //   this.$nextTick(() => {
      //     document
      //       .getElementsByClassName(column.id)[0]
      //       .setAttribute('rowSpan', 2);
      //   });
      // }
    },

    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      console.log(row);
      console.log(column);
      console.log(rowIndex);
      console.log(columnIndex);

      if (columnIndex == 0 && rowIndex == 2) {
        return {
          rowspan: 3,
          colspan: 0,
        };
      }

      return {
        rowspan: 0,
        colspan: 0,
      };
    },

    getUser() {
      getUserProfile().then((response) => {
        this.user = response.data;
      });
    },
    setActiveTab(activeTab) {
      this.activeTab = activeTab;
    },
  },
};
</script>

<style lang="scss" scoped>
.title {
  font-size: 16px;
  font-weight: 700;
  margin-bottom: 10px;
}

.user-info_wrapper {
  display: flex;
  align-items: flex-start;

  .el-avatar {
    flex: 0 0 50px;
    height: 50px;
  }

  .info {
    margin-left: 20px;
  }
}

.process-wrapper {
  .process-item {
    display: flex;
    margin-bottom: 45px;

    &:nth-last-child(1) {
      margin-bottom: 0;
    }

    .el-progress.el-progress--line {
      flex: 1;
    }
  }
}

.ratio-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.royalty-tips {
  margin: 15px 0;
  font-size: 14px;
  color: rgba(153, 153, 153, 1);
}

.st-table-wrapper {
  .border {
    border-right: 1px solid #dfe6ec;
    border-bottom: 1px solid #dfe6ec;
  }

  .b-b {
    border-bottom: 1px solid #dfe6ec;
  }

  .b-r {
    border-right: 1px solid #dfe6ec;
  }

  .flex {
    display: flex;
  }

  .flex-d-c {
    flex-direction: column;
  }

  .flex1 {
    flex: 1;
  }

  .bgc {
    background-color: #f5f7fa;
  }

  .col-span-2 {
    line-height: 88px;
    text-align: center;
  }

  .st-table-head {
    display: flex;
  }

  .st-table-item {
    flex: 1;

    .st-table-label {
      display: inline-block;
      // width: 206px;
      height: 44px;
      line-height: 44px;
      text-align: center;

      &.th {
        background-color: #f5f7fa;
      }
    }
  }
}
.pwd-wrapper {
  margin-top: 20px;
  background: #fff;
}
</style>
