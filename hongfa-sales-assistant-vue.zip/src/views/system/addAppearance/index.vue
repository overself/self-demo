<template>
  <div class="app-container Board">
    <!-- 搜索工作栏 -->
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <div class="search_wrap">
          <div class="component_title">SAP品项主数据
            <div class="title_right_btns">
              <screenfull
                id="screenfull"
                class="right-menu-item hover-effect"
              />全屏
            </div>
          </div>

          <!-- <BaseSearchContainer
            ref="searchRef"
            :column="searchColumn"
            :params="queryParams"
            @onSearch="handleQuery"
            @onReset="resetQuery"
          /> -->
          <el-form
            :model="queryParams"
            ref="queryForm"
            size="small"
            :inline="true"
            label-width="68px"
          >
            <el-form-item
              label="品项大类"
              prop="productType"
            >
              <el-select
                filterable
                clearable
                v-model="queryParams.productTopTypeCode"
                placeholder="请选择"
                style="width: 240px"
              >
                <el-option
                  v-for="dict in searchProductTopTypeList"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>

            <el-form-item
              label="品项分类"
              prop="productType"
            >
              <el-select
                clearable
                v-model="queryParams.type"
                placeholder="请选择"
                style="width: 240px"
              >
                <el-option
                  v-for="dict in searchProductTypeList"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>

            <el-form-item
              label="品项名称"
              prop="productId"
            >
              <el-input
                v-model="queryParams.name"
                placeholder="请输入品项名称"
                style="width: 240px"
                clearable
              />
            </el-form-item>

            <el-form-item
              label="品项编码"
              prop="productId"
            >
              <el-input
                v-model="queryParams.code"
                placeholder="请输入品项编码"
                style="width: 240px"
                clearable
              />
            </el-form-item>

            <el-form-item
              label="业务状态"
              prop="productType"
            >
              <el-select
                clearable
                v-model="queryParams.businessStatus"
                placeholder="请选择"
                style="width: 240px"
              >
                <el-option
                  label="常用品项"
                  :value="1"
                />

                <el-option
                  label="历史品项"
                  :value="0"
                />
              </el-select>
            </el-form-item>

            <el-form-item
              label="开启状态"
              prop="isEnable"
            >
              <el-select
                clearable
                v-model="queryParams.isEnable"
                placeholder="请选择"
                style="width: 240px"
              >
                <el-option
                  label="开启"
                  :value="1"
                />

                <el-option
                  label="关闭"
                  :value="0"
                />
              </el-select>
            </el-form-item>

            <!-- <el-form-item
              label="选择日期"
              prop="priceDate"
            >
              <el-date-picker
                v-model="queryParams.priceDate"
                style="width: 240px"
                value-format="yyyy-MM-dd"
                type="date"
                placeholder="选择日期"
              />
            </el-form-item> -->

            <el-form-item>
              <el-button
                icon="el-icon-search"
                @click="handleQuery"
              >查询</el-button>
              <el-button
                icon="el-icon-refresh"
                @click="resetQuery"
              >重置</el-button>
            </el-form-item>
          </el-form>
        </div>
        <CrudHeader>
          <template slot="rightBtns">
            <!-- <el-button
              size="small"
              style="margin-left:15px;"
              @click="sync()"
            >手动同步</el-button> -->

            <!-- <el-button
              v-hasPermi="['system:product:create']"
              size="small"
              style="margin-left:15px;"
              @click="handleAdd()"
            >新增品项</el-button> -->

            <el-button
              v-hasPermi="['system:product:export']"
              size="small"
              style="margin-left:15px;"
              @click="handleExport"
            >导出</el-button>
          </template>

          <template slot="list">
            <el-table
              :data="tableData"
              border
              :cell-style="addClass"
              style="width: 100%;"
            >
              <el-table-column
                prop="productTopTypeCode"
                label="大类编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="productTopTypeName"
                label="品项大类"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="productTypeCode"
                label="品类编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="productTypeName"
                label="品项分类"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="code"
                label="品项编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="name"
                label="品项名称"
                header-align="center"
                align="center"
                width="230"
              > </el-table-column>

              <el-table-column
                prop="spec"
                label="详细规格"
                header-align="center"
                align="center"
              > </el-table-column>

              <!-- <el-table-column
                prop="belongFactories"
                label="归属工厂"
                header-align="center"
                align="center"
              > </el-table-column> -->
              <!-- <el-table-column
                prop="belongPrices"
                label="归属价格表"
                header-align="center"
                align="center"
              > </el-table-column> -->

              <!-- <el-table-column
                prop="syncStatus"
                label="同步状态"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <el-tag :type="scope.row.syncStatus?'success':'danger'">{{scope.row.syncStatus?'正常':"异常"}}</el-tag>
                </template>
              </el-table-column> -->

              <!-- <el-table-column
                prop="syncTime"
                label="同步时间"
                header-align="center"
                align="center"
              ></el-table-column> -->

              <el-table-column
                prop="businessStatus"
                label="业务状态"
                header-align="center"
                align="center"
                width="107"
              >
                <template slot-scope="scope">
                  <!--<el-button
                    v-if="permi.hasPermi('system:product:business-status')"
                    size="small"
                    @click="updateBusinessStatus(scope.row)"
                  >{{ scope.row.businessStatus === 1 ? '常用品项' : '历史品项' }}</el-button>

                  <span v-else>暂无权限</span>-->
                  <span>{{ scope.row.businessStatus === 1 ? '常用品项' : '历史品项' }}</span>
                </template>
              </el-table-column>

              <el-table-column
                prop="updater"
                label="操作人"
                header-align="center"
                align="center"
              ></el-table-column>
              <el-table-column
                prop="isEnable"
                label="开启状态"
                header-align="center"
                align="center"
                width="107"
              >
                <template slot-scope="scope">
                  <el-switch
                    v-if="permi.hasPermi('system:product:is-enable')"
                    v-model="scope.row.isEnable"
                    active-color="#13ce66"
                    @change="onSwitchChange($event, scope.row)"
                  ></el-switch>

                  <span v-else>暂无权限</span>
                </template>
              </el-table-column>
<!--              <el-table-column
                prop="concatName"
                label="操作"
                header-align="center"
                align="center"
                width="107"
              >
                <template slot-scope="scope">
                  <el-button
                    v-hasPermi="['system:product:update']"
                    type="text"
                    size="small"
                    @click="handleEdit(scope.row)"
                  >编辑</el-button>
                </template>
              </el-table-column>-->
            </el-table>

            <pagination
              v-show="total>0"
              :total="total"
              :page.sync="queryParams.pageNo"
              :limit.sync="queryParams.pageSize"
              @pagination="getList"
            />
          </template>
        </CrudHeader>

        <!--新增&&编辑-->
        <el-dialog
          :title="title"
          :visible.sync="open"
          width="600px"
          append-to-body
        >
          <el-form
            ref="ruleForm"
            :model="form"
            :rules="rules"
            label-width="125px"
          >
            <el-form-item
              label="品项编码"
              prop="code"
            >
              <el-input
                v-model="form.code"
                placeholder="请输入品项编码"
                :disabled="isEdit"
              />
            </el-form-item>

            <el-form-item
              label="详细规格"
              prop="spec"
            >
              <el-input
                v-model="form.spec"
                placeholder="请输入详细规格"
                :disabled="isEdit"
              />
            </el-form-item>

            <!-- <el-form-item
              label="选择归属工厂"
              prop="belongFactories"
            >
              <el-select
                v-model="form.belongFactories"
                multiple
                placeholder="请选择"
                style="width: 100%;"
              >
                <el-option
                  v-for="dict in factoryOption"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                >
                </el-option>
              </el-select>
            </el-form-item> -->

            <el-form-item
              label="品项名称"
              prop="name"
            >
              <el-input
                v-model="form.name"
                placeholder="请输入品项名称"
                :disabled="isEdit"
              />
            </el-form-item>

            <!-- <el-form-item
              label="选择归属价格表"
              prop="belongPrices"
            >
              <el-select
                v-model="form.belongPrices"
                multiple
                placeholder="请选择"
                style="width: 100%;"
              >
                <el-option
                  v-for="dict in priceType"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                >
                </el-option>
              </el-select>
            </el-form-item> -->

            <el-form-item
              label="品项分类"
              prop="type"
            >
              <el-select
                v-model="form.type"
                placeholder="请选择"
                style="width: 100%;"
                filterable
              >
                <el-option
                  v-for="dict in categoryclassify"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>

          <div
            slot="footer"
            class="dialog-footer"
          >
            <el-button
              type="primary"
              @click="submitForm('ruleForm')"
            >确 定</el-button>
            <el-button @click="open = false">取 消</el-button>
          </div>
        </el-dialog>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import Screenfull from '@/components/Screenfull';
import BaseSearchContainer from '@/components/BaseSearchContainer/index';
import {
  listData,
  productCreate,
  exportRole,
  productGet,
  productUpdate,
  productBusinessStatus,
  customerIsEnable,
} from '@/api/system/addAppearance/index';
import { productTopType, producTtype } from '@/api/Board/StockBoard';
import { DICT_TYPE, getDictDatas } from '@/utils/dict';
import permi from '@/plugins/auth.js';

export default {
  components: {
    Screenfull,
    BaseSearchContainer,
  },
  data () {
    return {
      searchProductTopTypeList: [],
      searchProductTypeList: [],
      permi,
      title: '新增品项',
      open: false,
      isEdit: false, // 是否是编辑
      options: [],
      total: 0,
      tableData: [],
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        businessStatus: 1,
        isEnable: '',
        type: '',
      },
      searchColumn: [
        {
          label: '品项分类',
          prop: 'type',
          type: 'select',
          search: true,
          dicData: getDictDatas(DICT_TYPE.SYSTEM_CATEGORY_CLASSIFY),
        },
        {
          label: '品项编码',
          prop: 'code',
          type: 'input',
          search: true,
        },
        {
          label: '品项名称',
          prop: 'name',
          type: 'input',
          search: true,
        },
        {
          label: '业务状态',
          prop: 'businessStatus',
          type: 'select',
          search: true,
          dicData: [
            {
              label: '常用品项',
              value: 1,
            },
            {
              label: '历史品项',
              value: 0,
            },
          ],
        },
        // {
        //   label: '同步时间',
        //   prop: 'time',
        //   type: 'daterange',
        //   search: true,
        // },
      ],
      rules: {
        code: [{ required: true, message: '请输入品项编码', trigger: 'blur' }],
        spec: [{ required: true, message: '请输入详细规格', trigger: 'blur' }],
        belongFactories: [
          { required: true, message: '请选择所属工厂', trigger: 'blur' },
        ],
        name: [{ required: true, message: '请输入品项名称', trigger: 'blur' }],
        type: [{ required: true, message: '请选择品项分类', trigger: 'blur' }],
        // belongPrices: [
        //   { required: true, message: '请选择归属价格', trigger: 'blur' },
        // ],
      },
      form: {
        id: undefined,
      },
      factoryOption: getDictDatas(DICT_TYPE.SYSTEM_FACTORY),
      priceType: getDictDatas(DICT_TYPE.SYSTEM_PRICE_TYPE),
      categoryclassify: getDictDatas(DICT_TYPE.SYSTEM_CATEGORY_CLASSIFY),
    };
  },
  watch: {
    open (val) {
      if (!val) {
        this.form = {
          id: undefined,
        };
        this.$refs.ruleForm.resetFields();
        this.isEdit = false;
      }
    },
    'queryParams.productTopTypeCode' (newVal, oldVal) {
      console.log(newVal, oldVal);
      if (newVal === '') {
        this.searchProductTypeList = [];
      } else {
        this.queryParams.type = '';
        this.getSearchProducTtype();
      }
    },
  },

  created () {
    this.getProductTopType();
    this.getList();
  },

  methods: {
    //获取商品大类
    getProductTopType () {
      productTopType().then((res) => {
        this.searchProductTopTypeList = res.data;
      });
    },
    // 获取搜索品项分类
    getSearchProducTtype () {
      producTtype({ value: this.queryParams.productTopTypeCode }).then(
        (res) => {
          this.searchProductTypeList = res.data;
        }
      );
    },
    onSwitchChange (e, item) {
      customerIsEnable(item.id)
        .then((res) => {
          this.$message.success('开启状态更新成功');
          this.getList();
        })
        .catch((err) => {
          item.isEnable = !e;
        });
    },
    updateBusinessStatus (item) {
      productBusinessStatus(item.id)
        .then((res) => {
          this.$message.success('业务状态更新成功');
          this.getList();
        })
        .catch((err) => { });
    },

    // 同步
    sync () {
      this.$message.error('后端暂无接口');
    },

    // 获取品项分类
    getType (type) {
      return (
        this.categoryclassify.find((item) => item.value == type)?.label ?? '-'
      );
    },
    /** 导出按钮操作 */
    handleExport () {
      const queryParams = this.queryParams;
      //   exportRole(queryParams).then((res) => {
      //     this.$download.excel(res, '金蝶用户校验.xls');
      //   });
      this.$modal
        .confirm('是否确认导出数据项?')
        .then(() => {
          //   this.exportLoading = true;
          return exportRole(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '品项主数据校验.xls');
          //   this.exportLoading = false;
        })
        .catch(() => { });
    },
    // 编辑
    handleEdit (row) {
      productGet({ id: row.id, isApp: false }).then((res) => {
        this.form = res.data;
        this.form.belongFactories = res.data.belongFactoryKeys;
        // this.form.belongPrices = res.data.belongPriceKeys;
        delete this.form.belongPrices;
        this.isEdit = true;
        this.open = true;
        this.title = '编辑品项';
      });
    },
    getList () {
      listData(this.queryParams).then((res) => {
        this.tableData = res.data.list;
        this.total = res.data.total;
      });
    },
    submitForm (formName) {
      //   console.log('form', this.form);
      //   return;
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (!this.form.id) {
            productCreate(this.form).then((res) => {
              this.getList();
              this.open = false;
              this.$message.success('创建成功');
            });
          } else {
            productUpdate(this.form).then((res) => {
              this.getList();
              this.open = false;
              this.$message.success('编辑成功');
            });
          }
        }
      });
    },

    handleAdd () {
      this.title = '新增品项';
      this.open = true;
    },

    // 查询
    handleQuery (e) {
      //   console.log('查询参数', e);
      this.queryParams.pageNo = 1;
      this.getList();
    },

    // 重置、
    resetQuery () {
      //   console.log('searchRef', this.$refs.searchRef);
      //   console.log('hookForm', this.$refs.hookForm);
      //   this.$refs.searchRef.$refs.hookForm.resetFields();
      this.queryParams = {
        pageNo: 1,
        pageSize: 10,
        businessStatus: 1,
        isEnable: '',
        productTopTypeCode: '',
        type: '',
        name: '',
        code: '',
      };
      this.getList();
    },

    addClass ({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 6) {
        return 'background: #FAFAFB; font-weight: 600; font-size: 14px; color: #000000; line-height: 15px;';
      }

      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },
  },
};
</script>
