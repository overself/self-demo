<template>
  <div class="app-container Board">
    <!-- 搜索工作栏 -->
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <div class="search_wrap">
          <div class="component_title">客户主数据
            <div class="title_right_btns">
              <screenfull
                id="screenfull"
                class="right-menu-item hover-effect"
              />全屏
            </div>
          </div>

          <BaseSearchContainer
            :column="searchColumn"
            :params="queryParams"
            ref="searchRef"
            @onSearch="handleQuery"
            @onReset="resetQuery"
          />
        </div>
        <CrudHeader>
          <template slot="rightBtns">
            <!-- <el-button
              size="small"
              style="margin-left:15px;"
              @click="sync()"
            >手动同步</el-button> -->

            <!-- <el-button
              v-hasPermi="['hf:customer:create']"
              size="small"
              style="margin-left:15px;"
              @click="handleAdd()"
            >新增用户</el-button> -->

            <el-button
              v-hasPermi="['hf:customer:export']"
              size="small"
              style="margin-left:15px;"
              @click="handleExport"
              :loading="exportLoading"
            >导出</el-button>
          </template>

          <template slot="list">
            <el-table
              :data="tableData"
              border
              :cell-style="addClass"
              style="width: 100%;"
            >
              <el-table-column
                prop="customerCode"
                label="客户编码"
                header-align="center"
                align="center"
              > </el-table-column>

              <el-table-column
                prop="customerName"
                label="客户名称"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="sendCustomerCode"
                label="送货客户编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="sendCustomerName"
                label="送货客户名称"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="businessStatus"
                label="业务状态"
                header-align="center"
                align="center"
                width="107"
              >
                <template slot-scope="scope">
                  <!--<el-button v-if="permi.hasPermi('system:customer:business-status')" size="small"
                  @click="updateBusinessStatus(scope.row)"
                  {{ scope.row.businessStatus === 1 ? '常用客户' : '历史客户' }}
                  </el-button>
                  <span v-else>暂无权限</span>-->
                  {{ scope.row.businessStatus === 1 ? '常用客户' : '历史客户' }}
                </template>
              </el-table-column>

              <el-table-column
                prop="isEnable"
                label="开启状态"
                header-align="center"
                align="center"
                width="107"
              >
                <template slot-scope="scope">
                  <el-switch disabled
                    v-if="permi.hasPermi('system:customer:is-enable')"
                    v-model="scope.row.isEnable"
                    active-color="#13ce66"
                    @change="onSwitchChange($event, scope.row)"
                  ></el-switch>

                  <span v-else>暂无权限</span>
                </template>
              </el-table-column>

              <!--<el-table-column
                label="操作"
                header-align="center"
                align="center"
                class-name="small-padding fixed-width"
                width="107"
              >
                <template v-slot="scope">
                  <span
                    v-if="scope.row.isConfirm === 1"
                    style="color: #b3b3b3;"
                  >已确认</span>

                  <div v-else>
                    <el-button
                      v-if="permi.hasPermi('system:customer:confirm')"
                      size="mini"
                      type="text"
                      @click="confirmCustom(scope.row)"
                    >确认</el-button>

                    <span v-else>暂无权限</span>
                  </div>
                </template>
              </el-table-column>-->

              <!-- <el-table-column
                prop="syncTime"
                label="同步时间"
                header-align="center"
                align="center"
              ></el-table-column> -->
            </el-table>

            <pagination
              v-show="total>0"
              :total="total"
              :page.sync="queryParams.pageNo"
              :limit.sync="queryParams.pageSize"
              @pagination="getList"
            />
          </template>
        </CrudHeader>

        <!--新增&&编辑-->
        <el-dialog
          title="新增客户"
          :visible.sync="open"
          width="600px"
          append-to-body
        >
          <el-form
            ref="ruleForm"
            :model="form"
            :rules="rules"
            label-width="125px"
          >
            <el-form-item
              label="客户编码"
              prop="code"
            >
              <el-input
                v-model="form.code"
                placeholder="请输入客户编码"
              />
            </el-form-item>

            <el-form-item
              label="客户名称"
              prop="code"
            >
              <el-input
                v-model="form.name"
                placeholder="请输入客户名称"
              />
            </el-form-item>

            <el-form-item
              label="业务状态"
              prop="businessStatus"
            >
              <el-radio
                v-model="form.businessStatus"
                :label="1"
              >设为常用客户</el-radio>
              <el-radio
                v-model="form.businessStatus"
                :label="0"
              >设为历史客户</el-radio>
            </el-form-item>

            <el-form-item
              label="开启状态"
              prop="isEnable"
            >
              <el-radio
                v-model="form.isEnable"
                :label="1"
              >开启客户列表显示</el-radio>
              <el-radio
                v-model="form.isEnable"
                :label="0"
              >关闭客户列表显示</el-radio>
            </el-form-item>
          </el-form>

          <div
            slot="footer"
            class="dialog-footer"
          >
            <el-button
              type="primary"
              @click="submitForm('ruleForm')"
            >确 定</el-button>
            <el-button @click="open = false">取 消</el-button>
          </div>
        </el-dialog>

        <!-- 确认 -->
        <el-dialog
          title="客户确认"
          :visible.sync="confirmDialog"
          width="700px"
          append-to-body
        >
          <div v-if="confirmForm._hasParent">
            <el-descriptions
              title=""
              :column="2"
              border
            >
              <el-descriptions-item label="一级客户编码">{{confirmForm.customerCode}}</el-descriptions-item>
              <el-descriptions-item label="一级客户名称">{{confirmForm.customerName}}</el-descriptions-item>
              <el-descriptions-item label="送货客户编码">{{confirmForm.sendCustomerCode ? confirmForm.sendCustomerCode : '-'}}</el-descriptions-item>
              <el-descriptions-item label="二级(送货)客户名称">{{confirmForm.sendCustomerName ? confirmForm.sendCustomerName : '-'}}</el-descriptions-item>
            </el-descriptions>
          </div>

          <el-form
            v-else
            ref="confirmForm"
            :model="confirmForm"
            :rules="confirmFormRules"
            label-width="145px"
          >
            <el-row>
              <el-col :span="12">
                <el-form-item
                  label="客户编码(一级)"
                  prop="customerCode"
                >
                  <el-input
                    v-model="confirmForm.customerCode"
                    placeholder="请输入客户编码"
                    disabled
                  />
                </el-form-item>
              </el-col>

              <el-col :span="12">
                <el-form-item
                  label="客户名称(一级)"
                  prop="customerName"
                >
                  <el-input
                    v-model="confirmForm.customerName"
                    placeholder="请输入客户名称"
                  />
                </el-form-item>
              </el-col>
            </el-row>

            <el-row>
              <el-col :span="12">
                <el-form-item
                  label="送货客户编码(二级)"
                  prop="sendCustomerCode"
                >
                  <el-input
                    v-model="confirmForm.sendCustomerCode"
                    placeholder="请输入送货客户编码"
                    disabled
                  />
                </el-form-item>
              </el-col>

              <el-col :span="12">
                <el-form-item
                  label="送货客户名称(二级)"
                  prop="sendCustomerName"
                >
                  <el-input
                    v-model="confirmForm.sendCustomerName"
                    placeholder="请输入送货客户名称"
                    disabled
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>

          <div
            slot="footer"
            class="dialog-footer"
          >
            <el-button
              type="primary"
              @click="sureConfirmCustom"
            >确 定</el-button>
            <el-button @click="confirmDialog = false">取 消</el-button>
          </div>
        </el-dialog>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import Screenfull from '@/components/Screenfull';
import BaseSearchContainer from '@/components/BaseSearchContainer/index';
import {
  listCustomerTotalData,
  customerCreate,
  exportRole,
  getLevelCustomerInfo,
  customerConfirm,
  customerIsEnable,
  customerBusinessStatus,
} from '@/api/system/addCustomer/index';
import permi from '@/plugins/auth.js';
import { deepClone } from '@/utils';

export default {
  components: {
    Screenfull,
    BaseSearchContainer,
  },

  data() {
    return {
      permi,
      exportLoading: false,
      // 总条数
      total: 0,
      open: false,
      confirmDialog: false,
      tableData: [],
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        businessStatus: 1,
      },
      searchColumn: [
        {
          label: '客户编码',
          prop: 'code',
          type: 'input',
          search: true,
        },
        {
          label: '客户名称',
          prop: 'name',
          type: 'input',
          search: true,
        },
        {
          label: '业务状态',
          prop: 'businessStatus',
          type: 'select',
          search: true,
          dicData: [
            {
              label: '常用客户',
              value: 1,
            },
            {
              label: '历史客户',
              value: 0,
            },
          ],
        },
        {
          label: '开启状态',
          prop: 'isEnable',
          type: 'select',
          search: true,
          dicData: [
            {
              label: '开启',
              value: 1,
            },
            {
              label: '关闭',
              value: 0,
            },
          ],
        },
        /*{
          label: '确认操作',
          prop: 'isConfirm',
          type: 'select',
          search: true,
          dicData: [
            {
              label: '已确认',
              value: 1,
            },
            {
              label: '待确认',
              value: 0,
            },
          ],
        },*/
        // {
        //   label: '同步时间',
        //   prop: 'time',
        //   type: 'daterange',
        //   search: true,
        // },
      ],
      rules: {
        name: [{ required: true, message: '请输入客户名称', trigger: 'blur' }],
        code: [{ required: true, message: '请输入客户编码', trigger: 'blur' }],
        businessStatus: [
          {
            required: true,
            message: '请选择业务状态',
            trigger: ['blur', 'change'],
          },
        ],
        isEnable: [
          {
            required: true,
            message: '请选择开启状态',
            trigger: ['blur', 'change'],
          },
        ],
      },
      confirmFormRules: {
        customerName: [
          { required: true, message: '请输入客户名称', trigger: 'blur' },
        ],
      },
      form: {
        name: '',
        code: '',
        businessStatus: '',
        isEnable: '',
      },
      confirmForm: {
        customerId: '',
        customerCode: '',
        customerName: '',
        sendCustomerCode: '',
        sendCustomerName: '',
      },
    };
  },

  watch: {
    open(val) {
      if (!val) {
        this.form = {
          name: '',
          code: '',
        };
        this.$refs.ruleForm.resetFields();
      }
    },

    confirmDialog(val) {
      if (!val) {
        this.confirmForm = {
          customerId: '',
          customerCode: '',
          customerName: '',
          sendCustomerCode: '',
          sendCustomerName: '',
        };
        this.$refs.confirmForm?.resetFields();
      }
    },
  },

  created() {
    this.getList();
  },

  methods: {
    updateBusinessStatus(item) {
      customerBusinessStatus(item.customerId)
        .then((res) => {
          this.$message.success('业务状态更新成功');
          this.getList();
        })
        .catch((err) => {});
    },

    onSwitchChange(e, item) {
      customerIsEnable(item.customerId)
        .then((res) => {
          this.$message.success('开启状态更新成功');
          this.getList();
        })
        .catch((err) => {
          item.isEnable = !e;
        });
    },

    sureConfirmCustom() {
      let params = {
        customerId: this.confirmForm.customerId,
      };

      if (!this.confirmForm._hasParent) {
        params.customerName = this.confirmForm.customerName;

        this.$refs.confirmForm.validate((valid) => {
          if (valid) {
            customerConfirm(params).then((res) => {
              this.$message.success('确认成功');
              this.confirmDialog = false;
              this.getList();
            });
          }
        });

        return;
      }

      customerConfirm(params).then((res) => {
        this.$message.success('确认成功');
        this.confirmDialog = false;
        this.getList();
      });
    },

    confirmCustom(row) {
      this.confirmDialog = true;

      // console.log(row);

      getLevelCustomerInfo(row.customerId).then((res) => {
        // console.log(res);
        this.confirmForm = res.data;
        this.confirmForm._hasParent =
          res.data.customerCode !== null &&
          res.data.customerCode !== '' &&
          res.data.customerCode !== '-';

        if (!this.confirmForm._hasParent) {
          // 没有上级
          let sendCustomerCodeArr =
            this.confirmForm.sendCustomerCode.split('.');
          sendCustomerCodeArr.pop();
          this.confirmForm.customerCode = sendCustomerCodeArr.join('.');
          this.confirmForm.customerName = this.confirmForm.sendCustomerName;
        }
      });
    },

    // 同步
    sync() {
      this.$message.error('后端暂无接口');
    },
    /** 导出按钮操作 */
    handleExport() {
      const queryParams = this.queryParams;
      //   exportRole(queryParams).then((res) => {
      //     this.$download.excel(res, '金蝶用户校验.xls');
      //   });
      this.$modal
        .confirm('是否确认导出数据项?')
        .then(() => {
          //   this.exportLoading = true;
          return exportRole(queryParams);
        })
        .then((response) => {
          this.$download.excel(response, '客户主数据校验.xls');
          //   this.exportLoading = false;
        })
        .catch(() => {});
    },

    // 查询
    handleQuery(e) {
      //   console.log('查询参数', e);
      this.queryParams.pageNo = 1;
      this.getList();
    },

    // 重置、
    resetQuery() {
      //   console.log('searchRef', this.$refs.searchRef);
      //   console.log('hookForm', this.$refs.hookForm);
      this.$refs.searchRef.$refs.hookForm.resetFields();
      this.queryParams = {
        pageNo: 1,
        pageSize: 10,
        businessStatus: 1,
      };
      this.getList();
    },

    getList() {
      listCustomerTotalData(this.queryParams).then((res) => {
        this.tableData = res.data.list;
        this.total = res.data.total;
      });
    },

    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          customerCreate(this.form).then((res) => {
            this.getList();
            this.open = false;
            this.$message.success('创建成功');
          });
        }
      });
    },
    handleAdd() {
      this.open = true;
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.el-table .fixed-width .el-button--mini {
  padding-left: 3px;
  padding-right: 3px;
}
</style>
