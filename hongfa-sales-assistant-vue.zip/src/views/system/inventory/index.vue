<template>
  <div class="app-container Board">
    <!-- 搜索工作栏 -->
    <el-row :gutter="20">
      <el-col
        :span="24"
        :xs="24"
      >
        <div class="search_wrap">
          <div class="component_title">库存填写配置
            <div class="title_right_btns">
              <screenfull
                id="screenfull"
                class="right-menu-item hover-effect"
              />全屏
            </div>
          </div>

          <BaseSearchContainer
            ref="searchRef"
            :column="searchColumn"
            :params="queryParams"
            @onSearch="handleQuery"
            @onReset="resetQuery"
          >
            <template #productTopTypeCode>
              <el-select
                v-model="queryParams.productTopTypeCode"
                placeholder="请选择品项大类"
                clearable
                filterable
                style="width: 240px;"
                @change="onProductTopTypeCodeChange"
              >
                <el-option
                  v-for="item in productTopTypeCodeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </template>

            <template #productTypeCode>
              <el-select
                v-model="queryParams.productTypeCode"
                placeholder="请选择品项分类"
                clearable
                filterable
                allow-create
                style="width: 240px;"
              >
                <el-option
                  v-for="item in productTypeCodeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </template>
          </BaseSearchContainer>
        </div>

        <CrudHeader>
          <template slot="list">
            <el-table
              :data="tableData"
              border
              :cell-style="addClass"
              style="width: 100%;"
              v-loading="loading"
            >
              <el-table-column
                prop="productTopTypeCode"
                label="大类编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="productTopTypeName"
                label="品项大类"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="productTypeCode"
                label="品类编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="productTypeName"
                label="品项分类"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="productCode"
                label="品项编码"
                header-align="center"
                align="center"
              ></el-table-column>

              <el-table-column
                prop="productName"
                label="品项名称"
                header-align="center"
                align="center"
                width="230"
              > </el-table-column>

              <el-table-column
                prop="spec"
                label="详细规格"
                header-align="center"
                align="center"
              > </el-table-column>

              <el-table-column
                prop="factoryManagers"
                label="仓库管理员"
                header-align="center"
                align="center"
              > </el-table-column>

              <el-table-column
                prop="concatName"
                label="操作"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <el-button
                    v-hasPermi="['system:product:update']"
                    type="text"
                    size="small"
                    @click="handleEdit(scope.row)"
                  >编辑</el-button>
                </template>
              </el-table-column>
            </el-table>

            <pagination
              v-show="total>0"
              :total="total"
              :page.sync="queryParams.pageNo"
              :limit.sync="queryParams.pageSize"
              @pagination="getList"
            />
          </template>
        </CrudHeader>

        <!--新增&&编辑-->
        <el-dialog
          :title="title"
          :visible.sync="open"
          width="800px"
          append-to-body
        >
          <div>
            <el-table
              :data="editTableData"
              border
              style="width: 100%;"
            >
              <el-table-column
                prop="factoryName"
                label="归属工厂"
                header-align="center"
                align="center"
                width="155px"
              ></el-table-column>

              <el-table-column
                prop="managersList"
                label="仓库管理员"
                header-align="center"
                align="center"
              >
                <template slot-scope="scope">
                  <span v-if="scope.row.managersList.length == 0">暂无</span>

                  <div v-else>
                    <el-checkbox-group v-model="scope.row.selectedList">
                      <el-checkbox
                        v-for="(item, index) in scope.row.managersList"
                        :label="item.value"
                        :key="index"
                      >{{item.label}}</el-checkbox>
                    </el-checkbox-group>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>

          <div
            slot="footer"
            class="dialog-footer"
          >
            <el-button
              type="primary"
              @click="submitForm"
            >保 存</el-button>
            <el-button @click="open = false">取 消</el-button>
          </div>
        </el-dialog>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import Screenfull from '@/components/Screenfull';
import BaseSearchContainer from '@/components/BaseSearchContainer/index';
import {
  listData,
  update,
  factoryUserList,
} from '@/api/system/inventory/index';
import { DICT_TYPE, getDictDatas } from '@/utils/dict';
import permi from '@/plugins/auth.js';
import { productTopType, producTtype } from '@/api/Board/StockBoard.js';

export default {
  components: {
    Screenfull,
    BaseSearchContainer,
  },
  data() {
    return {
      permi,
      loading: false,
      editLoading: false,
      title: '新增品项',
      open: false,
      isEdit: false, // 是否是编辑
      options: [],
      total: 0,
      tableData: [],
      editTableData: [],
      queryParams: {
        pageNo: 1,
        pageSize: 10,
        productTopTypeCode: '',
        productTypeCode: '',
      },
      searchColumn: [
        {
          label: '品项大类',
          prop: 'productTopTypeCode',
          type: 'select',
          search: true,
          dicUrl: '/system/product/top/type/simple-list',
          dicLabelProp: 'label',
          dicValueProp: 'value',
        },
        {
          label: '品项分类',
          prop: 'productTypeCode',
          type: 'select',
          search: true,
          dicData: [],
        },
        {
          label: '品项名称',
          prop: 'productName',
          type: 'input',
          search: true,
        },
      ],
      rules: {
        code: [{ required: true, message: '请输入品项编码', trigger: 'blur' }],
        spec: [{ required: true, message: '请输入详细规格', trigger: 'blur' }],
        belongFactories: [
          { required: true, message: '请选择所属工厂', trigger: 'blur' },
        ],
        name: [{ required: true, message: '请输入品项名称', trigger: 'blur' }],
        type: [{ required: true, message: '请选择品项分类', trigger: 'blur' }],
        // belongPrices: [
        //   { required: true, message: '请选择归属价格', trigger: 'blur' },
        // ],
      },
      form: {
        id: undefined,
      },
      factoryOption: getDictDatas(DICT_TYPE.SYSTEM_FACTORY),
      priceType: getDictDatas(DICT_TYPE.SYSTEM_PRICE_TYPE),
      categoryclassify: getDictDatas(DICT_TYPE.SYSTEM_CATEGORY_CLASSIFY),
      productTopTypeCodeList: [],
      productTypeCodeList: [],
    };
  },

  watch: {
    open(val) {
      if (!val) {
        this.isEdit = false;
      }
    },
  },

  created() {
    this.handleGetProductTopType().then(() => {
      this.getList();
    });
  },

  methods: {
    onProductTopTypeCodeChange(e) {
      this.queryParams.productTypeCode = '';

      producTtype({
        value: e,
      }).then((res) => {
        this.productTypeCodeList = res.data;
      });
    },

    // 获取品项分类
    getType(type) {
      return (
        this.categoryclassify.find((item) => item.value == type)?.label ?? '-'
      );
    },

    // 编辑
    handleEdit(row) {
      this.editLoading = true;
      factoryUserList().then((res) => {
        // console.log(res);

        let arr = [];
        let factoryManagerIds = row.factoryManagerIds
          ? row.factoryManagerIds.split(',')
          : [];

        for (let key in res.data) {
          let obj = {
            factoryCode: key,
            managersList: res.data[key],
            selectedList: res.data[key]
              .filter((item) => factoryManagerIds.includes(item.value))
              .map((itm) => itm.value),
          };

          switch (key) {
            case 'bp1Factory':
              obj.factoryName = '北票一厂';
              break;

            case 'bp2Factory':
              obj.factoryName = '北票二厂';
              break;

            case 'cyFactory':
              obj.factoryName = '朝阳工厂';
              break;

            case 'kzFactory':
              obj.factoryName = '喀左工厂';
              break;

            /*case 'kzlnFactory':
              obj.factoryName = '喀左工厂(龙鸟)';
              break;

            case 'kzyyFactory':
              obj.factoryName = '喀左工厂(远赢)';
              break;*/
          }

          arr.push(obj);
        }

        this.editLoading = false;
        this.editTableData = arr;
        this.form = row;
        this.isEdit = true;
        this.open = true;
        this.title = '编辑仓库管理员';
      });
    },

    getList() {
      this.loading = true;
      listData(this.queryParams).then((res) => {
        this.loading = false;
        this.tableData = res.data.list;
        this.total = res.data.total;
      });
    },

    handleGetProductTopType() {
      return new Promise((resolve, reject) => {
        productTopType().then((res) => {
          this.productTopTypeCodeList = res.data;
          resolve(res);
        });
      });
    },

    submitForm() {
      update({
        productId: this.form.id,
        userIds: this.editTableData.flatMap((itm) => itm.selectedList),
      }).then((res) => {
        this.getList();
        this.open = false;
        this.$message.success('更新成功');
      });
    },

    handleAdd() {
      this.title = '新增品项';
      this.open = true;
    },

    // 查询
    handleQuery(e) {
      //   console.log('查询参数', e);
      this.getList();
    },

    // 重置、
    resetQuery() {
      //   console.log('searchRef', this.$refs.searchRef);
      //   console.log('hookForm', this.$refs.hookForm);
      this.queryParams = {
        pageNo: 1,
        pageSize: 10,
        productTopTypeCode: '',
        productTypeCode: '',
      };
      this.getList();
    },

    addClass({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 5 || columnIndex === 6) {
        return 'background: #FAFAFB; font-weight: 600; font-size: 14px; color: #000000; line-height: 15px;';
      }

      if (row[column.property] == null) {
        row[column.property] = '-';
      }
    },
  },
};
</script>

<style lang="scss" scoped>
::v-deep .list_wrap {
  margin-top: 0 !important;
}
</style>
