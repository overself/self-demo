<template>
  <div id="app">
    <router-view />
    <theme-picker />
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import ThemePicker from '@/components/ThemePicker';
import { listenfullscreen } from '@/utils/fullScreen.js';

export default {
  name: 'App',
  components: { ThemePicker },

  computed: {
    ...mapGetters(['sidebar']),
  },

  mounted() {
    listenfullscreen(this.setScreen);
  },

  metaInfo() {
    return {
      title:
        this.$store.state.settings.dynamicTitle &&
        this.$store.state.settings.title,
      titleTemplate: (title) => {
        return title
          ? `${title} - ${process.env.VUE_APP_TITLE}`
          : process.env.VUE_APP_TITLE;
      },
    };
  },

  methods: {
    setScreen() {
      if (document.fullscreenElement && this.sidebar.opened) {
        this.$store.dispatch('app/toggleSideBar');
      }
    },
  },
};
</script>
<style scoped>
#app .theme-picker {
  display: none;
}
</style>
