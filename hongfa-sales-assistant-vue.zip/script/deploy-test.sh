#!/bin/bash

# 设置变量
LOCAL_PROJECT_DIR="./"
REMOTE_USER="root"
REMOTE_HOST="123.57.78.187"
REMOTE_DIR="/www/wwwroot/hongfa.admin.vue/dist"

# 打包 Vue 项目
echo "正在打包 Vue 项目 for test环境..."
cd $LOCAL_PROJECT_DIR
yarn build:test

# 检查打包是否成功
if [ $? -ne 0 ]; then
  echo "打包失败，请检查错误信息。"
  exit 1
fi

# 删除远程服务器上的旧文件
echo "删除远程服务器上的旧文件..."
ssh $REMOTE_USER@$REMOTE_HOST "rm -rf $REMOTE_DIR/*"

# 上传新文件到远程服务器
echo "上传新文件到远程服务器..."
scp -r $LOCAL_PROJECT_DIR/dist/* $REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR

# 检查上传是否成功
if [ $? -ne 0 ]; then
  echo "文件上传失败，请检查错误信息。"
  exit 1
fi

echo "部署成功！"
