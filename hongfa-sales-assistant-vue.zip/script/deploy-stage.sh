#!/bin/bash

# 设置变量
LOCAL_PROJECT_DIR="./"
REMOTE_USER="root"
REMOTE_HOST="60.22.64.169"
REMOTE_DIR="/www/wwwroot/192.168.0.145_48083"

# 打包 Vue 项目
echo "正在打包 Vue 项目 for stage环境..."
cd $LOCAL_PROJECT_DIR
yarn build:stage

# 检查打包是否成功
if [ $? -ne 0 ]; then
  echo "打包失败，请检查错误信息。"
  exit 1
fi

# 删除远程服务器上的旧文件
echo "删除远程服务器上的旧文件..."
ssh $REMOTE_USER@$REMOTE_HOST "rm -rf $REMOTE_DIR/*"

# 上传新文件到远程服务器
echo "上传新文件到远程服务器..."
scp -r -P 30 $LOCAL_PROJECT_DIR/dist/* $REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR

# 检查上传是否成功
if [ $? -ne 0 ]; then
  echo "文件上传失败，请检查错误信息。"
  exit 1
fi

echo "部署成功！"
