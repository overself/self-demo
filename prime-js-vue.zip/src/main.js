import { createApp } from 'vue';
import App from './App.vue';
import router from './router';
import VueI18n from 'vue-i18n';

import Aura from '@primevue/themes/aura';
import PrimeVue from 'primevue/config';
import ConfirmationService from 'primevue/confirmationservice';
import ToastService from 'primevue/toastservice';

import { LOCALE_MESSAGE } from '@/i18n/ag-grid-language'

import { AgGridVue } from 'ag-grid-vue3';

import '@/assets/styles.scss';
import '@/assets/tailwind.css';

const app = createApp(App);

// Vue Routers
app.use(router);

// PrimeVue UI custom
app.use(PrimeVue, {
    theme: {
        preset: Aura,
        options: {
            darkModeSelector: '.app-dark'
        }
    }
});
app.use(ToastService);
app.use(ConfirmationService);

// AG Grid import
app.component("ag-grid-vue", AgGridVue);

// i18n setting
// 获取浏览器语言
const preferredLang = localStorage.getItem('preferred_lang');
const lang = preferredLang || (navigator.language || navigator.browserLanguage).toLowerCase();

VueI18n.createI18n({
    locale: lang.substr(0, 2),
    messages: LOCALE_MESSAGE,
    allowComposition: true,
    legacy: false, // 如果要支持compositionAPI，此项必须设置为false;
    globalInjection: true // 全局注册$t方法
})
app.use(VueI18n)

app.config.globalProperties.$AgGrid={
    localeText: this.$i18n.locale
}

// APP amount
app.mount('#app');
