export const PRIME_UI_LOCALE_CN = {
    "views.pv.000001": "Personal Center",
    "views.pv.000002": "Logout",
    "views.pv.000003": "Home Page"
}
