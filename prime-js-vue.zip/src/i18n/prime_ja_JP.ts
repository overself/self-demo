export const PRIME_UI_LOCALE_JP = {
    "views.pv.000001": "パーソナルセンター",
    "views.pv.000002": "ログオン",
    "views.pv.000003": "ポータル"
}
