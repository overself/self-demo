package com.wenjay.sample.web.model.user.feign.factory;

import com.wenjay.sample.web.model.user.feign.RemoteTenantService;
import com.wenjay.sample.web.model.user.feign.fallback.RemoteTenantServiceFallbackImpl;
import org.springframework.stereotype.Component;

/**
 * <p>Title: </p>
 * <p> Description:</p>
 * <p>  </p>
 *
 * @author HanWenjie
 */
@Component
public class RemoteTenantServiceFallbackFactory /*implements FallbackFactory<RemoteTenantService>*/ {

    //@Override
    public RemoteTenantService create(Throwable throwable) {
        RemoteTenantServiceFallbackImpl remoteUserServiceFallback = new RemoteTenantServiceFallbackImpl();
        remoteUserServiceFallback.setCause(throwable);
        return remoteUserServiceFallback;
    }
}
