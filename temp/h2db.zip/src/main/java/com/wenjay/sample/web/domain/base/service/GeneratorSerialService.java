package com.wenjay.sample.web.domain.base.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.wenjay.sample.web.domain.base.entity.GeneratorSerial;
import jodd.util.ArraysUtil;

public interface GeneratorSerialService extends IService<GeneratorSerial> {

    /**
     * 获取指定类型的当前最大流水号
     *
     * @param serialName
     * @param prefixCode
     * @return
     */
    String getCurrentSerialMaxNumber(String serialName, String prefixCode);

    /**
     * 删除参数serialName指定的流水记录（除参数perfixCode指定除外）
     *
     * @param serialName
     * @param perfixCode
     * @return
     */
    boolean delSerialWithoutThisPrefix(String serialName, String perfixCode);

    /**
     * 获得ScenarioNo
     *
     * @return
     */
    String generateScenarioNo();

    String generateScenarioSubNo(String kind, String prefixCode);

    String[] generateScenarioBPackage(String prefixCode);

    String[] generateScenarioSPackage(String prefixCode);

    String[] generateScenarioAttribute(String prefixCode);


}
