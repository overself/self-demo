package com.wenjay.sample.web.model.user.feign;

import com.wenjay.sample.web.model.user.co.TenantCo;
import com.wenjay.sample.web.model.user.dto.TenantDto;
import com.wenjay.sample.web.model.user.vo.TenantVo;
import com.wenjay.framework.web.model.co.PageCondition;
import com.wenjay.framework.web.model.vo.Result;
import com.wenjay.framework.web.model.vo.ResultPage;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>Title: </p>
 * <p> Description:</p>
 * <p>  </p>
 *
 * @author Hanwenjie
 */
//@FeignClient(value = ServiceNameConstant.IM_WEBCHAT_CHAT_SERVICE, fallbackFactory = RemoteImManagerServiceFallbackFactory.class)
public interface RemoteTenantService {


    /**
     * 数据对象详细
     *
     * @param id 用户名
     * @return R
     */
    @GetMapping("/api/tenant/info/{id}")
    Result<TenantVo> info(@PathVariable("id") String id);

    /**
     * 查询数据对象
     *
     * @param tenantCo 用户名
     * @return R
     */
    @GetMapping("/api/tenant/page.json")
    ResultPage<List<TenantVo>> tenants(@RequestBody PageCondition<TenantCo> tenantCo);

    /**
     * 保存数据对象
     * @param tenantDto
     * @return
     */
    @PostMapping("/api/tenant/save")
    Result<Boolean> save(@Valid @RequestBody TenantDto tenantDto);
}
