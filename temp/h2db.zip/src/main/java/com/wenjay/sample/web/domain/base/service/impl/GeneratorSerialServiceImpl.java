package com.wenjay.sample.web.domain.base.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.wenjay.framework.core.common.constant.MessageCode;
import com.wenjay.framework.core.exception.BusinessException;
import com.wenjay.sample.web.domain.base.entity.GeneratorSerial;
import com.wenjay.sample.web.domain.base.mapper.GeneratorSerialMapper;
import com.wenjay.sample.web.domain.base.service.GeneratorSerialService;
import jodd.util.ArraysUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("generatorSerialService")
public class GeneratorSerialServiceImpl extends ServiceImpl<GeneratorSerialMapper, GeneratorSerial> implements GeneratorSerialService {

    @Value("${spring.datasource.driver-class-name:}")
    private String dbDriver;

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
    public String getCurrentSerialMaxNumber(String serialName, String prefixCode) {
        if (StrUtil.isBlank(serialName)) {
            throw new BusinessException(MessageCode.COMM_SYS_ERROR, "没有指定生成流水编码的名称");
        }
        GeneratorSerial serialEntity = new GeneratorSerial();
        serialEntity.setSerialName(serialName);
        serialEntity.setPrefixCode(prefixCode);
        if ("org.h2.Driver".equalsIgnoreCase(dbDriver)) {
            getSequenceSerialNum(serialEntity);
        } else {
            baseMapper.getSequenceSerialNum(serialEntity);
        }
        if (serialEntity.getCurrentValue() != null) {
            return serialEntity.getCurrentValue().toString();
        }
        serialEntity.setCurrentValue(1);
        return save(serialEntity) ? serialEntity.getCurrentValue().toString() : null;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
    public boolean delSerialWithoutThisPrefix(String serialName, String perfixCode) {
        LambdaQueryWrapper<GeneratorSerial> qr = Wrappers.lambdaQuery();
        return this.remove(qr.eq(GeneratorSerial::getSerialName, serialName).notIn(GeneratorSerial::getPrefixCode, perfixCode)
        );
    }

    @Override
    public String generateScenarioNo() {
        String serialMax = getCurrentSerialMaxNumber("SCENARIO", "main");
        return StrUtil.padPre(serialMax, 4, "0");
    }

    @Override
    public String generateScenarioSubNo(String kind, String prefixCode) {
        StringBuffer billNumber = new StringBuffer();
        if ("B".equals(kind)) {
            billNumber.append("B#").append(prefixCode).append("-");
        } else if ("S".equals(kind)) {
            billNumber.append("S#").append(prefixCode).append("-");
        } else {
            billNumber.append("A#").append(prefixCode).append("-");
        }
        String serialMax = getCurrentSerialMaxNumber("SCENARIO_" + kind, prefixCode);
        return billNumber.append(StrUtil.padPre(serialMax, "S".equals(kind) ? 2 : 3, "0")).toString();
    }

    public String[] generateScenarioBPackage(String prefixCode) {
        String serialMax = generateScenarioSubNo("B", prefixCode);
        String serialBNo = serialMax.replace("B#", "B10").replace("-", "");
        return ArraysUtil.array(serialMax, serialBNo);
    }

    public String[] generateScenarioSPackage(String prefixCode) {
        String serialMax = generateScenarioSubNo("S", prefixCode);
        String serialB = serialMax.replace("S#", "S10").replace("-", "");
        String serialMSN = serialMax.replace("S#", "8010").replace("-", "");
        return ArraysUtil.array(serialMax, serialB, serialMSN);
    }

    public String[] generateScenarioAttribute(String prefixCode) {
        String serialMax = generateScenarioSubNo("A", prefixCode);
        return ArraysUtil.array(serialMax);
    }

    private void getSequenceSerialNum(GeneratorSerial serialEntity) {
        LambdaQueryWrapper<GeneratorSerial> qr = Wrappers.lambdaQuery();
        qr.eq(GeneratorSerial::getSerialName, serialEntity.getSerialName());
        qr.eq(GeneratorSerial::getPrefixCode, serialEntity.getPrefixCode());
        GeneratorSerial serial = getOne(qr, true);
        if (serial == null) {
            return;
        }
        serial.setCurrentValue(serial.getCurrentValue() + 1);
        if (saveOrUpdate(serial)) {
            BeanUtils.copyProperties(serial, serialEntity);
        }
    }

}
