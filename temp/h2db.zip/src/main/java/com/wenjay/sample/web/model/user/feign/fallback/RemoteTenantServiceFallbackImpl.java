package com.wenjay.sample.web.model.user.feign.fallback;

import cn.hutool.json.JSONUtil;
import com.wenjay.sample.web.model.user.co.TenantCo;
import com.wenjay.sample.web.model.user.dto.TenantDto;
import com.wenjay.sample.web.model.user.feign.RemoteTenantService;
import com.wenjay.sample.web.model.user.vo.TenantVo;
import com.wenjay.framework.web.model.co.PageCondition;
import com.wenjay.framework.web.model.vo.Result;
import com.wenjay.framework.web.model.vo.ResultPage;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: </p>
 * <p> Description:</p>
 * <p>  </p>
 *
 * @author HanWenjie
 */
@Slf4j
@Component
public class RemoteTenantServiceFallbackImpl implements RemoteTenantService {

    @Setter
    private Throwable cause;

    @Override
    public Result<TenantVo> info(String id) {
        log.error("feign 顾问发送材料清单失败:{}", id, cause);
        return Result.ok();
    }

    @Override
    public ResultPage<List<TenantVo>> tenants(PageCondition<TenantCo> tenantCo) {
        log.error("feign 顾问发送材料清单失败:{},{}", JSONUtil.toJsonStr(tenantCo), cause);
        return ResultPage.ok();
    }

    @Override
    public Result<Boolean> save(TenantDto tenantDto) {
        log.error("feign 顾问发送材料清单失败:{},{}", JSONUtil.toJsonStr(tenantDto), cause);
        return Result.ok();
    }
}
