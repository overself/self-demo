package com.wenjay.sample.web.controller;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.wenjay.framework.core.common.constant.MessageCode;
import com.wenjay.framework.core.component.RedisHelper;
import com.wenjay.framework.core.exception.BusinessException;
import com.wenjay.framework.core.util.BeanUtils;
import com.wenjay.sample.web.domain.user.entity.Tenant;
import com.wenjay.sample.web.domain.user.service.TenantService;
import com.wenjay.sample.web.model.user.co.TenantCo;
import com.wenjay.sample.web.model.user.dto.TenantDto;
import com.wenjay.sample.web.model.user.vo.TenantVo;
import com.wenjay.framework.web.model.co.PageCondition;
import com.wenjay.framework.web.model.vo.Result;
import com.wenjay.framework.web.model.vo.ResultPage;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * 架构Demo
 * @author Hanwenjie
 */
@Slf4j
@RestController
@RequestMapping(value = {"/api/tenant"})
@Api(value = "架构Demo服务",tags="架构Demo")
public class TenantController {

    @Autowired
    private TenantService tenantService;

    @PostMapping("/page.json")
    @ApiOperation(value = "分页查询", notes = "分页查询")
    public ResultPage<List<TenantVo>> list(@RequestBody @Valid PageCondition<TenantCo> tenantCo) {

        IPage<Tenant> result =  tenantService.pageListCustom(tenantCo);
        log.info("result={}",result);

        IPage<Tenant> page = tenantService.pageList(tenantCo);
        if (page.getRecords() == null) {
            return ResultPage.ok();
        }
        List<TenantVo> results = BeanUtils.copyProperties(page.getRecords(), TenantVo.class);
        return ResultPage.ok(results);
    }

    @GetMapping("/info/{id}")
    @ApiOperation(value = "获得指定数据", notes = "获得指定数据")
    public Result<TenantVo> info(@ApiParam(name="id",value="数据id",required=true) @PathVariable("id") String id) {
        Tenant tenant = tenantService.loadTenantById(id);
        if (BeanUtil.isEmpty(tenant)) {
            throw new BusinessException(MessageCode.COMM_BASE_ERR0001);
        }
        return Result.ok(BeanUtils.copyProperties(tenant, TenantVo.class));
    }
    /**
     * 新增数据对象
     *
     * @param tenantDto 数据对象
     * @return Result<Boolean>:success、false
     */
    @PostMapping("/save")
    @ApiOperation(value = "新增数据对象", notes = "新增数据对象")
    public Result<Boolean> save(@Validated @RequestBody TenantDto tenantDto) {
        Tenant tenant = BeanUtils.copyProperties(tenantDto,Tenant.class);
        RedisHelper.save("tenantDto:"+tenantDto.getCode(),tenantDto,3000L);
        return Result.ok(tenantService.saveTenant(tenant));
    }

    /**
     * 更新数据对象
     *
     * @param tenantDto 数据对象
     * @return Result<Boolean>:success、false
     */
    @PostMapping("/update")
    @ApiOperation(value = "更新数据对象", notes = "更新数据对象")
    public Result<Boolean> update( @RequestBody TenantDto tenantDto) {
        return Result.ok(tenantService.updateTenant(tenantDto));
    }

    /**
     * 删除数据对象
     *
     * @param id 数据对象ID
     * @return Result<Boolean>:success、false
     */
    @PostMapping("/delete/{id}")
    @ApiOperation(value = "删除数据对象", notes = "删除数据对象")
    public Result<Boolean> removeById(@ApiParam(name="id",value="数据id", required=true) @Validated @NotEmpty(message = "{title.tenantCode}") @PathVariable String id) {
        return Result.ok(tenantService.deleteTenantById(id));
    }
}
