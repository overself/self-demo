package com.wenjay.sample.web.domain.base.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.wenjay.framework.data.mysql.entity.BaseEntity;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
@TableName("sys_serial")
public class GeneratorSerial extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * serial_id : 流水ID
     */
    @TableId(type = IdType.AUTO)
    private String id;

    /**
     * serial_name : 流水编码名称
     */
    private String serialName;

    /**
     * prefix_code : 流水编码前缀
     */
    private String prefixCode="";

    /**
     * current_value : 当前流水值
     */
    private Integer currentValue;

    /**
     * code_length : 流水编码长度
     */
    private Integer codeLength;

    /**
     * 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    protected List<Map<String, Object>> ukVal() {
        return null;
    }
}
