package com.wenjay.sample.web.domain.base.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wenjay.sample.web.domain.base.entity.GeneratorSerial;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface GeneratorSerialMapper extends BaseMapper<GeneratorSerial> {

    /**
     * 获取当前最大流水编码
     *
     * @param serialEntity 流水编码信息
     * @return
     */
    void getSequenceSerialNum(GeneratorSerial serialEntity);

}
