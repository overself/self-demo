package com.wenjay.sample.service;


import com.wenjay.sample.web.StartWebApplication;
import com.wenjay.sample.web.domain.base.service.GeneratorSerialService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {StartWebApplication.class})
public class TestGeneratorSerial {

    @Autowired
    private GeneratorSerialService serialService;

    @Test
    public void testGeneratorSerial() {
        String max = serialService.getCurrentSerialMaxNumber("SC", "test");
        log.info("max:{}", max);
        String max2 = serialService.getCurrentSerialMaxNumber("SC", "B" + max);
        log.info("max2:{}", max2);
        max2 = serialService.getCurrentSerialMaxNumber("SC", "B" + max);
        log.info("max3:{}", max2);
    }

    @Test
    public void testGeneratorScenarioNo() {
        String scenarioNo = serialService.generateScenarioNo();
        log.info("scenarioNo1:{}", scenarioNo);
        scenarioNo = serialService.generateScenarioNo();
        log.info("scenarioNo2:{}", scenarioNo);
        scenarioNo = serialService.generateScenarioNo();
        log.info("scenarioNo3:{}", scenarioNo);
    }

    @Test
    public void testGeneratorScenarioSubNo() {
        String scenarioNo = serialService.generateScenarioNo();
        log.info("scenarioNo:{}", scenarioNo);
        String scenariosSubNo = serialService.generateScenarioSubNo("B", scenarioNo);
        log.info("scenariosSubNo-B1：{}", scenariosSubNo);
        scenariosSubNo = serialService.generateScenarioSubNo("B", scenarioNo);
        log.info("scenariosSubNo-B2：{}", scenariosSubNo);

        scenariosSubNo = serialService.generateScenarioSubNo("S", scenarioNo);
        log.info("scenariosSubNo-S1：{}", scenariosSubNo);
        scenariosSubNo = serialService.generateScenarioSubNo("S", scenarioNo);
        log.info("scenariosSubNo-S2：{}", scenariosSubNo);

        scenariosSubNo = serialService.generateScenarioSubNo("A", scenarioNo);
        log.info("scenariosSubNo-A1：{}", scenariosSubNo);
        scenariosSubNo = serialService.generateScenarioSubNo("A", scenarioNo);
        log.info("scenariosSubNo-A2：{}", scenariosSubNo);
        scenariosSubNo = serialService.generateScenarioSubNo("A", scenarioNo);
        log.info("scenariosSubNo-A3：{}", scenariosSubNo);
        scenariosSubNo = serialService.generateScenarioSubNo("A", scenarioNo);
        log.info("scenariosSubNo-A4：{}", scenariosSubNo);
        scenariosSubNo = serialService.generateScenarioSubNo("A", scenarioNo);
        log.info("scenariosSubNo-A5：{}", scenariosSubNo);
        scenariosSubNo = serialService.generateScenarioSubNo("A", scenarioNo);
        log.info("scenariosSubNo-A6：{}", scenariosSubNo);
    }

    @Test
    public void testGeneratorScenarioBizNo() {
        String scenarioNo = serialService.generateScenarioNo();
        log.info("scenarioNo:{}", scenarioNo);
        String[] scenariosBNo = serialService.generateScenarioBPackage(scenarioNo);
        log.info("scenariosBNo-B1：{}", Lists.newArrayList(scenariosBNo));
        scenariosBNo = serialService.generateScenarioBPackage(scenarioNo);
        log.info("scenariosBNo-B2：{}", Lists.newArrayList(scenariosBNo));

        String scenariosSNo[] = serialService.generateScenarioSPackage(scenarioNo);
        log.info("scenariosSNo-S1：{}", Lists.newArrayList(scenariosSNo));
        scenariosSNo = serialService.generateScenarioSPackage(scenarioNo);
        log.info("scenariosSubNo-S2：{}", Lists.newArrayList(scenariosSNo));

        String[] scenariosANo = serialService.generateScenarioAttribute(scenarioNo);
        log.info("scenariosSubNo-A1：{}", Lists.newArrayList(scenariosANo));
        scenariosANo = serialService.generateScenarioAttribute(scenarioNo);
        log.info("scenariosSubNo-A2：{}", Lists.newArrayList(scenariosANo));
        scenariosANo = serialService.generateScenarioAttribute( scenarioNo);
        log.info("scenariosSubNo-A3：{}", Lists.newArrayList(scenariosANo));
        scenariosANo = serialService.generateScenarioAttribute(scenarioNo);
        log.info("scenariosSubNo-A4：{}", Lists.newArrayList(scenariosANo));
        scenariosANo = serialService.generateScenarioAttribute(scenarioNo);
        log.info("scenariosSubNo-A5：{}", Lists.newArrayList(scenariosANo));
        scenariosANo = serialService.generateScenarioAttribute(scenarioNo);
        log.info("scenariosSubNo-A6：{}", Lists.newArrayList(scenariosANo));
    }

}
