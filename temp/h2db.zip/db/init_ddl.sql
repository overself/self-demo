-- ----------------------------
-- Table structure for sys_tenant
-- ----------------------------
DROP TABLE IF EXISTS `sys_tenant`;
CREATE TABLE `sys_tenant`(
    `id`         bigint NOT NULL AUTO_INCREMENT COMMENT '租户id',
    `name`       varchar(255) NULL DEFAULT NULL,
    `phone`      varchar(50) NULL DEFAULT NULL,
    `code`       varchar(64) NULL DEFAULT NULL,
    `start_time`      date NULL DEFAULT NULL COMMENT '开始时间',
    `end_time`   date NULL DEFAULT NULL COMMENT '结束时间',
    `status`     tinyint(1) NULL DEFAULT 0,
    `is_deleted`      tinyint(1) NULL DEFAULT 0,
    `version_num`     int(0) NOT NULL DEFAULT 1,
    `create_time`     datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP (0) COMMENT '创建',
    `update_time`     datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP (0) ON UPDATE CURRENT_TIMESTAMP (0) COMMENT '更新时间',
    `account_code`    varchar(200) NULL DEFAULT NULL COMMENT '账号编码',
    `password`   varchar(50) NULL DEFAULT NULL COMMENT '明文密码（历史数据迁移）',
    `password_cipher` varchar(200) NULL DEFAULT NULL COMMENT '密文密码',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB COMMENT = '租户表';

-- ----------------------------
-- Records of sys_tenant
-- ----------------------------
INSERT INTO `sys_tenant` VALUES (1241010104625156098, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-20', 0, b'0', 1, '2020-03-20 22:34:00', '2020-03-27 17:44:36', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241013769561866241, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 22:48:34', '2020-03-20 22:48:34', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241021879064158210, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 23:20:48', '2020-03-20 23:20:48', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241026283267883010, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 23:38:18', '2020-03-20 23:38:18', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241026818855337986, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 23:40:25', '2020-03-20 23:40:25', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241026872034918401, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 23:40:38', '2020-03-20 23:40:38', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241026962858377218, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 23:41:00', '2020-03-20 23:41:00', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241027494910033922, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 23:43:07', '2020-03-20 23:43:07', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241027529840197633, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 23:43:15', '2020-03-20 23:43:15', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241030063946440706, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 9, b'0', 1, '2020-03-20 23:53:19', '2020-03-20 23:53:19', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241030170087497729, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 23:53:44', '2020-03-20 23:53:44', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241030601819791361, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-20 23:55:27', '2020-03-20 23:55:27', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241724554403586050, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-22 21:52:59', '2020-03-22 21:52:59', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241724589241475074, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-22 21:53:07', '2020-03-22 21:53:07', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241724671160426498, '斯琴高娃', '13592296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-22 21:53:26', '2020-03-22 21:53:26', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241725352483094530, '张娃', '13692296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-22 21:56:09', '2020-03-22 21:56:09', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1241763845200621569, '张娃', '13692296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-23 00:29:06', '2020-03-23 00:29:06', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1242092880568975361, '张娃', '13692296556', '10000000001', '2020-03-11', '2020-03-27', 0, b'0', 1, '2020-03-23 22:16:34', '2020-03-23 22:16:34', NULL, NULL, NULL);
INSERT INTO `sys_tenant` VALUES (1243410804428742657, '王柳', '13591197556', '13591197556', '2020-03-21', '2020-03-30', 9, b'0', 3, '2020-03-27 13:33:32', '2020-03-27 13:33:32', NULL, 'yUNbePoEu3Yz93sZufN4gA==', NULL);

DROP TABLE IF EXISTS `sys_serial`;
CREATE TABLE `sys_serial`(
    `id`            bigint(20)      NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '流水ID',
    `serial_name`   varchar(40)          DEFAULT NULL COMMENT '流水编码名称',
    `prefix_code`   varchar(20)          DEFAULT NULL COMMENT '流水编码前缀',
    `current_value` int                  DEFAULT NULL COMMENT '当前流水值',
    `code_length`   int                  DEFAULT NULL COMMENT '流水编码长度',
    `is_deleted`    tinyint(1)  NULL     DEFAULT 0,
    `version_num`   int(4)      NOT NULL DEFAULT 1,
    `create_time`   datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建',
    `update_time`   datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
    KEY `serial_IDX` (`serial_name`)
) ENGINE = InnoDB COMMENT ='流水编码管理';


-- H2DB 构建时不需要执行
DROP PROCEDURE IF EXISTS `next_serial_num`;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `next_serial_num`(INOUT `serialName` varchar(60),INOUT `prefixCode` varchar(20),INOUT `currentValue` int)
BEGIN
    set autocommit=0;
    -- set autocommit=1;
    -- show VARIABLES like 'autocommit';
    IF IFNULL(prefixCode,'')='' THEN
        select current_value+1 into currentValue from sys_serial t where t.serial_name = serialName and (t.prefix_code is null) for UPDATE;
        update sys_serial t set t.current_value = currentValue where t.serial_name = serialName and t.prefix_code is null;
    ELSE
        select current_value+1 into currentValue from sys_serial t where t.serial_name = serialName AND t.prefix_code= prefixCode for UPDATE;
        update sys_serial t set t.current_value = currentValue where t.serial_name = serialName AND t.prefix_code= prefixCode;
    end if;

    COMMIT;
END
;;
DELIMITER ;
