Vue.component('detail', {
    template: '#third-component',
    data () {
        return {
            formInline: {
                user: '',
                password: ''
            }
        }
    },
    methods: {
        goBack(id) {
            this.$router.push({ path: `/home` })
            Notice.success({
                title: "成功",
                desc: "返回首页"
            })
        },
    },
});

Vue.component('third-page', function (resolve) {
    $.get("./components/experts.html").then(function (res) {

    });
});