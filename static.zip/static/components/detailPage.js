Vue.component('detail-page', function (resolve) {
    $.get("./components/detailPage.html").then(function (res) {
        resolve({
            template: res,
            data: () => {
                return {
                    allnone:true,
                    detailStr:"dddddddddddddddddddddddddddddddd",
                }
            },
            created: function (){
            },
            methods: {
                goBack : ()=>{
                    router.push({ path: `/` })
                    Notice.success({
                        title: "成功",
                        desc: "返回首页"
                    })
                }
            }
        })
    });
});

