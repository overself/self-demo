Vue.component(
    'edit-page',
    //返回的是一个promise对象，获得结果之后，需要触发工厂函数的resolve回调
    (resolve) => $.get('./components/editPage.html').then(res => {
        resolve({
            template: res,
            data() {
                return {
                    formValidate: {
                        name: '',
                        mail: '',
                        city: '',
                        gender: '',
                        interest: [],
                        date: '',
                        time: '',
                        desc: '',
                        cityList: [
                            {
                                value: 'New York',
                                label: 'New York'
                            },
                            {
                                value: 'London',
                                label: 'London'
                            },
                            {
                                value: 'Sydney',
                                label: 'Sydney'
                            },
                            {
                                value: 'Ottawa',
                                label: 'Ottawa'
                            },
                            {
                                value: 'Paris',
                                label: 'Paris'
                            },
                            {
                                value: 'Canberra',
                                label: 'Canberra'
                            }
                        ],
                        startDate: {
                            disabledDate (date) {
                                return date && date.valueOf() < Date.now() - 86400000;
                            }
                        },
                        endDate: {
                            disabledDate (date) {
                                const disabledDay = date.getDate();
                                return disabledDay === 15;
                            }
                        }
                    },
                    ruleValidate: {
                        name: [
                            {required: true, message: 'The name cannot be empty', trigger: 'blur'}
                        ],
                        mail: [
                            {required: true, message: 'Mailbox cannot be empty', trigger: 'blur'},
                            {type: 'email', message: 'Incorrect email format', trigger: 'blur'}
                        ],
                        city: [
                            {required: true, message: 'Please select the city', trigger: 'change'}
                        ],
                        gender: [
                            {required: true, message: 'Please select gender', trigger: 'change'}
                        ],
                        interest: [
                            {
                                required: true,
                                type: 'array',
                                min: 1,
                                message: 'Choose at least one hobby',
                                trigger: 'change'
                            },
                            {type: 'array', max: 2, message: 'Choose two hobbies at best', trigger: 'change'}
                        ],
                        date: [
                            {required: true, type: 'date', message: 'Please select the date', trigger: 'change'}
                        ],
                        time: [
                            {required: true, type: 'string', message: 'Please select time', trigger: 'change'}
                        ],
                        desc: [
                            {required: true, message: 'Please enter a personal introduction', trigger: 'blur'},
                            {type: 'string', min: 20, message: 'Introduce no less than 20 words', trigger: 'blur'}
                        ]
                    }
                }
            },
            methods: {
                handleCreateCity (val) {
                    alert(val)
                    this.formValidate.cityList.push({
                        value: val,
                        label: val
                    });
                },
                handleSubmit(name) {
                    this.$refs[name].validate((valid) => {
                        if (valid) {
                            this.$Message.success('页面表单校验成功!');
                        } else {
                            this.$Message.error('页面表单校验失败!');
                        }
                    })
                },
                handleReset(name) {
                    this.$refs[name].resetFields();
                },
                goBack: () => {
                    router.push({path: `/`})
                    Notice.success({
                        title: "成功",
                        desc: "返回首页"
                    })
                }
            }
        });
    })
);
