Vue.config.productionTip = false
Vue.config.devtools = false

const Notice = iview.Notice

var routes = [
    {
        name: 'home',
        path: "/",
        component: {template: "#home"}
    },
    {
        name: 'detail',
        path: "/detail",
        component: {template: "#detail"}
    },
    {
        name: 'home',
        path: "/home",
        component: {template: "#home"}
    },
    {
        name: 'home',
        path: "/home",
        component: {template: "#home"}
    }
];
// 定义路由组件
var router = new VueRouter({
    routes
});

const global_vue = new Vue({
    router
}).$mount('#app')
