Vue.config.productionTip = false
Vue.config.devtools = false

const Notice = iview.Notice
