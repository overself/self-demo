﻿//当使用 PascalCase (首字母大写命名) 定义一个组件时，你在引用这个自定义元素时两种命名法都可以使用
//也就是说 <my-home-list> 和 <MyHomeList> 都是可接受的
Vue.component('MyHomeList', {
    template: '#home-list-component',
    data() {
        return {
            columns7: [
                {
                    title: 'Name',
                    key: 'name',
                    render: (h, params) => {
                        return h('div', [
                            h('Icon', {
                                props: {
                                    type: 'person'
                                }
                            }),
                            h('strong', params.row.name)
                        ]);
                    }
                },
                {
                    title: 'Age',
                    key: 'age'
                },
                {
                    title: 'Address',
                    key: 'address'
                },
                {
                    title: 'Action',
                    key: 'action',
                    width: 200,
                    align: 'center',
                    render: (h, params) => {
                        return h('div', [
                            h('Button', {
                                props: {
                                    type: 'primary',
                                    size: 'small'
                                },
                                style: {
                                    marginRight: '5px'
                                },
                                on: {
                                    click: () => {
                                        this.show(params.index)
                                    }
                                }
                            }, 'View'),
                            h('Button', {
                                props: {
                                    id: 'error',
                                },
                                on: {
                                    click: () => {
                                        this.goEditPage(params.index)
                                    }
                                }
                            }, 'Edit'),
                            h('Button', {
                                props: {
                                    type: 'error',
                                    size: 'small'
                                },
                                on: {
                                    click: () => {
                                        this.remove(params.index)
                                    }
                                }
                            }, 'Delete')
                        ]);
                    }
                }
            ],
            data6: [
                {
                    name: 'John Brown',
                    age: 18,
                    address: 'New York No. 1 Lake Park'
                },
                {
                    name: 'Jim Green',
                    age: 24,
                    address: 'London No. 1 Lake Park'
                },
                {
                    name: 'Joe Black',
                    age: 30,
                    address: 'Sydney No. 1 Lake Park'
                },
                {
                    name: 'Jon Snow',
                    age: 26,
                    address: 'Ottawa No. 2 Lake Park'
                }
            ]
        }
    },
    mounted(){
        this.doSearch();
    },
    beforeDestroy() {
        this.$bus.$off("doSearch")
    },
    methods: {
        show(index) {
            this.$Modal.info({
                title: 'User Info',
                content: `Name：${this.data6[index].name}<br>Age：${this.data6[index].age}<br>Address：${this.data6[index].address}`
            })
        },
        remove(index) {
            this.data6.splice(index, 1);
        },
        goDetail(id) {
            this.$router.push({path: `/detail`});
            Notice.success({
                title: "成功",
                desc: "来到了第二页面"
            })
        },
        goThirdPage(id) {
            this.$router.push({path: `/third`});
            Notice.success({
                title: "成功",
                desc: "来到了第三个页面"
            })
        },
        goEditPage(id) {
            this.$router.push({path: `/edit?` + id});
            Notice.success({
                title: "成功",
                desc: "来到了Edit页面"
            })
        },
        doSearch() {
            this.$bus.$on("doSearch", (data) => {
                let newArr = this.data6.filter(item => item.name.indexOf(data)>=0);
                console.log("筛选数据后：", newArr);
                this.data6 = newArr;
            })
        },
    }
});


Vue.component('third', {
    template: '#third-component',
    data() {
        return {
            formInline: {
                user: 'ssssssss',
                password: 'wwwwwwwww'
            }
        }
    },
    methods: {
        goBack(id) {
            this.$router.push({path: `/`})
            Notice.success({
                title: "成功",
                desc: "返回首页"
            })
        },
    },
});