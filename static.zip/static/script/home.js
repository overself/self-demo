﻿
Vue.component('home', {
    template: '#home-component',
    data () {
        return {
            formInline: {
                user: '',
                password: ''
            }
        }
    },
    methods: {
        goDetail(id) {
            this.$router.push({ path: `/detail` });
            Notice.success({
                title: "成功",
                desc: "来到了第二页面"
            })
        },
    },
});

Vue.component('detail', {
    template: '#detail-component',
    data () {
        return {
            formInline: {
                user: '',
                password: ''
            }
        }
    },
    methods: {
        goBack(id) {
            this.$router.push({ path: `/home` })
            Notice.success({
                title: "成功",
                desc: "返回首页"
            })
        },
    },
});