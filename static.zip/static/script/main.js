const routes = [
    {
        name: 'homeListRoute',
        path: "/",
        component: {template: "#homeListTemplate"},
        meta: {"forSearch": true}
    },
    {
        name: 'detailRoute',
        path: "/detail",
        component: {template: "#detailTemplate"}
    },
    {
        name: 'editPageRoute',
        path: "/edit",
        component: {template: "#editPageTemplate"}
    },
    {
        name: 'thirdRoute',
        path: "/third",
        component: {template: "#thirdTemplate"}
    },
];
// 定义路由组件
const router = new VueRouter({
    routes
});

new Vue({
    router,
    data() {
        return {
            searchValue: ""
        }
    },
    methods: {
        searchHandel(e) {
            this.$bus.$emit("doSearch",this.searchValue);
        },
    },
    beforeCreate() {
        Vue.prototype.$bus = this//安装全局事件总线
    }
}).$mount('#app')

const bus = new Vue();