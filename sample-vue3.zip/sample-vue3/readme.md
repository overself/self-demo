
## vue3-sfc-loader Git官网
https://github.com/FranckFreiburger/vue3-sfc-loader/blob/main/docs/examples.md#vue2-basic-example

https://gitee.com/fushengruomengzhang_admin/vue3-sfc-loader

vue3-sfc-loader
Vue3/Vue2单文件组件加载程序。在运行时从html/js动态加载.vue文件。没有node.js环境，不需要（网页包）构建步骤。

公共API文档:
loadModule(path: string, options: Options): Promise<VueComponent>
https://www.5axxw.com/wiki/content/ofbu7a#

## html使用vue.js作为组件引入
https://blog.csdn.net/qq_38004125/article/details/120786060

## 普通web项目引入VUE开发
https://blog.csdn.net/ajian132/article/details/103714109

## http-vue-loader从浏览器直接引入vue文件
https://pengshiyu.blog.csdn.net/article/details/120344577

## Vue项目入口文件main.js和App.vue和index.html之间的关系
https://blog.csdn.net/FurtherSkyQ/article/details/115521697

## 使用 Vue3 开发项目[不用Node,实现浏览器访问]
https://fushengzhang.blog.csdn.net/article/details/115624705

https://blog.csdn.net/lovely960823/article/details/117351830
# Spring Security
https://blog.csdn.net/m0_52012606/article/details/123692236
https://gitee.com/chaozexu/token.git
https://dandelioncloud.cn/article/details/1479008592681586689

https://blog.csdn.net/yu619251940/article/details/126872454