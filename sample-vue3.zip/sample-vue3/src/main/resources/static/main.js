;(async () => {
    const args = {name: 'app', components: {'layout': await loadVue('./views/App.vue')}};
    const app = Vue.createApp(args)
    app.use(vueRouter)
    app.use(i18n);
    app.use(ViewUIPlus, {
        size: 'small',
        select: {
            arrow: 'md-arrow-dropdown',
            arrowSize: 20
        }
    });
    app.use(store);
    app.mount("#app")
})().catch(ex => console.error(ex));