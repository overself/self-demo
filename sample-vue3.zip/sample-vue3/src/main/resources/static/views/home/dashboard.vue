<template>
  <div>
    <Row>
      <i-col span="5">
        你正在访问的是{{ systemName }}
      </i-col>
      <i-col span="1" style="text-align: center">-</i-col>
      <i-col span="4">
        系统采用Vue {{ vueVer }} 版本
      </i-col>
      <i-col span="2">
        <i-button type="primary" @click="logout()">退出系统</i-button>
      </i-col>
      <i-col span="2">
        <i-button type="primary" @click="seeHelp()">シナリオ説明</i-button>
      </i-col>
    </Row>
    <Row :gutter="20" style="margin-top: 10px;">
      <i-col :md="24" :lg="12" style="margin-bottom: 20px;">
        <Card shadow>
          <chart-pie style="height: 260px;" :value="pieData" text="用户访问来源"></chart-pie>
        </Card>
      </i-col>
      <i-col :md="24" :lg="12" style="margin-bottom: 20px;">
        <Card shadow>
          <chart-bar style="height: 260px;" :value="barData" text="每周用户活跃量"/>
        </Card>
      </i-col>
    </Row>
    <Row>
      <Card shadow>
        <exampleEcharts style="height: 310px; width: 1000px"/>
      </Card>
    </Row>
  </div>
</template>
<script>
import ChartPie from '../components/charts/pie.vue'
import ChartBar from '../components/charts/bar.vue'
import {pieData, barData} from "../../script/testDataConst.mjs";
import ExampleEcharts from './exampleEcharts.vue'

export default {
  components: {ChartPie, ChartBar,ExampleEcharts},
  data() {
    return {
      systemName: "シナリオ管理システム",
      vueVer: vueVersion,
      pieData,
      barData,
    }
  },
  mounted() {
  },
  computed: {},
  methods: {
    async logout() {
      let reqData = await doGet("/api/logout", {});
      if (reqData.success) {
        localStorage.removeItem('token');
        this.$router.push({path: `/login`});
      }
    },
    seeHelp() {
      this.$Modal.info({
        title: '帮助文档：',
        content: '敬请期待！！！ '
      });
    },
  }
}
</script>

<style scoped>

</style>
