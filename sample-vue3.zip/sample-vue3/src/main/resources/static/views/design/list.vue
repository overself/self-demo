<template>
  <div style="height: 100%;">
    <Card v-show="showSearch" style="margin-bottom: 10px" dis-hover>
      <Form :model="formSearch" label-position="right" :label-width="100">
        <Row gutter>
          <i-Col span="8">
            <FormItem label="编号">
              <Input v-model="formSearch.code" clearable></Input>
            </FormItem>
          </i-Col>
          <i-Col span="8">
            <FormItem label="名称">
              <Input v-model="formSearch.name" clearable></Input>
            </FormItem>
          </i-Col>
          <i-Col span="8">
            <FormItem label="作成者">
              <Input v-model="formSearch.creator" clearable></Input>
            </FormItem>
          </i-Col>
        </Row>
        <Row>
          <i-Col span="8">
            <FormItem label="标签">
              <Select v-model="formSearch.label" placeholder="选择标签" style="width: 190px">
                <Option value="">全部</Option>
                <Option value="1001">标签1</Option>
                <Option value="1002">标签2</Option>
                <Option value="1003">标签3</Option>
              </Select>
            </FormItem>
          </i-Col>
          <i-Col span="8">
            <FormItem label="做成时间">
              <Space style="width: 190px">
                <DatePicker type="date" :model-value="formSearch.createStartDate" placeholder="开始日期" style="width: 120px"/>
                ～
                <DatePicker type="date" :model-value="formSearch.createEndDate" placeholder="结束日期" style="width: 120px"/>
              </Space>
            </FormItem>
          </i-Col>
          <i-Col span="8">
            <FormItem style="float: right">
              <Space wrap>
                <Button type="primary" icon="ios-search">查询</Button>
                <Button icon="md-refresh">重置</Button>
              </Space>
            </FormItem>
          </i-Col>
        </Row>
      </Form>
    </Card>
    <Card dis-hover>
      <div style="margin-bottom: 10px; height: 20px;width: 100%">
        <Button type="primary" icon="md-add" @click="createOrUpdate">新規作成</Button>
        <Button shape="circle" icon="ios-search" style="float: right; margin-right: 10px" @click="switchSearch"></Button>
        <Button shape="circle" icon="md-refresh" style="float: right; margin-right: 10px"></Button>
      </div>
      <div style="width: 100%">
        <Table border :columns="columns" :data="dataList" style="width: 100%">
          <template #code="{ row }">
            <span style="background: #8ce6b0" >{{ row.code }}</span>
          </template>
          <template #labelNames="{ row }">
            <span>{{ row.labelNames.join(",") }}</span>
          </template>
          <template #action="{ row, index }">
            <Button style="margin-right: 2px" icon="md-reorder" @click="show(index)">查看</Button>
            <Button type="primary" style="margin-right: 2px" icon="md-create" @click="createOrUpdate(index)">编辑</Button>
            <Poptip confirm transfer title="你确定要删除吗?" @on-ok="remove(index)">
              <Button type="error" icon="md-trash">删除</Button>
            </Poptip>
          </template>
        </Table>
        <Page :total="50" show-sizer style="margin-top: 10px" />
      </div>
    </Card>
  </div>
  <Modal v-model="modal" scrollable mask-closable fullscreen title="设计CASE" ok-text='关闭' cancel-text="取消">
    <design-detail></design-detail>
  </Modal>
</template>
<script>
import DesignDetail from './detail.vue'
import {designList} from "../../script/testDataConst.mjs";

export default {
  name: "designList",
  components: {DesignDetail},
  data() {
    return {
      modal: false,
      showSearch: true,
      formSearch: {
        code: "",
        name: "",
        creator: "",
        label: "",
        createStartDate: "",
        createEndDate: ""
      },
      columns: [
        {
          title: '编码',
          slot: 'code'
        },
        {
          title: '名称',
          key: 'name'
        },
        {
          title: '标签',
          slot: 'labelNames'
        },
        {
          title: '作成日期',
          key: 'createDate'
        },
        {
          title: '操作',
          slot: 'action',
          width: 240,
          align: 'center'
        }
      ],
      dataList: []
    }
  },
  methods: {
    show(index) {
      this.modal = true;
    },
    remove(index) {
      this.data.splice(index, 1);
    },
    createOrUpdate(index){
      this.$router.push({path: `/design_edit`})
    },
    switchSearch(){
      this.showSearch=!this.showSearch
    },
  },
  created(){
    this. dataList = designList;
  }
}
</script>
