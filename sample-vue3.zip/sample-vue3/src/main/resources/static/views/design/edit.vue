<template>
  <div style="height: 100%;">
    <div style="margin-bottom: 20px; margin-top: 2px; height: 10px">
      <Button style="float: left" @click="goBack">返回</Button>
    </div>
    <Card dis-hover style="height: 100%;">
      <Divider plain orientation="left" style="margin-top: 2px"><strong>基本信息</strong></Divider>
      <Form ref="formEdit" label-colon="：" :model="formEdit" :rules="formRule" :label-width="120">
        <Row>
          <i-Col span="12">
            <FormItem label="编号" prop="code">
              <i-Input v-model="formEdit.code" flex="1 1 200px" style="min-width: 100px;max-width: 100px"
                       clearable></i-Input>
            </FormItem>
          </i-Col>
          <i-Col>
            <FormItem label="作成者" prop="creator">
              <Select v-model="formEdit.creator" filterable :remote-method="remoteUserList"
                      :loading="userLoading" placeholder="请输入选择的名字" clearable>
                <Option v-for="(user, index) in userList" :value="user.userId" :key="index">{{ user.name }}</Option>
              </Select>
            </FormItem>
          </i-Col>
        </Row>
        <Row>
          <i-Col span="18">
            <FormItem label="名称" prop="name">
              <i-Input v-model="formEdit.name" style="min-width: 100px;max-width:400px" clearable></i-Input>
            </FormItem>
          </i-Col>
        </Row>
        <Row>
          <i-Col span="18">
            <FormItem label="标签" prop="labels">
              <Select v-model="formEdit.labels" filterable multiple allow-create @on-create="handleCreateLabel"
                      clearable>
                <Option v-for="item in labelList" :value="item.code" :key="item.code">{{ item.name }}</Option>
              </Select>
            </FormItem>
          </i-Col>
        </Row>
      </Form>
      <div style="margin: 5px; height: 10px; padding-right: 20px">
        <Button type="primary" icon="md-add" style="float: right">B#</Button>
      </div>
      <Divider plain orientation="left" style="margin-top: 2px; margin-bottom: 2px"><strong>B服务数据</strong></Divider>
      <Form ref="formEdit" label-colon="：" :model="formEdit" :rules="formRule" :label-width="120">
        <Card style="width:100%" dis-hover>
          <template #title>
            B情报-{{ 1001 }}
          </template>
          <template #extra>
            <Space style="width: 80px">
              <a href="#">
                <Icon type="ios-loop-strong"></Icon>
                删除</a>
              <a href="#">
                <Icon type="ios-loop-strong"></Icon>
                展开</a>
            </Space>
          </template>
          <div>
            <Form ref="formEdit" label-colon="：" :model="formEdit" :rules="formRule" :label-width="120">
              <Row wrap gutter="100">
                <i-Col>
                  <FormItem label="编号" prop="code">
                    <i-Input v-model="formEdit.code" flex="1 1 200px" style="min-width: 100px;max-width: 100px"
                             clearable></i-Input>
                  </FormItem>
                </i-Col>
                <i-Col>
                  <FormItem label="Sub编号" prop="creator">
                    <i-Input v-model="formEdit.code" flex="1 1 200px" style="min-width: 100px;max-width: 100px"
                             clearable></i-Input>
                  </FormItem>
                </i-Col>
                <i-Col>
                  <FormItem label="Sub编号" prop="creator">
                    <i-Input v-model="formEdit.code" flex="1 1 200px" style="min-width: 100px;max-width: 100px" clearable></i-Input>
                  </FormItem>
                </i-Col>
              </Row>
              <div style="margin: 5px; height: 10px;">
                <Button type="primary" icon="md-add" style="float: right">S#</Button>
              </div>
              <Divider plain orientation="left" style="margin-top: 2px; margin-bottom: 2px">S服务数据</Divider>
            </Form>
          </div>
        </Card>
      </Form>
    </Card>

  </div>
</template>
<script>
import {userStoreList} from "../../script/testDataConst.mjs";

export default {
  data() {
    return {
      userList: [],
      userLoading: false,
      labelList: [{code: '1001', name: '标签001'}, {code: '1002', name: '标签002'}, {
        code: '1003',
        name: '标签003'
      }, {code: '1004', name: '标签005'}],
      formEdit: {
        code: '',
        name: '',
        creator: '',
        labels: [],
      },
      formRule: {
        name: [
          {required: true, message: '名称不能为空', trigger: 'blur'}
        ],
        creator: [
          {required: true, message: '作成者不能为空', trigger: 'change'},
        ],
        labels: [
          {required: true, type: 'array', min: 1, message: '请至少选择一个', trigger: 'change'},
          {type: 'array', max: 4, message: '选择不能超过4个', trigger: 'change'},
        ]
      }
    }
  },
  methods: {
    handleSubmit(name) {
      this.$refs[name].validate((valid) => {
        if (valid) {
          this.$Message.success('Success!');
        } else {
          this.$Message.error('Fail!');
        }
      })
    },
    handleReset(name) {
      this.$refs[name].resetFields();
    },
    handleCreateLabel(name) {
      //调后台创建一个标签，并返回到前段，前端获得之后加到列表里
      let maxCode = Math.max.apply(Math, this.labelList.map(item => {
        return item.code
      }))
      this.labelList.push({code: maxCode + 1, name: name});
    },
    remoteUserList(query) {
      if (query !== '') {
        this.userLoading = true;
        setTimeout(() => {
          this.userLoading = false;
          this.userList = userStoreList.filter(item => item.name.indexOf(query) > -1);
        }, 200);
      } else {
        this.userList = [];
      }
    },
    goBack() {
      this.$router.back()
    },
  },
}
</script>