<template>
  <Form :label-width="100" label-colon="：">
    <Row>
      <Col span="8">
        <FormItem label="名称"><span>{{ name }}</span></FormItem>
      </Col>
      <Col span="8">
        <FormItem label="E-mail"><span>{{ mail }}</span></FormItem>
      </Col>
      <Col span="8">
        <FormItem label="城市"><span>{{ city }}</span></FormItem>
      </Col>
    </Row>
    <FormItem label="Date">
      <Row>
        <Col span="8">
          <FormItem><span>{{ date }}　{{ time }}</span></FormItem>
        </Col>
      </Row>
    </FormItem>
    <FormItem label="性别">
      <RadioGroup v-model="gender">
        <Radio disabled label="male">男</Radio>
        <Radio disabled label="female">女</Radio>
        <Radio disabled label="">未选择</Radio>
      </RadioGroup>
    </FormItem>
    <FormItem label="业余爱好" border="false">
      <CheckboxGroup v-model="interest">
        <Checkbox disabled label="Eat"></Checkbox>
        <Checkbox disabled label="Sleep"></Checkbox>
        <Checkbox disabled label="Run"></Checkbox>
        <Checkbox disabled label="Movie"></Checkbox>
      </CheckboxGroup>
    </FormItem>
    <FormItem label="个人简述">
      <!--<Input v-model="desc" wrap="hard" clearable="false" :border="false" suffix="" type="textarea"
             :autosize="{minRows: 5}"></Input>-->
      <!--<pre>{{desc}}</pre>-->
      <p class="intro-p">{{ desc }}</p>
    </FormItem>
  </Form>
</template>
<script>
export default {
  data() {
    return {
      name: '测试数据',
      mail: 'test@163.com',
      city: '中国·大连市',
      gender: 'male',
      interest: ['Eat', 'Sleep'],
      date: '2022-11-19',
      time: '12:24:30',
      desc: '自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }，自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }，自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n\r\n\r自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }，自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }\n'
    }
  },
  methods: {}
}
</script>
<style scoped>
.res-show-box {
  display: inline-block;
  margin-left: 20px;
  border: 1px solid #eeeeee;
  vertical-align: top;
  width: 350px;
  height: 570px;
}

</style>