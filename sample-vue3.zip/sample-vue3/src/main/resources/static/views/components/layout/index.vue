<template>
  <div class="layout">
    <Layout :style="'height: 100%'">
      <Sider ref="sideRef" hide-trigger collapsible :collapsed-width="50" :width="180" v-model="isCollapsed">
        <div :class="logoClasses" @click="goHome">
          <img :src="logoUrl" class="logoImage">
          <span class="logoTitle">シナリオ管理</span>
        </div>
        <Menu class="menu" ref="asideMenu" active-name="1-0" theme="dark" width="100%" accordion :class="menuitemClasses">
          <MenuItem name="1-0" to="/" v-show="false">
            <!--<Icon type="md-stats" size="20"/>-->
            <Icon type="md-pie" size="20"/>
            <span>首页</span>
          </MenuItem>
          <MenuItem name="1-1" to="/design">
            <Icon type="md-people" size="20"/>
            <span>ユーザ管理</span>
          </MenuItem>
          <MenuItem name="1-2" to="/design">
            <!-- <Icon type="md-paper" />-->
            <Icon type="md-brush" size="20"/>
            <span>シナリオ設計</span>
          </MenuItem>
          <MenuItem name="1-3" to="/print">
            <Icon type="md-print" size="20"/>
            <span>シナリオ印刷</span>
          </MenuItem>
          <MenuItem name="1-4" to="/markdown_page">
            <Icon type="logo-markdown" size="20"></Icon>
            <span>MarkDown編集</span>
          </MenuItem>
        </Menu>
      </Sider>
      <Layout>
        <Header :style="{padding: 0}" class="layout-header-bar">
          <div class="h-left">
            <Icon @click="collapsedSide" :class="rotateIcon" :style="{margin: '0 20px'}" type="md-menu"
                  size="24"></Icon>
            <div>
              <Icon type="ios-home-outline" size="24" @click="goHome"/>
              <!--<span class="homeTitle" @click="goHome">首页</span>-->
            </div>
          </div>
          <div class="h-right">
            <Fullscreen style="margin-right: 10px;"></Fullscreen>
            <!-- 消息 -->
            <div class="notice-c" title="查看新消息">
              <div :class="{newMsg: hasNewMsg}"></div>
              <Icon type="ios-notifications-outline" size="24"></Icon>
            </div>
            <!-- 用户头像 -->
            <div class="user-img-c">
              <img :src="userImg">
            </div>
            <!-- 下拉菜单 -->
            <Dropdown trigger="click" @on-click="userOperate" @on-visible-change="showArrow">
              <a href="javascript:void(0)" class="userDown">
                <span>{{ userNick }}</span>
                <Icon v-show="arrowDown" type="md-arrow-dropdown"/>
                <Icon v-show="arrowUp" type="md-arrow-dropup"/>
              </a>
              <template #list>
                <DropdownMenu slot="list" class="userDownItem">
                  <DropdownItem name="1">个人资料</DropdownItem>
                  <DropdownItem divided name="99">退出登陆</DropdownItem>
                </DropdownMenu>
              </template>
            </Dropdown>
          </div>
        </Header>
        <Content class="main-content-con">
          <Layout class="main-layout-con">
            <!-- 导航Tags -->
            <!--<div class="tag-nav-wrapper">待后期完善</div>-->
            <Content class="content-wrapper">
              <div style="height: 100%">
                <router-view></router-view>
              </div>
            </Content>
          </Layout>
          <BackTop :height="50" :bottom="50" :right="25" container=".content-wrapper"></BackTop>
        </Content>
      </Layout>
    </Layout>
  </div>
  <Modal v-model="personalModel" footer-hide title="个人资料">
    <personal-edit v-on:onModelClose="modelClose($event)" v-bind:personal-model="personalModel"></personal-edit>
  </Modal>
</template>

<script>
import PersonalEdit from "../common/personalEdit.vue";
import Fullscreen from '../common/fullscreen.vue'
import BackTop from '../common/backTop.vue'

export default {
  name: "LayoutPortal",
  components: {PersonalEdit, Fullscreen, BackTop},
  data() {
    return {
      currentMenu: '1-0',
      isCollapsed: false,
      isShowAsideTitle: true,
      logoUrl: './images/logo_design_big.png',

      hasNewMsg: true, // 是否有新消息
      userNick: "用户昵称",
      userImg: "./images/defaultUserIcon.jpeg",
      arrowUp: false, // 用户详情向上箭头
      arrowDown: true, // 用户详情向下箭头
      personalModel: false
    }
  },
  methods: {
    collapsedSide() {
      this.$refs.sideRef.toggleCollapse();
      this.isShowAsideTitle = !this.isCollapsed;
    },
    goHome() {
      this.$router.push({path: `/`})
    },
    // 用户操作
    userOperate(name) {
      switch (name) {
        case '1':
          // 修改密码
          this.doPersonalEdit();
          break
        case '99':
          this.logout();
          break
      }
    },
    // 控制用户三角箭头显示状态
    showArrow(flag) {
      this.arrowUp = flag
      this.arrowDown = !flag
    },
    monitorWindowSize() {
      window.onresize = () => {
        let currentWidth = document.documentElement.clientWidth || document.body.clientWidth
        // 可视窗口宽度太小 自动收缩侧边栏
        if (currentWidth > 1000 && this.isCollapsed) {
          this.isCollapsed = false;
        }
        if (currentWidth <= 1000 && !this.isCollapsed && !this.isShowAsideTitle) {
          this.isCollapsed = true;
        }
      }
    },
    doPersonalEdit() {
      this.personalModel = true;
    },
    async logout() {
      let reqData = await doGet("/api/logout", {});
      localStorage.removeItem('token');
      this.$router.push({path: `/login`});
    },
    modelClose(params) {
      //关闭Model窗口
      console.log("从子组件发来的params", params)
      this.personalModel = false;
    }
  },
  // mounted函数就会在组件挂载完成后被调用
  mounted() {
    // 设置用户信息
    this.userNick = localStorage.getItem('userNick')
    this.userImg = localStorage.getItem('userImg')
    // 监听窗口大小 自动收缩侧边栏
    this.monitorWindowSize()
  },
  computed: {
    rotateIcon() {
      return ['menu-icon', this.isCollapsed ? 'rotate-icon' : ''];
    },
    menuitemClasses() {
      return ['menu-item', this.isCollapsed ? 'collapsed-menu' : '']
    },
    logoClasses() {
      return ['menu-logo', this.isCollapsed ? 'collapsed-logo' : '']
    },
  }
}
</script>

<style scoped>
.layout {
  border: 1px solid #d7dde4;
  background: #f5f7f9;
  position: relative;
  border-radius: 4px;
  overflow: hidden;
  height: 100%;
}

.layout .ivu-menu {
  z-index: 0
}

.layout-header-bar {
  background: #fff;
  box-shadow: 0 1px 1px rgba(0, 0, 0, .1);
  justify-content: space-between;
  padding-right: 40px;
  padding-left: 10px;
  font-size: 14px;
  height: 50px;
  border-bottom: none;
  display: flex;
}

.menu-icon {
  transition: all .3s;
}

.rotate-icon {
  transform: rotate(-90deg);
}

.menu-item span {
  display: inline-block;
  overflow: hidden;
  width: 120px;
  text-overflow: ellipsis;
  white-space: nowrap;
  vertical-align: bottom;
  transition: width .2s ease .2s;
}

.menu-item i {
  transform: translateX(0px);
  transition: font-size .2s ease, transform .2s ease;
  vertical-align: middle;
  font-size: 16px;
}

.collapsed-menu span {
  width: 0px;
  transition: width .2s ease;
}

.collapsed-menu i {
  transform: translateX(6px);
  transition: font-size .2s ease .2s, transform .2s ease .2s;
  vertical-align: middle;
  font-size: 24px;
}

.menu-logo {
  display: flex;
  align-items: center;
  color: rgba(255, 255, 255, .8);
  font-size: 16px;
  justify-content: center;
}

.menu-logo span {
  display: inline-block;
  overflow: hidden;
  width: 120px;
  white-space: nowrap;
  vertical-align: bottom;
  transition: width .2s ease .2s;
}

.collapsed-logo span {
  width: 0px;
  transition: width .2s ease;
}

.ivu-menu-vertical .ivu-menu-item {
  padding: 12px 8px;
  position: relative;
  cursor: pointer;
  z-index: 1;
  transition: all .2s ease-in-out;
}

.logoImage {
  padding: 2px;
  width: 30px;
  height: 35px;
  margin: 8px;
}

.logoTitle {
  font-size: 18px;
  color: #0BACD3;
  font-weight: bold;
  float: left;
  margin-left: 2px;
}

.homeTitle {
  float: right;
  margin-left: 2px;
}

.h-right {
  display: flex;
  height: 50px;
  align-items: center;
}

.h-left {
  display: flex;
  height: 50px;
  align-items: center;
}

.notice-c {
  margin-top: 5px;
  cursor: pointer;
  position: relative;
}

.notice-c .ivu-icon {
  font-size: 24px;
}

.newMsg {
  padding: 2px 2px;
  position: absolute;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: #FF5722;
  right: 2px;
  top: 18px;
}

.user-img-c {
  width: 34px;
  height: 34px;
  background: #ddd;
  border-radius: 50%;
  overflow: hidden;
  margin: 10px 20px;
}

.user-img-c img {
  width: 40px;
  height: 40px;
  float: left;

}

.userDown {
  color: #17233d;
  cursor: pointer;
  margin-right: 20px;
}

.userDownItem {
  color: #17233d;
  cursor: pointer;
  top: 10px;
}

/** 右部 内容区域 */
.main-content-con {
  height: calc(100% - 60px);
  overflow: hidden;
}

.main-layout-con {
  height: 100%;
  overflow: hidden;
}

.layout .content-wrapper {
  padding: 10px;
  height: calc(100% - 80px);
  overflow: auto;
  background: #F5F5F9FF;
}

.tag-nav-wrapper {
  padding: 0;
  height: 30px;
  background: #F0F0F0;
}
</style>
