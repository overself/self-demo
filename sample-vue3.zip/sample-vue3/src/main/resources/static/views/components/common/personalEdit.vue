<template>
  <div>
    <Tabs size="small" v-model="currentTab">
      <TabPane label="基本信息" name="tabCustom">
        <Form ref="formCustom" :model="formCustom" :rules="ruleCustom" :label-width="80">
          <FormItem label="用户昵称" prop="userNick">
            <Input v-model="formCustom.userNick" placeholder="输入你的昵称"></Input>
          </FormItem>
          <FormItem label="电话号" prop="mobile">
            <Input v-model="formCustom.mobile" placeholder="输入你的电话"></Input>
          </FormItem>
          <FormItem label="邮箱" prop="email">
            <Input v-model="formCustom.email" placeholder="输入你的E-Mail"></Input>
          </FormItem>
          <FormItem label="性别" prop="gender">
            <RadioGroup v-model="formCustom.gender">
              <Radio label="male">男</Radio>
              <Radio label="female">女</Radio>
            </RadioGroup>
          </FormItem>
          <FormItem label="个人简述" prop="desc">
            <Input v-model="formCustom.desc" type="textarea"
                   :autosize="{minRows: 2,maxRows: 5}" placeholder="输入个人简述信息"></Input>
          </FormItem>
        </Form>
      </TabPane>
      <TabPane label="修改密码" name="tabPassword">
        <Form ref="formPassword" :model="formPassword" :rules="rulePassword" :label-width="80">
          <FormItem label="旧密码" prop="oldPassword">
            <i-input type="password" v-model="formPassword.oldPassword"></i-input>
          </FormItem>
          <FormItem label="新密码" prop="password">
            <i-input type="password" v-model="formPassword.password"></i-input>
          </FormItem>
          <FormItem label="确认密码" prop="passwordCheck">
            <i-input type="password" v-model="formPassword.passwordCheck"></i-input>
          </FormItem>
        </Form>
      </TabPane>
    </Tabs>
    <!-- 底部按钮部分 -->
    <div class="dialog-footer-divided"></div>
    <span slot="footer" class="dialog-footer">
        <Button @click="handleReset(currentTab)" style="margin-left: 8px;float: left">重置</Button>
        <Button type="primary" @click="handleSubmit(currentTab)">保存</Button>
        <Button @click="handleCancel" style="margin-left: 8px;">取消</Button>
    </span>
  </div>
</template>
<script>
export default {
  name: 'personalEdit',
  props: ["personalModel"],
  data() {
    const validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入你的新密码'));
      } else {
        if (this.formPassword.passwordCheck !== '') {
          // 对第二个密码框单独验证
          this.$refs.formPassword.validateField('passwordCheck');
        }
        callback();
      }
    };
    const validatePassCheck = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入你的新确认密码'));
      } else if (value !== this.formPassword.password) {
        callback(new Error('两次输入的新密码不匹配'));
      } else {
        callback();
      }
    };
    return {
      currentTab: "tabCustom",
      userId: '',
      formCustom: {
        userNick: '',
        mobile: '',
        email: '',
        gender: '',
        desc: ''
      },
      ruleCustom: {
        userNick: [
          {required: true, message: '用户昵称不能为空', trigger: 'blur'}
        ],
        mobile: [
          {required: true, message: '电话号码不能为空', trigger: 'blur'}
        ],
        email: [
          {required: true, message: '邮箱不能为空', trigger: 'blur'},
          {type: 'email', message: '错误的邮箱信息', trigger: 'blur'}
        ],
        gender: [
          {required: true, message: '选择你的性别', trigger: 'change'}
        ],
        desc: [
          {required: true, message: '请输入个人介绍', trigger: 'blur'},
          {type: 'string', min: 20, message: '个人介绍不少于20文字', trigger: 'blur'}
        ]
      },
      formPassword: {
        oldPassword: '',
        password: '',
        passwordCheck: '',
      },
      rulePassword: {
        oldPassword: [
          {required: true, message: '请输入你的旧密码', trigger: 'blur'}
        ],
        password: [
          {required: true, validator: validatePass, trigger: 'blur'}
        ],
        passwordCheck: [
          {required: true, validator: validatePassCheck, trigger: 'blur'}
        ]
      }
    }
  },
  methods: {
    async handleSubmit(currentTab) {
      let name = currentTab == 'tabCustom' ? 'formCustom' : 'formPassword';
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          if (currentTab == 'tabCustom') {
            const userCustomData = JSON.parse(JSON.stringify(this.formCustom));
            userCustomData.userName = userCustomData.userNick;
            userCustomData.userId = this.userId;
            let reqData = await doPost("/api/user/update", userCustomData);
            if (reqData.success) {
              this.$Message.success('处理成功!');
              this.$emit("onModelClose", {"Result": "关闭用户信息窗口"})
            } else {
              this.$Message.error(reqData.msg);
            }
          } else {
            const userPasswordData = JSON.parse(JSON.stringify(this.formPassword));
            userPasswordData.userId = this.userId;
            let reqData = await doPost("/api/user/password/reset", userPasswordData);
            if (reqData.success) {
              this.$Message.success('处理成功!');
              this.$emit("onModelClose", {"Result": "关闭用户信息窗口"})
            } else {
              this.$Message.error(reqData.msg);
            }
          }
        } else {
          this.$Message.error('请输入有效性信息');
        }
      })
    },
    handleReset(currentTab) {
      let name = currentTab == 'tabCustom' ? 'formCustom' : 'formPassword';
      this.$refs[name].resetFields();
      if (name == 'formCustom') {
        this.getUserInfo();
      }
    },
    handleCancel() {
      this.$emit("onModelClose", {"Result": "关闭当前窗口"})
    },
    async getUserInfo() {
      try {
        this.userId = localStorage.getItem("userId")
        let resultData = await doGet("/api/user/info/" + this.userId, {});
        this.$refs['formCustom'].resetFields();
        if (resultData.success) {
          this.formCustom = resultData.result
        } else {
          this.$Message.error(resultData.msg);
        }
      } catch (err) {
        console.error("getUserInfo Error:", err)
      }
    }
  },
  watch: {
    // 每当 personalModel 改变时，这个函数就会执行
    personalModel(newObj, oldObj) {
      if (newObj) {
        this.getUserInfo();
      }
    }
  },
}
</script>

<style scoped>

.dialog-footer-divided {
  height: 0.1mm;
  display: block;
  margin: 0 -14px;
  background-color: #e8eaec;
  position: relative;
  top: 2px;
}

.dialog-footer {
  height: 40px;
  display: block;
  text-align: right;
  padding-top: 12px;
}
</style>
