<template>
  <div v-if="showFullScreenBtn" class="full-screen-btn-con">
    <Tooltip :content="this.isFullscreen ? '退出全屏' : '全屏'" placement="bottom">
      <Icon @click="handleChange" :type="this.isFullscreen ? 'md-contract' : 'md-expand'" :size="24"></Icon>
    </Tooltip>
  </div>
</template>

<script>
export default {
  name: 'Fullscreen',
  data() {
    return {
      isFullscreen: false
    }
  },
  computed: {
    showFullScreenBtn() {
      return screenfull.isEnabled;
    },
  },
  methods: {
    handleChange() {
      screenfull.toggle();
    }
  },
  mounted() {
    screenfull.onchange(() => {
      this.isFullscreen = !this.isFullscreen;
    })
  }
}
</script>

<style>
.full-screen-btn-con .ivu-tooltip-rel {
  height: 60px;
  line-height: 70px;
  margin-right: 10px;
}

.full-screen-btn-con .ivu-tooltip-rel i {
  cursor: pointer;
}

</style>
