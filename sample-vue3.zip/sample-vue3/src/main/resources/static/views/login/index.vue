<template>
  <div class="login-vue" :style="bGround">
    <div class="container">
      <p class="title">シナリオ管理システム</p>
      <Form ref="formInline" :model="formInline" :rules="ruleInline" inline>
        <div class="input-c">
          <FormItem prop="account">
            <Input prefix="ios-contact" v-model="formInline.account" placeholder="请输入用户名" clearable/>
          </FormItem>
        </div>
        <div class="input-c">
          <FormItem prop="password">
            <Input type="password" v-model="formInline.password" prefix="md-lock" placeholder="请输入密码" clearable
                   @keyup.enter.native="handleSubmit('formInline')"/>
          </FormItem>
        </div>
        <div class="demo-auto-login">
          <Space style="width: 200px">
          <Checkbox v-model="formInline.autoLogin">自动登录</Checkbox>
            <a @click="register" style="color: #47cb89">注册</a>
            |
            <a @click="forgetPassword">忘记密码</a>
          </Space>

        </div>
        <Button :loading="isShowLoading" class="submit" type="primary" @click="handleSubmit('formInline')">登陆</Button>
      </Form>
    </div>
  </div>
</template>

<script>
export default {
  name: 'login',
  data() {
    return {
      flag: false,
      formInline: {
        account: 'admin',
        password: 'admin',
        autoLogin: false,
      },
      ruleInline: {
        account: [
          {required: true, message: '请输入用户名', trigger: 'blur'}
        ],
        password: [
          {required: true, message: '请输入密码', trigger: 'blur'},
          {type: 'string', min: 5, message: '密码的长度不能少于5位', trigger: 'blur'}
        ]
      },
      isShowLoading: false,
      bGround: {},
    }
  },
  created() {
    this.bGround.backgroundImage = 'url(' + './images/login-background.png' + ')'
    this.bGround.backgroundSize = "cover";
  },
  watch: {
    $route: {
      handler(route) {
        this.redirect = route.query && route.query.redirect
      },
      immediate: true,
    },
  },
  methods: {
    register(){
      this.$Message.info('敬请期待！！！')
    },
    forgetPassword() {
      this.$Message.info('敬请期待！！！')
    },
    handleSubmit(name) {
      this.isShowLoading = true
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          let reqData = await doPost("/api/login", {
            "username": this.formInline.account,
            "password": this.formInline.password
          });
          if (reqData.success) {
            localStorage.setItem('userImg', './images/userAvatar01.png')
            localStorage.setItem('userId', reqData.result.userId)
            localStorage.setItem('roles', "superAdmin,manager")
            localStorage.setItem("userNick", reqData.result.userNick)
            localStorage.setItem('token', reqData.result.token)
            this.$router.push({path: this.redirect || '/'})
          } else {
            this.$Message.error('登录失败')
          }
          // 登陆成功 设置用户信息
          // if (this.formInline.account === 'admin' && this.formInline.password === 'admin') {
          //   localStorage.setItem('userImg', './images/userAvatar01.png')
          //   localStorage.setItem('userId', '1001')
          //   localStorage.setItem('roles', "superAdmin,manager")
          //   localStorage.setItem("userNick", '管理员')
          //   localStorage.setItem('token', 'token_1111111111111111111111111111')
          //   this.$router.push({path: this.redirect || '/'})
          // } else {
          //   if (this.account !== 'admin') {
          //     this.$Message.error('账号为admin')
          //   }
          //   if (this.formInline.password !== 'admin') {
          //     this.$Message.error('密码为admin')
          //   }
          // }
        } else {
          this.$Message.error('请确认用户名和密码的输入信息')
        }
        this.isShowLoading = false
      })
    },
  },
}
</script>

<style>
.login-vue {
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #fff;
}

.login-vue .container {
  background: rgba(255, 255, 255, .2);
  width: 300px;
  text-align: center;
  border-radius: 10px;
  padding: 30px;
}

.login-vue .ivu-input {
  background-color: transparent;
  color: #fff;
  outline: #fff;
  border-color: #fff;
}

.login-vue ::-webkit-input-placeholder { /* WebKit, Blink, Edge */
  color: rgba(255, 255, 255, .8);
}

.login-vue :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
  color: rgba(255, 255, 255, .8);
}

.login-vue ::-moz-placeholder { /* Mozilla Firefox 19+ */
  color: rgba(255, 255, 255, .8);
}

.login-vue :-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: rgba(255, 255, 255, .8);
}

.login-vue .title {
  font-size: 16px;
  color: #17233d;
  font-weight: bold;
  margin-bottom: 20px;
}

.login-vue .input-c {
  margin: 5px auto;
  width: 200px;
}

.login-vue .error {
  color: red;
  text-align: left;
  margin: 5px auto;
  font-size: 12px;
  padding-left: 30px;
  height: 20px;
}

.login-vue .submit {
  width: 200px;
}

.login-vue .ivu-icon {
  color: #eee;
}

.login-vue .ivu-icon-ios-close-circle {
  color: #777;
}

.demo-auto-login {
  padding: 20px;
  text-align: left;
}

.demo-auto-login a {
  float: right;
  color: #57a3f3;
}


</style>
