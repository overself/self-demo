<template>
  <Button type="primary" @click="goHome">戻る</Button>
  <Table border :columns="columns" :data="data"></Table>
</template>
<script>
import { resolveComponent } from 'vue'
export default {
  data () {
    return {
      columns: [
        {
          title: 'Name',
          key: 'name',
          render: (h, params) => {
            return h('div', [
              h('Icon', {
                props: {
                  type: 'person'
                }
              }),
              h('strong', params.row.name)
            ]);
          }
        },
        {
          title: 'Age',
          key: 'age'
        },
        {
          title: 'Address',
          key: 'address'
        },
        {
          title: 'Action',
          key: 'action',
          width: 180,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(resolveComponent('Button'), {
                props: {
                  type: 'primary',
                  size: 'small'
                },
                style: {
                  marginRight: '5px'
                },
                onClick: () => {
                  this.show(params.index)
                }
              }, {
                default() {
                  return 'View'
                }
              }),
              h(resolveComponent('Button'), {
                props: {
                  type: 'error',
                  size: 'small'
                },
                onClick: () => {
                  this.remove(params.index)
                }
              }, {
                default() {
                  return 'Delete'
                }
              })
            ]);
          }
        }
      ],
      data: [
        {
          name: 'John Brown',
          age: 18,
          address: 'New York No. 1 Lake Park'
        },
        {
          name: 'Jim Green',
          age: 24,
          address: 'London No. 1 Lake Park'
        },
        {
          name: 'Joe Black',
          age: 30,
          address: 'Sydney No. 1 Lake Park'
        },
        {
          name: 'Jon Snow',
          age: 26,
          address: 'Ottawa No. 2 Lake Park'
        }
      ]
    }
  },
  methods: {
    show (index) {
      this.$Modal.info({
        title: 'User Info',
        content: `Name：${this.data[index].name}<br>Age：${this.data[index].age}<br>Address：${this.data[index].address}`
      })
    },
    remove (index) {
      this.data.splice(index, 1);
    },
    goHome() {
      this.$router.push({path: `/`})
    },
  }
}
</script>
