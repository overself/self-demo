<template>
  <div id="root" style="height: 100%">
    <router-view></router-view>
  </div>
</template>

<script>
//const mapState = Vuex.mapState
export default {
  name: "layout",
  data() {
    return {}
  },
  created: function () {
    //console.log("mapState", mapState)
  },
}
</script>
<style>

/* loading */
.global-loading {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(255, 255, 255, .5);
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>