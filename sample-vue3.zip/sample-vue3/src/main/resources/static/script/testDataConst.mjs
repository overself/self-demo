export const pieData = [
    {value: 335, name: '直接访问'},
    {value: 310, name: '邮件营销'},
    {value: 234, name: '联盟广告'},
    {value: 135, name: '视频广告'},
    {value: 1548, name: '搜索引擎'}
];

export const barData = {
    Mon: 13253,
    Tue: 34235,
    Wed: 26321,
    Thu: 12340,
    Fri: 24643,
    Sat: 1322,
    Sun: 1324
};

export const designList = [
    {
        id: 1,
        name: '测试数据0000001',
        code: 'SN100001',
        creator: '10001',
        creatorName: '张三',
        createDate: '2022-11-11',
        labelCodes: ['L001', 'L002', 'L003'],
        labelNames: ['标签1', '标签2', '标签3']
    },
    {
        id: 2,
        name: '测试数据0000002',
        code: 'SN100002',
        creator: '10001',
        creatorName: '张三',
        createDate: '2022-11-11',
        labelCodes: ['L001', 'L003'],
        labelNames: ['标签1', '标签3']
    },
    {
        id: 3,
        name: '测试数据0000003',
        code: 'SN100003',
        creator: '10001',
        creatorName: '张三',
        createDate: '2022-11-12',
        labelCodes: ['L001', 'L002', 'L003'],
        labelNames: ['标签1', '标签2', '标签3']
    },
    {
        id: 4,
        name: '测试数据0000004',
        code: 'SN100004',
        creator: '10001',
        creatorName: '张三',
        createDate: '2022-11-13',
        labelCodes: ['L002', 'L003'],
        labelNames: ['标签2', '标签3']
    },
    {
        id: 5,
        name: '测试数据0000005',
        code: 'SN100005',
        creator: '10002',
        creatorName: '李四',
        createDate: '2022-11-13',
        labelCodes: ['L001', 'L002', 'L003'],
        labelNames: ['标签1', '标签2', '标签3']
    },
    {
        id: 6,
        name: '测试数据0000006',
        code: 'SN100006',
        creator: '10002',
        creatorName: '李四',
        createDate: '2022-11-13',
        labelCodes: ['L001', 'L002', 'L003'],
        labelNames: ['标签1', '标签2', '标签3']
    },
    {
        id: 7,
        name: '测试数据0000007',
        code: 'SN100007',
        creator: '10002',
        creatorName: '李四',
        createDate: '2022-11-13',
        labelCodes: ['L001', 'L002', 'L003'],
        labelNames: ['标签1', '标签2', '标签3']
    },
    {
        id: 8,
        name: '测试数据0000008',
        code: 'SN100008',
        creator: '10002',
        creatorName: '李四',
        createDate: '2022-11-13',
        labelCodes: ['L001', 'L002', 'L003'],
        labelNames: ['标签1', '标签2', '标签3']
    },
    {
        id: 9,
        name: '测试数据0000009',
        code: 'SN100009',
        creator: '10002',
        creatorName: '李四',
        createDate: '2022-11-13',
        labelCodes: ['L001', 'L002', 'L003'],
        labelNames: ['标签1', '标签2', '标签3']
    },
    {
        id: 10,
        name: '测试数据0000010',
        code: 'SN100010',
        creator: '10002',
        creatorName: '李四',
        createDate: '2022-11-13',
        labelCodes: ['L001', 'L002', 'L003'],
        labelNames: ['标签1', '标签2', '标签3']
    },
];

export const userStoreList = [
    {
        userId: '1001',
        name: 'wenjay1'
    },
    {
        userId: '1002',
        name: 'wenjay2'
    },
    {
        userId: '1003',
        name: 'wenjay3'
    },
    {
        userId: '1004',
        name: 'wenjay4'
    }
]
