// 请求头的设置
axios.defaults.headers.get['Content-Type'] = 'application/json; charset=UTF-8'
axios.defaults.headers.post['Content-Type'] = 'application/json; charset=UTF-8'

const myService = axios.create({
    // baseURL: window.location.origin,
    baseURL: '',
    timeout: 20 * 1000, // Timeout
    responseType: 'json' // 请求数据格式
})

myService.interceptors.request.use(
    (config) => {
        if (localStorage.getItem('token')) {
            config.headers["access-token"] = localStorage.getItem('token')
        }
        return config
    },
    (error) => Promise.reject(error)
)

myService.interceptors.response.use(
    (response) => {
        const res = response.data
        // 错误处理
        if (!res.success && res.msg) {
            // token 无效，清空路由，退出登录
            if (res.code == "401") {
                //resetTokenAndClearUser()
                localStorage.removeItem("token")
                localStorage.removeItem("userImg")
                localStorage.removeItem("userNick")
                localStorage.removeItem("username")
                vueRouter.push('/login')
            }
            //跳转到登录页面
            Message.error({content: res.msg})
            return Promise.reject(response)
        }
        // 如果接口正常，直接返回数据
        return Promise.resolve(response)
    },
    (error) => {
        if (error.response.status) {
            switch (error.response.status) {
                case 401:
                    localStorage.removeItem("token")
                    localStorage.removeItem("userImg")
                    localStorage.removeItem("userNick")
                    localStorage.removeItem("username")
                    vueRouter.push('/login')
                    Message.error({title: "错误", content: "访问受限，请登陆系统"});
                    break;
                case 403:
                    localStorage.removeItem("token")
                    localStorage.removeItem("userImg")
                    localStorage.removeItem("userNick")
                    localStorage.removeItem("username")
                    vueRouter.push('/login')
                    Message.error({title: "错误", content: "未认证，请先登录系统"});
                    break;
                case 404:
                    Message.error({title: "错误", content: "请求网络资源不存在"});
                    vueRouter.push('/404')
                    break;
                default:
                    Message.error({title: "错误", content: error.response.data.data || error.message});
                    break;
            }
        }
        return Promise.reject(error.response)
    }
)

function doPost(url, params) {
    return new Promise((resolve, reject) => {
        myService.post(url, params).then(
            (response) => {
                let result = response.data;
                if (result && !result.success) {
                    Message.error({title: "错误", content: error.response.data.data || error.message});
                } else {
                    resolve(response.data)
                }
            },
            (err) => {
                reject(err.data);
            })
    })
}

function doGet(url, params) {
    return new Promise((resolve, reject) => {
        myService.get(url, {params: params}).then(
            (response) => {
                resolve(response.data);
            },
            (err) => {
                reject(err);
            })
    })
}

