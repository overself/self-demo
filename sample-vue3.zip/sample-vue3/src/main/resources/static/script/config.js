// 导入View的组件
const Notice = ViewUIPlus.Notice
const Message = ViewUIPlus.Message

// 导入vue3-sfc-loader preprocessLang
const {loadModule, vueVersion} = window['vue3-sfc-loader'];

// 创建一个新的 store 实例
const store = new Vuex.Store({})

// 配置vue3-loader的参数
const options = {
    moduleCache: {
        vue: Vue,
        stylus: source => Object.assign(stylus(source), {deps: () => []}),
        'file!'(content, path, type, options) {

            return String(new URL(path, window.location));
        },
        'url!'(content, path, type, options) {
            if (type === '.svg')
                return `data:image/svg+xml;base64,${btoa(content)}`;
            throw new Error(`${type} not handled by url!`);
        },
    },
    getFile(url) {
        return fetch(url).then(res => {
            if (!res.ok) {
                throw Object.assign(new Error(url + ' ' + res.statusText), {res});
            }
            return res.text().then(content => {
                if (/.*?\.js$/.test(url)) {
                    console.log("content:", content)
                    return {content: content, type: ".mjs"}
                }
                return content;
            });
        })
    },
    addStyle(textContent) {
        document.head.insertBefore(
            Object.assign(document.createElement('style'), {textContent}),
            document.head.getElementsByTagName('style')[0] || null);
    },
    handleModule: async function (type, getContentData, path, options) {
        switch (type) {
            case '.css':
                options.addStyle(await getContentData(false));
                return null;
            case '.json':
                return JSON.parse(await getContentData(false));
            case '.svg':
                return await getContentData(false);
            default:
                return undefined;
        }
    },
    customBlockHandler(block, filename, options) {
        if (block.type !== 'i18n') {
            return
        }
        const messages = JSON.parse(block.content);
        for (let locale in messages) {
            i18n.global.mergeLocaleMessage(locale, messages[locale]);
        }
    }

};

const loadVue = (vuePath) => loadModule(vuePath, options);
const loadVueFile = (vuePath) => () => loadVue(vuePath);

// 路由配置
let routes = [
    /*首页*/
    {
        path: '/',
        name: 'home',
        component: loadVueFile('./views/components/layout/index.vue'),
        children: [
            {path: '', name: 'dashboard', component: loadVueFile('./views/home/dashboard.vue')},
            {path: 'design', name: 'design', component: loadVueFile('./views/design/list.vue')},
            {path: 'print', name: 'print', component: loadVueFile('./views/print/list.vue')},
            // ...其他子路由
            {
                path: 'markdown_page',
                name: 'markdown_page',
                component: loadVueFile('./views/components/common/markdown.vue'),
                meta: {
                    notCache: true,
                    beforeCloseName: 'before_close_normal'
                }
            },
            {
                path: '/design_edit', name: 'design_edit', component: loadVueFile('./views/design/edit.vue')
            },

        ],
    },
    {
        path: '/404', name: '404', meta: {title: '404'}, component: loadVueFile('./views/components/common/404.vue'),
    },
    {path: '/login', name: 'login', component: loadVueFile('./views/login/index.vue')},
]
const vueRouter = VueRouter.createRouter({history: VueRouter.createWebHashHistory(), routes: routes})

/**
 * 一、完整的导航解析流程：
 * 1、导航被触发。
 * 2、在失活的组件里调用 beforeRouteLeave 守卫。
 * 3、调用全局的 beforeEach 守卫。
 * 4、在重用的组件里调用 beforeRouteUpdate 守卫(2.2+)。
 * 5、在路由配置里调用 beforeEnter。
 * 6、解析异步路由组件。
 * 7、在被激活的组件里调用 beforeRouteEnter。
 * 8、调用全局的 beforeResolve 守卫(2.5+)。
 * 9、导航被确认。
 * 10、调用全局的 afterEach 钩子。
 * 11、触发 DOM 更新。
 * 12、调用 beforeRouteEnter 守卫中传给 next 的回调函数，创建好的组件实例会作为回调函数的参数传入。
 * 二、数据获取：
 * 1、导航完成之后获取：先完成导航，然后在接下来的组件生命周期钩子中获取数据。在数据获取期间显示“加载中”之类的指示。
 * 2、导航完成之前获取：导航完成前，在路由进入的守卫中获取数据，在数据获取成功后执行导航。
 */
vueRouter.beforeEach((to, from, next) => {
    ViewUIPlus.LoadingBar.start()
    const isAuthenticated = localStorage.getItem('token')
    if (to.name !== 'login' && !isAuthenticated) {
        next({name: 'login'});
    } else {
        next();
    }
})
vueRouter.afterEach((to, from, failure) => {
    if (!failure) {
        console.log("to.fullPath:", to.fullPath)
    }
    ViewUIPlus.LoadingBar.finish();
    window.scrollTo(0, 0);
})

//国际化支持
const messages = {
    en: {
        tos: 'Term of Service',
        term: 'I accept xxx {0}.'
    },
    ja: {
        tos: '利用規約',
        term: '私は xxx の{0}に同意します。'
    }
}

const i18n = VueI18n.createI18n({
    locale: 'ja',
    legacy: false,
    globalInjection: false,
    messages
})

