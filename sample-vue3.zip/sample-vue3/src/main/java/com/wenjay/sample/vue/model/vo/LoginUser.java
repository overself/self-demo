package com.wenjay.sample.vue.model.vo;

import lombok.Data;

@Data
public class LoginUser {

    private String userId;

    private String userNick;

    private String token;

}
