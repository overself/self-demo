package com.wenjay.sample.vue.user.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.wenjay.framework.core.common.constant.MessageCode;
import com.wenjay.framework.core.exception.BusinessException;
import com.wenjay.framework.core.util.BeanUtils;
import com.wenjay.sample.vue.model.dto.UserDto;
import com.wenjay.sample.vue.user.entity.SystemUser;
import org.springframework.context.annotation.Lazy;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl /*implements UserDetailsService*/ {

    @Resource
    @Lazy
    private PasswordEncoder passwordEncoder;

    /**
     * select 'wenjay1' userName, '111111' `password`, 'wenjay1@163.com' email, JSON_ARRAY('user','admin','vip') roles  from dual
     * UNION
     * select 'wenjay2' userName, '111111' `password`, 'wenjay2@163.com' email, JSON_ARRAY('user','admin') roles  from dual
     * UNION
     * select 'wenjay3' userName, '111111' `password`, 'wenjay3@163.com' email, JSON_ARRAY('user') roles  from dual
     */
    public static final List<SystemUser> loginUsers = Lists.newArrayList(
            SystemUser.builder().userId("1000").userName("admin").password("admin").email("admin@163.com").userNick("超级管理员").mobile("13591197001").roles(new String[]{"ADMIN", "USER"}).build(),
            SystemUser.builder().userId("1001").userName("wenjay1").password("111111").email("wenjay1@163.com").userNick("Nick1").mobile("13591197001").roles(new String[]{"ADMIN", "USER"}).build(),
            SystemUser.builder().userId("1002").userName("wenjay2").password("111111").email("wenjay2@163.com").userNick("Nick2").mobile("13591197002").roles(new String[]{"USER", "VIP"}).build(),
            SystemUser.builder().userId("1003").userName("wenjay3").password("111111").email("wenjay3@163.com").userNick("Nick2").mobile("13591197003").roles(new String[]{"VIP"}).build(),
            SystemUser.builder().userId("1004").userName("wenjay4").password("111111").email("wenjay4@163.com").userNick("Nick3").mobile("13591197004").roles(new String[]{"USER"}).build());

    public SystemUser checkUsername(String username, String password) {
        Optional<SystemUser> first = loginUsers.stream().filter(item ->
                item.getUserName().equals(username) && item.getPassword().equals(password)).findFirst();
        if (first.isEmpty()) {
            return null;
        } else {
            return first.get();
        }
    }

//    @Override
//    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//        Optional<SystemUser> first = loginUsers.stream().filter(item -> item.getUserName().equals(username)).findFirst();
//        if (first.isEmpty()) {
//            throw new UsernameNotFoundException("用户没有找到");
//        }
//        SystemUser loginUser = first.get();
//        return User.builder().username(loginUser.getUserName())
//                .password(passwordEncoder.encode(loginUser.getPassword()))
//                .roles(loginUser.getRoles())
//                .build();
//    }

    public boolean matchPassword(String requestPassword, String encodePassword) {
        return passwordEncoder.matches(requestPassword, encodePassword);
    }

    public SystemUser getUserById(String id) {
        if (StrUtil.isEmpty(id)) {
            throw new BusinessException(MessageCode.COMM_BASE_ERR0001);
        }
        Optional<SystemUser> first = loginUsers.stream().filter(u -> u.getUserId().equals(id)).findFirst();
        if (first.isEmpty()) {
            throw new BusinessException(MessageCode.COMM_BASE_ERR0001);
        }
        return first.get();
    }

    public List<SystemUser> getUserList(String userNick) {
        if (StrUtil.isBlank(userNick)) {
            return loginUsers;
        }
        List<SystemUser> users = loginUsers.stream().filter(item -> item.getUserNick().contains(userNick)).collect(Collectors.toList());
        if (CollUtil.isEmpty(users)) {
            return Lists.newArrayList();
        }
        return users;
    }

    public Boolean saveUser(UserDto userDto) {
        Optional<SystemUser> first = loginUsers.stream().filter(item -> item.getUserName().equals(userDto.getUserName())).findFirst();
        if (first.isPresent()) {
            throw new BusinessException(MessageCode.COMM_BASE_ERR0001);
        }
        //Optional<SystemUser> maxUser = loginUsers.stream().max((user1, user2) -> user1.getId().compareTo(user2.getId()));
        Optional<SystemUser> maxUser = loginUsers.stream().max(Comparator.comparing(SystemUser::getUserId));
        SystemUser user = BeanUtils.copyProperties(userDto, SystemUser.class);
        if (maxUser.isPresent()) {
            user.setUserId(String.valueOf(Integer.valueOf(maxUser.get().getUserId()) + 1));
        } else {
            user.setUserId(String.valueOf(1));
        }
        loginUsers.add(user);
        return true;
    }

}
