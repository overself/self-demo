package com.wenjay.sample.vue.model.dto;

import lombok.Data;

@Data
public class ResetPasswordDto {

    private String userId;

    private String oldPassword;

    private String password;

}
