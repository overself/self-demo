package com.wenjay.sample.vue.controller;

import cn.hutool.core.util.StrUtil;
import com.wenjay.framework.core.common.constant.MessageCode;
import com.wenjay.framework.core.exception.BusinessException;
import com.wenjay.framework.web.model.vo.Result;
import com.wenjay.sample.vue.filter.LoginUserUtils;
import com.wenjay.sample.vue.model.dto.LoginDto;
import com.wenjay.sample.vue.model.dto.ResetPasswordDto;
import com.wenjay.sample.vue.model.dto.UserDto;
import com.wenjay.sample.vue.model.vo.LoginUser;
import com.wenjay.sample.vue.user.entity.SystemUser;
import com.wenjay.sample.vue.user.service.UserServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@Slf4j
@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserServiceImpl service;

    @PostMapping("/login")
    public Result<LoginUser> login(@RequestBody LoginDto loginDto) {
        // 获取参数
        String username = loginDto.getUsername();
        String password = loginDto.getPassword();
        if (!StrUtil.isAllNotBlank(username, password)) {
            throw new BusinessException(MessageCode.COMM_SYS_FAIL, "用户名或者密码错误");
        }

        // 登陆判断
        SystemUser user = service.checkUsername(username, password);
        if (user == null) {
            throw new BusinessException(MessageCode.COMM_SYS_FAIL, "用户名或者密码错误");
        }
        // 生成token，把登陆信息存入redis，有效期30分钟
        String token = UUID.randomUUID().toString().replace("-", "");
        LoginUser loginUser = new LoginUser();
        loginUser.setToken(token);
        loginUser.setUserNick(user.getUserNick());
        loginUser.setUserId(user.getUserId());
        LoginUserUtils.singInUser(token, loginUser);
        return Result.ok(loginUser);
    }

    @GetMapping("/logout")
    public Result<Boolean> logout() {
        LoginUserUtils.singOutUser(LoginUserUtils.get().getToken());
        return Result.ok(true);
    }

    @GetMapping("/user/info/{id}")
    public Result<SystemUser> getUserInfo(@PathVariable("id") String userId) {
        return Result.ok(service.getUserById(userId));
    }

    @PostMapping("/user/query")
    public Result<List<SystemUser>> getUserList(@RequestBody UserDto con) {
        return Result.ok(service.getUserList(con.getUserNick()));
    }

    @PostMapping("/user/save")
    public Result<Boolean> saveUser(@RequestBody UserDto user) {
        return Result.ok(service.saveUser(user));
    }

    @PostMapping("/user/update")
    public Result<Boolean> updateUser(@RequestBody UserDto user) {
        log.info("updateUser：{}", user);
        return Result.ok();
    }

    @PostMapping("/user/password/reset")
    public Result<Boolean> resetPassword(@RequestBody ResetPasswordDto resetPassword) {
        log.info("resetPassword{}", resetPassword);
        return Result.ok(true);
    }

}
