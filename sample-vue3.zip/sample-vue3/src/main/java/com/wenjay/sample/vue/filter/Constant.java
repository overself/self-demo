package com.wenjay.sample.vue.filter;

public class Constant {

    public static final String TOKEN_HEADER_NAME = "access-token";

    public static final String REDIS_USER_PREFIX = "user:token:";
}
