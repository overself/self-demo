package com.wenjay.sample.vue.filter;

import com.wenjay.sample.vue.model.vo.LoginUser;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.map.HashedMap;

import java.util.Map;

@Slf4j
public class LoginUserUtils {

    /**
     * 暂时用内存记忆当前登录用户，模拟Redis
     */
    private static Map<String, MemoryLoginUser> onLineUser = new HashedMap();

    private static final ThreadLocal<LoginUser> LOGIN_USER = new ThreadLocal<>();

    private LoginUserUtils() {
    }

    public static LoginUser get() {
        return LOGIN_USER.get();
    }

    public static void put(LoginUser user) {
        LOGIN_USER.set(user);
    }

    public static void remove() {
        LOGIN_USER.remove();
    }

    public static LoginUser getSingInUser(String token) {
        MemoryLoginUser memoryLoginUser = onLineUser.get(token);
        if (memoryLoginUser != null && memoryLoginUser.isValidSession()) {
            return memoryLoginUser.getLoginUser();
        }
        return null;
    }

    public static MemoryLoginUser singOutUser(String token) {
        return onLineUser.remove(token);
    }

    public static MemoryLoginUser singInUser(String token, LoginUser user) {
        return onLineUser.put(token, new MemoryLoginUser(user, System.currentTimeMillis()));
    }

    public static MemoryLoginUser refreshSingInStatus(String token) {
        MemoryLoginUser memoryLoginUser = onLineUser.get(token);
        if (memoryLoginUser != null) {
            memoryLoginUser.setLoginTime(System.currentTimeMillis());
            return onLineUser.put(token, memoryLoginUser);
        } else {
            return null;
        }

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class MemoryLoginUser {
        public MemoryLoginUser(LoginUser loginUser, long loginTime) {
            this.loginUser = loginUser;
            this.loginTime = loginTime;
        }

        private LoginUser loginUser;
        private long loginTime;
        private long expire = 3l * 24l * 60l * 60l * 1000l;

        public boolean isValidSession() {
            long current = System.currentTimeMillis();
            log.info("System.currentTimeMillis:{},过期时间：{}", current, (loginTime + expire));
            if (current < loginTime + expire) {
                return true;
            } else {
                log.info("用户【{}】的会话已经过期", loginUser.getUserNick());
                onLineUser.remove(loginUser.getToken());
                return false;
            }
        }
    }
}
