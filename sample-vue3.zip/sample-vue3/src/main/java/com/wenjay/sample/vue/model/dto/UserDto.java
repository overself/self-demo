package com.wenjay.sample.vue.model.dto;

import lombok.Data;

@Data
public class UserDto {

    private String userId;

    private String userName;

    private String userNick;

    private String password;

    private String mobile;

    private String email;

    private String desc;
}
