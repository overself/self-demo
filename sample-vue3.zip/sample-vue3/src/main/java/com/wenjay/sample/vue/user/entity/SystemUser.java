package com.wenjay.sample.vue.user.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class SystemUser {

    public SystemUser(){
    }

    private String userId;

    private String userName;

    private String userNick;

    private String password;

    private String mobile;

    private String email;

    private String[] roles;
}
