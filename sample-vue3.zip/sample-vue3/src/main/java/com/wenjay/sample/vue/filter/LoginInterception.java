package com.wenjay.sample.vue.filter;

import cn.hutool.core.util.StrUtil;
import com.wenjay.framework.core.component.JsonHelper;
import com.wenjay.framework.web.model.vo.Result;
import com.wenjay.sample.vue.model.vo.LoginUser;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Component
public class LoginInterception implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 获取token
        String token = request.getHeader(Constant.TOKEN_HEADER_NAME);
        if (StrUtil.isBlank(token)) {
            returnNoLogin(response);
            return false;
        }
        // 从redis中拿token对应user

        LoginUser user = LoginUserUtils.getSingInUser(token);
        if (user == null) {
            returnNoLogin(response);
            return false;
        }
        // token续期
        LoginUserUtils.refreshSingInStatus(token);
        // 存放如ThreadLocal
        LoginUserUtils.put(user);
        return true;
    }

    /**
     * 返回未登录的错误信息
     *
     * @param response ServletResponse
     */
    private void returnNoLogin(HttpServletResponse response) throws IOException {
        ServletOutputStream outputStream = response.getOutputStream();
        // 设置返回401 和响应编码
        response.setStatus(401);
        response.setContentType("Application/json;charset=utf-8");
        // 构造返回响应体
        String resultString = JsonHelper.obj2json(Result.failed("401", "访问受限，请先登陆"));
        outputStream.write(resultString.getBytes(StandardCharsets.UTF_8));
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // 存放如ThreadLocal
        LoginUserUtils.remove();
    }
}
