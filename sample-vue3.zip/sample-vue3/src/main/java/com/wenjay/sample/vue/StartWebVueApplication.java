package com.wenjay.sample.vue;

import com.wenjay.framework.swagger.annotation.EnableWenjaySwagger2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;

@EnableWenjaySwagger2
@SpringBootApplication
public class StartWebVueApplication {
    public static void main(String[] args) {
        SpringApplication.run(StartWebVueApplication.class, args);
    }

}
