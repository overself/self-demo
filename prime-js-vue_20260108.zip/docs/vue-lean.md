# VUE

### VUE 生命周期图示
![vue-lifecycle-api.png](vue-lifecycle-api.png)

### setup
  setup()钩子是在组件中使用组合式 API 的入口，通常只在以下情况下使用：
  - 需要在非单文件组件中使用组合式 API 时。
  - 需要在基于选项式 API 的组件中集成基于组合式 API 的代码时。

### beforeCreate
  在实例初始化完成并且 props 被解析后立即调用。接着 props 会被定义成响应式属性，data() 和 computed 等选项也开始进行处理
