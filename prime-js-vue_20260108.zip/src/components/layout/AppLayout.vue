<script setup>
import { useLayout } from '@/components/layout/composables/layout';
import { computed, provide, ref, watch } from 'vue';
import AppFooter from './AppFooter.vue';
import AppSideBar from './AppSidebar.vue';
import AppTopBar from './AppTopbar.vue';

const { layoutConfig, layoutState, isSidebarActive, resetMenu } = useLayout();

const outsideClickListener = ref(null);

watch(isSidebarActive, (newVal) => {
    if (newVal) {
        bindOutsideClickListener();
    } else {
        unbindOutsideClickListener();
    }
});

const containerClass = computed(() => {
    return {
        'layout-overlay': layoutConfig.menuMode === 'overlay',
        'layout-static': layoutConfig.menuMode === 'static',
        'layout-drawer': layoutConfig.menuMode === 'drawer',
        'layout-static-inactive': layoutState.staticMenuDesktopInactive && layoutConfig.menuMode === 'static',
        'layout-overlay-active': layoutState.overlayMenuActive,
        'layout-drawer-active': layoutState.drawerMenuActive,
        'layout-mobile-active': layoutState.staticMenuMobileActive
    };
});

function bindOutsideClickListener() {
    if (!outsideClickListener.value) {
        outsideClickListener.value = (event) => {
            if (isOutsideClicked(event)) {
                resetMenu();
            }
        };
        document.addEventListener('click', outsideClickListener.value);
    }
}

function unbindOutsideClickListener() {
    if (outsideClickListener.value) {
        document.removeEventListener('click', outsideClickListener);
        outsideClickListener.value = null;
    }
}

function isOutsideClicked(event) {
    const sideBarEl = document.querySelector('.layout-sidebar');
    const topBarEl = document.querySelector('.layout-menu-button');
    return !(sideBarEl.isSameNode(event.target) || sideBarEl.contains(event.target) || (topBarEl != null && topBarEl.isSameNode(event.target)) || (topBarEl != null && topBarEl.contains(event.target)));
}

const layoutMainRouter = ref(true);
provide('layout-Main-Router', layoutMainRouter);
</script>

<template>
    <div class="layout-wrapper" :class="containerClass">
        <AppTopBar></AppTopBar>
        <AppSideBar></AppSideBar>
        <div class="layout-main-container">
            <div class="layout-main">
                <router-view v-if="layoutMainRouter"></router-view>
            </div>
            <app-footer></app-footer>
        </div>
        <div class="layout-mask animate-fadein"></div>
    </div>
    <Toast />
</template>
