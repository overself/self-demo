<script setup>
import { columnDefs, defaultColDef, rowClassRules, rowData, selection } from '@/views/demo/ag/DataGrid3';
import { onBeforeMount, ref, shallowRef } from 'vue';

const gridApi = shallowRef();
const paginationPageSize = ref(10);
const paginationPageSizeSelector = ref([10, 25, 50]);

onBeforeMount(() => {
    //console.log(rowData.value);
});

const onGridReady = (params) => {
    gridApi.value = params.api;
};

</script>

<template>
    <div class="card" style="height: 100%">
        <ag-grid-vue
            style="width: 100%; height: 25rem;"
            :class="$AgGrid.themeClass"
            :locale-text="$AgGrid.localeText"
            :rowClassRules="rowClassRules"
            :columnDefs="columnDefs"
            @grid-ready="onGridReady"
            :rowData="rowData"
            :defaultColDef="defaultColDef"
            :selection="selection"
            :pagination="true"
            :paginationPageSize="paginationPageSize"
            :paginationPageSizeSelector="paginationPageSizeSelector">
        </ag-grid-vue>
    </div>
</template>

<style module lang="scss">
.custom-button {
    background-color: #42b983;
    color: white;
    margin: 3px;
    padding: -4px 0px 0px 0px;
    border-radius: 4px;
    cursor: pointer;
    border: #38a16a solid 1px;
    height: 1.5rem;
    z-index: 999;
    font-family: "Arabic Typesetting";
}
.rag-red {
    background-color: #cc222244;
}

.rag-green {
    background-color: #33cc3344;
}
</style>
