import { defineComponent, ref } from 'vue';
import { useToast } from 'primevue/usetoast';
import Button from 'primevue/button';


const CustomButtonComponent = defineComponent(
    {
        name: 'CustomButtonComponent',
        components: { Button },
        template: `
            <div class="flex flex-wrap gap-2">
                <Button @click="showSuccess()" label="Success" style="margin:2px; height: 1.6rem" severity="success" />
                <Button @click="showInfo()" label="Info" style="margin:2px; height: 1.6rem" severity="info" text />
            </div>`,
        setup(props) {
            const toast = useToast();
            const cellValue = props.params.value;
            function showSuccess() {
                toast.add({ severity: 'success', summary: 'Success Message', detail: 'Message Detail：'+cellValue, life: 3000 });
            }

            function showInfo() {
                toast.add({ severity: 'info', summary: 'Info Message', detail: 'Message Detail：'+cellValue, life: 3000 });
            }

            return {
                showSuccess,
                showInfo
            };
        }
    });


export const selection = ref({
    mode: 'multiRow',
    headerCheckbox: false
});

export const defaultColDef = ref({
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    flex: 1
});

export const rowClassRules = ref({
    'rag-red': (params) => params.data.make === 'Ford'
});

export const ragCellClassRules = {
    // apply green to electric cars
    'rag-green': (params) => params.value === true
};
export const columnDefs = ref([
    {
        field: 'make',
        editable: true,
        cellEditor: 'agSelectCellEditor',
        cellEditorParams: {
            values: [
                'Tesla',
                'Ford',
                'Toyota',
                'Mercedes',
                'Fiat',
                'Nissan',
                'Vauxhall',
                'Volvo',
                'Jaguar'
            ]
        }
    },
    { field: 'model' },
    {
        field: 'price', filter: 'agNumberColumnFilter',
        valueFormatter: (p) => '£' + Math.floor(p.value).toLocaleString()
    },
    { field: 'electric', cellClassRules: ragCellClassRules },
    {
        field: 'month',
        comparator: (valueA, valueB) => {
            const months = [
                'January',
                'February',
                'March',
                'April',
                'May',
                'June',
                'July',
                'August',
                'September',
                'October',
                'November',
                'December'
            ];
            const idxA = months.indexOf(valueA);
            const idxB = months.indexOf(valueB);
            return idxA - idxB;
        }
    },
    {
        field: 'price',
        headerName: '操作',
        cellRenderer: CustomButtonComponent,
        floatingFilter: false,
        filter: false,
        sortable: false
    }
]);

export const rowData = ref([
    {
        make: 'Tesla',
        model: 'Model Y',
        price: 64950,
        electric: true,
        month: 'June'
    },
    {
        make: 'Ford',
        model: 'F-Series',
        price: 33850,
        electric: false,
        month: 'October'
    },
    {
        make: 'Toyota',
        model: 'Corolla',
        price: 29600,
        electric: false,
        month: 'August'
    },
    {
        make: 'Mercedes',
        model: 'EQA',
        price: 48890,
        electric: true,
        month: 'February'
    },
    {
        make: 'Fiat',
        model: '500',
        price: 15774,
        electric: false,
        month: 'January'
    },
    {
        make: 'Nissan',
        model: 'Juke',
        price: 20675,
        electric: false,
        month: 'March'
    },
    {
        make: 'Vauxhall',
        model: 'Corsa',
        price: 18460,
        electric: false,
        month: 'July'
    },
    {
        make: 'Volvo',
        model: 'EX30',
        price: 33795,
        electric: true,
        month: 'September'
    },
    {
        make: 'Mercedes',
        model: 'Maybach',
        price: 175720,
        electric: false,
        month: 'December'
    },
    {
        make: 'Vauxhall',
        model: 'Astra',
        price: 25795,
        electric: false,
        month: 'April'
    },
    {
        make: 'Fiat',
        model: 'Panda',
        price: 13724,
        electric: false,
        month: 'November'
    },
    {
        make: 'Jaguar',
        model: 'I-PACE',
        price: 69425,
        electric: true,
        month: 'May'
    },
    {
        make: 'Tesla',
        model: 'Model Y',
        price: 64950,
        electric: true,
        month: 'June'
    },
    {
        make: 'Ford',
        model: 'F-Series',
        price: 33850,
        electric: false,
        month: 'October'
    },
    {
        make: 'Toyota',
        model: 'Corolla',
        price: 29600,
        electric: false,
        month: 'August'
    },
    {
        make: 'Mercedes',
        model: 'EQA',
        price: 48890,
        electric: true,
        month: 'February'
    },
    {
        make: 'Fiat',
        model: '500',
        price: 15774,
        electric: false,
        month: 'January'
    },
    {
        make: 'Nissan',
        model: 'Juke',
        price: 20675,
        electric: false,
        month: 'March'
    },
    {
        make: 'Vauxhall',
        model: 'Corsa',
        price: 18460,
        electric: false,
        month: 'July'
    },
    {
        make: 'Volvo',
        model: 'EX30',
        price: 33795,
        electric: true,
        month: 'September'
    },
    {
        make: 'Mercedes',
        model: 'Maybach',
        price: 175720,
        electric: false,
        month: 'December'
    },
    {
        make: 'Vauxhall',
        model: 'Astra',
        price: 25795,
        electric: false,
        month: 'April'
    },
    {
        make: 'Fiat',
        model: 'Panda',
        price: 13724,
        electric: false,
        month: 'November'
    },
    {
        make: 'Jaguar',
        model: 'I-PACE',
        price: 69425,
        electric: true,
        month: 'May'
    },
    {
        make: 'Tesla',
        model: 'Model Y',
        price: 64950,
        electric: true,
        month: 'June'
    },
    {
        make: 'Ford',
        model: 'F-Series',
        price: 33850,
        electric: false,
        month: 'October'
    },
    {
        make: 'Toyota',
        model: 'Corolla',
        price: 29600,
        electric: false,
        month: 'August'
    },
    {
        make: 'Mercedes',
        model: 'EQA',
        price: 48890,
        electric: true,
        month: 'February'
    },
    {
        make: 'Fiat',
        model: '500',
        price: 15774,
        electric: false,
        month: 'January'
    },
    {
        make: 'Nissan',
        model: 'Juke',
        price: 20675,
        electric: false,
        month: 'March'
    },
    {
        make: 'Vauxhall',
        model: 'Corsa',
        price: 18460,
        electric: false,
        month: 'July'
    },
    {
        make: 'Volvo',
        model: 'EX30',
        price: 33795,
        electric: true,
        month: 'September'
    },
    {
        make: 'Mercedes',
        model: 'Maybach',
        price: 175720,
        electric: false,
        month: 'December'
    },
    {
        make: 'Vauxhall',
        model: 'Astra',
        price: 25795,
        electric: false,
        month: 'April'
    },
    {
        make: 'Fiat',
        model: 'Panda',
        price: 13724,
        electric: false,
        month: 'November'
    },
    {
        make: 'Jaguar',
        model: 'I-PACE',
        price: 69425,
        electric: true,
        month: 'May'
    }
]);
