///////////////////////////////////////////
///
///////////////////////////////////////////
interface Student extends Person {
    code: string;
    address?: Address;
    description?: string;
}

interface Address {
    postCode: String;
    description: String;
}

interface Person {
    firstName: string;
    lastName: string;
    age: number;
    dateOfBirth: any;
    fullName(): string;
}

