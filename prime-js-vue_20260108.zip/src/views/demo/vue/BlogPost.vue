<script setup>
import { ref, watch } from 'vue';

//defineProps(['id', 'title']);
let { foo = 'hello' } = defineProps({ id: String, title: String, foo: String });
defineEmits(['enlarge-text']);
watch(() => {
    return foo;
}, () => {
    console.log(foo);
});
const context = ref('1234');
</script>
<template>
    <div style="margin-bottom: 1rem; width: 25rem">
        <div>{{ id }}：{{ title }}
            <InputText v-model="context" style="height: 1.5rem; width: 5rem" />
            <Button label="Test" type="Info" style="height: 1.5rem; margin-left: 1rem" @click="()=>{foo=foo+'111'; $emit('enlarge-text')}"></Button>
        </div>
    </div>
</template>
<style scoped lang="scss">
</style>
