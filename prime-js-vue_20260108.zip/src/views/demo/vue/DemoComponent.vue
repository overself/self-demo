<script setup>
import { defineComponent, ref } from 'vue';

const Home = defineComponent({
    name: 'home',
    template: `
        <div class="tab">
            Home component
        </div>`,
    setup(props) {
        return {};
    }
});
const Posts = defineComponent({
    name: 'Posts',
    template: `
  <div class="tab">
    Posts component
  </div>`
});
const Archive = defineComponent({
    name: 'Archive',
    template: `
  <div class="tab">
    Posts component
  </div>`
});
const tabs = { Home, Posts, Archive };
const currentTab = ref('Home');
</script>

<template>
    <div class="demo">
        <button v-for="(_, tab) in tabs" :key="tab"
                :class="['tab-button', { active: currentTab === tab }]"
                @click="currentTab = tab">
            {{ tab }}
        </button>
        <component :is="tabs[currentTab]" class="tab"></component>
    </div>
</template>

<style>
.demo {
    font-family: sans-serif;
    border: 1px solid #eee;
    border-radius: 2px;
    padding: 4px 5px;
    margin-top: 1em;
    margin-bottom: 0px;
    user-select: none;
    overflow-x: auto;
}

.tab-button {
    padding: 6px 10px;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    border: 1px solid #ccc;
    cursor: pointer;
    background: #f0f0f0;
    margin-bottom: -1px;
    margin-right: -1px;
}

.tab-button:hover {
    background: #e0e0e0;
}

.tab-button.active {
    background: #e0e0e0;
}

.tab {
    border: 1px solid #ccc;
    padding: 10px;
}
</style>
