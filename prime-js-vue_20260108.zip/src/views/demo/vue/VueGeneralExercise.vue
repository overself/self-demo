<script setup>
import { defineComponent, onWatcherCleanup, reactive, ref, useTemplateRef, watch } from 'vue';
import BlogPost from '@/views/demo/vue/BlogPost.vue';
import AlertBox from '@/views/demo/vue/AlertBox.vue';
import DemoComponent from '@/views/demo/vue/DemoComponent.vue';
///////////   组件   ///////////////
///////////   primeVue   /////////
import Button from 'primevue/button';

///////////   侦听器   ///////////////
const question = ref('');
const answer = ref('Questions usually contain a question mark. ?');
const loading = ref(false);
// 可以直接侦听一个 ref
watch(question, async (newQuestion, oldQuestion) => {
    if (newQuestion.includes('?')) {
        loading.value = true;
        answer.value = 'Thinking...';
        try {
            const res = await fetch('https://yesno.wtf/api');
            answer.value = (await res.json()).answer;
        } catch (error) {
            answer.value = 'Error! Could not reach the API. ' + error;
        } finally {
            loading.value = false;
        }
    }
});
const objCount = reactive({ count: 0 });
const objAnswer = ref('Object Count Display');
watch(/*() => objCount.count*/objCount, (newValue, oldValue) => {
//watchEffect(/*() => objCount.count*/(newValue, oldValue) => {
    const controller = new AbortController();
    // 在嵌套的属性变更时触发
    // 注意：`newValue` 此处和 `oldValue` 是相等的
    //console.log(newValue, oldValue);
    setTimeout(() => objAnswer.value = objAnswer.value + '、' + objCount.count, 500);
    onWatcherCleanup(() => {
        // 终止过期请求
        controller.abort();
    });
}, { immediate: true, once: false, flush: 'post' });
///////////   侦听器   ///////////////
///////////   模板引用   ///////////////
const inputRefObj = useTemplateRef('my-input');
const inputObj = ref('模板测试');
watch(inputRefObj, () => {
    if (inputRefObj.value) {
        inputRefObj.value.focus();
        inputRefObj.value.style = 'border: blueviolet solid 2px; height: 20px';
    } else {
        console.log('inputObj还未挂载！');
    }
}, { once: false });

const list = ref([1, 2, 3, 4]);
const itemRefs = useTemplateRef('items');

function refClick() {
    let value = list.value.pop();
    list.value.push(value + 1);
    if (itemRefs.value) {
        itemRefs.value[0].style = 'border: yellow solid 2px; height: 32px; padding:4px';
        itemRefs.value[0].innerText = itemRefs.value[0].innerText + ', ' + list.value[list.value.length - 1];
    }

}

///////////   模板引用   ///////////////
///////////   组件   ///////////////
const postFontSize1 = ref(0.5);
const postFontSize2 = ref(1.5);

function fontChange(param, sizeValue) {
    if (param === 1) {
        postFontSize1.value = postFontSize1.value + sizeValue;
    } else {
        postFontSize2.value = postFontSize2.value + sizeValue;
    }
}

const CustomButton = defineComponent({
    name: 'custom-button',
    components: { 'pv-button': Button },
    setup() {
        const buttonClicked = () => {
            alert('按钮被点击了!');
        };
        return {
            buttonClicked
        };
    },
    template: `
        <div class="card flex flex-col gap-4">
            <div class="font-semibold text-xl">Default</div>
            <div class="flex flex-wrap gap-2">
                <pv-button label="Primary" @click="buttonClicked">点击按钮</pv-button>
                <pv-button severity="success" label="Disabled" @click="buttonClicked" :disabled="true">点击也没用</pv-button>
                <pv-button class="p-button-link" @click="buttonClicked">可点击链接</pv-button>
            </div>
        </div>`
});
///////////   primeVue   /////////
</script>

<template>
    <div style="height: 100%">
        <div class="card font-semibold text-xl " style="padding: 1rem">
           Vue 基础知识
        </div>
        <div class="flex flex-col md:flex-row gap-8 mt-6">
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                    <div class="font-semibold text-xl mb-4">侦听器</div>
                    <div class="card" style="padding: 0rem">
                        <p>可以使用 watch 函数在每次响应式状态发生变化时触发回调函数</p>
                        <p>
                            基本示例：
                            <InputText v-model="question" :disabled="loading" />
                        </p>
                        <p>{{ answer }}</p>
                    </div>
                    <div class="card" style="padding: 1rem 0 0 0;">
                        <p>
                            深层侦听器：
                            <InputText type="number" @change="objCount.count++" />
                        </p>
                        <p>{{ objAnswer }}</p>
                    </div>
                </div>
            </div>
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                    <div class="font-semibold text-xl mb-4">ref 模板引用：</div>
                    <div class="card" style="padding: 0rem; ">
                        <input :value="inputObj" ref="my-input" type="text" />{{ inputRefObj ? inputRefObj.value : '' }}
                    </div>
                    <div class="font-semibold text-xl mb-4">
                        v-for 中的ref模板引用：
                        <Button label="RefClick" severity="help" text @click="refClick" />
                    </div>
                    <div class="card" style="padding: 0rem">
                        <ul>
                            <li v-for="item in list" ref="items">
                                {{ item }}
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                    <div class="font-semibold text-xl mb-4">Overlay Menu</div>
                </div>
                <div class="card" style="padding: 1rem">
                    <div class="font-semibold text-xl mb-4">Context Menu</div>
                </div>
            </div>
        </div>
        <div class="flex flex-col md:flex-row gap-8 mt-6">
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                    <div class="font-semibold text-xl mb-4">组件基础:defineProps & defineEmits</div>
                    <div class="card" style="padding: 0rem">
                        <div :style="{ fontSize: postFontSize1 + 'em' }">
                            <blog-post @enlarge-text="fontChange(1, 0.1)" :id="'10001'" :title="'组件100001'"></blog-post>
                        </div>
                        <div :style="{ fontSize: postFontSize2 + 'em' }">
                            <blog-post @enlarge-text="fontChange(2, -0.1)" id="10002" title="组件100002"></blog-post>
                        </div>
                    </div>
                </div>
            </div>
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                    <div class="font-semibold text-xl mb-4">组件插槽：slot</div>
                    <div class="card" style="padding: 0rem">
                        <AlertBox>这是我得测试</AlertBox>
                    </div>
                </div>
            </div>
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                    <div class="font-semibold text-xl mb-4">动态组件：component & is</div>
                    <div class="card" style="padding: 0rem">
                        <KeepAlive>
                            <DemoComponent></DemoComponent>
                        </KeepAlive>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex flex-col md:flex-row gap-8 mt-6">
            <!-- 使用自定义的子组件 -->
            <div>
                <CustomButton />
            </div>
            <div class="card flex flex-col gap-4">
                <div class="font-semibold text-xl">Severities</div>
                <div class="flex flex-wrap gap-2">
                    <Button label="Primary" />
                    <Button label="Secondary" severity="secondary" />
                    <Button label="Success" severity="success" />
                    <Button label="Info" severity="info" />
                    <Button label="Warn" severity="warn" />
                    <Button label="Help" severity="help" />
                    <Button label="Danger" severity="danger" />
                    <Button label="Contrast" severity="contrast" />
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped lang="scss">

</style>
