<script setup lang="ts">

//import {Student} from './ts/InterfaceDefined'
//Props练习
class Student {
    code: string;
    address?: String;
    description?: string;
    firstName: string;
    lastName: string;
    age: number;
    dateOfBirth: any;

    fullName(): string;
}

import { defineComponent } from 'vue';

const StudentComp = defineComponent({
    name: 'StudentComp',
    template: `
        <div>ddddd</div>`,
    props: { student: Student },
    //emits: ['update:student'],
    setup(props) {
        return {};
    }
});
</script>

<template>
    <div style="height: 100%">
        <div class="card font-semibold text-xl " style="padding: 0.5rem 1rem"> Vue3 专项练习</div>
        <div class="flex flex-col md:flex-row gap-7 mt-5">
            <div class="md:w-1/3">
                <div class="card" style="padding: 0.5rem">
                    <div class="font-semibold text-xl"> Props练习</div>
                    <div class="font-semibold text-xm">
                        参数：
                        <InputText class="ShortInput" />
                        <InputText class="ShortInput" />
                        <InputText class="ShortInput" />
                        <InputText class="ShortInput" />
                    </div>
                    <div class="font-semibold text-xm">组件：</div>
                    <StudentComp></StudentComp>
                </div>
            </div>
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                </div>
            </div>
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                </div>
            </div>
        </div>
        <div class="flex flex-col md:flex-row gap-8 mt-5">
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                </div>
            </div>
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                </div>
            </div>
            <div class="md:w-1/3">
                <div class="card" style="padding: 1rem">
                </div>
            </div>
        </div>
    </div>
</template>

<style lang="scss">

.ShortInput {
    height: 25px;
    width: 80px;
    margin-right: 0.5rem
}
</style>
